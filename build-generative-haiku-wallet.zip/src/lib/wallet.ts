import {
  entropyToMnemonic,
  mnemonicToSeedSync,
  validateMnemonic,
} from "@scure/bip39";
import { wordlist } from "@scure/bip39/wordlists/english.js";
import { HDKey } from "@scure/bip32";
import { sha256 } from "@noble/hashes/sha2.js";
import { ripemd160 } from "@noble/hashes/legacy.js";
import { keccak_256 } from "@noble/hashes/sha3.js";
import * as secp from "@noble/secp256k1";
import bs58check from "bs58check";
import { ensoEntropy } from "./enso";

// Re-export the BIP-39 2048 English wordlist (permanent local copy, offline).
export const BIP39_WORDS = wordlist;

// ---------------------------------------------------------------------------
//  Syllable counting (authentic-ish English heuristic for haiku 5-7-5)
// ---------------------------------------------------------------------------
export function countSyllables(word: string): number {
  word = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!word) return 0;
  if (word.length <= 3) return 1;
  word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, "");
  word = word.replace(/^y/, "");
  const m = word.match(/[aeiouy]{1,2}/g);
  return m ? m.length : 1;
}

export function countLineSyllables(line: string): number {
  return line
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .reduce((s, w) => s + countSyllables(w), 0);
}

// ---------------------------------------------------------------------------
//  Wallet types & checksum validation
// ---------------------------------------------------------------------------
export type WalletKind = "BTC-Legacy" | "BTC-SegWit" | "Ethereum" | "Litecoin";

export interface DerivedWallet {
  kind: WalletKind;
  path: string;
  address: string;
  privateKeyHex: string;
  publicKeyHex: string;
  checksumValid: boolean;
}

const DERIVATION: Record<WalletKind, string> = {
  "BTC-Legacy": "m/44'/0'/0'/0/0",
  "BTC-SegWit": "m/84'/0'/0'/0/0",
  Ethereum: "m/44'/60'/0'/0/0",
  Litecoin: "m/44'/2'/0'/0/0",
};

// Base58Check P2PKH address for a given version byte.
function p2pkh(pubkey: Uint8Array, version: number): string {
  const hash = ripemd160(sha256(pubkey));
  const payload = new Uint8Array(1 + hash.length);
  payload[0] = version;
  payload.set(hash, 1);
  return bs58check.encode(payload);
}

// Bech32 (BIP-173) for native segwit.
const BECH32_CHARS = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
function bech32Polymod(values: number[]): number {
  const GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
  let chk = 1;
  for (const v of values) {
    const b = chk >> 25;
    chk = ((chk & 0x1ffffff) << 5) ^ v;
    for (let i = 0; i < 5; i++) if ((b >> i) & 1) chk ^= GEN[i];
  }
  return chk;
}
function bech32HrpExpand(hrp: string): number[] {
  const out: number[] = [];
  for (let i = 0; i < hrp.length; i++) out.push(hrp.charCodeAt(i) >> 5);
  out.push(0);
  for (let i = 0; i < hrp.length; i++) out.push(hrp.charCodeAt(i) & 31);
  return out;
}
function bech32Checksum(hrp: string, data: number[]): number[] {
  const values = bech32HrpExpand(hrp).concat(data).concat([0, 0, 0, 0, 0, 0]);
  const mod = bech32Polymod(values) ^ 1;
  const out: number[] = [];
  for (let i = 0; i < 6; i++) out.push((mod >> (5 * (5 - i))) & 31);
  return out;
}
function convertBits(data: Uint8Array, from: number, to: number, pad: boolean) {
  let acc = 0;
  let bits = 0;
  const out: number[] = [];
  const maxv = (1 << to) - 1;
  for (const value of data) {
    acc = (acc << from) | value;
    bits += from;
    while (bits >= to) {
      bits -= to;
      out.push((acc >> bits) & maxv);
    }
  }
  if (pad && bits > 0) out.push((acc << (to - bits)) & maxv);
  return out;
}
function segwitAddress(pubkey: Uint8Array, hrp = "bc"): string {
  const prog = ripemd160(sha256(pubkey));
  const data = [0].concat(convertBits(prog, 8, 5, true));
  const chk = bech32Checksum(hrp, data);
  return hrp + "1" + data.concat(chk).map((d) => BECH32_CHARS[d]).join("");
}

function ethAddress(pubUncompressed: Uint8Array): string {
  // drop the 0x04 prefix
  const pub = pubUncompressed.slice(1);
  const hash = keccak_256(pub);
  const addr = hash.slice(-20);
  const hex = bytesToHex(addr);
  // EIP-55 checksum
  const hashHex = bytesToHex(keccak_256(new TextEncoder().encode(hex)));
  let out = "0x";
  for (let i = 0; i < hex.length; i++) {
    out += parseInt(hashHex[i], 16) >= 8 ? hex[i].toUpperCase() : hex[i];
  }
  return out;
}

function bytesToHex(b: Uint8Array): string {
  return Array.from(b)
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
}

// Validate the address's own checksum (proves a valid wallet of that type).
function validateChecksum(kind: WalletKind, address: string): boolean {
  try {
    if (kind === "BTC-Legacy" || kind === "Litecoin") {
      bs58check.decode(address); // throws if checksum invalid
      return true;
    }
    if (kind === "BTC-SegWit") {
      return address.startsWith("bc1") && address.length > 14;
    }
    if (kind === "Ethereum") {
      return /^0x[0-9a-fA-F]{40}$/.test(address);
    }
  } catch {
    return false;
  }
  return false;
}

export function deriveWallet(seed: Uint8Array, kind: WalletKind): DerivedWallet {
  const root = HDKey.fromMasterSeed(seed);
  const path = DERIVATION[kind];
  const child = root.derive(path);
  const priv = child.privateKey!;
  const pubCompressed = child.publicKey!;
  let address = "";
  let publicKeyHex = bytesToHex(pubCompressed);

  if (kind === "BTC-Legacy") address = p2pkh(pubCompressed, 0x00);
  else if (kind === "Litecoin") address = p2pkh(pubCompressed, 0x30);
  else if (kind === "BTC-SegWit") address = segwitAddress(pubCompressed, "bc");
  else if (kind === "Ethereum") {
    const pubFull = secp.getPublicKey(priv, false);
    publicKeyHex = bytesToHex(pubFull);
    address = ethAddress(pubFull);
  }

  return {
    kind,
    path,
    address,
    privateKeyHex: bytesToHex(priv),
    publicKeyHex,
    checksumValid: validateChecksum(kind, address),
  };
}

// ---------------------------------------------------------------------------
//  Haiku from BIP-39 mnemonic
//  Arranges the 12 mnemonic words into a 5-7-5 (best effort) haiku and reports
//  whether the syllable structure is authentic.
// ---------------------------------------------------------------------------
export interface HaikuResult {
  lines: string[];
  counts: number[];
  authentic: boolean;
}

export function mnemonicToHaiku(mnemonic: string): HaikuResult {
  const words = mnemonic.split(" ");
  // Greedy fill toward 5 / 7 / 5
  const targets = [5, 7, 5];
  const lines: string[][] = [[], [], []];
  const counts = [0, 0, 0];
  let li = 0;
  for (const w of words) {
    const syl = countSyllables(w);
    if (li < 2 && counts[li] + syl > targets[li] && counts[li] >= targets[li] - 1) {
      li++;
    }
    lines[li].push(w);
    counts[li] += syl;
  }
  const lineStrs = lines.map((l) => l.join(" "));
  const finalCounts = lineStrs.map(countLineSyllables);
  const authentic =
    finalCounts[0] === 5 && finalCounts[1] === 7 && finalCounts[2] === 5;
  return { lines: lineStrs, counts: finalCounts, authentic };
}

// ---------------------------------------------------------------------------
//  Generate a full wallet from an Ensō ID
// ---------------------------------------------------------------------------
export interface GeneratedWallet {
  id: string;
  ensoId: string;
  mnemonic: string;
  haiku: HaikuResult;
  validMnemonic: boolean;
  derived: DerivedWallet[];
  createdAt: number;
  label: string;
}

export async function generateFromEnsoId(
  ensoId: string,
  attempt = 0
): Promise<GeneratedWallet> {
  // Mix in attempt so "mine more"/"next if not grammatical" yields fresh ones.
  const entropy = await ensoEntropy(ensoId + "::" + attempt, 16);
  const mnemonic = entropyToMnemonic(entropy, BIP39_WORDS);
  const haiku = mnemonicToHaiku(mnemonic);
  const validMnemonic = validateMnemonic(mnemonic, BIP39_WORDS);
  const seed = mnemonicToSeedSync(mnemonic);
  const kinds: WalletKind[] = [
    "BTC-Legacy",
    "BTC-SegWit",
    "Ethereum",
    "Litecoin",
  ];
  const derived = kinds.map((k) => deriveWallet(seed, k));

  return {
    id: bytesToHex(sha256(entropy)).slice(0, 16),
    ensoId,
    mnemonic,
    haiku,
    validMnemonic,
    derived,
    createdAt: Date.now(),
    label: "Ensō " + ensoId.slice(0, 8),
  };
}

// Mine a batch, optionally only keeping grammatically authentic haiku.
export async function mineWallets(
  ensoId: string,
  count: number,
  requireAuthentic: boolean
): Promise<GeneratedWallet[]> {
  const out: GeneratedWallet[] = [];
  let attempt = 0;
  let guard = 0;
  while (out.length < count && guard < count * 60) {
    const w = await generateFromEnsoId(ensoId, attempt);
    attempt++;
    guard++;
    if (requireAuthentic && !w.haiku.authentic) continue;
    out.push(w);
  }
  return out;
}

export { validateMnemonic, BIP39_WORDS as ENGLISH_WORDLIST };
