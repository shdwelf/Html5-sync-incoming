import CryptoJS from "crypto-js";
import { GeneratedWallet, BIP39_WORDS } from "./wallet";

const COOKIE_KEY = "enso_vault";
const LS_KEY = "enso_vault_store";

// AES-256 encrypt/decrypt a JSON-serialisable value with a passphrase.
export function encryptData(data: unknown, passphrase: string): string {
  const json = JSON.stringify(data);
  return CryptoJS.AES.encrypt(json, passphrase).toString();
}

export function decryptData<T>(cipher: string, passphrase: string): T | null {
  try {
    const bytes = CryptoJS.AES.decrypt(cipher, passphrase);
    const txt = bytes.toString(CryptoJS.enc.Utf8);
    if (!txt) return null;
    return JSON.parse(txt) as T;
  } catch {
    return null;
  }
}

// ---- Cookie helpers (store ENCRYPTED only) --------------------------------
function setCookie(name: string, value: string, days = 365) {
  const exp = new Date(Date.now() + days * 864e5).toUTCString();
  // chunk to stay under 4KB cookie limit
  const chunks = value.match(/.{1,3500}/g) ?? [];
  // clear previous chunks
  for (let i = 0; i < 20; i++) {
    document.cookie = `${name}_${i}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
  }
  chunks.forEach((c, i) => {
    document.cookie = `${name}_${i}=${encodeURIComponent(c)}; expires=${exp}; path=/; SameSite=Strict`;
  });
  document.cookie = `${name}_n=${chunks.length}; expires=${exp}; path=/; SameSite=Strict`;
}

function getCookie(name: string): string | null {
  const all = document.cookie.split("; ").reduce((acc, kv) => {
    const [k, v] = kv.split("=");
    acc[k] = v;
    return acc;
  }, {} as Record<string, string>);
  const n = parseInt(all[`${name}_n`] ?? "0", 10);
  if (!n) return null;
  let out = "";
  for (let i = 0; i < n; i++) {
    if (all[`${name}_${i}`] == null) return null;
    out += decodeURIComponent(all[`${name}_${i}`]);
  }
  return out;
}

// ---- Vault save/load (encrypted both in cookie and localStorage) -----------
export function saveVault(wallets: GeneratedWallet[], passphrase: string) {
  const cipher = encryptData(wallets, passphrase);
  try {
    localStorage.setItem(LS_KEY, cipher);
  } catch {
    /* ignore */
  }
  setCookie(COOKIE_KEY, cipher);
}

export function loadVault(passphrase: string): GeneratedWallet[] {
  const cipher = localStorage.getItem(LS_KEY) ?? getCookie(COOKIE_KEY);
  if (!cipher) return [];
  const data = decryptData<GeneratedWallet[]>(cipher, passphrase);
  return data ?? [];
}

export function hasVault(): boolean {
  return !!(localStorage.getItem(LS_KEY) ?? getCookie(COOKIE_KEY));
}

export function clearVault() {
  localStorage.removeItem(LS_KEY);
  setCookie(COOKIE_KEY, "", -1);
}

// ---- Export encrypted .txt -------------------------------------------------
export function exportEncryptedTxt(
  wallets: GeneratedWallet[],
  passphrase: string
) {
  const cipher = encryptData(wallets, passphrase);
  const header =
    "ENSO HAIKU WALLET VAULT (AES-256 encrypted)\n" +
    "Decrypt with your Ensō ID / passphrase.\n" +
    "----------------------------------------\n";
  const blob = new Blob([header + cipher], { type: "text/plain" });
  triggerDownload(blob, `enso-vault-${Date.now()}.txt`);
}

export function exportPlainTxt(wallets: GeneratedWallet[]) {
  let out = "ENSO HAIKU WALLET EXPORT\n========================\n\n";
  for (const w of wallets) {
    out += `Label: ${w.label}\nEnsō ID: ${w.ensoId}\nWallet ID: ${w.id}\n`;
    out += `Haiku:\n  ${w.haiku.lines.join("\n  ")}\n`;
    out += `Syllables: ${w.haiku.counts.join("-")} (${
      w.haiku.authentic ? "authentic 5-7-5" : "non-standard"
    })\n`;
    out += `Mnemonic (BIP-39): ${w.mnemonic}\n`;
    out += `Valid BIP-39: ${w.validMnemonic}\n`;
    for (const d of w.derived) {
      out += `  ${d.kind} [${d.path}]: ${d.address} (checksum ${
        d.checksumValid ? "OK" : "BAD"
      })\n`;
    }
    out += "\n";
  }
  const blob = new Blob([out], { type: "text/plain" });
  triggerDownload(blob, `enso-wallets-${Date.now()}.txt`);
}

function triggerDownload(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ---- Spell check ----------------------------------------------------------
// All mnemonic words must be valid BIP-39 words (the "dictionary"). Also flag
// whether the haiku reads in grammatical 5-7-5 form.
const WORDSET = new Set(BIP39_WORDS);

export function spellCheck(mnemonic: string): {
  ok: boolean;
  badWords: string[];
} {
  const bad = mnemonic.split(" ").filter((w) => !WORDSET.has(w));
  return { ok: bad.length === 0, badWords: bad };
}
