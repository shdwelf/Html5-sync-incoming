// ============================================================================
//  Ensō Engine
//  Ported & rewritten from the hand-made PIM (pim.jar) source.
//  The original Java GUI version is preserved (commented) at the bottom of
//  this file for reference. This is the active "command line / web" version.
// ============================================================================

// ---- Deterministic PRNG (Mulberry32) ---------------------------------------
// Worms Armageddon style: a single 32-bit seed deterministically produces an
// entire "terrain". Here the terrain == the ensō stroke + the wallet entropy.
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---- Ensō configurable variables -------------------------------------------
export type Direction = "Clockwise" | "Counter-Clockwise";
export type Stretch = "Equal" | "Unequal";
export type Signature = "Light" | "Dark";
export type StrokeSize = "Small" | "Medium" | "Large";

export interface EnsoConfig {
  inkLoad: number; // 0-7
  direction: Direction;
  paperHue: string; // hue name
  brushSize: number; // 0-15
  inkDensity: number; // 0-7
  stretch: Stretch;
  paperTexture: number; // 0-7
  bristleDensity: number; // 0-7
  signature: Signature;
  strokeSize: StrokeSize;
  startRotation: number; // degrees 0-359
}

export const PAPER_HUES = [
  "Cyan",
  "Magenta",
  "Amber",
  "Jade",
  "Crimson",
  "Indigo",
  "Slate",
  "Ivory",
];

export const HUE_MAP: Record<string, { bg: string; ink: string; accent: string }> = {
  Cyan: { bg: "#e6f7fa", ink: "#0c3b44", accent: "#06b6d4" },
  Magenta: { bg: "#fbe9f5", ink: "#4a0d36", accent: "#db2777" },
  Amber: { bg: "#fdf3e3", ink: "#4a2f0a", accent: "#d97706" },
  Jade: { bg: "#e8f6ee", ink: "#0c3b22", accent: "#10b981" },
  Crimson: { bg: "#fceaea", ink: "#4a0c0c", accent: "#dc2626" },
  Indigo: { bg: "#ebe9fb", ink: "#1a0d4a", accent: "#6366f1" },
  Slate: { bg: "#eef1f5", ink: "#1e293b", accent: "#475569" },
  Ivory: { bg: "#fbfaf3", ink: "#3a3520", accent: "#a8a29e" },
};

export const DEFAULT_CONFIG: EnsoConfig = {
  inkLoad: 4,
  direction: "Clockwise",
  paperHue: "Cyan",
  brushSize: 6,
  inkDensity: 3,
  stretch: "Unequal",
  paperTexture: 4,
  bristleDensity: 5,
  signature: "Dark",
  strokeSize: "Medium",
  startRotation: 216,
};

// ---- Ensō ID <-> Config encoding -------------------------------------------
// The "terrain id" used as the master vault password. Encodes every variable
// into a single base36 string. Same id -> same ensō + same wallet entropy.
const STRETCH_VALS: Stretch[] = ["Equal", "Unequal"];
const DIR_VALS: Direction[] = ["Clockwise", "Counter-Clockwise"];
const SIG_VALS: Signature[] = ["Light", "Dark"];
const SIZE_VALS: StrokeSize[] = ["Small", "Medium", "Large"];

export function configToId(cfg: EnsoConfig, seed: number): string {
  const parts = [
    seed >>> 0,
    clamp(cfg.inkLoad, 0, 7),
    DIR_VALS.indexOf(cfg.direction),
    Math.max(0, PAPER_HUES.indexOf(cfg.paperHue)),
    clamp(cfg.brushSize, 0, 15),
    clamp(cfg.inkDensity, 0, 7),
    STRETCH_VALS.indexOf(cfg.stretch),
    clamp(cfg.paperTexture, 0, 7),
    clamp(cfg.bristleDensity, 0, 7),
    SIG_VALS.indexOf(cfg.signature),
    SIZE_VALS.indexOf(cfg.strokeSize),
    clamp(cfg.startRotation, 0, 359),
  ];
  return parts.map((p) => (p >>> 0).toString(36)).join("-").toUpperCase();
}

export function idToConfig(
  id: string
): { cfg: EnsoConfig; seed: number } | null {
  try {
    const parts = id.trim().toLowerCase().split("-").map((p) => parseInt(p, 36));
    if (parts.length !== 12 || parts.some((p) => isNaN(p))) return null;
    const [
      seed,
      inkLoad,
      dir,
      hue,
      brushSize,
      inkDensity,
      stretch,
      paperTexture,
      bristleDensity,
      sig,
      size,
      startRotation,
    ] = parts;
    return {
      seed: seed >>> 0,
      cfg: {
        inkLoad,
        direction: DIR_VALS[dir] ?? "Clockwise",
        paperHue: PAPER_HUES[hue] ?? "Cyan",
        brushSize,
        inkDensity,
        stretch: STRETCH_VALS[stretch] ?? "Unequal",
        paperTexture,
        bristleDensity,
        signature: SIG_VALS[sig] ?? "Dark",
        strokeSize: SIZE_VALS[size] ?? "Medium",
        startRotation,
      },
    };
  } catch {
    return null;
  }
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, Math.round(v)));
}

// ---- Random config (Worms-style randomised terrain) ------------------------
export function randomConfig(seed?: number): { cfg: EnsoConfig; seed: number } {
  const s = seed ?? (Math.floor(Math.random() * 0xffffffff) >>> 0);
  const rng = mulberry32(s);
  const pick = <T,>(arr: T[]) => arr[Math.floor(rng() * arr.length)];
  const cfg: EnsoConfig = {
    inkLoad: Math.floor(rng() * 8),
    direction: pick(DIR_VALS),
    paperHue: pick(PAPER_HUES),
    brushSize: Math.floor(rng() * 16),
    inkDensity: Math.floor(rng() * 8),
    stretch: pick(STRETCH_VALS),
    paperTexture: Math.floor(rng() * 8),
    bristleDensity: Math.floor(rng() * 8),
    signature: pick(SIG_VALS),
    strokeSize: pick(SIZE_VALS),
    startRotation: Math.floor(rng() * 360),
  };
  return { cfg, seed: s };
}

// ---- Ensō entropy ----------------------------------------------------------
// Derive deterministic entropy bytes from the ensō id, used to seed the
// BIP-39 mnemonic. The id IS the master vault password.
export async function ensoEntropy(id: string, bytes = 16): Promise<Uint8Array> {
  const enc = new TextEncoder();
  const data = enc.encode("ENSO::" + id);
  const digest = await crypto.subtle.digest("SHA-256", data);
  const full = new Uint8Array(digest);
  return full.slice(0, bytes);
}

// ============================================================================
//  ORIGINAL JAVA GUI VERSION (from pim.jar) — COMMENTED OUT
//  The GUI (Swing) renderer has been disabled in favour of the command-line /
//  web (canvas + websocket) version above.
// ----------------------------------------------------------------------------
//  public class Pim extends JFrame {
//      // private void buildGui() {            // <-- GUI disabled
//      //     JPanel canvas = new EnsoPanel();
//      //     add(canvas, BorderLayout.CENTER);
//      //     setVisible(true);
//      // }
//
//      public static void main(String[] args) {
//          // GUI version (disabled):
//          // SwingUtilities.invokeLater(() -> new Pim().buildGui());
//
//          // Command-line version (enabled):
//          runCommandLine(args);
//      }
//
//      static void runCommandLine(String[] args) {
//          long seed = args.length > 0 ? Long.parseLong(args[0])
//                                      : System.currentTimeMillis();
//          // ... emits ensō id + haiku wallet to stdout ...
//      }
//  }
// ============================================================================
