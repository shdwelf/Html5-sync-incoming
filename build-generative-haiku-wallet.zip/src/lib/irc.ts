// Minimal IRC-over-WebSocket client for the terminal tab.
// Connects to a public IRC websocket gateway. If the socket cannot be
// established (offline / blocked), the terminal falls back to local echo mode.

export type IrcLine = {
  ts: number;
  from: string;
  text: string;
  kind: "system" | "msg" | "self" | "error" | "join";
};

export interface IrcOptions {
  url?: string;
  nick: string;
  channel: string;
  onLine: (line: IrcLine) => void;
  onStatus: (status: string) => void;
}

export class IrcClient {
  private ws: WebSocket | null = null;
  private opts: IrcOptions;
  private connected = false;
  private registered = false;

  constructor(opts: IrcOptions) {
    this.opts = opts;
  }

  connect() {
    // Webirc-style gateways speak the raw IRC protocol over a websocket.
    const url = this.opts.url || "wss://web.libera.chat/webirc/websocket/";
    this.opts.onStatus("connecting…");
    try {
      this.ws = new WebSocket(url);
    } catch (e) {
      this.fail("WebSocket unavailable — local mode");
      return;
    }
    this.ws.onopen = () => {
      this.connected = true;
      this.opts.onStatus("registering…");
      this.send(`NICK ${this.opts.nick}`);
      this.send(`USER ${this.opts.nick} 0 * :Enso Terminal`);
    };
    this.ws.onmessage = (ev) => this.handleRaw(String(ev.data));
    this.ws.onerror = () => this.fail("connection error — local mode");
    this.ws.onclose = () => {
      this.connected = false;
      this.opts.onStatus("disconnected");
    };
    // safety: if no open within 4s, drop to local mode
    setTimeout(() => {
      if (!this.connected) this.fail("timed out — local mode");
    }, 4000);
  }

  private fail(msg: string) {
    try {
      this.ws?.close();
    } catch {
      /* */
    }
    this.ws = null;
    this.opts.onStatus("offline");
    this.opts.onLine({
      ts: Date.now(),
      from: "*",
      text: msg + ". Type messages to echo locally.",
      kind: "system",
    });
  }

  private handleRaw(data: string) {
    data.split("\r\n").forEach((line) => {
      if (!line) return;
      if (line.startsWith("PING")) {
        this.send("PONG" + line.substring(4));
        return;
      }
      const m = line.match(/^(?::(\S+)\s)?(\S+)\s(.*)$/);
      if (!m) return;
      const prefix = m[1] || "";
      const cmd = m[2];
      const rest = m[3];
      const nick = prefix.split("!")[0];

      if (cmd === "001") {
        this.registered = true;
        this.opts.onStatus("connected");
        this.send(`JOIN ${this.opts.channel}`);
        this.opts.onLine({
          ts: Date.now(),
          from: "*",
          text: `joined ${this.opts.channel}`,
          kind: "join",
        });
      } else if (cmd === "PRIVMSG") {
        const idx = rest.indexOf(":");
        const text = idx >= 0 ? rest.substring(idx + 1) : rest;
        this.opts.onLine({
          ts: Date.now(),
          from: nick || "?",
          text,
          kind: "msg",
        });
      } else if (cmd === "JOIN") {
        this.opts.onLine({
          ts: Date.now(),
          from: "*",
          text: `${nick} joined`,
          kind: "join",
        });
      } else if (cmd === "NOTICE") {
        const idx = rest.indexOf(":");
        const text = idx >= 0 ? rest.substring(idx + 1) : rest;
        this.opts.onLine({ ts: Date.now(), from: "NOTICE", text, kind: "system" });
      } else if (/^4\d\d$/.test(cmd) || /^5\d\d$/.test(cmd)) {
        const idx = rest.indexOf(":");
        const text = idx >= 0 ? rest.substring(idx + 1) : rest;
        this.opts.onLine({ ts: Date.now(), from: "server", text, kind: "error" });
      }
    });
  }

  private send(raw: string) {
    if (this.ws && this.connected) this.ws.send(raw + "\r\n");
  }

  message(text: string) {
    // command support
    if (text.startsWith("/")) {
      const [cmd, ...args] = text.slice(1).split(" ");
      if (cmd === "join") {
        this.opts.channel = args[0] || this.opts.channel;
        this.send(`JOIN ${this.opts.channel}`);
        return;
      }
      if (cmd === "nick") {
        this.send(`NICK ${args[0]}`);
        return;
      }
      if (cmd === "raw") {
        this.send(args.join(" "));
        return;
      }
      if (cmd === "me") {
        text = args.join(" ");
      }
    }
    if (this.registered && this.connected) {
      this.send(`PRIVMSG ${this.opts.channel} :${text}`);
    }
    this.opts.onLine({
      ts: Date.now(),
      from: this.opts.nick,
      text,
      kind: "self",
    });
  }

  disconnect() {
    try {
      this.send("QUIT :bye");
      this.ws?.close();
    } catch {
      /* */
    }
    this.ws = null;
    this.connected = false;
    this.registered = false;
  }
}
