import { EnsoConfig, HUE_MAP, mulberry32 } from "./enso";

// Renders a hand-painted ensō onto a canvas. Deterministic given (cfg, seed).
export function renderEnso(
  canvas: HTMLCanvasElement,
  cfg: EnsoConfig,
  seed: number
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  const hue = HUE_MAP[cfg.paperHue] ?? HUE_MAP.Cyan;
  const rng = mulberry32(seed ^ 0x9e3779b9);

  // ---- Paper ----
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = hue.bg;
  ctx.fillRect(0, 0, W, H);

  // Paper texture: speckles based on texture value
  const speckCount = cfg.paperTexture * 220;
  ctx.save();
  for (let i = 0; i < speckCount; i++) {
    const x = rng() * W;
    const y = rng() * H;
    const a = rng() * 0.05;
    ctx.fillStyle = `rgba(0,0,0,${a})`;
    ctx.fillRect(x, y, 1.5, 1.5);
  }
  ctx.restore();

  // ---- Stroke geometry ----
  const cx = W / 2;
  const cy = H / 2;
  const sizeFactor =
    cfg.strokeSize === "Small" ? 0.28 : cfg.strokeSize === "Large" ? 0.42 : 0.35;
  const baseR = Math.min(W, H) * sizeFactor;
  const stretchX =
    cfg.stretch === "Unequal" ? 1 + (rng() - 0.5) * 0.45 : 1;
  const stretchY =
    cfg.stretch === "Unequal" ? 1 + (rng() - 0.5) * 0.45 : 1;
  const start = (cfg.startRotation * Math.PI) / 180;
  const dir = cfg.direction === "Clockwise" ? 1 : -1;
  // Leave a small gap (the open ensō) ~ 18-40 degrees
  const gap = (18 + rng() * 22) * (Math.PI / 180);
  const sweep = Math.PI * 2 - gap;

  const baseWidth = 3 + cfg.brushSize * 1.6;
  const bristles = 3 + cfg.bristleDensity * 2;
  const inkAlphaBase = 0.18 + cfg.inkDensity * 0.06;
  const steps = 260;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(stretchX, stretchY);

  for (let b = 0; b < bristles; b++) {
    const bristleOffset = (b / bristles - 0.5) * baseWidth;
    const wobbleSeed = mulberry32((seed + b * 131) >>> 0);
    ctx.beginPath();
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      // ink load: ink runs out near the end of the stroke
      const inkRemaining = Math.min(1, (cfg.inkLoad + 1) / 8 + 0.15);
      const fade = t > inkRemaining ? Math.max(0, 1 - (t - inkRemaining) * 4) : 1;
      const angle = start + dir * sweep * t;
      const wob = (wobbleSeed() - 0.5) * baseWidth * 0.5;
      const taper = Math.sin(t * Math.PI); // thicker in middle
      const r = baseR + bristleOffset + wob * (0.4 + taper);
      const x = Math.cos(angle) * r;
      const y = Math.sin(angle) * r;
      if (s === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      // dab strokes for texture
      if (s % 4 === 0) {
        const alpha = inkAlphaBase * fade * (0.5 + taper * 0.7);
        ctx.strokeStyle = withAlpha(hue.ink, alpha);
        ctx.lineWidth = (1 + cfg.brushSize * 0.4) * (0.5 + taper);
        ctx.lineCap = "round";
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, y);
      }
    }
  }

  // Ink splatter at start (heavy load)
  const splat = cfg.inkLoad * 3;
  for (let i = 0; i < splat; i++) {
    const angle = start + (rng() - 0.5) * 0.5;
    const r = baseR + (rng() - 0.5) * baseWidth;
    const x = Math.cos(angle) * r;
    const y = Math.sin(angle) * r;
    ctx.beginPath();
    ctx.fillStyle = withAlpha(hue.ink, 0.3 * (cfg.inkDensity / 7));
    ctx.arc(x, y, rng() * 3 + 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();

  // ---- Signature seal (red stamp) ----
  const sealColor = cfg.signature === "Dark" ? "#7a0d0d" : "#c0392b";
  const sx = W * 0.78;
  const sy = H * 0.8;
  ctx.fillStyle = sealColor;
  ctx.globalAlpha = 0.88;
  roundRect(ctx, sx, sy, 34, 34, 4);
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.fillStyle = hue.bg;
  ctx.font = "bold 20px serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("円", sx + 17, sy + 18);
}

function withAlpha(hex: string, a: number) {
  const c = hex.replace("#", "");
  const r = parseInt(c.substring(0, 2), 16);
  const g = parseInt(c.substring(2, 4), 16);
  const b = parseInt(c.substring(4, 6), 16);
  return `rgba(${r},${g},${b},${a.toFixed(3)})`;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export function downloadCanvasPng(canvas: HTMLCanvasElement, name: string) {
  const url = canvas.toDataURL("image/png");
  const a = document.createElement("a");
  a.href = url;
  a.download = name.endsWith(".png") ? name : name + ".png";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
