import { useEffect, useState } from "react";

interface Coin {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  total_volume: number;
  sparkline_in_7d?: { price: number[] };
}

const FALLBACK: Coin[] = [
  { id: "bitcoin", symbol: "btc", name: "Bitcoin", current_price: 67421, price_change_percentage_24h: 2.4, market_cap: 1.33e12, total_volume: 3.1e10 },
  { id: "ethereum", symbol: "eth", name: "Ethereum", current_price: 3284, price_change_percentage_24h: -1.1, market_cap: 3.9e11, total_volume: 1.5e10 },
  { id: "waves", symbol: "waves", name: "Waves", current_price: 1.82, price_change_percentage_24h: 5.7, market_cap: 2.0e8, total_volume: 3.2e7 },
  { id: "litecoin", symbol: "ltc", name: "Litecoin", current_price: 84.3, price_change_percentage_24h: 0.9, market_cap: 6.3e9, total_volume: 4.1e8 },
  { id: "monero", symbol: "xmr", name: "Monero", current_price: 168, price_change_percentage_24h: -0.4, market_cap: 3.1e9, total_volume: 9.0e7 },
];

export default function Market() {
  const [coins, setCoins] = useState<Coin[]>(FALLBACK);
  const [live, setLive] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const r = await fetch(
          "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=bitcoin,ethereum,waves,litecoin,monero,solana,cardano&order=market_cap_desc&sparkline=true"
        );
        if (!r.ok) throw new Error("bad");
        const data = (await r.json()) as Coin[];
        if (alive && Array.isArray(data) && data.length) {
          setCoins(data);
          setLive(true);
        }
      } catch {
        // simulate drift on fallback
        if (alive)
          setCoins((c) =>
            c.map((x) => ({
              ...x,
              current_price: x.current_price * (1 + (Math.random() - 0.5) * 0.01),
            }))
          );
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <h2 className="text-lg font-bold text-stone-100">Market Data</h2>
        <span
          className={`rounded px-2 py-0.5 text-[10px] font-medium ${
            live ? "bg-emerald-900/60 text-emerald-300" : "bg-stone-700 text-stone-400"
          }`}
        >
          {loading ? "loading…" : live ? "live · CoinGecko" : "offline · simulated"}
        </span>
      </div>
      <div className="overflow-hidden rounded-2xl border border-stone-700">
        <table className="w-full text-sm">
          <thead className="bg-stone-800/70 text-left text-xs uppercase text-stone-400">
            <tr>
              <th className="px-4 py-2">Asset</th>
              <th className="px-4 py-2 text-right">Price</th>
              <th className="px-4 py-2 text-right">24h</th>
              <th className="hidden px-4 py-2 text-right sm:table-cell">Mkt Cap</th>
              <th className="hidden px-4 py-2 text-right md:table-cell">Volume</th>
              <th className="hidden px-4 py-2 lg:table-cell">7d</th>
            </tr>
          </thead>
          <tbody>
            {coins.map((c) => (
              <tr
                key={c.id}
                className="border-t border-stone-800 text-stone-200 hover:bg-stone-800/40"
              >
                <td className="px-4 py-3">
                  <span className="font-semibold">{c.name}</span>{" "}
                  <span className="text-xs uppercase text-stone-500">
                    {c.symbol}
                  </span>
                </td>
                <td className="px-4 py-3 text-right font-mono">
                  ${c.current_price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                </td>
                <td
                  className={`px-4 py-3 text-right font-mono ${
                    (c.price_change_percentage_24h ?? 0) >= 0
                      ? "text-emerald-400"
                      : "text-rose-400"
                  }`}
                >
                  {(c.price_change_percentage_24h ?? 0) >= 0 ? "▲" : "▼"}{" "}
                  {Math.abs(c.price_change_percentage_24h ?? 0).toFixed(2)}%
                </td>
                <td className="hidden px-4 py-3 text-right font-mono text-stone-400 sm:table-cell">
                  ${abbrev(c.market_cap)}
                </td>
                <td className="hidden px-4 py-3 text-right font-mono text-stone-400 md:table-cell">
                  ${abbrev(c.total_volume)}
                </td>
                <td className="hidden px-4 py-3 lg:table-cell">
                  <Spark data={c.sparkline_in_7d?.price} up={(c.price_change_percentage_24h ?? 0) >= 0} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function abbrev(n?: number) {
  if (!n) return "—";
  if (n >= 1e12) return (n / 1e12).toFixed(2) + "T";
  if (n >= 1e9) return (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
  return n.toFixed(0);
}

function Spark({ data, up }: { data?: number[]; up: boolean }) {
  if (!data || data.length < 2) return <span className="text-stone-600">—</span>;
  const pts = data.filter((_, i) => i % 4 === 0);
  const min = Math.min(...pts);
  const max = Math.max(...pts);
  const range = max - min || 1;
  const W = 90;
  const H = 28;
  const path = pts
    .map((p, i) => {
      const x = (i / (pts.length - 1)) * W;
      const y = H - ((p - min) / range) * H;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg width={W} height={H}>
      <path d={path} fill="none" stroke={up ? "#34d399" : "#fb7185"} strokeWidth={1.5} />
    </svg>
  );
}
