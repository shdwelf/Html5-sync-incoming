import { useEffect, useRef, useState } from "react";
import { IrcClient, IrcLine } from "../lib/irc";

export default function Terminal() {
  const [lines, setLines] = useState<IrcLine[]>([
    {
      ts: Date.now(),
      from: "*",
      text: "PIM command-line terminal (web/websocket build). GUI version disabled.",
      kind: "system",
    },
    {
      ts: Date.now(),
      from: "*",
      text: "Type /irc to connect to IRC chat, or run commands: help, enso, about.",
      kind: "system",
    },
  ]);
  const [input, setInput] = useState("");
  const [status, setStatus] = useState("offline");
  const [nick] = useState(
    "enso-" + Math.random().toString(36).slice(2, 7)
  );
  const clientRef = useRef<IrcClient | null>(null);
  const ircMode = useRef(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [lines]);

  const push = (l: IrcLine) => setLines((p) => [...p, l]);

  const connectIrc = (channel = "#enso") => {
    push({
      ts: Date.now(),
      from: "*",
      text: `connecting to IRC as ${nick} on ${channel}…`,
      kind: "system",
    });
    const c = new IrcClient({
      nick,
      channel,
      onLine: push,
      onStatus: setStatus,
    });
    c.connect();
    clientRef.current = c;
    ircMode.current = true;
  };

  const runLocal = (cmd: string) => {
    const c = cmd.trim();
    if (c === "help") {
      push(line("*", "commands: help, about, enso, clear, /irc [#chan], /nick, /raw"));
    } else if (c === "about") {
      push(line("*", "PIM — ported from pim.jar. GUI commented out; CLI + websocket enabled."));
    } else if (c === "enso") {
      push(line("*", "○ The Ensō ID is your master vault password. Forge one in the Studio tab."));
    } else if (c === "clear") {
      setLines([]);
    } else {
      push(line("sh", `command not found: ${c}`, "error"));
    }
  };

  const submit = () => {
    if (!input.trim()) return;
    const text = input;
    setInput("");

    if (text.trim() === "/irc" || text.trim().startsWith("/irc ")) {
      const chan = text.trim().split(" ")[1];
      connectIrc(chan || "#enso");
      return;
    }
    if (text.trim() === "/quit") {
      clientRef.current?.disconnect();
      ircMode.current = false;
      setStatus("offline");
      push(line("*", "disconnected from IRC"));
      return;
    }

    if (ircMode.current && clientRef.current) {
      clientRef.current.message(text);
    } else if (text.startsWith("/")) {
      // allow /nick etc to imply irc; otherwise treat as local
      runLocal(text.slice(1));
    } else {
      runLocal(text);
    }
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-stone-700 bg-black shadow-xl">
      <div className="flex items-center justify-between border-b border-stone-700 bg-stone-900 px-4 py-2">
        <div className="flex items-center gap-2 text-xs text-stone-400">
          <span className="h-3 w-3 rounded-full bg-rose-500" />
          <span className="h-3 w-3 rounded-full bg-amber-500" />
          <span className="h-3 w-3 rounded-full bg-emerald-500" />
          <span className="ml-2 font-mono">pim@terminal — irc</span>
        </div>
        <span
          className={`rounded px-2 py-0.5 text-[10px] font-mono ${
            status === "connected"
              ? "bg-emerald-900/60 text-emerald-300"
              : "bg-stone-800 text-stone-400"
          }`}
        >
          irc: {status}
        </span>
      </div>
      <div
        ref={scrollRef}
        className="h-[420px] overflow-y-auto p-3 font-mono text-[13px] leading-relaxed"
      >
        {lines.map((l, i) => (
          <div key={i} className="whitespace-pre-wrap break-words">
            <span className="text-stone-600">
              {new Date(l.ts).toLocaleTimeString()}{" "}
            </span>
            <span className={fromColor(l.kind)}>
              {l.kind === "self" ? `<${l.from}>` : l.from === "*" ? "*" : `<${l.from}>`}
            </span>{" "}
            <span className={textColor(l.kind)}>{l.text}</span>
          </div>
        ))}
      </div>
      <div className="flex border-t border-stone-700 bg-stone-900">
        <span className="px-3 py-2 font-mono text-emerald-400">
          {ircMode.current ? nick : "$"}
        </span>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={
            ircMode.current
              ? "message channel… (/join #chan, /quit)"
              : "type a command or /irc to connect…"
          }
          className="flex-1 bg-transparent py-2 pr-3 font-mono text-[13px] text-stone-100 outline-none placeholder:text-stone-600"
        />
      </div>
    </div>
  );
}

function line(from: string, text: string, kind: IrcLine["kind"] = "system"): IrcLine {
  return { ts: Date.now(), from, text, kind };
}

function fromColor(k: IrcLine["kind"]) {
  switch (k) {
    case "self":
      return "text-emerald-400";
    case "msg":
      return "text-cyan-400";
    case "error":
      return "text-rose-400";
    case "join":
      return "text-amber-400";
    default:
      return "text-stone-500";
  }
}
function textColor(k: IrcLine["kind"]) {
  switch (k) {
    case "error":
      return "text-rose-300";
    case "system":
      return "text-stone-400";
    default:
      return "text-stone-200";
  }
}
