import { useEffect, useRef, useState } from "react";
import {
  DEFAULT_CONFIG,
  EnsoConfig,
  PAPER_HUES,
  configToId,
  idToConfig,
  randomConfig,
  Direction,
  Stretch,
  Signature,
  StrokeSize,
} from "../lib/enso";
import { renderEnso, downloadCanvasPng } from "../lib/ensoRender";

interface Props {
  onForge: (ensoId: string) => void;
}

export default function EnsoStudio({ onForge }: Props) {
  const [cfg, setCfg] = useState<EnsoConfig>(DEFAULT_CONFIG);
  const [seed, setSeed] = useState<number>(0xe25c0);
  const [ensoId, setEnsoId] = useState<string>("");
  const [idInput, setIdInput] = useState<string>("");
  const [forging, setForging] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const id = configToId(cfg, seed);
    setEnsoId(id);
  }, [cfg, seed]);

  useEffect(() => {
    if (canvasRef.current) renderEnso(canvasRef.current, cfg, seed);
  }, [cfg, seed]);

  const set = <K extends keyof EnsoConfig>(k: K, v: EnsoConfig[K]) =>
    setCfg((c) => ({ ...c, [k]: v }));

  const randomize = () => {
    const { cfg: c, seed: s } = randomConfig();
    setCfg(c);
    setSeed(s);
  };

  const loadId = () => {
    const parsed = idToConfig(idInput);
    if (parsed) {
      setCfg(parsed.cfg);
      setSeed(parsed.seed);
    } else {
      alert("Invalid Ensō ID format");
    }
  };

  const doForge = async () => {
    setForging(true);
    await new Promise((r) => setTimeout(r, 2200));
    setForging(false);
    onForge(ensoId);
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
      {/* Canvas + actions */}
      <div className="space-y-4">
        <div className="relative overflow-hidden rounded-2xl border border-stone-700 bg-stone-900 shadow-xl">
          <canvas
            ref={canvasRef}
            width={400}
            height={400}
            className="block h-auto w-full"
          />
          {forging && <ForgeOverlay />}
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={randomize}
            className="flex-1 rounded-lg bg-stone-700 px-4 py-2 text-sm font-medium text-stone-100 hover:bg-stone-600"
          >
            🎲 Random Terrain
          </button>
          <button
            onClick={() =>
              canvasRef.current &&
              downloadCanvasPng(canvasRef.current, `enso-${ensoId}`)
            }
            className="flex-1 rounded-lg bg-stone-700 px-4 py-2 text-sm font-medium text-stone-100 hover:bg-stone-600"
          >
            ⬇ Download PNG
          </button>
        </div>
        <button
          onClick={doForge}
          disabled={forging}
          className="w-full rounded-lg bg-gradient-to-r from-amber-600 to-rose-600 px-4 py-3 text-sm font-bold text-white shadow-lg hover:from-amber-500 hover:to-rose-500 disabled:opacity-60"
        >
          {forging ? "⚒ Forging…" : "⚒ Forge Haiku Wallet from this Ensō"}
        </button>

        <div className="rounded-xl border border-stone-700 bg-stone-800/60 p-3">
          <div className="mb-1 text-[11px] uppercase tracking-wider text-amber-400">
            Ensō ID · Master Vault Password
          </div>
          <code className="block break-all text-xs text-emerald-300">
            {ensoId}
          </code>
          <div className="mt-3 flex gap-2">
            <input
              value={idInput}
              onChange={(e) => setIdInput(e.target.value)}
              placeholder="Paste an Ensō ID to restore…"
              className="flex-1 rounded-md border border-stone-600 bg-stone-900 px-2 py-1 text-xs text-stone-100 placeholder:text-stone-500"
            />
            <button
              onClick={loadId}
              className="rounded-md bg-stone-600 px-3 py-1 text-xs text-white hover:bg-stone-500"
            >
              Load
            </button>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="grid content-start gap-4 rounded-2xl border border-stone-700 bg-stone-800/40 p-5 sm:grid-cols-2">
        <Slider label="Ink Load" value={cfg.inkLoad} min={0} max={7} onChange={(v) => set("inkLoad", v)} />
        <Select label="Direction" value={cfg.direction} options={["Clockwise", "Counter-Clockwise"]} onChange={(v) => set("direction", v as Direction)} />
        <Select label="Paper Hue" value={cfg.paperHue} options={PAPER_HUES} onChange={(v) => set("paperHue", v)} />
        <Slider label="Brush Size" value={cfg.brushSize} min={0} max={15} onChange={(v) => set("brushSize", v)} />
        <Slider label="Ink Density" value={cfg.inkDensity} min={0} max={7} onChange={(v) => set("inkDensity", v)} />
        <Select label="X/Y Stretch" value={cfg.stretch} options={["Equal", "Unequal"]} onChange={(v) => set("stretch", v as Stretch)} />
        <Slider label="Paper Texture" value={cfg.paperTexture} min={0} max={7} onChange={(v) => set("paperTexture", v)} />
        <Slider label="Bristle Density" value={cfg.bristleDensity} min={0} max={7} onChange={(v) => set("bristleDensity", v)} />
        <Select label="Signature Style" value={cfg.signature} options={["Light", "Dark"]} onChange={(v) => set("signature", v as Signature)} />
        <Select label="Brushstroke Size" value={cfg.strokeSize} options={["Small", "Medium", "Large"]} onChange={(v) => set("strokeSize", v as StrokeSize)} />
        <Slider label="Start Rotation°" value={cfg.startRotation} min={0} max={359} onChange={(v) => set("startRotation", v)} />
        <div>
          <label className="mb-1 block text-xs font-medium text-stone-300">
            Seed
          </label>
          <input
            type="number"
            value={seed}
            onChange={(e) => setSeed(Number(e.target.value) >>> 0)}
            className="w-full rounded-md border border-stone-600 bg-stone-900 px-2 py-1.5 text-sm text-stone-100"
          />
        </div>
      </div>
    </div>
  );
}

function ForgeOverlay() {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="enso-spin h-40 w-40 rounded-full border-[10px] border-amber-400 border-t-transparent" />
      <div className="mt-4 animate-pulse font-mono text-sm text-amber-300">
        forging ensō · binding haiku · deriving keys…
      </div>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <label className="mb-1 flex justify-between text-xs font-medium text-stone-300">
        <span>{label}</span>
        <span className="text-amber-400">{value}</span>
      </label>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-amber-500"
      />
    </div>
  );
}

function Select({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-stone-300">
        {label}
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border border-stone-600 bg-stone-900 px-2 py-1.5 text-sm text-stone-100"
      >
        {options.map((o) => (
          <option key={o} value={o}>
            {o}
          </option>
        ))}
      </select>
    </div>
  );
}
