import { useEffect, useState } from "react";
import {
  GeneratedWallet,
  mineWallets,
} from "../lib/wallet";
import {
  exportEncryptedTxt,
  exportPlainTxt,
  loadVault,
  saveVault,
  clearVault,
  spellCheck,
} from "../lib/storage";

interface Props {
  pendingEnsoId: string | null;
  onConsumed: () => void;
}

export default function Vault({ pendingEnsoId, onConsumed }: Props) {
  const [passphrase, setPassphrase] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [wallets, setWallets] = useState<GeneratedWallet[]>([]);
  const [mineCount, setMineCount] = useState(1);
  const [requireAuthentic, setRequireAuthentic] = useState(false);
  const [mining, setMining] = useState(false);
  const [manualId, setManualId] = useState("");

  // When unlocked, restore the encrypted vault.
  const unlock = () => {
    if (!passphrase) return;
    setWallets(loadVault(passphrase));
    setUnlocked(true);
  };

  // Persist (encrypted) whenever wallets change & unlocked.
  useEffect(() => {
    if (unlocked && passphrase) saveVault(wallets, passphrase);
  }, [wallets, unlocked, passphrase]);

  // Auto-handle a forge coming from the studio.
  useEffect(() => {
    if (pendingEnsoId && unlocked) {
      void doMine(pendingEnsoId);
      onConsumed();
    }
  }, [pendingEnsoId, unlocked]); // eslint-disable-line

  const doMine = async (ensoId: string) => {
    setMining(true);
    const mined = await mineWallets(ensoId, mineCount, requireAuthentic);
    setWallets((w) => [...mined, ...w]);
    setMining(false);
  };

  const remove = (id: string) =>
    setWallets((w) => w.filter((x) => x.id !== id));

  const relabel = (id: string, label: string) =>
    setWallets((w) => w.map((x) => (x.id === id ? { ...x, label } : x)));

  if (!unlocked) {
    return (
      <div className="mx-auto max-w-md rounded-2xl border border-stone-700 bg-stone-800/50 p-8 text-center">
        <div className="mb-2 text-4xl">🔐</div>
        <h2 className="mb-1 text-lg font-bold text-stone-100">
          Haiku Wallet Vault
        </h2>
        <p className="mb-5 text-sm text-stone-400">
          Enter your Ensō ID (or any passphrase) to unlock the AES-256 encrypted
          vault. The same passphrase decrypts your saved collectibles.
        </p>
        <input
          type="password"
          value={passphrase}
          onChange={(e) => setPassphrase(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && unlock()}
          placeholder="Ensō ID / master passphrase"
          className="mb-3 w-full rounded-lg border border-stone-600 bg-stone-900 px-3 py-2 text-sm text-stone-100"
        />
        <button
          onClick={unlock}
          className="w-full rounded-lg bg-amber-600 px-4 py-2 font-semibold text-white hover:bg-amber-500"
        >
          Unlock Vault
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Mining controls */}
      <div className="flex flex-wrap items-end gap-3 rounded-2xl border border-stone-700 bg-stone-800/50 p-4">
        <div>
          <label className="mb-1 block text-xs text-stone-400">Mine count</label>
          <input
            type="number"
            min={1}
            max={20}
            value={mineCount}
            onChange={(e) =>
              setMineCount(Math.max(1, Math.min(20, Number(e.target.value))))
            }
            className="w-24 rounded-md border border-stone-600 bg-stone-900 px-2 py-1.5 text-sm text-stone-100"
          />
        </div>
        <label className="flex items-center gap-2 text-xs text-stone-300">
          <input
            type="checkbox"
            checked={requireAuthentic}
            onChange={(e) => setRequireAuthentic(e.target.checked)}
            className="accent-amber-500"
          />
          Only authentic 5-7-5 haiku (skip if not grammatical)
        </label>
        <div className="flex flex-1 gap-2">
          <input
            value={manualId}
            onChange={(e) => setManualId(e.target.value)}
            placeholder="Manual Ensō ID…"
            className="flex-1 rounded-md border border-stone-600 bg-stone-900 px-2 py-1.5 text-sm text-stone-100"
          />
          <button
            onClick={() => manualId && doMine(manualId)}
            disabled={mining}
            className="rounded-md bg-emerald-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-emerald-500 disabled:opacity-50"
          >
            ⛏ Mine
          </button>
        </div>
      </div>

      {/* Vault actions */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => exportEncryptedTxt(wallets, passphrase)}
          className="rounded-md bg-stone-700 px-3 py-1.5 text-xs font-medium text-stone-100 hover:bg-stone-600"
        >
          ⬇ Export .txt (AES-256)
        </button>
        <button
          onClick={() => exportPlainTxt(wallets)}
          className="rounded-md bg-stone-700 px-3 py-1.5 text-xs font-medium text-stone-100 hover:bg-stone-600"
        >
          ⬇ Export plain .txt
        </button>
        <button
          onClick={() => {
            if (confirm("Clear entire encrypted vault & cookies?")) {
              clearVault();
              setWallets([]);
            }
          }}
          className="rounded-md bg-rose-700/80 px-3 py-1.5 text-xs font-medium text-white hover:bg-rose-600"
        >
          🗑 Clear Vault
        </button>
        <span className="ml-auto self-center text-xs text-stone-500">
          {wallets.length} collectible{wallets.length === 1 ? "" : "s"} · encrypted
          cookie + local
        </span>
      </div>

      {mining && (
        <div className="rounded-lg border border-amber-600/40 bg-amber-900/20 px-4 py-2 text-sm text-amber-300">
          ⛏ Mining haiku wallets…
        </div>
      )}

      {/* Collectibles */}
      {wallets.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-stone-700 p-12 text-center text-stone-500">
          No wallets yet. Forge an Ensō or mine one above.
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {wallets.map((w) => (
            <WalletCard
              key={w.id}
              w={w}
              onRemove={() => remove(w.id)}
              onRelabel={(l) => relabel(w.id, l)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function WalletCard({
  w,
  onRemove,
  onRelabel,
}: {
  w: GeneratedWallet;
  onRemove: () => void;
  onRelabel: (l: string) => void;
}) {
  const [show, setShow] = useState(false);
  const spell = spellCheck(w.mnemonic);
  return (
    <div className="rounded-2xl border border-stone-700 bg-stone-800/50 p-4">
      <div className="mb-2 flex items-center justify-between gap-2">
        <input
          value={w.label}
          onChange={(e) => onRelabel(e.target.value)}
          className="min-w-0 flex-1 rounded bg-transparent text-sm font-bold text-amber-300 outline-none hover:bg-stone-700/50 focus:bg-stone-700/50"
        />
        <span
          className={`rounded px-2 py-0.5 text-[10px] font-bold ${
            w.haiku.authentic
              ? "bg-emerald-900/60 text-emerald-300"
              : "bg-stone-700 text-stone-400"
          }`}
        >
          {w.haiku.counts.join("-")}
        </span>
        <button
          onClick={onRemove}
          className="rounded px-1.5 text-rose-400 hover:bg-rose-900/40"
          title="Delete"
        >
          ✕
        </button>
      </div>

      {/* Haiku */}
      <div className="mb-3 rounded-lg bg-stone-900/60 p-3 font-serif italic leading-relaxed text-stone-200">
        {w.haiku.lines.map((l, i) => (
          <div key={i}>{l}</div>
        ))}
      </div>

      <div className="mb-2 flex flex-wrap gap-1.5 text-[10px]">
        <Tag ok={w.validMnemonic}>
          BIP-39 {w.validMnemonic ? "valid" : "invalid"}
        </Tag>
        <Tag ok={spell.ok}>
          spell {spell.ok ? "ok" : `${spell.badWords.length} bad`}
        </Tag>
        <Tag ok={w.haiku.authentic}>
          {w.haiku.authentic ? "5-7-5 ✓" : "non-standard"}
        </Tag>
        <span className="rounded bg-stone-700 px-1.5 py-0.5 text-stone-400">
          ID {w.id}
        </span>
      </div>

      <button
        onClick={() => setShow((s) => !s)}
        className="text-xs text-amber-400 hover:underline"
      >
        {show ? "Hide secrets" : "Reveal addresses & keys"}
      </button>

      {show && (
        <div className="mt-2 space-y-2 rounded-lg bg-stone-900/60 p-3 text-[11px]">
          <div className="break-all text-stone-400">
            <span className="text-stone-500">Mnemonic: </span>
            {w.mnemonic}
          </div>
          {w.derived.map((d) => (
            <div key={d.kind} className="border-t border-stone-700/60 pt-1.5">
              <div className="flex items-center gap-2">
                <span className="font-bold text-emerald-300">{d.kind}</span>
                <span className="text-stone-600">{d.path}</span>
                <span
                  className={
                    d.checksumValid ? "text-emerald-500" : "text-rose-500"
                  }
                >
                  {d.checksumValid ? "✓ checksum" : "✗ checksum"}
                </span>
              </div>
              <div className="break-all text-stone-300">{d.address}</div>
              <div className="break-all text-stone-600">
                priv: {d.privateKeyHex}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Tag({ ok, children }: { ok: boolean; children: React.ReactNode }) {
  return (
    <span
      className={`rounded px-1.5 py-0.5 font-medium ${
        ok ? "bg-emerald-900/50 text-emerald-300" : "bg-rose-900/50 text-rose-300"
      }`}
    >
      {children}
    </span>
  );
}
