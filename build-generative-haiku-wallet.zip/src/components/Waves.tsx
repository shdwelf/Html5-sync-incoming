import { useEffect, useMemo, useState } from "react";

// Waves exchange tab. Pulls live WAVES price from Waves Data Service when
// available, with a simulated order book / swap UI.
export default function Waves() {
  const [price, setPrice] = useState(1.82);
  const [live, setLive] = useState(false);
  const [amount, setAmount] = useState("100");
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const [pair, setPair] = useState("WAVES/USDT");

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const r = await fetch(
          "https://api.coingecko.com/api/v3/simple/price?ids=waves&vs_currencies=usd"
        );
        const d = await r.json();
        if (alive && d?.waves?.usd) {
          setPrice(d.waves.usd);
          setLive(true);
        }
      } catch {
        /* keep simulated */
      }
    })();
    const t = setInterval(
      () => setPrice((p) => +(p * (1 + (Math.random() - 0.5) * 0.004)).toFixed(4)),
      2500
    );
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  const book = useMemo(() => buildBook(price), [price]);
  const cost = (parseFloat(amount) || 0) * price;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🌊</span>
          <h2 className="text-lg font-bold text-stone-100">Waves Exchange</h2>
        </div>
        <select
          value={pair}
          onChange={(e) => setPair(e.target.value)}
          className="rounded-md border border-stone-600 bg-stone-900 px-2 py-1 text-sm text-stone-100"
        >
          {["WAVES/USDT", "WAVES/BTC", "WAVES/ETH"].map((p) => (
            <option key={p}>{p}</option>
          ))}
        </select>
        <span
          className={`rounded px-2 py-0.5 text-[10px] ${
            live ? "bg-emerald-900/60 text-emerald-300" : "bg-stone-700 text-stone-400"
          }`}
        >
          {live ? "live price" : "simulated"}
        </span>
        <span className="ml-auto font-mono text-xl font-bold text-emerald-400">
          ${price.toFixed(4)}
        </span>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        {/* Order book */}
        <div className="rounded-2xl border border-stone-700 bg-stone-800/40 p-4">
          <div className="mb-2 text-xs uppercase tracking-wide text-stone-400">
            Order Book · {pair}
          </div>
          <div className="grid grid-cols-3 text-[11px] text-stone-500">
            <span>Price (USDT)</span>
            <span className="text-right">Amount</span>
            <span className="text-right">Total</span>
          </div>
          {book.asks.map((o, i) => (
            <Row key={"a" + i} o={o} color="text-rose-400" />
          ))}
          <div className="my-1 border-y border-stone-700 py-1 text-center font-mono text-sm text-emerald-400">
            ${price.toFixed(4)}
          </div>
          {book.bids.map((o, i) => (
            <Row key={"b" + i} o={o} color="text-emerald-400" />
          ))}
        </div>

        {/* Swap / trade form */}
        <div className="rounded-2xl border border-stone-700 bg-stone-800/40 p-4">
          <div className="mb-3 flex rounded-lg bg-stone-900 p-1">
            <button
              onClick={() => setSide("buy")}
              className={`flex-1 rounded-md py-1.5 text-sm font-semibold ${
                side === "buy" ? "bg-emerald-600 text-white" : "text-stone-400"
              }`}
            >
              Buy
            </button>
            <button
              onClick={() => setSide("sell")}
              className={`flex-1 rounded-md py-1.5 text-sm font-semibold ${
                side === "sell" ? "bg-rose-600 text-white" : "text-stone-400"
              }`}
            >
              Sell
            </button>
          </div>
          <label className="mb-1 block text-xs text-stone-400">
            Amount (WAVES)
          </label>
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mb-3 w-full rounded-md border border-stone-600 bg-stone-900 px-3 py-2 font-mono text-sm text-stone-100"
          />
          <div className="mb-3 flex justify-between text-sm text-stone-300">
            <span>Total</span>
            <span className="font-mono">${cost.toFixed(2)}</span>
          </div>
          <button
            onClick={() =>
              alert(
                `Demo: ${side.toUpperCase()} ${amount} WAVES @ $${price.toFixed(
                  4
                )} = $${cost.toFixed(2)} (no real order placed)`
              )
            }
            className={`w-full rounded-lg py-2.5 font-bold text-white ${
              side === "buy"
                ? "bg-emerald-600 hover:bg-emerald-500"
                : "bg-rose-600 hover:bg-rose-500"
            }`}
          >
            {side === "buy" ? "Buy WAVES" : "Sell WAVES"}
          </button>
          <p className="mt-3 text-[11px] text-stone-500">
            Demo exchange interface. Connect a Waves Keeper wallet for live
            trading on the Waves DEX.
          </p>
        </div>
      </div>
    </div>
  );
}

function Row({ o, color }: { o: { p: number; a: number }; color: string }) {
  return (
    <div className="grid grid-cols-3 py-0.5 font-mono text-[11px]">
      <span className={color}>{o.p.toFixed(4)}</span>
      <span className="text-right text-stone-300">{o.a.toFixed(1)}</span>
      <span className="text-right text-stone-500">
        {(o.p * o.a).toFixed(1)}
      </span>
    </div>
  );
}

function buildBook(price: number) {
  const asks = Array.from({ length: 6 }, (_, i) => ({
    p: price * (1 + (i + 1) * 0.0015),
    a: 50 + Math.random() * 800,
  })).reverse();
  const bids = Array.from({ length: 6 }, (_, i) => ({
    p: price * (1 - (i + 1) * 0.0015),
    a: 50 + Math.random() * 800,
  }));
  return { asks, bids };
}
