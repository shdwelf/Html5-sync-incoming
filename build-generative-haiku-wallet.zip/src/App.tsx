import { useState } from "react";
import EnsoStudio from "./components/EnsoStudio";
import Vault from "./components/Vault";
import Terminal from "./components/Terminal";
import Waves from "./components/Waves";
import Market from "./components/Market";

type Tab = "studio" | "vault" | "terminal" | "waves" | "market";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "studio", label: "Ensō Studio", icon: "○" },
  { id: "vault", label: "Haiku Vault", icon: "🔐" },
  { id: "terminal", label: "Terminal · IRC", icon: "▌" },
  { id: "waves", label: "Waves Exchange", icon: "🌊" },
  { id: "market", label: "Market Data", icon: "📈" },
];

export default function App() {
  const [tab, setTab] = useState<Tab>("studio");
  const [pendingEnsoId, setPendingEnsoId] = useState<string | null>(null);

  const handleForge = (id: string) => {
    setPendingEnsoId(id);
    setTab("vault");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-950 via-stone-900 to-stone-950 text-stone-100">
      <div className="mx-auto max-w-6xl px-4 py-6">
        {/* Header */}
        <header className="mb-6 flex flex-wrap items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-full border-[3px] border-amber-400 border-t-transparent text-xl">
            円
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">
              PIM · Ensō Haiku Wallet
            </h1>
            <p className="text-xs text-stone-500">
              Worms-style terrain seeds · BIP-39/44 · websocket IRC · standalone offline build
            </p>
          </div>
        </header>

        {/* Tabs */}
        <nav className="mb-6 flex flex-wrap gap-1 rounded-xl border border-stone-800 bg-stone-900/60 p-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${
                tab === t.id
                  ? "bg-amber-600 text-white shadow"
                  : "text-stone-400 hover:bg-stone-800 hover:text-stone-200"
              }`}
            >
              <span>{t.icon}</span>
              <span className="hidden sm:inline">{t.label}</span>
            </button>
          ))}
        </nav>

        {/* Panels */}
        <main>
          {tab === "studio" && <EnsoStudio onForge={handleForge} />}
          {tab === "vault" && (
            <Vault
              pendingEnsoId={pendingEnsoId}
              onConsumed={() => setPendingEnsoId(null)}
            />
          )}
          {tab === "terminal" && <Terminal />}
          {tab === "waves" && <Waves />}
          {tab === "market" && <Market />}
        </main>

        <footer className="mt-10 border-t border-stone-800 pt-4 text-center text-xs text-stone-600">
          Ported from pim.jar · GUI (Swing) disabled · CLI + WebSocket build ·
          AES-256 encrypted vault · all crypto runs locally in your browser
        </footer>
      </div>
    </div>
  );
}
