"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import WorldMap from "@/components/WorldMap";
import { MapPin, Users, Globe2, TrendingUp } from "lucide-react";

interface Country {
  id: number;
  name: string;
  code: string;
  continent: string;
  capital: string | null;
  population: number | null;
}

export default function HomePage() {
  const router = useRouter();
  const [countries, setCountries] = useState<Country[]>([]);
  const [stats, setStats] = useState({ total: 0, continents: 0 });

  useEffect(() => {
    fetch("/api/countries")
      .then((res) => res.json())
      .then((data: Country[]) => {
        setCountries(data);
        const uniqueContinents = new Set(data.map((c) => c.continent));
        setStats({ total: data.length, continents: uniqueContinents.size });
      });
  }, []);

  const handleMapSelect = (name: string) => {
    const country = countries.find(
      (c) => c.name.toLowerCase() === name.toLowerCase()
    );
    if (country) {
      router.push(`/country/${country.code}`);
    }
  };

  const featuredCountries = countries.slice(0, 6);

  return (
    <div className="space-y-8">
      <section className="text-center space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold text-white">
          Interactive World Atlas
        </h1>
        <p className="text-lg text-slate-400 max-w-2xl mx-auto">
          Explore the world like never before. Click on any country to discover
          its geography, demographics, economy, and culture.
        </p>
      </section>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-2 bg-blue-500/10 rounded-lg">
            <Globe2 className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-white">{stats.total}</div>
            <div className="text-xs text-slate-400">Countries</div>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 rounded-lg">
            <MapPin className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-white">{stats.continents}</div>
            <div className="text-xs text-slate-400">Continents</div>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 rounded-lg">
            <Users className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-white">8B+</div>
            <div className="text-xs text-slate-400">World Population</div>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-2 bg-rose-500/10 rounded-lg">
            <TrendingUp className="w-5 h-5 text-rose-400" />
          </div>
          <div>
            <div className="text-2xl font-bold text-white">195</div>
            <div className="text-xs text-slate-400">UN Members</div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 md:p-6">
        <h2 className="text-lg font-semibold text-white mb-4">World Map</h2>
        <WorldMap
          onSelectCountry={handleMapSelect}
          highlightedCountries={featuredCountries.map((c) => c.name)}
        />
        <p className="text-sm text-slate-500 mt-3 text-center">
          Click on any country to view its profile
        </p>
      </div>

      <section>
        <h2 className="text-lg font-semibold text-white mb-4">Featured Countries</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {featuredCountries.map((country) => (
            <button
              key={country.id}
              onClick={() => router.push(`/country/${country.code}`)}
              className="text-left bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-blue-500/50 hover:bg-slate-800/50 transition-all group"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-white group-hover:text-blue-400 transition-colors">
                    {country.name}
                  </h3>
                  <p className="text-sm text-slate-400 mt-1">
                    {country.capital} &middot; {country.continent}
                  </p>
                </div>
                <span className="text-xs font-mono text-slate-600 bg-slate-800 px-2 py-1 rounded">
                  {country.code}
                </span>
              </div>
              {country.population && (
                <p className="text-xs text-slate-500 mt-2">
                  Population: {country.population.toLocaleString()}
                </p>
              )}
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
