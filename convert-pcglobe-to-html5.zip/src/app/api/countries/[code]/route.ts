import { db } from "@/db";
import { countries } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ code: string }> }
) {
  const { code } = await params;
  const data = await db
    .select()
    .from(countries)
    .where(eq(countries.code, code.toUpperCase()));

  if (data.length === 0) {
    return NextResponse.json({ error: "Country not found" }, { status: 404 });
  }

  return NextResponse.json(data[0]);
}
