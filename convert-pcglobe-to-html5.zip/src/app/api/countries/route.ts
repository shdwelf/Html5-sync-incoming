import { db } from "@/db";
import { countries } from "@/db/schema";
import { sql } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q");
  const continent = searchParams.get("continent");

  const conditions: ReturnType<typeof sql>[] = [];

  if (q) {
    conditions.push(
      sql`(${countries.name} ILIKE ${"%" + q + "%"} OR ${countries.capital} ILIKE ${"%" + q + "%"} OR ${countries.code} ILIKE ${"%" + q + "%"})`
    );
  }

  if (continent) {
    conditions.push(sql`${countries.continent} = ${continent}`);
  }

  const data =
    conditions.length > 0
      ? await db
          .select()
          .from(countries)
          .where(sql`${conditions.reduce((a, b) => sql`${a} AND ${b}`)}`)
          .orderBy(countries.name)
      : await db.select().from(countries).orderBy(countries.name);

  return NextResponse.json(data);
}
