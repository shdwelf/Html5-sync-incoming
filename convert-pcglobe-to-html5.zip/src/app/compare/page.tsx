"use client";

import { useEffect, useState } from "react";
import { Search, X, Users, Maximize, DollarSign, BarChart3 } from "lucide-react";

interface Country {
  id: number;
  name: string;
  code: string;
  continent: string;
  capital: string | null;
  population: number | null;
  areaSqKm: number | null;
  gdpUsd: number | null;
  currency: string | null;
  language: string | null;
  government: string | null;
}

export default function ComparePage() {
  const [allCountries, setAllCountries] = useState<Country[]>([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Country[]>([]);

  useEffect(() => {
    fetch("/api/countries")
      .then((res) => res.json())
      .then((data: Country[]) => setAllCountries(data));
  }, []);

  const filtered = allCountries.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) &&
      !selected.find((s) => s.id === c.id)
  );

  const addCountry = (country: Country) => {
    if (selected.length < 4) {
      setSelected([...selected, country]);
      setSearch("");
    }
  };

  const removeCountry = (id: number) => {
    setSelected(selected.filter((c) => c.id !== id));
  };

  const density = (pop: number | null, area: number | null) => {
    if (!pop || !area) return "N/A";
    return `${(pop / area).toFixed(1)} /km²`;
  };

  const gdpPerCapita = (gdp: number | null, pop: number | null) => {
    if (!gdp || !pop) return "N/A";
    return `$${(gdp / pop).toFixed(0)}`;
  };

  const rows = [
    { label: "Continent", key: "continent" as const },
    { label: "Capital", key: "capital" as const },
    { label: "Population", key: "population" as const, format: (v: number) => v.toLocaleString() },
    { label: "Area", key: "areaSqKm" as const, format: (v: number) => `${v.toLocaleString()} km²` },
    { label: "GDP", key: "gdpUsd" as const, format: (v: number) => `$${(v / 1e9).toFixed(1)}B` },
    { label: "Currency", key: "currency" as const },
    { label: "Language", key: "language" as const },
    { label: "Government", key: "government" as const },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Compare Countries</h1>
        <p className="text-slate-400 mt-1">Select up to 4 countries to compare side by side.</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input
          type="text"
          placeholder="Search and add countries..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
        />
        {search && filtered.length > 0 && (
          <div className="absolute z-10 w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg shadow-xl max-h-60 overflow-auto">
            {filtered.slice(0, 10).map((country) => (
              <button
                key={country.id}
                onClick={() => addCountry(country)}
                className="w-full text-left px-4 py-2 text-sm text-white hover:bg-slate-800 transition-colors"
              >
                {country.name} ({country.code})
              </button>
            ))}
          </div>
        )}
      </div>

      {selected.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left px-4 py-3 font-medium text-slate-400 sticky left-0 bg-slate-900">
                    Attribute
                  </th>
                  {selected.map((country) => (
                    <th key={country.id} className="px-4 py-3 text-center min-w-[160px]">
                      <div className="flex items-center justify-center gap-2">
                        <span className="font-semibold text-white">{country.name}</span>
                        <button
                          onClick={() => removeCountry(country.id)}
                          className="text-slate-500 hover:text-red-400"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.label} className="border-b border-slate-800/50">
                    <td className="px-4 py-3 font-medium text-slate-400 sticky left-0 bg-slate-900">
                      {row.label}
                    </td>
                    {selected.map((country) => {
                      const val = country[row.key];
                      return (
                        <td key={country.id} className="px-4 py-3 text-center text-white">
                          {val
                            ? row.format
                              ? row.format(val as number)
                              : String(val)
                            : "N/A"}
                        </td>
                      );
                    })}
                  </tr>
                ))}
                <tr className="border-b border-slate-800/50">
                  <td className="px-4 py-3 font-medium text-slate-400 sticky left-0 bg-slate-900">
                    <div className="flex items-center gap-1">
                      <BarChart3 className="w-3 h-3" />
                      Density
                    </div>
                  </td>
                  {selected.map((country) => (
                    <td key={country.id} className="px-4 py-3 text-center text-white">
                      {density(country.population, country.areaSqKm)}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="px-4 py-3 font-medium text-slate-400 sticky left-0 bg-slate-900">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      GDP per capita
                    </div>
                  </td>
                  {selected.map((country) => (
                    <td key={country.id} className="px-4 py-3 text-center text-white">
                      {gdpPerCapita(country.gdpUsd, country.population)}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {selected.length === 0 && (
        <div className="text-center py-16 text-slate-500">
          <Users className="w-12 h-12 mx-auto mb-3 text-slate-700" />
          <p>No countries selected. Search above to add countries for comparison.</p>
        </div>
      )}
    </div>
  );
}
