"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Filter, ArrowUpDown } from "lucide-react";

interface Country {
  id: number;
  name: string;
  code: string;
  iso2: string;
  continent: string;
  capital: string | null;
  population: number | null;
  areaSqKm: number | null;
}

const continents = [
  "All",
  "Africa",
  "Asia",
  "Europe",
  "North America",
  "South America",
  "Oceania",
];

type SortKey = "name" | "population" | "areaSqKm";

export default function CountriesPage() {
  const router = useRouter();
  const [countries, setCountries] = useState<Country[]>([]);
  const [search, setSearch] = useState("");
  const [continent, setContinent] = useState("All");
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  useEffect(() => {
    const params = new URLSearchParams();
    if (search) params.set("q", search);
    if (continent !== "All") params.set("continent", continent);

    fetch(`/api/countries?${params.toString()}`)
      .then((res) => res.json())
      .then((data: Country[]) => setCountries(data));
  }, [search, continent]);

  const sorted = [...countries].sort((a, b) => {
    const aVal = a[sortKey] ?? 0;
    const bVal = b[sortKey] ?? 0;
    if (typeof aVal === "string" && typeof bVal === "string") {
      return sortDir === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    return sortDir === "asc" ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
  });

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-3xl font-bold text-white">All Countries</h1>
        <div className="flex items-center gap-2 text-sm text-slate-400">
          <span>{countries.length} countries</span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search countries, capitals..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-500" />
          <select
            value={continent}
            onChange={(e) => setContinent(e.target.value)}
            className="px-3 py-2.5 bg-slate-900 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
          >
            {continents.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="text-left px-4 py-3 font-medium text-slate-400">
                  <button
                    onClick={() => toggleSort("name")}
                    className="flex items-center gap-1 hover:text-white"
                  >
                    Country
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="text-left px-4 py-3 font-medium text-slate-400">Code</th>
                <th className="text-left px-4 py-3 font-medium text-slate-400">Continent</th>
                <th className="text-left px-4 py-3 font-medium text-slate-400">Capital</th>
                <th className="text-right px-4 py-3 font-medium text-slate-400">
                  <button
                    onClick={() => toggleSort("population")}
                    className="flex items-center gap-1 hover:text-white ml-auto"
                  >
                    Population
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="text-right px-4 py-3 font-medium text-slate-400">
                  <button
                    onClick={() => toggleSort("areaSqKm")}
                    className="flex items-center gap-1 hover:text-white ml-auto"
                  >
                    Area (km²)
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((country) => (
                <tr
                  key={country.id}
                  onClick={() => router.push(`/country/${country.code}`)}
                  className="border-b border-slate-800/50 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <td className="px-4 py-3 font-medium text-white">{country.name}</td>
                  <td className="px-4 py-3 text-slate-400 font-mono">{country.code}</td>
                  <td className="px-4 py-3 text-slate-400">{country.continent}</td>
                  <td className="px-4 py-3 text-slate-400">{country.capital || "—"}</td>
                  <td className="px-4 py-3 text-right text-slate-400">
                    {country.population?.toLocaleString() || "—"}
                  </td>
                  <td className="px-4 py-3 text-right text-slate-400">
                    {country.areaSqKm?.toLocaleString() || "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {sorted.length === 0 && (
          <div className="px-4 py-12 text-center text-slate-500">
            No countries found matching your criteria.
          </div>
        )}
      </div>
    </div>
  );
}
