"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Search, MapPin, Users, ArrowRight } from "lucide-react";

interface Country {
  id: number;
  name: string;
  code: string;
  continent: string;
  capital: string | null;
  population: number | null;
  areaSqKm: number | null;
}

export default function SearchPage() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Country[]>([]);
  const [allCountries, setAllCountries] = useState<Country[]>([]);

  useEffect(() => {
    fetch("/api/countries")
      .then((res) => res.json())
      .then((data: Country[]) => setAllCountries(data));
  }, []);

  const performSearch = useCallback(
    (q: string) => {
      if (!q.trim()) {
        setResults([]);
        return;
      }
      const lower = q.toLowerCase();
      const filtered = allCountries.filter(
        (c) =>
          c.name.toLowerCase().includes(lower) ||
          c.capital?.toLowerCase().includes(lower) ||
          c.code.toLowerCase().includes(lower) ||
          c.continent.toLowerCase().includes(lower)
      );
      setResults(filtered);
    },
    [allCountries]
  );

  useEffect(() => {
    const timeout = setTimeout(() => performSearch(query), 150);
    return () => clearTimeout(timeout);
  }, [query, performSearch]);

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">Search</h1>
        <p className="text-slate-400">Find countries by name, capital, code, or continent.</p>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
        <input
          type="text"
          placeholder="Type to search..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
          className="w-full pl-12 pr-4 py-4 bg-slate-900 border border-slate-800 rounded-xl text-lg text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
        />
      </div>

      {query && (
        <div className="text-sm text-slate-500">
          {results.length} result{results.length !== 1 ? "s" : ""} found
        </div>
      )}

      <div className="space-y-2">
        {results.map((country) => (
          <button
            key={country.id}
            onClick={() => router.push(`/country/${country.code}`)}
            className="w-full text-left bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-blue-500/50 hover:bg-slate-800/50 transition-all group flex items-center justify-between"
          >
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-white group-hover:text-blue-400 transition-colors">
                  {country.name}
                </h3>
                <span className="text-xs font-mono text-slate-600 bg-slate-800 px-1.5 py-0.5 rounded">
                  {country.code}
                </span>
              </div>
              <div className="flex items-center gap-3 mt-1 text-sm text-slate-400">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {country.capital || "N/A"}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {country.population?.toLocaleString() || "N/A"}
                </span>
                <span>{country.continent}</span>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-blue-400 transition-colors" />
          </button>
        ))}
      </div>

      {!query && allCountries.length > 0 && (
        <div>
          <h2 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-3">
            Popular Countries
          </h2>
          <div className="flex flex-wrap gap-2">
            {["United States", "China", "India", "Brazil", "Germany", "Japan", "France", "United Kingdom"].map(
              (name) => {
                const country = allCountries.find((c) => c.name === name);
                if (!country) return null;
                return (
                  <button
                    key={country.id}
                    onClick={() => router.push(`/country/${country.code}`)}
                    className="px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-sm text-slate-300 hover:text-white hover:border-blue-500/50 transition-colors"
                  >
                    {country.name}
                  </button>
                );
              }
            )}
          </div>
        </div>
      )}
    </div>
  );
}
