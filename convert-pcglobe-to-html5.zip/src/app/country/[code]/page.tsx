"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  MapPin,
  Users,
  Maximize,
  DollarSign,
  Phone,
  Clock,
  Landmark,
  Languages,
  Banknote,
  Globe2,
  Mountain,
  CloudSun,
  Briefcase,
  BookOpen,
  Plane,
  BarChart3,
  Palette,
  Map,
} from "lucide-react";

interface Country {
  id: number;
  name: string;
  code: string;
  iso2: string;
  continent: string;
  capital: string | null;
  population: number | null;
  areaSqKm: number | null;
  gdpUsd: number | null;
  currency: string | null;
  language: string | null;
  government: string | null;
  timezone: string | null;
  callingCode: string | null;
  region: string | null;
  subregion: string | null;
  latitude: number | null;
  longitude: number | null;
  geography: string | null;
  climate: string | null;
  economy: string | null;
  history: string | null;
  tourism: string | null;
  demographics: string | null;
  flagColors: string | null;
  neighbors: string | null;
}

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
}) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4 text-blue-400" />
        <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
          {label}
        </span>
      </div>
      <div className="text-white font-semibold">{value}</div>
    </div>
  );
}

function InfoSection({
  icon: Icon,
  title,
  children,
}: {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-5 h-5 text-blue-400" />
        <h2 className="text-lg font-semibold text-white">{title}</h2>
      </div>
      <div className="text-slate-300 text-sm leading-relaxed">{children}</div>
    </div>
  );
}

export default function CountryDetailPage() {
  const params = useParams();
  const code = params.code as string;
  const [country, setCountry] = useState<Country | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!code) return;
    fetch(`/api/countries/${code}`)
      .then((res) => res.json())
      .then((data: Country) => {
        setCountry(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [code]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="text-slate-400">Loading country profile...</div>
      </div>
    );
  }

  if (!country) {
    return (
      <div className="text-center py-24">
        <h1 className="text-2xl font-bold text-white mb-2">Country not found</h1>
        <Link href="/countries" className="text-blue-400 hover:text-blue-300">
          Browse all countries
        </Link>
      </div>
    );
  }

  const density =
    country.population && country.areaSqKm
      ? (country.population / country.areaSqKm).toFixed(1)
      : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link
          href="/countries"
          className="flex items-center gap-1 text-sm text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Link>
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-4xl font-bold text-white">{country.name}</h1>
            <span className="text-sm font-mono text-slate-500 bg-slate-800 px-2 py-1 rounded">
              {country.code}
            </span>
          </div>
          <p className="text-slate-400">
            {country.capital && (
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                Capital: {country.capital}
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 text-sm font-medium">
            {country.continent}
          </span>
          {country.subregion && (
            <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-400 text-sm">
              {country.subregion}
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard
          icon={Users}
          label="Population"
          value={country.population?.toLocaleString() || "N/A"}
        />
        <StatCard
          icon={Maximize}
          label="Area"
          value={country.areaSqKm ? `${country.areaSqKm.toLocaleString()} km²` : "N/A"}
        />
        <StatCard
          icon={DollarSign}
          label="GDP"
          value={
            country.gdpUsd
              ? `$${(country.gdpUsd / 1e9).toFixed(1)}B`
              : "N/A"
          }
        />
        <StatCard
          icon={BarChart3}
          label="Density"
          value={density ? `${density} /km²` : "N/A"}
        />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Banknote} label="Currency" value={country.currency || "N/A"} />
        <StatCard icon={Languages} label="Language" value={country.language || "N/A"} />
        <StatCard icon={Landmark} label="Government" value={country.government || "N/A"} />
        <StatCard icon={Clock} label="Timezone" value={country.timezone || "N/A"} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <InfoSection icon={Mountain} title="Geography">
          {country.geography || "No geography data available."}
        </InfoSection>
        <InfoSection icon={CloudSun} title="Climate">
          {country.climate || "No climate data available."}
        </InfoSection>
        <InfoSection icon={Briefcase} title="Economy">
          {country.economy || "No economy data available."}
        </InfoSection>
        <InfoSection icon={BookOpen} title="History">
          {country.history || "No history data available."}
        </InfoSection>
        <InfoSection icon={Plane} title="Tourism">
          {country.tourism || "No tourism data available."}
        </InfoSection>
        <InfoSection icon={Users} title="Demographics">
          {country.demographics || "No demographics data available."}
        </InfoSection>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {country.flagColors && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Palette className="w-5 h-5 text-blue-400" />
              <h2 className="text-lg font-semibold text-white">Flag Colors</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {country.flagColors.split(", ").map((color) => (
                <span
                  key={color}
                  className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-sm"
                >
                  {color}
                </span>
              ))}
            </div>
          </div>
        )}
        {country.neighbors && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Map className="w-5 h-5 text-blue-400" />
              <h2 className="text-lg font-semibold text-white">Neighbors</h2>
            </div>
            <p className="text-slate-300 text-sm">{country.neighbors}</p>
          </div>
        )}
      </div>

      {country.latitude && country.longitude && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Globe2 className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-semibold text-white">Coordinates</h2>
          </div>
          <p className="text-slate-300 text-sm">
            Latitude: {country.latitude.toFixed(4)}°, Longitude:{" "}
            {country.longitude.toFixed(4)}°
          </p>
        </div>
      )}
    </div>
  );
}
