import { pgTable, serial, text, integer, real, varchar, jsonb } from "drizzle-orm/pg-core";

export const countries = pgTable("countries", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  code: varchar("code", { length: 3 }).notNull().unique(),
  iso2: varchar("iso2", { length: 2 }).notNull(),
  continent: varchar("continent", { length: 50 }).notNull(),
  capital: varchar("capital", { length: 200 }),
  population: integer("population"),
  areaSqKm: real("area_sq_km"),
  gdpUsd: real("gdp_usd"),
  currency: varchar("currency", { length: 100 }),
  language: varchar("language", { length: 200 }),
  government: varchar("government", { length: 200 }),
  timezone: varchar("timezone", { length: 100 }),
  callingCode: varchar("calling_code", { length: 20 }),
  region: varchar("region", { length: 100 }),
  subregion: varchar("subregion", { length: 100 }),
  latitude: real("latitude"),
  longitude: real("longitude"),
  geography: text("geography"),
  climate: text("climate"),
  economy: text("economy"),
  history: text("history"),
  tourism: text("tourism"),
  demographics: text("demographics"),
  flagColors: text("flag_colors"),
  neighbors: text("neighbors"),
});

export type Country = typeof countries.$inferSelect;
export type NewCountry = typeof countries.$inferInsert;
