"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { geoNaturalEarth1, geoPath, geoGraticule } from "d3-geo";
import { feature } from "topojson-client";
import type { Geometry } from "geojson";

interface CountryFeature {
  type: "Feature";
  properties: {
    name: string;
    [key: string]: unknown;
  };
  geometry: Geometry;
  id?: string;
}

interface WorldMapProps {
  onSelectCountry?: (countryName: string) => void;
  highlightedCountries?: string[];
}

export default function WorldMap({ onSelectCountry, highlightedCountries = [] }: WorldMapProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [geoData, setGeoData] = useState<CountryFeature[] | null>(null);
  const [hoveredCountry, setHoveredCountry] = useState<string | null>(null);
  const [dimensions, setDimensions] = useState({ width: 960, height: 500 });

  useEffect(() => {
    const updateDimensions = () => {
      const container = svgRef.current?.parentElement;
      if (container) {
        const width = Math.min(container.clientWidth, 1200);
        setDimensions({ width, height: width * 0.52 });
      }
    };
    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

  useEffect(() => {
    fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json")
      .then((res) => res.json())
      .then((topology) => {
        const geojson = feature(topology, topology.objects.countries) as unknown as {
          type: "FeatureCollection";
          features: CountryFeature[];
        };
        setGeoData(geojson.features);
      })
      .catch((err) => {
        console.error("Failed to load map data:", err);
      });
  }, []);

  const projection = geoNaturalEarth1()
    .scale(dimensions.width / 5.5)
    .translate([dimensions.width / 2, dimensions.height / 2]);

  const path = geoPath().projection(projection);
  const graticule = geoGraticule();

  const handleClick = useCallback(
    (feature: CountryFeature) => {
      if (onSelectCountry) {
        onSelectCountry(feature.properties.name);
      }
    },
    [onSelectCountry]
  );

  if (!geoData) {
    return (
      <div className="flex items-center justify-center" style={{ height: dimensions.height }}>
        <div className="text-slate-400">Loading map...</div>
      </div>
    );
  }

  return (
    <svg
      ref={svgRef}
      width={dimensions.width}
      height={dimensions.height}
      viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
      className="w-full h-auto"
    >
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <rect width={dimensions.width} height={dimensions.height} fill="#0f172a" rx="8" />
      <path d={path(graticule()) || undefined} fill="none" stroke="#1e293b" strokeWidth="0.5" />
      <path d={path({ type: "Sphere" }) || undefined} fill="none" stroke="#334155" strokeWidth="1" />
      {geoData.map((feature, i) => {
        const name = feature.properties.name;
        const isHighlighted = highlightedCountries.includes(name);
        const isHovered = hoveredCountry === name;
        return (
          <path
            key={i}
            d={path(feature) || undefined}
            fill={isHighlighted ? "#3b82f6" : isHovered ? "#60a5fa" : "#1e293b"}
            stroke="#334155"
            strokeWidth={isHovered || isHighlighted ? "1" : "0.5"}
            className="cursor-pointer transition-colors duration-200"
            onMouseEnter={() => setHoveredCountry(name)}
            onMouseLeave={() => setHoveredCountry(null)}
            onClick={() => handleClick(feature)}
            filter={isHighlighted ? "url(#glow)" : undefined}
          />
        );
      })}
      {hoveredCountry && (
        <text
          x={dimensions.width / 2}
          y={dimensions.height - 20}
          textAnchor="middle"
          fill="#e2e8f0"
          fontSize="14"
          fontWeight="500"
        >
          {hoveredCountry}
        </text>
      )}
    </svg>
  );
}
