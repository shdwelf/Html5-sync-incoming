# 🌐 News Globe

A single-page HTML5 app that:

1. **Scrapes an OPML file from GitHub** at runtime
   ([`plenaryapp/awesome-rss-feeds` › World News](https://github.com/plenaryapp/awesome-rss-feeds/blob/master/recommended/with_category/News.opml))
2. **Polls every RSS feed** in the OPML on a rolling schedule
3. **Geocodes each new article** with a hybrid strategy:
   - First: an in-browser **gazetteer** of ~300 countries & major cities (fast, zero network)
   - Fallback: **OpenStreetMap Nominatim** (free, no key, rate-limited to ~1 req/sec)
4. **Plots events live on a D3 orthographic globe** with pulsing rings as stories arrive
5. **Pops up a thumbnail card** anchored to each event's location on the globe, with
   the article image, source chip, place chip, and headline (auto-dismisses after ~14 s
   — hover to keep it open). A subtle leader line connects the card to its dot.
6. **Scrolls a live news ticker** along the bottom of the globe with every incoming
   headline (hover to pause).
7. **Click anything** (dot · popup · ticker item · right-panel card) to open a
   full **detail modal** with hero image, full description excerpt, source, time,
   coordinates, and "Read full article" / "Fly globe here" buttons.

## Running it

Because browsers block `file://` cross-origin requests, serve the folder over HTTP. Any of these works:

```bash
# Python
python3 -m http.server 8000

# Node
npx serve .

# Or just open the live preview pane in this workspace
```

Then open <http://localhost:8000/news-globe/>.

## How geocoding works

For every new article, the title + description is lower-cased and scanned against the bundled
gazetteer (`gazetteer.js`). Names are sorted longest-first so "New York" is matched before
"York". If nothing matches, the title is scanned for capitalized phrases (likely place names)
which are sent — one at a time, with a polite 1.1 s delay — to OpenStreetMap Nominatim.

You can swap the OPML file by changing `OPML_URL` at the top of `app.js`. Any raw GitHub
`.opml` URL works.

## Files

| File                 | Purpose                                                      |
|----------------------|--------------------------------------------------------------|
| **`news-globe.html`**| **Single-file HTML5 build — everything inlined, just open it** |
| `index.html`         | Multi-file dev version (UI shell + CDN imports)             |
| `app.js`             | OPML/RSS pipeline, geocoder, globe rendering, animation     |
| `gazetteer.js`       | ~300 country & city coordinates for offline geocoding       |

> 💡 If you just want to use the app, only `news-globe.html` is needed.
> The other three files are the development source.

## Notes / known limits

- A free CORS proxy (`corsproxy.io`) is used to read RSS feeds from the browser, and
  `api.rss2json.com` does XML→JSON conversion. Both are public services with rate limits.
  For production, run your own backend that fetches & parses feeds server-side.
- The in-app workspace preview can't load CDN scripts (sandboxed iframe with no network).
  Open the served file in a normal browser to see it live.
- The OPML used (`recommended/with_category/News.opml`) is small (~11 feeds). Point
  `OPML_URL` at one of the country files (e.g. `countries/with_category/India.opml`) for
  more volume.
