/* News Globe — live OPML → RSS → geocode → orthographic D3 globe */
(() => {
  'use strict';

  // ====== CONFIG ======
  const OPML_URL =
    'https://raw.githubusercontent.com/plenaryapp/awesome-rss-feeds/master/recommended/with_category/News.opml';
  // CORS proxy (no key needed for basic usage)
  const CORS = (u) => 'https://corsproxy.io/?url=' + encodeURIComponent(u);
  // Free RSS->JSON service (no key)
  const RSS2JSON = (u) =>
    'https://api.rss2json.com/v1/api.json?rss_url=' + encodeURIComponent(u);
  // Nominatim fallback (used sparingly; rate-limited)
  const NOMINATIM = (q) =>
    'https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' +
    encodeURIComponent(q);

  const POLL_INTERVAL_MS = 90_000; // refresh each feed every 90s
  const FEEDS_PARALLEL = 4;        // concurrent feed fetches
  const NOMINATIM_GAP_MS = 1100;   // be polite (1 req/sec)
  const MAX_EVENT_AGE_MS = 1000 * 60 * 60 * 6; // 6h trail
  const MAX_FEED_PARSE_PER_TICK = 6;

  // ====== STATE ======
  const state = {
    feeds: [],            // {title, url}
    seenIds: new Set(),   // de-dup article guids
    events: [],           // {lat, lon, title, link, source, ts, place}
    feedCursor: 0,
    nominatimQueue: [],
    nominatimBusy: false,
    rotation: [0, -15],   // [lambda, phi]
    autoRotate: true,
    paused: false,
  };

  // ====== UI HELPERS ======
  const $ = (s) => document.querySelector(s);
  const log = (msg, type = 'info') => {
    const el = $('#log');
    const line = document.createElement('div');
    line.className = 'log-line log-' + type;
    const t = new Date().toLocaleTimeString();
    line.textContent = `[${t}] ${msg}`;
    el.prepend(line);
    while (el.children.length > 60) el.removeChild(el.lastChild);
  };
  const setStat = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };

  // ====== OPML LOADING ======
  async function loadOPML() {
    log('Fetching OPML from GitHub…');
    const res = await fetch(CORS(OPML_URL));
    if (!res.ok) throw new Error('OPML HTTP ' + res.status);
    const txt = await res.text();
    const doc = new DOMParser().parseFromString(txt, 'text/xml');
    const nodes = doc.querySelectorAll('outline[xmlUrl]');
    const feeds = [];
    nodes.forEach((n) => {
      const url = n.getAttribute('xmlUrl');
      const title = n.getAttribute('title') || n.getAttribute('text') || url;
      if (url) feeds.push({ title, url });
    });
    log(`Loaded ${feeds.length} feeds from OPML`, 'ok');
    return feeds;
  }

  // ====== RSS POLLING ======
  async function fetchFeed(feed) {
    try {
      const res = await fetch(RSS2JSON(feed.url));
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      if (data.status !== 'ok' || !data.items) return [];
      return data.items.map((it) => ({
        id: it.guid || it.link,
        title: it.title || '',
        description: stripHtml(it.description || ''),
        link: it.link,
        source: feed.title,
        ts: Date.parse(it.pubDate) || Date.now(),
      }));
    } catch (e) {
      // silent — many feeds rate-limit
      return [];
    }
  }

  function stripHtml(s) {
    const d = document.createElement('div');
    d.innerHTML = s;
    return (d.textContent || '').replace(/\s+/g, ' ').trim();
  }

  async function pollTick() {
    if (state.paused) return;
    const batch = [];
    for (let i = 0; i < MAX_FEED_PARSE_PER_TICK; i++) {
      if (!state.feeds.length) break;
      const f = state.feeds[state.feedCursor % state.feeds.length];
      state.feedCursor++;
      batch.push(f);
    }
    setStat('stat-polling', batch.map((b) => b.title).join(' · ').slice(0, 80) + '…');

    // run in small parallel groups
    for (let i = 0; i < batch.length; i += FEEDS_PARALLEL) {
      const slice = batch.slice(i, i + FEEDS_PARALLEL);
      const results = await Promise.all(slice.map(fetchFeed));
      results.flat().forEach(processArticle);
    }
  }

  function processArticle(item) {
    if (!item || !item.id) return;
    if (state.seenIds.has(item.id)) return;
    state.seenIds.add(item.id);
    if (state.seenIds.size > 5000) {
      // bound the set
      const arr = Array.from(state.seenIds);
      state.seenIds = new Set(arr.slice(-3000));
    }
    setStat('stat-articles', state.seenIds.size);

    const haystack = (item.title + ' ' + item.description).toLowerCase();
    const hit = gazetteerMatch(haystack);
    if (hit) {
      addEvent({ ...item, lat: hit.lat, lon: hit.lon, place: hit.name, source_geo: 'gazetteer' });
    } else {
      // queue Nominatim fallback on title only
      enqueueNominatim(item);
    }
  }

  // ====== GEOCODING ======
  function gazetteerMatch(text) {
    // GAZETTEER is sorted longest first
    for (const g of window.GAZETTEER) {
      // word-ish boundary check (allow punctuation/space around the key)
      const k = g.key;
      const idx = text.indexOf(k);
      if (idx === -1) continue;
      const before = idx === 0 ? ' ' : text[idx - 1];
      const after = idx + k.length >= text.length ? ' ' : text[idx + k.length];
      if (/[a-z0-9]/.test(before) || /[a-z0-9]/.test(after)) continue;
      return g;
    }
    return null;
  }

  function enqueueNominatim(item) {
    // pick capitalized phrases as candidate place names
    const cand = extractCandidates(item.title);
    if (!cand.length) return;
    state.nominatimQueue.push({ item, candidates: cand });
    if (state.nominatimQueue.length > 60) state.nominatimQueue.shift();
    processNominatim();
  }

  function extractCandidates(s) {
    if (!s) return [];
    // Find sequences of Capitalized Words (length 1-3)
    const re = /\b([A-Z][a-zA-Z\u00C0-\u017F]{2,}(?:\s+[A-Z][a-zA-Z\u00C0-\u017F]{2,}){0,2})\b/g;
    const out = [];
    let m;
    const stop = new Set([
      'The','New','Breaking','News','Live','Update','Report','Reuters','AP','BBC','CNN','Guardian',
      'World','International','Today','Yesterday','President','Minister','Prime','First','Last',
    ]);
    while ((m = re.exec(s)) && out.length < 3) {
      const v = m[1].trim();
      const first = v.split(' ')[0];
      if (stop.has(first)) continue;
      out.push(v);
    }
    return out;
  }

  async function processNominatim() {
    if (state.nominatimBusy) return;
    if (!state.nominatimQueue.length) return;
    state.nominatimBusy = true;
    while (state.nominatimQueue.length) {
      const job = state.nominatimQueue.shift();
      let found = null;
      for (const c of job.candidates) {
        try {
          const r = await fetch(CORS(NOMINATIM(c)), { headers: { 'Accept': 'application/json' } });
          if (r.ok) {
            const j = await r.json();
            if (j && j.length) {
              found = { lat: parseFloat(j[0].lat), lon: parseFloat(j[0].lon), name: j[0].display_name };
              break;
            }
          }
        } catch (e) { /* ignore */ }
        await sleep(NOMINATIM_GAP_MS);
      }
      if (found) {
        addEvent({ ...job.item, lat: found.lat, lon: found.lon, place: found.name.split(',')[0], source_geo: 'nominatim' });
      }
      await sleep(NOMINATIM_GAP_MS);
    }
    state.nominatimBusy = false;
  }

  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

  // ====== EVENTS ======
  function addEvent(ev) {
    ev.added = performance.now();
    state.events.unshift(ev);
    if (state.events.length > 400) state.events.length = 400;
    setStat('stat-events', state.events.length);
    addArticleCard(ev);
    log(`📍 ${ev.place} — ${ev.title.slice(0, 60)}…`, 'event');
    // briefly spin globe toward the event
    if (state.autoRotate) {
      flyTo(ev.lon, ev.lat);
    }
  }

  function addArticleCard(ev) {
    const feed = $('#articles');
    const card = document.createElement('article');
    card.className = 'card';
    card.dataset.lat = ev.lat;
    card.dataset.lon = ev.lon;
    card.innerHTML = `
      <div class="card-place">📍 ${escapeHtml(ev.place)} <span class="card-src">${escapeHtml(ev.source)}</span></div>
      <a class="card-title" href="${ev.link}" target="_blank" rel="noopener">${escapeHtml(ev.title)}</a>
      <div class="card-meta">${new Date(ev.ts).toLocaleString()} · ${ev.source_geo}</div>
    `;
    card.addEventListener('click', () => { state.autoRotate = false; flyTo(ev.lon, ev.lat, true); });
    feed.prepend(card);
    while (feed.children.length > 80) feed.removeChild(feed.lastChild);
  }

  function escapeHtml(s) {
    return (s || '').replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }

  // ====== D3 GLOBE ======
  let svg, projection, path, width, height;
  let landFeatures, countryFeatures;

  async function initGlobe() {
    const stage = $('#globe-stage');
    width = stage.clientWidth;
    height = stage.clientHeight;
    svg = d3.select(stage).append('svg').attr('width', width).attr('height', height);

    // gradient background sphere
    const defs = svg.append('defs');
    const grad = defs.append('radialGradient').attr('id', 'oceanGrad').attr('cx', '50%').attr('cy', '40%').attr('r', '70%');
    grad.append('stop').attr('offset', '0%').attr('stop-color', '#1b3a6b');
    grad.append('stop').attr('offset', '100%').attr('stop-color', '#04101f');

    const glow = defs.append('radialGradient').attr('id', 'glow').attr('cx', '50%').attr('cy', '50%').attr('r', '55%');
    glow.append('stop').attr('offset', '85%').attr('stop-color', 'rgba(80,160,255,0)');
    glow.append('stop').attr('offset', '100%').attr('stop-color', 'rgba(80,160,255,0.35)');

    projection = d3.geoOrthographic()
      .scale(Math.min(width, height) / 2.2)
      .translate([width / 2, height / 2])
      .clipAngle(90)
      .rotate(state.rotation);
    path = d3.geoPath(projection);

    // outer glow
    svg.append('circle').attr('cx', width/2).attr('cy', height/2)
      .attr('r', projection.scale() + 18).attr('fill', 'url(#glow)');

    // ocean
    svg.append('path').datum({ type: 'Sphere' })
      .attr('class', 'sphere').attr('d', path).attr('fill', 'url(#oceanGrad)');

    // graticule
    const graticule = d3.geoGraticule().step([20, 20]);
    svg.append('path').datum(graticule).attr('class', 'graticule').attr('d', path)
      .attr('fill', 'none').attr('stroke', 'rgba(120,180,255,0.12)').attr('stroke-width', 0.6);

    // landmass placeholder layer (drawn after data loads)
    svg.append('g').attr('class', 'land-layer');
    svg.append('g').attr('class', 'country-layer');
    svg.append('g').attr('class', 'event-layer');

    // load world topojson (Natural Earth via unpkg)
    try {
      const world = await fetch('https://unpkg.com/world-atlas@2/countries-110m.json').then((r) => r.json());
      landFeatures = topojson.feature(world, world.objects.land);
      countryFeatures = topojson.feature(world, world.objects.countries);
      drawWorld();
      log('Globe loaded', 'ok');
    } catch (e) {
      log('Could not load world topology (offline?)', 'warn');
    }

    enableDrag();
    window.addEventListener('resize', onResize);
    d3.timer(tick);
  }

  function drawWorld() {
    if (!landFeatures) return;
    svg.select('.land-layer').selectAll('path').remove();
    svg.select('.land-layer').append('path').datum(landFeatures)
      .attr('class', 'land').attr('d', path)
      .attr('fill', '#1f4a2a').attr('stroke', '#2c6b3d').attr('stroke-width', 0.4);
    svg.select('.country-layer').selectAll('path').remove();
    svg.select('.country-layer').selectAll('path').data(countryFeatures.features).enter()
      .append('path').attr('class', 'country').attr('d', path)
      .attr('fill', 'none').attr('stroke', 'rgba(255,255,255,0.08)').attr('stroke-width', 0.4);
  }

  function onResize() {
    const stage = $('#globe-stage');
    width = stage.clientWidth; height = stage.clientHeight;
    svg.attr('width', width).attr('height', height);
    projection.scale(Math.min(width, height) / 2.2).translate([width/2, height/2]);
    svg.selectAll('circle.glow').attr('cx', width/2).attr('cy', height/2);
    redrawStatic();
  }

  function redrawStatic() {
    svg.select('.sphere').attr('d', path);
    svg.select('.graticule').attr('d', path);
    svg.selectAll('.land').attr('d', path);
    svg.selectAll('.country').attr('d', path);
  }

  function enableDrag() {
    let v0, q0, r0;
    const drag = d3.drag()
      .on('start', (event) => {
        state.autoRotate = false;
        v0 = versor.cartesian(projection.invert([event.x, event.y]));
        q0 = versor(r0 = projection.rotate());
      })
      .on('drag', (event) => {
        const v1 = versor.cartesian(projection.rotate(r0).invert([event.x, event.y]));
        const q1 = versor.multiply(q0, versor.delta(v0, v1));
        projection.rotate(versor.rotation(q1));
        state.rotation = projection.rotate();
        redrawStatic();
      });
    svg.call(drag);
    svg.on('wheel', (event) => {
      event.preventDefault();
      const s = projection.scale();
      const ns = Math.max(150, Math.min(s * (event.deltaY < 0 ? 1.1 : 0.9), 1800));
      projection.scale(ns);
      redrawStatic();
    }, { passive: false });
  }

  // simple drag fallback using pointer events if versor missing
  if (!window.versor) {
    window.versor = (function () {
      function cartesian(e) { const l = e[0]*Math.PI/180, p = e[1]*Math.PI/180, cp = Math.cos(p); return [cp*Math.cos(l), cp*Math.sin(l), Math.sin(p)]; }
      function v(angles){ const [l,p,g]=angles.map(a=>a*Math.PI/360); const sl=Math.sin(l),cl=Math.cos(l),sp=Math.sin(p),cp=Math.cos(p),sg=Math.sin(g),cg=Math.cos(g); return [cl*cp*cg+sl*sp*sg,sl*cp*cg-cl*sp*sg,cl*sp*cg+sl*cp*sg,cl*cp*sg-sl*sp*cg]; }
      v.cartesian=cartesian;
      v.multiply=function(a,b){return[a[0]*b[0]-a[1]*b[1]-a[2]*b[2]-a[3]*b[3],a[0]*b[1]+a[1]*b[0]+a[2]*b[3]-a[3]*b[2],a[0]*b[2]-a[1]*b[3]+a[2]*b[0]+a[3]*b[1],a[0]*b[3]+a[1]*b[2]-a[2]*b[1]+a[3]*b[0]];};
      v.delta=function(v0,v1){const w=v0[0]*v1[0]+v0[1]*v1[1]+v0[2]*v1[2];if(w>0.9999999)return[1,0,0,0];const a=Math.acos(Math.max(-1,Math.min(1,w))),s=Math.sin(a/2)/Math.sin(a),x=[v0[1]*v1[2]-v0[2]*v1[1],v0[2]*v1[0]-v0[0]*v1[2],v0[0]*v1[1]-v0[1]*v1[0]];return[Math.cos(a/2),s*x[0],s*x[1],s*x[2]];};
      v.rotation=function(q){return[Math.atan2(2*(q[0]*q[1]+q[2]*q[3]),1-2*(q[1]*q[1]+q[2]*q[2]))*180/Math.PI,Math.asin(Math.max(-1,Math.min(1,2*(q[0]*q[2]-q[3]*q[1]))))*180/Math.PI,Math.atan2(2*(q[0]*q[3]+q[1]*q[2]),1-2*(q[2]*q[2]+q[3]*q[3]))*180/Math.PI];};
      return v;
    })();
  }

  // ====== ANIMATION ======
  let lastT = performance.now();
  let flyTarget = null;
  function flyTo(lon, lat, instant=false) {
    flyTarget = { lon, lat, started: performance.now(), duration: instant ? 0 : 1200, from: projection.rotate().slice() };
  }

  function tick(elapsed) {
    const now = performance.now();
    const dt = (now - lastT) / 1000;
    lastT = now;

    if (flyTarget) {
      const t = flyTarget.duration === 0 ? 1 : Math.min(1, (now - flyTarget.started) / flyTarget.duration);
      const e = easeInOut(t);
      const from = flyTarget.from;
      const targetLambda = -flyTarget.lon;
      const targetPhi = -flyTarget.lat;
      const lam = from[0] + shortestArc(from[0], targetLambda) * e;
      const phi = from[1] + (targetPhi - from[1]) * e;
      projection.rotate([lam, phi, 0]);
      state.rotation = projection.rotate();
      if (t >= 1) flyTarget = null;
    } else if (state.autoRotate) {
      const r = projection.rotate();
      projection.rotate([r[0] + dt * 6, r[1], r[2]]);
      state.rotation = projection.rotate();
    }
    redrawStatic();
    drawEvents(now);
  }

  function easeInOut(t) { return t < 0.5 ? 2*t*t : 1 - Math.pow(-2*t+2, 2)/2; }
  function shortestArc(a, b) {
    let d = ((b - a) % 360 + 540) % 360 - 180;
    return d;
  }

  function drawEvents(now) {
    const layer = svg.select('.event-layer');
    // prune
    state.events = state.events.filter((e) => (now - e.added) < MAX_EVENT_AGE_MS);
    const data = state.events;
    const sel = layer.selectAll('g.event').data(data, (d) => d.id);
    const enter = sel.enter().append('g').attr('class', 'event');
    enter.append('circle').attr('class', 'ring').attr('r', 0).attr('fill', 'none').attr('stroke', '#ff5e7a').attr('stroke-width', 1.5);
    enter.append('circle').attr('class', 'dot').attr('r', 2.5).attr('fill', '#ffd166').attr('stroke', '#fff').attr('stroke-width', 0.5);
    sel.exit().remove();

    layer.selectAll('g.event').each(function(d) {
      const g = d3.select(this);
      // visibility: only show if on visible hemisphere
      const c = projection([d.lon, d.lat]);
      const visible = isVisible(d.lon, d.lat);
      if (!c || !visible) { g.style('display', 'none'); return; }
      g.style('display', null).attr('transform', `translate(${c[0]},${c[1]})`);
      const age = (now - d.added) / 1000; // seconds
      // pulsing ring (resets every 3s)
      const phase = (age % 3) / 3;
      const r = 4 + phase * 22;
      const opacity = 1 - phase;
      g.select('.ring').attr('r', r).attr('stroke-opacity', opacity * 0.9);
      // fade dot as it ages over hours
      const ageHours = age / 3600;
      g.select('.dot').attr('fill-opacity', Math.max(0.3, 1 - ageHours / 6));
    });
  }

  function isVisible(lon, lat) {
    const r = projection.rotate();
    const lambda = -r[0] * Math.PI / 180;
    const phi = -r[1] * Math.PI / 180;
    const cx = Math.cos(phi) * Math.cos(lambda);
    const cy = Math.cos(phi) * Math.sin(lambda);
    const cz = Math.sin(phi);
    const a = lon * Math.PI / 180, b = lat * Math.PI / 180;
    const x = Math.cos(b) * Math.cos(a), y = Math.cos(b) * Math.sin(a), z = Math.sin(b);
    return (x*cx + y*cy + z*cz) > 0.05;
  }

  // ====== BOOT ======
  async function boot() {
    log('Booting News Globe…');
    await initGlobe();
    try {
      state.feeds = await loadOPML();
      setStat('stat-feeds', state.feeds.length);
    } catch (e) {
      log('OPML fetch failed: ' + e.message, 'err');
      // tiny fallback
      state.feeds = [
        { title: 'BBC World', url: 'http://feeds.bbci.co.uk/news/world/rss.xml' },
        { title: 'Reuters World', url: 'https://feeds.reuters.com/Reuters/worldNews' },
        { title: 'Al Jazeera', url: 'https://www.aljazeera.com/xml/rss/all.xml' },
        { title: 'Guardian World', url: 'https://www.theguardian.com/world/rss' },
      ];
      setStat('stat-feeds', state.feeds.length);
    }

    // Wire UI
    $('#btn-pause').addEventListener('click', () => {
      state.paused = !state.paused;
      $('#btn-pause').textContent = state.paused ? '▶ Resume' : '⏸ Pause';
    });
    $('#btn-rotate').addEventListener('click', () => {
      state.autoRotate = !state.autoRotate;
      $('#btn-rotate').textContent = state.autoRotate ? '🌐 Auto-rotate: ON' : '🌐 Auto-rotate: OFF';
    });
    $('#btn-clear').addEventListener('click', () => {
      state.events = []; $('#articles').innerHTML = '';
      setStat('stat-events', 0);
    });

    // Start polling
    pollTick();
    setInterval(pollTick, 15_000); // process a small batch every 15s; cycles through all feeds
  }

  boot();
})();
