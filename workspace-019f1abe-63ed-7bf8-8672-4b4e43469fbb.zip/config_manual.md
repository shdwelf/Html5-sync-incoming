# Filofax Technical Configuration Manual

## 1. X.25 Interface (Legacy Packet Switching)
To interface with X.25 in 2026, you cannot typically use a physical X.25 modem. Instead, use **X.25 over TCP (XOT)**.

- **XOT Gateway:** Set up an XOT gateway to translate X.25 packets into TCP/IP.
- **Configuration:** 
    - Terminal Type: ASCII / VT100
    - Baud Rate: 2400 or 9600 (simulated)
    - Addressing: Use DNIC (Data Network Identification Code) for routing.
- **Tymnet Emulation:** For the Filofax app, the Tymnet module simulates the `PLEASE LOG IN:` sequence and the `C:\>` prompt.
- **Active Infrastructure:** Specialized gateways like FarLinX and Cisco routers still support XOT for aviation and legacy industrial systems.

## 2. SSTV (Slow Scan Television) Modes
SSTV converts images into audio frequencies.

### Core Frequencies:
- **Sync Pulse:** 1200 Hz
- **Low Level (Black):** 1500 Hz
- **High Level (White):** 2300 Hz

### Common Modes:
- **Robot 24/36/72:** Fast, lower resolution. Used for quick checks.
- **Scottie 1/2:** High quality, standard for US amateur radio.
- **Martin 1/2:** Standard for European radio.
- **PD Modes:** Higher resolution, color differentiation.

### Implementation:
The Filofax app uses the **Web Audio API** to map pixel brightness to frequency. 
`Frequency = LowFreq + (HighFreq - LowFreq) * Brightness`

## 3. Prodigy Classic Access
The original Prodigy service is no longer active on phone lines, but **Prodigy Reloaded** provides a compatible backend.
- **Connection:** Download the original Prodigy Client and point it toward the Prodigy Reloaded servers.
- **Legacy Data:** Use `.DAT` cache files (like `STAGE.DAT`) to recover original content.

## 4. Banano Messaging (On-Chain)
Instead of a traditional mail server, this UX uses the Banano blockchain.
- **Method:** The "Message" is embedded into a transaction.
- **Signing:** The user's Banano private key signs the transaction, proving identity without a password.
- **SSTV Overlay:** For maximum nostalgia, messages can be encoded as SSTV audio clips and linked via the transaction metadata.

## 5. Leo Laporte / PBS IPTV Concept
Inspired by the PBS experiments, this involves embedding data into the VBI (Vertical Blanking Interval) or using IPTV streams to broadcast file-transfer packets.
- **Implementation:** Use a tool like `ffmpeg` to embed data in the video stream or use SSTV-style audio bursts during "dead air" in the stream to transmit images/files to viewers with the right software.

## 6. Fidonet & Telnet Gateways
Fidonet's store-and-forward nature is preserved through modern Telnet BBSes.
- **Access:** Use `telnetbbsguide.com` to find active nodes.
- **Gateways:** Many modern BBSes (running Synchronet or Mystic) act as gateways between the Internet (TCP/IP) and the legacy FidoNet echomail/netmail feeds.
- **Routing:** FidoNet uses a hierarchical routing system (Node -> Hub -> Region -> Zone). Messages are batched and transmitted during "Zone Mail Hour."
- **Bang-Paths:** Legacy UUCP routing uses "bang-paths" (e.g., `hostA!hostB!user`) to specify the exact path a message should take.
