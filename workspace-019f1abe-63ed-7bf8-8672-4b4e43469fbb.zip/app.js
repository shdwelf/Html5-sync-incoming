const bbsData = [
    { name: "The Lizard's Den", phone: "216-220-6394", city: "Cleveland, OH", year: "1994" },
    { name: "Brunswick Online", phone: "216-220-8214", city: "Cleveland, OH", year: "1995-1999" },
    { name: "Gandalf's Gallery", phone: "216-221-5783", city: "Cleveland, OH", year: "1994" },
    { name: "The Amiga Workbench", phone: "216-233-4292", city: "Lorain, OH", year: "1982-2001" },
    { name: "Lost Time BBS", phone: "216-237-2116", city: "Cleveland, OH", year: "1982-2001" },
    { name: "The Pueblo Towne Crier", phone: "303-543-0512", city: "Pueblo, CO", year: "1978-1989" },
    { name: "MileHi", phone: "303-582-0511", city: "Denver, CO", year: "1992-2009" },
];

const gopherData = {
    'gopher.floodgap.com': [
        { type: '1', label: 'Welcome to Floodgap', content: 'The premier Gopher proxy and archive.' },
        { type: '1', label: 'The Gopherverse', content: 'A map of all active Gopher holes.' },
        { type: '0', label: 'Jump to Tymnet', content: 'REDIRECT' },
    ],
    'sdf.org': [
        { type: '1', label: 'SDF Public Access UNIX', content: 'One of the oldest and largest active gopher holes.' },
        { type: '1', label: 'User Directory', content: 'A list of SDF users.' },
        { type: '1', label: 'Technical Docs', content: 'The art of UNIX.' },
    ],
    'quux.org': [
        { type: '1', label: 'Quux.org', content: 'A classic hobbyist Gopher site.' },
        { type: '1', label: 'The Gopher Project', content: 'Software for the modern Gopher enthusiast.' },
    ]
};

let currentGopherHost = 'gopher.floodgap.com';
let fidoQueue = [];

function toggleMenu() {
    document.getElementById('main-sidebar').classList.toggle('active');
}

function showPage(pageId) {
    document.querySelectorAll('.page, #welcome-page').forEach(p => p.style.display = 'none');
    const page = document.getElementById(pageId + '-page');
    if (page) page.style.display = 'block';
    
    document.getElementById('main-sidebar').classList.remove('active');
    
    if (pageId === 'bbs') {
        loadBBS();
    } else if (pageId === 'gopher') {
        loadGopher();
    } else if (pageId === 'creator') {
        updatePreview();
    } else if (pageId === 'banano') {
        generateNewWallet();
    } else if (pageId === 'fido') {
        updateFidoQueue();
    }
}

function loadBBS() {
    const list = document.getElementById('bbs-list');
    list.innerHTML = '';
    bbsData.forEach(bbs => {
        const div = document.createElement('div');
        div.className = 'bbs-item';
        div.style.borderBottom = '1px solid #ccc';
        div.style.padding = '5px 0';
        div.innerHTML = `<strong>${bbs.name}</strong> - ${bbs.phone} (${bbs.city}, ${bbs.year})`;
        list.appendChild(div);
    });
}

function loadGopher() {
    const hostEl = document.getElementById('gopher-host');
    const content = document.getElementById('gopher-content');
    hostEl.innerText = currentGopherHost;
    content.innerHTML = '';
    
    const items = gopherData[currentGopherHost] || [];
    items.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = 'gopher-item';
        div.innerText = `[${item.type}] ${item.label}`;
        div.onclick = () => {
            if (item.content === 'REDIRECT') {
                showPage('tymnet');
            } else {
                alert(`Gopher Content from ${currentGopherHost}: ${item.content}`);
            }
        };
        content.appendChild(div);
    });
    
    const switcher = document.createElement('div');
    switcher.style.marginTop = '20px';
    switcher.innerHTML = `<strong>Switch Host:</strong> `;
    Object.keys(gopherData).forEach(host => {
        const btn = document.createElement('button');
        btn.innerText = host;
        btn.style.marginRight = '5px';
        btn.onclick = () => {
            currentGopherHost = host;
            loadGopher();
        };
        switcher.appendChild(btn);
    });
    content.appendChild(switcher);
}

function addRetroElement(type) {
    const preview = document.getElementById('preview-window');
    if (type === 'marquee') {
        preview.innerHTML += `<marquee>NEW RETRO TEXT!</marquee>`;
    } else if (type === 'blink') {
        preview.innerHTML += `<span style="text-decoration: blink;">BLINKING TEXT!</span> `;
    } else if (type === 'image') {
        preview.innerHTML += `<img src="https://web.archive.org/web/20091027083155im_/http://geocities.com/Athens/Olympus/7771/undercon.gif" width="100">`;
    }
}

function updatePreview() {
    const preview = document.getElementById('preview-window');
    const bg = document.getElementById('page-bg').value;
    const title = document.getElementById('page-title').value || "My Cool Page";
    preview.style.backgroundColor = bg;
    preview.innerHTML = `<h1>${title}</h1>`;
}

document.getElementById('page-bg')?.addEventListener('input', updatePreview);
document.getElementById('page-title')?.addEventListener('input', updatePreview);

function exportRetroPage() {
    const bg = document.getElementById('page-bg').value;
    const title = document.getElementById('page-title').value;
    const content = document.getElementById('preview-window').innerHTML;
    const html = `<html><body style="background-color:${bg}"><h1>${title}</h1>${content}</body></html>`;
    const blob = new Blob([html], {type: 'text/html'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'retro_page.html';
    a.click();
}

async function generateSSTVAudio() {
    const fileInput = document.getElementById('sstv-image');
    const status = document.getElementById('sstv-status');
    const player = document.getElementById('sstv-player');
    if (!fileInput.files[0]) return alert("Please select an image first!");
    status.innerText = "Encoding image to Martin 1 tones...";
    const img = new Image();
    img.src = URL.createObjectURL(fileInput.files[0]);
    img.onload = async () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 320;
        canvas.height = 256;
        ctx.drawImage(img, 0, 0, 320, 256);
        const imageData = ctx.getImageData(0, 0, 320, 256).data;
        const sampleRate = 44100;
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const syncFreq = 1200, lowFreq = 1500, highFreq = 2300, samplesPerPixel = 100;
        const totalSamples = (256 * (320 + 1)) * samplesPerPixel;
        const buffer = audioCtx.createBuffer(1, totalSamples, sampleRate);
        const channelData = buffer.getChannelData(0);
        let offset = 0;
        for (let y = 0; y < 256; y++) {
            for (let i = 0; i < samplesPerPixel; i++) {
                channelData[offset++] = Math.sin(2 * Math.PI * syncFreq * (offset / sampleRate));
            }
            for (let x = 0; x < 320; x++) {
                const idx = (y * 320 + x) * 4;
                const brightness = (imageData[idx] + imageData[idx+1] + imageData[idx+2]) / 3 / 255;
                const freq = lowFreq + (highFreq - lowFreq) * brightness;
                for (let i = 0; i < samplesPerPixel; i++) {
                    channelData[offset++] = Math.sin(2 * Math.PI * freq * (offset / sampleRate));
                }
            }
        }
        const wavBlob = bufferToWav(buffer);
        player.src = URL.createObjectURL(wavBlob);
        player.style.display = 'block';
        status.innerText = "Encoding Complete!";
    };
}

function bufferToWav(buffer) {
    const length = buffer.length * 2;
    const bufferArr = new ArrayBuffer(44 + length);
    const view = new DataView(bufferArr);
    const writeString = (offset, string) => {
        for (let i = 0; i < string.length; i++) view.setUint8(offset + i, string.charCodeAt(i));
    };
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, buffer.sampleRate, true);
    view.setUint32(28, buffer.sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length, true);
    const data = buffer.getChannelData(0);
    let offset = 44;
    for (let i = 0; i < data.length; i++) {
        const s = Math.max(-1, Math.min(1, data[i]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        offset += 2;
    }
    return new Blob([bufferArr], { type: 'audio/wav' });
}

// FidoNet Logic
function queueFidoMail() {
    const dest = document.getElementById('fido-dest').value;
    const msg = document.getElementById('fido-msg').value;
    if (!dest || !msg) return alert("Missing destination or message!");
    
    fidoQueue.push({ dest, msg, status: 'QUEUED', id: Date.now() });
    document.getElementById('fido-dest').value = '';
    document.getElementById('fido-msg').value = '';
    updateFidoQueue();
}

function updateFidoQueue() {
    const list = document.getElementById('fido-queue-list');
    list.innerHTML = '';
    fidoQueue.forEach(item => {
        const li = document.createElement('li');
        li.className = `queue-item ${item.status === 'SENT' ? 'sent' : ''}`;
        li.innerText = `To: ${item.dest} | Status: ${item.status}`;
        list.appendChild(li);
    });
}

async function processFidoMail() {
    const log = document.getElementById('fido-log');
    if (!log) return;
    
    const pending = fidoQueue.filter(i => i.status === 'QUEUED');
    if (pending.length === 0) return;
    
    log.innerText = "--- ZONE MAIL HOUR STARTED ---\n";
    
    for (let item of pending) {
        const hops = item.dest.split('!');
        log.innerText += `\nProcessing mail to ${item.dest}...`;
        
        for (let i = 0; i < hops.length - 1; i++) {
            await new Promise(r => setTimeout(r, 800));
            log.innerText += `\n  Hop ${i+1}: ${hops[i]} -> ${hops[i+1]} (Handshake OK)`;
        }
        
        await new Promise(r => setTimeout(r, 500));
        log.innerText += `\n  DELIVERED to ${hops[hops.length-1]}\n`;
        item.status = 'SENT';
    }
    
    log.innerText += `\n--- ZONE MAIL HOUR ENDED ---\nIdle...`;
    updateFidoQueue();
}

setInterval(processFidoMail, 30000);

function generateNewWallet() {
    const addrEl = document.getElementById('wallet-addr');
    const seed = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const addr = "ban_" + btoa(seed).substring(0, 34);
    addrEl.innerText = "Address: " + addr;
    drawMonKey();
}

function drawMonKey() {
    const canvas = document.getElementById('monkey-canvas');
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 64, 64);
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
    ctx.fillStyle = colors[Math.floor(Math.random() * colors.length)];
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            if (Math.random() > 0.5) ctx.fillRect(i * 16, j * 16, 16, 16);
        }
    }
}

function sendBananoMessage() {
    const addr = document.getElementById('banano-addr').value;
    const msg = document.getElementById('banano-msg').value;
    if (!addr || !msg) return alert("Please enter address and message!");
    const txList = document.getElementById('tx-list');
    const li = document.createElement('li');
    li.innerText = `TX: ${addr.substring(0, 10)}... | Msg: ${msg.substring(0, 20)}... | Status: SIGNED`;
    txList.prepend(li);
    alert("Transaction signed with Banano private key and broadcast to network!");
}

let tymnetConnected = false;
let tymnetHost = "";
function handleTymnetInput(e) {
    if (e.key === 'Enter') {
        const input = document.getElementById('tymnet-input');
        const output = document.getElementById('tymnet-output');
        const cmd = input.value.trim();
        input.value = '';
        output.innerText += `\n> ${cmd}`;
        if (cmd === '*exit') {
            output.innerText += `\nDISCONNECTING... \nSESSIONS CLOSED. \n\nXOT PAD Ready. \nType *call [host] to connect or *exit to leave.`;
            tymnetConnected = false;
        } else if (cmd.startsWith('*call ')) {
            const host = cmd.substring(6);
            output.innerText += `\nDIALING ${host}...`;
            setTimeout(() => {
                output.innerText += `\nCARRIER DETECTED. \nCONNECTED TO HOST ${host}. \nPLEASE LOG IN:`;
                tymnetConnected = true;
            }, 1000);
        } else if (tymnetConnected) {
            output.innerText += `\n[HOST ${tymnetHost}] Echo: ${cmd}`;
        } else {
            output.innerText += `\nINVALID COMMAND. TRY *call [host]`;
        }
        output.scrollTop = output.scrollHeight;
    }
}

function connectTymnet() {
    const host = document.getElementById('tymnet-host').value;
    const output = document.getElementById('tymnet-output');
    if (!host) return alert("Enter Host Number!");
    output.innerText = `\nDIALING ${host} via XOT...`;
    setTimeout(() => {
        output.innerText += `\nCARRIER DETECTED. \nCONNECTED TO HOST ${host}. \nPLEASE LOG IN:`;
        tymnetConnected = true;
        tymnetHost = host;
    }, 1500);
}

setInterval(() => {
    const term = document.getElementById('terminal-output');
    if (term && !tymnetConnected) {
        const text = term.innerText;
        if (text.endsWith('_')) term.innerText = text.slice(0, -1);
        else term.innerText = text + '_';
    }
}, 500);
