
    Hello!

    Since there are no need for docs, this read-me file should do it.


    TIPS
    ~~~~
        1 - Compress you file BEFORE encrypting it, if you  will  want
            to have the benefit of compression.
            Encrypted  files  are NOT compressible... So do-it BEFORE!
            An Extra benefit is that compressors are also archivers so
            you will place a lot of files in one smaller ciphered file

        2 - Use LONG passphrases,  since the security of a  Good crypt
            algorithm depends on the passphrase and its  length.  This
            program   can   have   passphrases  up  to  576  bits  !!!

        3 - To increase  even further  your passphrase safety  you may
            then COMPRESS your files.
            Compressed files are very much like encrypted files except
            for  the header, but even if BLW-CBC hadn't be implemented
            the in CBC mode the result would still be VERY  effective!

        4 - The original file is still on your disk...  If that is NOT
            in your idea, then use Norton Utilities to Erase the  file
            and  every  non  used  disk  space...  You  may  have data
            residues somewhere on the  disk, and certainly on RAM.

        5 - Your Computer MAY not be safe SO your typing MAY be loged.

        ==> IT'S UPON YOU THESE SECURITY CIRCUMSTANCES.



    WARNING
    ~~~~~~~

            It is possible to create a Quantum Computer  that solves a
            crypto problem. It may already exist, and probably does...

               MEANING:
            Pure mathematical cipher, no matter how powerful, like the
            case of RijnDael (alias: AES)

               SOLUTIONS:
            a) Use a less powerful Cipher but with random PBoxes, like
               Blowfish or Blowfish based like Cobra or DNA-Blowfish.

            b) Use a COMPRESSOR  like RAR, ARJ, ZIP or LHA ... to hide
               your info will be inside, protected and you will also
               save  valuable disk space.

               The ideal would be to have streamed compressed data with
               NO references to the method or filenames inside... just
               like random data...



    HOME
    ~~~~
            It can get it at  http://www.afn.org/~afn21533/tinyaes.zip
            ... going to my site in http://planeta.ip.pt/~ip200075/ or
            ... going trough my Site Alias as http://www.factor-h.com/




    CREDITS
    ~~~~~~~
            AES algorithm was made in Belgium enhancing SQUARE cipher.

            TinyAES Version's Author is: "Robert Durnal" from the USA.

            This file was checked and distributed from his HomePage in
            http://www.afn.org/~afn21533/  by  "Dutra de Lacerda" from
            Portugal as a contribute to the dignity of the Human Kind.



    MOTIVATION
    ~~~~~~~~~~
            Mankind is usually seen as a child.  Childs need education
            while they grow and as they grow to become healthy adults.

            Therefore communication and privacy are important subjects.
            Usually because there's no growth without individuality or
            cooperation.

            A different strategy to deal with childhood is control but
            with it's static nature results in negating growth.

            But Mankind, like its individuals, is more than an evolved
            variation of insect societies. Civilizations are more like
            individuals... and they also suffer the same problems...

            ...

            Cryptography is a way to keep privacy, protect information
            and, as a result, to enhance individuality and cooperation
            and also to be a reference to the ownership of thoughts.

            Anyone trying to prohibit this privacy/ownership is simply
            saying: "*I* do not authorize *YOU* to think/say/own those
            informations"  OR  "You are a child and I'm YOUR tutor"...

            ...


            We hope that the seekers of control understand that "Peace
            can not be obtained by control but by respect + education,
            not twisted by propaganda, and by respecting and enhancing
            respect for human dignity above all words.

            ...


            This 20th was one of technological growth but that was all
            there was to see... Old recipes where used to new problems
            like the old "Bread and Circus" formula and the result was
            not a very good one... The lack of growth in mankind terms
            can only be seen as a result of a bad strategy... One that
            calls to harden positions... not to solve the problem.

            ...

            Creating a world as a mix of "1984", "Brave New World" and
            "RollerBall" (the movie) does not seems, at least to me, a
            solution to anything... It seems more to be a new problem.

            The inertia of Human Toughs is huge.
            This is usually reflected by pride and illusion.
            As when someone say to justify it's errors:
             - "We are the good guys"
            Obviously this is an invitation to all sorts of crimes and
            to extremize the problems and, again, creating new ones.

            The real reason to such behavior may be:
             - "Pride, Fear and Stupidity" ...
            Stupidity because  being on the top doesn't make the World
            a safer place for nobody.

            ...

            But in the end we are all responsible for we accepted this
            "modus vivendi" and a twisted, and also sterile, view over
            our reality... and thus maintain it! In other terms:

            - It become our virtual-reality, reflected and feed by the
              Media as measure, and mean, of our acceptance!

            Thus we are called, not to react, but to wake up.
            To make a U-turn and look to the Essentials...
            To search for the lost TRUE values. They are more and more
            evident as their absence becomes more painful.

            ...

            Those are the reasons for spreading this little program.
            Now go outside and look the sky ! Search the good stars.


    Cordially,
    Dutra Lacerda

---
       [E-Mail] dutra.lacerda@mail.telepac.pt
    [Alternate] dulac@ip.pt
    [Home-Page] http://planeta.ip.pt/~ip200075/
        [Alias] http://www.factor-h.com/
---

TagLine: Usually the Solution is part of the Problem.

---
