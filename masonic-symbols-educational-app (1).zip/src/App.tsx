import { useEffect, useMemo, useState } from "react";
import { cn } from "./utils/cn";

type GaugePhaseId = "service" | "work" | "rest";
type SymbolGroupId = "tools" | "architecture" | "celestial" | "ritual";

type GaugePhase = {
  id: GaugePhaseId;
  title: string;
  hours: string;
  summary: string;
  detail: string;
  start: number;
  end: number;
  ringColor: string;
  softColor: string;
  borderColor: string;
};

type SymbolItem = {
  id: string;
  number: number;
  name: string;
  group: SymbolGroupId;
  icon: string;
  teaches: string;
  description: string;
  visualCue: string;
  keywords: string[];
};

const gaugePhases: GaugePhase[] = [
  {
    id: "service",
    title: "Service & duty",
    hours: "Hours 1–8",
    summary: "Eight hours are devoted to service of God and distressed worthy brethren.",
    detail:
      "In symbolic teaching, this block represents duty, conscience, charity, and care for obligations beyond the self.",
    start: 0,
    end: 7,
    ringColor: "#0f766e",
    softColor: "bg-teal-500/10 text-teal-200",
    borderColor: "border-teal-400/30",
  },
  {
    id: "work",
    title: "Work & vocation",
    hours: "Hours 9–16",
    summary: "Eight hours are reserved for labor, trade, and the ordinary duties of life.",
    detail:
      "This portion emphasizes disciplined effort, craftsmanship, usefulness, and the honorable earning of a livelihood.",
    start: 8,
    end: 15,
    ringColor: "#4338ca",
    softColor: "bg-indigo-500/10 text-indigo-200",
    borderColor: "border-indigo-400/30",
  },
  {
    id: "rest",
    title: "Refreshment & sleep",
    hours: "Hours 17–24",
    summary: "Eight hours are set aside for refreshment, restoration, and sleep.",
    detail:
      "The lesson is balance: rest is not laziness, but a necessary part of a well-governed and sustainable life.",
    start: 16,
    end: 23,
    ringColor: "#d97706",
    softColor: "bg-amber-500/10 text-amber-200",
    borderColor: "border-amber-400/30",
  },
];

const groupMeta: Record<
  SymbolGroupId,
  {
    label: string;
    accent: string;
    border: string;
    soft: string;
  }
> = {
  tools: {
    label: "Working tools & core emblems",
    accent: "text-sky-300",
    border: "border-sky-400/25",
    soft: "bg-sky-500/10",
  },
  architecture: {
    label: "Architecture & geometry",
    accent: "text-emerald-300",
    border: "border-emerald-400/25",
    soft: "bg-emerald-500/10",
  },
  celestial: {
    label: "Celestial & universal icons",
    accent: "text-amber-300",
    border: "border-amber-400/25",
    soft: "bg-amber-500/10",
  },
  ritual: {
    label: "Ritualistic & esoteric symbols",
    accent: "text-rose-300",
    border: "border-rose-400/25",
    soft: "bg-rose-500/10",
  },
};

const symbols: SymbolItem[] = [
  {
    id: "square",
    number: 1,
    name: "The Square",
    group: "tools",
    icon: "square",
    teaches: "Square your actions with virtue and fairness.",
    description:
      "A builder's square becomes a moral image: actions should meet the standard of honesty, justice, and self-command.",
    visualCue: "A right angle or carpenter's square, often paired with compasses.",
    keywords: ["virtue", "fairness", "morality", "right angle"],
  },
  {
    id: "compasses",
    number: 2,
    name: "The Compasses",
    group: "tools",
    icon: "compasses",
    teaches: "Keep passions and desires within due bounds.",
    description:
      "The compasses suggest restraint, reminding the learner that freedom is strengthened by self-discipline.",
    visualCue: "Two hinged legs used to draw circles or measure distance.",
    keywords: ["restraint", "discipline", "bounds", "circle"],
  },
  {
    id: "letter-g",
    number: 3,
    name: "The Letter 'G'",
    group: "tools",
    icon: "letter-g",
    teaches: "Unites Geometry with reverence for God.",
    description:
      "The emblem commonly points to geometry as a foundation of the craft and to the Grand Architect in spiritual reflection.",
    visualCue: "A single capital G placed at the center of geometric emblems.",
    keywords: ["geometry", "god", "grand architect"],
  },
  {
    id: "gavel",
    number: 4,
    name: "The Common Gavel",
    group: "tools",
    icon: "gavel",
    teaches: "Chip away vice, rough habits, and moral excess.",
    description:
      "As a workman's tool shapes stone, conscience is imagined as shaping character through effort and correction.",
    visualCue: "A short-handled striking tool with a block-like head.",
    keywords: ["conscience", "correction", "discipline", "character"],
  },
  {
    id: "gauge",
    number: 5,
    name: "The 24-Inch Gauge",
    group: "tools",
    icon: "gauge",
    teaches: "Use time deliberately and live in balanced proportion.",
    description:
      "Its 24 parts represent the 24 hours of the day and form one of the clearest time-management lessons in Freemasonry.",
    visualCue: "A measuring rule marked into equal divisions.",
    keywords: ["time", "hours", "discipline", "balance"],
  },
  {
    id: "trowel",
    number: 6,
    name: "The Trowel",
    group: "tools",
    icon: "trowel",
    teaches: "Spread the cement of brotherly love and affection.",
    description:
      "A practical masonry tool becomes a social metaphor for unity, reconciliation, and mutual goodwill.",
    visualCue: "A flat triangular blade with a handle.",
    keywords: ["brotherly love", "unity", "affection", "cement"],
  },
  {
    id: "plumb",
    number: 7,
    name: "The Plumb",
    group: "tools",
    icon: "plumb",
    teaches: "Stand upright in integrity and justice.",
    description:
      "Because a plumb line reveals true vertical alignment, it is used to symbolize moral uprightness and inner honesty.",
    visualCue: "A hanging line or weight indicating perfect verticality.",
    keywords: ["uprightness", "integrity", "justice", "vertical"],
  },
  {
    id: "level",
    number: 8,
    name: "The Level",
    group: "tools",
    icon: "level",
    teaches: "Remember the equality of all human beings.",
    description:
      "The level compares surfaces on a common plane and, symbolically, urges humility and equality before the Creator.",
    visualCue: "A horizontal leveling tool or frame.",
    keywords: ["equality", "humility", "balance", "level"],
  },
  {
    id: "rough-ashlar",
    number: 9,
    name: "The Rough Ashlar",
    group: "architecture",
    icon: "rough-ashlar",
    teaches: "Represents the natural and unfinished self.",
    description:
      "This unshaped stone stands for human potential before education, discipline, and moral refinement.",
    visualCue: "An irregular stone block with jagged edges.",
    keywords: ["potential", "unfinished", "natural state", "stone"],
  },
  {
    id: "perfect-ashlar",
    number: 10,
    name: "The Perfect Ashlar",
    group: "architecture",
    icon: "perfect-ashlar",
    teaches: "Represents the polished self improved by study and discipline.",
    description:
      "A squared and finished stone symbolizes the aspirational result of education, self-governance, and practiced virtue.",
    visualCue: "A clean-cut rectangular stone block.",
    keywords: ["improvement", "education", "discipline", "refinement"],
  },
  {
    id: "pillars",
    number: 11,
    name: "The Pillars (Boaz & Jachin)",
    group: "architecture",
    icon: "pillars",
    teaches: "Convey strength, establishment, and sacred memory.",
    description:
      "Often linked to Solomon's Temple, the paired columns evoke stability, threshold, and inherited tradition.",
    visualCue: "Two standing columns with simple capitals and bases.",
    keywords: ["strength", "establishment", "solomon", "columns"],
  },
  {
    id: "winding-staircase",
    number: 12,
    name: "The Winding Staircase",
    group: "architecture",
    icon: "winding-staircase",
    teaches: "Learning is a gradual ascent toward greater light.",
    description:
      "The staircase serves as an allegory for progress, study, and the layered movement from ignorance toward understanding.",
    visualCue: "A spiral or turning stair rising upward.",
    keywords: ["progress", "learning", "ascent", "journey"],
  },
  {
    id: "trestleboard",
    number: 13,
    name: "The Trestleboard",
    group: "architecture",
    icon: "trestleboard",
    teaches: "Live by a wise design rather than by accident.",
    description:
      "The master's drawing board symbolizes ordered plans, instruction, scripture, and the designs woven into creation.",
    visualCue: "A board, slate, or drafting surface holding drawn plans.",
    keywords: ["plan", "design", "instruction", "blueprint"],
  },
  {
    id: "euclid",
    number: 14,
    name: "The 47th Problem of Euclid",
    group: "architecture",
    icon: "euclid",
    teaches: "Honor geometry, reason, and the arts and sciences.",
    description:
      "This famous theorem is treated as a tribute to intellectual order and the beauty of mathematical truth.",
    visualCue: "A right triangle with measured sides or diagram lines.",
    keywords: ["geometry", "science", "triangle", "theorem"],
  },
  {
    id: "all-seeing-eye",
    number: 15,
    name: "The All-Seeing Eye",
    group: "celestial",
    icon: "all-seeing-eye",
    teaches: "Thoughts and deeds are never hidden from divine observation.",
    description:
      "The eye reinforces accountability, reminding the student to act as if every private intention were visible.",
    visualCue: "A single watchful eye often enclosed in rays or a triangle.",
    keywords: ["providence", "accountability", "observation", "eye"],
  },
  {
    id: "blazing-star",
    number: 16,
    name: "The Blazing Star",
    group: "celestial",
    icon: "blazing-star",
    teaches: "Divine guidance shines through the journey of life.",
    description:
      "Radiant and central, the star is read as a sign of providence, illumination, and directional hope.",
    visualCue: "A bright multi-pointed star with surrounding rays.",
    keywords: ["guidance", "providence", "light", "star"],
  },
  {
    id: "sun-moon",
    number: 17,
    name: "The Sun and the Moon",
    group: "celestial",
    icon: "sun-moon",
    teaches: "Order, rhythm, and balance govern lodge and life.",
    description:
      "These paired heavenly bodies symbolize recurring cycles, governance, and the harmony of complementary forces.",
    visualCue: "A radiant sun balanced with a crescent moon.",
    keywords: ["balance", "cycle", "governance", "nature"],
  },
  {
    id: "beehive",
    number: 18,
    name: "The Beehive",
    group: "celestial",
    icon: "beehive",
    teaches: "Industry and cooperative labor strengthen the whole community.",
    description:
      "The beehive presents work as collective, systematic, and beneficial when each member contributes.",
    visualCue: "A hive shape surrounded by small bees or flight lines.",
    keywords: ["industry", "labor", "community", "cooperation"],
  },
  {
    id: "apron",
    number: 19,
    name: "The White Apron",
    group: "ritual",
    icon: "apron",
    teaches: "Purity of conduct and honorable labor are marks of dignity.",
    description:
      "Often described as the badge of a Mason, the apron evokes innocence, service, and honorable identity.",
    visualCue: "A simple apron with flap and tied sides.",
    keywords: ["purity", "honor", "badge", "conduct"],
  },
  {
    id: "cable-tow",
    number: 20,
    name: "The Cable Tow",
    group: "ritual",
    icon: "cable-tow",
    teaches: "Obligation and commitment bind a person to duty.",
    description:
      "The cord represents a pledged connection to moral responsibilities and to one's obligations toward brethren.",
    visualCue: "A coiled rope or cord looped into a symbolic line.",
    keywords: ["obligation", "duty", "rope", "commitment"],
  },
  {
    id: "acacia",
    number: 21,
    name: "The Sprig of Acacia",
    group: "ritual",
    icon: "acacia",
    teaches: "The soul endures beyond material life.",
    description:
      "This evergreen image is commonly read as a sign of immortality, memory, and hope beyond death.",
    visualCue: "A small leafy branch or sprig.",
    keywords: ["immortality", "hope", "memory", "evergreen"],
  },
  {
    id: "coffin-shovel",
    number: 22,
    name: "The Coffin and Shovel",
    group: "ritual",
    icon: "coffin-shovel",
    teaches: "Meditate on mortality and the use of your remaining time.",
    description:
      "These emblems turn attention toward death, accountability, and the urgency of living meaningfully.",
    visualCue: "A coffin form beside a shovel or spade.",
    keywords: ["mortality", "time", "reflection", "death"],
  },
  {
    id: "anchor-ark",
    number: 23,
    name: "The Anchor and Ark",
    group: "ritual",
    icon: "anchor-ark",
    teaches: "Hope should be steady and securely grounded.",
    description:
      "The combined image joins safe passage with steadfast hope through life's uncertainty and storms.",
    visualCue: "An anchor and a small vessel or ark-like hull.",
    keywords: ["hope", "security", "voyage", "steadfastness"],
  },
  {
    id: "handshake",
    number: 24,
    name: "The Handshake (Grip)",
    group: "ritual",
    icon: "handshake",
    teaches: "Recognition is tied to trust, fellowship, and mutual respect.",
    description:
      "Without discussing private details, the handshake is broadly understood as a token of fellowship and identification.",
    visualCue: "Two hands meeting in agreement.",
    keywords: ["recognition", "fellowship", "trust", "token"],
  },
];

function getPhase(hour: number) {
  return gaugePhases.find((phase) => hour >= phase.start && hour <= phase.end) ?? gaugePhases[0];
}

function SymbolIcon({ icon, className }: { icon: string; className?: string }) {
  const shared = {
    viewBox: "0 0 64 64",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2.4,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className,
  };

  switch (icon) {
    case "square":
      return (
        <svg {...shared}>
          <path d="M14 48V16h34" />
          <path d="M18 44h26" opacity="0.45" />
          <path d="M18 38h18" opacity="0.45" />
        </svg>
      );
    case "compasses":
      return (
        <svg {...shared}>
          <path d="M32 14 19 46" />
          <path d="M32 14 45 46" />
          <path d="M25 30h14" />
          <circle cx="32" cy="14" r="3" />
        </svg>
      );
    case "letter-g":
      return (
        <svg {...shared}>
          <circle cx="32" cy="32" r="20" opacity="0.25" />
          <path d="M40 25a12 12 0 1 0 0 14h-8" />
          <path d="M40 39v-7h6" />
        </svg>
      );
    case "gavel":
      return (
        <svg {...shared}>
          <rect x="16" y="18" width="18" height="10" rx="2" />
          <path d="M31 27 47 43" />
          <path d="M20 34h18" />
        </svg>
      );
    case "gauge":
      return (
        <svg {...shared}>
          <rect x="12" y="26" width="40" height="12" rx="3" />
          {Array.from({ length: 11 }).map((_, index) => {
            const x = 16 + index * 3.2;
            const long = index % 2 === 0;
            return <path key={index} d={`M${x} 26v${long ? 8 : 5}`} />;
          })}
        </svg>
      );
    case "trowel":
      return (
        <svg {...shared}>
          <path d="M18 36 34 20l12 12-16 12Z" />
          <path d="M16 38 10 44" />
          <path d="M10 44h10" />
        </svg>
      );
    case "plumb":
      return (
        <svg {...shared}>
          <path d="M32 14v28" />
          <path d="M24 14h16" />
          <path d="M32 42 25 52h14Z" />
        </svg>
      );
    case "level":
      return (
        <svg {...shared}>
          <path d="M14 38h36" />
          <path d="M18 32h28l4 6-4 6H18l-4-6Z" />
          <circle cx="32" cy="38" r="4" />
        </svg>
      );
    case "rough-ashlar":
      return (
        <svg {...shared}>
          <path d="M18 46 14 27l10-11 18 4 8 14-7 14Z" />
          <path d="M22 22 31 28" opacity="0.45" />
        </svg>
      );
    case "perfect-ashlar":
      return (
        <svg {...shared}>
          <rect x="18" y="18" width="28" height="28" rx="2" />
          <path d="M18 26h28" opacity="0.45" />
          <path d="M26 18v28" opacity="0.45" />
        </svg>
      );
    case "pillars":
      return (
        <svg {...shared}>
          <path d="M18 48V22" />
          <path d="M26 48V22" />
          <path d="M38 48V22" />
          <path d="M46 48V22" />
          <path d="M14 18h16" />
          <path d="M34 18h16" />
          <path d="M14 50h16" />
          <path d="M34 50h16" />
        </svg>
      );
    case "winding-staircase":
      return (
        <svg {...shared}>
          <path d="M18 44c0-10 8-18 18-18h10" />
          <path d="M20 44h8v-8h8v-8h8" />
          <path d="M46 26v10" />
        </svg>
      );
    case "trestleboard":
      return (
        <svg {...shared}>
          <rect x="18" y="14" width="28" height="20" rx="2" />
          <path d="M24 34 18 50" />
          <path d="M40 34 46 50" />
          <path d="M24 20h16" opacity="0.45" />
          <path d="M24 26h12" opacity="0.45" />
        </svg>
      );
    case "euclid":
      return (
        <svg {...shared}>
          <path d="M18 46h28" />
          <path d="M18 46 18 22" />
          <path d="M18 22 46 46" />
          <path d="M26 46v-8h8" opacity="0.45" />
        </svg>
      );
    case "all-seeing-eye":
      return (
        <svg {...shared}>
          <path d="M10 32s8-12 22-12 22 12 22 12-8 12-22 12S10 32 10 32Z" />
          <circle cx="32" cy="32" r="5" />
          <path d="M32 14v-4" opacity="0.45" />
          <path d="M46 18l3-3" opacity="0.45" />
          <path d="M18 18l-3-3" opacity="0.45" />
        </svg>
      );
    case "blazing-star":
      return (
        <svg {...shared}>
          <path d="m32 14 5.3 10.8L49 26.6l-8.5 8.3 2 11.8L32 41l-10.5 5.7 2-11.8L15 26.6l11.7-1.8Z" />
          <path d="M32 8v4" opacity="0.45" />
          <path d="M54 32h-4" opacity="0.45" />
          <path d="M14 32h-4" opacity="0.45" />
        </svg>
      );
    case "sun-moon":
      return (
        <svg {...shared}>
          <circle cx="23" cy="28" r="8" />
          <path d="M23 14v-4" />
          <path d="M23 42v4" />
          <path d="M11 28H7" />
          <path d="M39 28h4" />
          <path d="M44 20a10 10 0 1 0 0 24 12 12 0 1 1 0-24Z" />
        </svg>
      );
    case "beehive":
      return (
        <svg {...shared}>
          <path d="M20 44c0-12 6-20 12-20s12 8 12 20Z" />
          <path d="M20 44h24" />
          <path d="M23 34h18" opacity="0.45" />
          <path d="M25 28h14" opacity="0.45" />
          <path d="M48 24c2 0 4 2 4 4" opacity="0.45" />
        </svg>
      );
    case "apron":
      return (
        <svg {...shared}>
          <path d="M22 20h20l-2 10H24Z" />
          <path d="M24 30h16l4 18H20Z" />
          <path d="M22 22l-8 4" />
          <path d="M42 22l8 4" />
        </svg>
      );
    case "cable-tow":
      return (
        <svg {...shared}>
          <path d="M18 42c0-8 6-14 14-14 10 0 14 8 14 14 0 4-2 8-6 8-5 0-5-8 0-8" />
          <path d="M16 22c4-5 10-8 16-8" opacity="0.45" />
        </svg>
      );
    case "acacia":
      return (
        <svg {...shared}>
          <path d="M32 48V18" />
          <path d="M32 24c-6 0-10 4-12 8 6 0 10-4 12-8Z" />
          <path d="M32 30c6 0 10 4 12 8-6 0-10-4-12-8Z" />
          <path d="M32 36c-5 0-8 3-10 6 5 0 8-3 10-6Z" />
        </svg>
      );
    case "coffin-shovel":
      return (
        <svg {...shared}>
          <path d="M20 46 16 30l8-12h16l8 12-4 16Z" />
          <path d="M45 18 54 27" />
          <path d="M50 23l4 12" />
        </svg>
      );
    case "anchor-ark":
      return (
        <svg {...shared}>
          <path d="M24 42c0 6 4 10 8 10s8-4 8-10" />
          <path d="M32 16v26" />
          <circle cx="32" cy="12" r="4" />
          <path d="M22 34h20" />
          <path d="M12 46c4-6 10-6 14 0Z" />
        </svg>
      );
    case "handshake":
      return (
        <svg {...shared}>
          <path d="M15 34l8-8 9 7 9-7 8 8" />
          <path d="M23 26l-5 14" />
          <path d="M41 26l5 14" />
          <path d="M27 36l4 4 6-6" />
        </svg>
      );
    default:
      return (
        <svg {...shared}>
          <circle cx="32" cy="32" r="18" />
        </svg>
      );
  }
}

export default function App() {
  const [selectedHour, setSelectedHour] = useState(0);
  const [activeGroup, setActiveGroup] = useState<SymbolGroupId | "all">("all");
  const [query, setQuery] = useState("");
  const [activeSymbolId, setActiveSymbolId] = useState(symbols[0].id);

  const filteredSymbols = useMemo(() => {
    const search = query.trim().toLowerCase();

    return symbols.filter((item) => {
      const matchesGroup = activeGroup === "all" || item.group === activeGroup;
      const matchesSearch =
        search.length === 0 ||
        item.name.toLowerCase().includes(search) ||
        item.teaches.toLowerCase().includes(search) ||
        item.description.toLowerCase().includes(search) ||
        item.keywords.some((keyword) => keyword.toLowerCase().includes(search));

      return matchesGroup && matchesSearch;
    });
  }, [activeGroup, query]);

  useEffect(() => {
    if (!filteredSymbols.some((item) => item.id === activeSymbolId) && filteredSymbols[0]) {
      setActiveSymbolId(filteredSymbols[0].id);
    }
  }, [activeSymbolId, filteredSymbols]);

  const activeSymbol =
    filteredSymbols.find((item) => item.id === activeSymbolId) ?? filteredSymbols[0] ?? symbols[0];
  const selectedPhase = getPhase(selectedHour);
  const currentGroupMeta = groupMeta[activeSymbol.group];
  const searchResultsLabel = `${filteredSymbols.length} of ${symbols.length} symbols shown`;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="absolute inset-x-0 top-0 -z-10 h-[36rem] bg-[radial-gradient(circle_at_top,_rgba(56,189,248,0.18),_transparent_35%),radial-gradient(circle_at_80%_20%,_rgba(245,158,11,0.15),_transparent_28%),linear-gradient(to_bottom,_rgba(15,23,42,1),_rgba(2,6,23,1))]" />

      <header className="border-b border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-8 lg:px-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-3xl space-y-5">
              <div className="flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-[0.22em] text-slate-300">
                <span className="rounded-full border border-teal-400/30 bg-teal-500/10 px-3 py-1 text-teal-200">
                  Interactive 24-hour gauge
                </span>
                <span className="rounded-full border border-indigo-400/30 bg-indigo-500/10 px-3 py-1 text-indigo-200">
                  24-symbol visual atlas
                </span>
                <span className="rounded-full border border-amber-400/30 bg-amber-500/10 px-3 py-1 text-amber-200">
                  Degree-neutral educational overview
                </span>
              </div>
              <div className="space-y-4">
                <p className="text-sm uppercase tracking-[0.28em] text-sky-300">24 Masonic Symbols Explorer</p>
                <h1 className="text-4xl font-semibold tracking-tight text-white md:text-6xl">
                  Two meanings are usually hiding inside the phrase “24 Masonic symbols.”
                </h1>
                <p className="max-w-2xl text-base leading-7 text-slate-300 md:text-lg">
                  In common Masonic explanation, the phrase often refers either to the
                  <span className="font-semibold text-white"> 24-Inch Gauge</span>—a moral symbol about dividing the day—or to a
                  <span className="font-semibold text-white"> curated set of 24 major emblems</span> used across lodge teaching and tracing-board study.
                </p>
              </div>
            </div>

            <nav className="flex flex-wrap gap-3 text-sm">
              <a
                href="#gauge"
                className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-slate-100 transition hover:border-sky-300/40 hover:bg-sky-400/10"
              >
                Explore the gauge
              </a>
              <a
                href="#symbols"
                className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-slate-100 transition hover:border-amber-300/40 hover:bg-amber-400/10"
              >
                Browse all 24 symbols
              </a>
              <a
                href="#notes"
                className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-slate-100 transition hover:border-white/30 hover:bg-white/10"
              >
                Read the study notes
              </a>
            </nav>
          </div>

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
              <p className="text-sm font-medium text-slate-300">Primary meaning</p>
              <p className="mt-2 text-2xl font-semibold text-white">The 24-Inch Gauge</p>
              <p className="mt-2 text-sm leading-6 text-slate-400">
                A symbolic ruler split into 24 parts, teaching disciplined time allocation and personal balance.
              </p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
              <p className="text-sm font-medium text-slate-300">Secondary meaning</p>
              <p className="mt-2 text-2xl font-semibold text-white">A list of 24 emblems</p>
              <p className="mt-2 text-sm leading-6 text-slate-400">
                A study-friendly collection of prominent tools, geometric figures, celestial icons, and ritual symbols.
              </p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
              <p className="text-sm font-medium text-slate-300">Day structure</p>
              <p className="mt-2 text-2xl font-semibold text-white">8 / 8 / 8</p>
              <p className="mt-2 text-sm leading-6 text-slate-400">
                Service, work, and rest each receive one equal third of the day in the classic explanation.
              </p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
              <p className="text-sm font-medium text-slate-300">Study map</p>
              <p className="mt-2 text-2xl font-semibold text-white">4 themed groups</p>
              <p className="mt-2 text-sm leading-6 text-slate-400">
                The 24-symbol atlas below is organized into tools, architecture, celestial imagery, and ritual emblems.
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto flex max-w-7xl flex-col gap-20 px-6 py-12 lg:px-8 lg:py-16">
        <section id="gauge" className="scroll-mt-24 space-y-8">
          <div className="max-w-3xl space-y-4">
            <p className="text-sm uppercase tracking-[0.28em] text-teal-300">Meaning 1 · The symbol of time</p>
            <h2 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">
              The 24-Inch Gauge turns a measuring tool into a lesson about how a day should be lived.
            </h2>
            <p className="text-base leading-7 text-slate-300">
              Operative stonemasons used the gauge for measurement. In speculative teaching, its 24 equal parts become the 24 hours of the day. The traditional lesson divides them into three balanced portions: service, vocation, and refreshment.
            </p>
          </div>

          <div className="grid gap-8 xl:grid-cols-[1.15fr_0.85fr]">
            <div className="rounded-[2rem] border border-white/10 bg-white/5 p-6 shadow-2xl shadow-black/20 backdrop-blur">
              <div className="grid gap-8 lg:grid-cols-[1fr_0.95fr] lg:items-center">
                <div className="order-2 space-y-5 lg:order-1">
                  <div>
                    <p className="text-sm font-medium text-slate-400">Selected hour</p>
                    <h3 className="mt-1 text-3xl font-semibold text-white">
                      Hour {String(selectedHour + 1).padStart(2, "0")}
                    </h3>
                    <p className="mt-3 text-sm leading-6 text-slate-300">{selectedPhase.summary}</p>
                  </div>

                  <div
                    className={cn(
                      "rounded-2xl border p-4",
                      selectedPhase.softColor,
                      selectedPhase.borderColor,
                    )}
                  >
                    <p className="text-xs font-semibold uppercase tracking-[0.24em] opacity-80">
                      {selectedPhase.hours}
                    </p>
                    <p className="mt-2 text-xl font-semibold text-white">{selectedPhase.title}</p>
                    <p className="mt-2 text-sm leading-6 text-slate-200/90">{selectedPhase.detail}</p>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-3">
                    {gaugePhases.map((phase) => {
                      const isActive = phase.id === selectedPhase.id;
                      return (
                        <button
                          key={phase.id}
                          type="button"
                          onClick={() => setSelectedHour(phase.start)}
                          className={cn(
                            "rounded-2xl border p-4 text-left transition",
                            isActive
                              ? `${phase.softColor} ${phase.borderColor} shadow-lg shadow-black/10`
                              : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10",
                          )}
                        >
                          <p className="text-xs uppercase tracking-[0.22em] text-slate-400">{phase.hours}</p>
                          <p className="mt-2 font-semibold text-white">{phase.title}</p>
                          <p className="mt-2 text-sm leading-5 text-slate-300">{phase.summary}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="order-1 flex justify-center lg:order-2">
                  <div className="relative flex h-80 w-80 items-center justify-center sm:h-96 sm:w-96">
                    <div
                      className="absolute inset-0 rounded-full shadow-[0_0_70px_rgba(14,165,233,0.08)]"
                      style={{
                        background:
                          "conic-gradient(from -90deg, #0f766e 0deg 120deg, #4338ca 120deg 240deg, #d97706 240deg 360deg)",
                      }}
                    />
                    <div className="absolute inset-[16%] rounded-full bg-slate-950/95 ring-1 ring-white/10" />
                    <div className="absolute inset-[8%] rounded-full border border-white/10" />

                    {Array.from({ length: 24 }).map((_, hour) => {
                      const angle = (hour / 24) * Math.PI * 2 - Math.PI / 2;
                      const left = 50 + Math.cos(angle) * 42;
                      const top = 50 + Math.sin(angle) * 42;
                      const isSelected = hour === selectedHour;
                      const phase = getPhase(hour);

                      return (
                        <button
                          key={hour}
                          type="button"
                          aria-label={`Select hour ${hour + 1}`}
                          onClick={() => setSelectedHour(hour)}
                          className={cn(
                            "absolute flex h-7 w-7 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full text-[10px] font-semibold transition sm:h-8 sm:w-8 sm:text-xs",
                            isSelected
                              ? "scale-110 bg-white text-slate-950 shadow-lg shadow-black/30"
                              : "bg-slate-900/80 text-slate-300 ring-1 ring-white/10 hover:bg-slate-800 hover:text-white",
                          )}
                          style={{ left: `${left}%`, top: `${top}%` }}
                        >
                          <span
                            className="absolute -z-10 h-full w-full rounded-full blur-md"
                            style={{ backgroundColor: isSelected ? phase.ringColor : "transparent" }}
                          />
                          {hour + 1}
                        </button>
                      );
                    })}

                    <div className="relative z-10 flex max-w-[12rem] flex-col items-center text-center">
                      <p className="text-xs uppercase tracking-[0.3em] text-slate-400">24-Inch Gauge</p>
                      <p className="mt-3 text-5xl font-semibold text-white">24</p>
                      <p className="mt-2 text-sm leading-6 text-slate-300">
                        Equal divisions of time form a moral schedule rather than a literal stopwatch.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8 grid gap-2 sm:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8">
                {Array.from({ length: 24 }).map((_, hour) => {
                  const phase = getPhase(hour);
                  const isSelected = hour === selectedHour;

                  return (
                    <button
                      key={`cell-${hour}`}
                      type="button"
                      onClick={() => setSelectedHour(hour)}
                      className={cn(
                        "rounded-2xl border px-3 py-3 text-left transition",
                        isSelected
                          ? `${phase.softColor} ${phase.borderColor}`
                          : "border-white/10 bg-slate-900/60 hover:border-white/20 hover:bg-slate-900",
                      )}
                    >
                      <p className="text-xs uppercase tracking-[0.22em] text-slate-400">Hour</p>
                      <p className="mt-1 text-lg font-semibold text-white">{String(hour + 1).padStart(2, "0")}</p>
                      <p className="mt-1 text-xs text-slate-300">{phase.title}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-4 rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
              <div>
                <p className="text-sm uppercase tracking-[0.28em] text-slate-400">What the symbol teaches</p>
                <h3 className="mt-2 text-2xl font-semibold text-white">Balanced time is treated as a moral craft.</h3>
              </div>
              <div className="space-y-4 text-sm leading-7 text-slate-300">
                <p>
                  The gauge is not merely about productivity. It frames time as something that should be measured with intention, shared with duty, and protected from waste.
                </p>
                <p>
                  The three equal portions do not describe every modern schedule literally; instead, they offer a memorable symbolic pattern: <span className="font-semibold text-white">serve</span>, <span className="font-semibold text-white">work</span>, and <span className="font-semibold text-white">restore</span>.
                </p>
                <p>
                  That is why “24 Masonic symbols” often first points to a single emblem: the 24-Inch Gauge is one of the clearest moral symbols in the Entered Apprentice tradition.
                </p>
              </div>

              <div className="grid gap-3">
                {gaugePhases.map((phase) => (
                  <div
                    key={`summary-${phase.id}`}
                    className={cn("rounded-2xl border p-4", phase.softColor, phase.borderColor)}
                  >
                    <p className="text-xs uppercase tracking-[0.24em] opacity-80">{phase.hours}</p>
                    <p className="mt-2 font-semibold text-white">{phase.title}</p>
                    <p className="mt-2 text-sm leading-6 text-slate-200/90">{phase.summary}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="symbols" className="scroll-mt-24 space-y-8">
          <div className="max-w-4xl space-y-4">
            <p className="text-sm uppercase tracking-[0.28em] text-amber-300">Meaning 2 · A curated collection of 24 emblems</p>
            <h2 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">
              Explore 24 commonly recognized Masonic symbols through an interactive visual atlas.
            </h2>
            <p className="text-base leading-7 text-slate-300">
              This collection organizes the most frequently cited symbols into four themes. Meanings vary between jurisdictions and degrees, but these summaries capture the broad moral ideas most often associated with each emblem.
            </p>
          </div>

          <div className="grid gap-4 lg:grid-cols-[0.95fr_1.45fr] xl:grid-cols-[0.9fr_1.5fr]">
            <aside className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur lg:sticky lg:top-6 lg:h-fit">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-sm uppercase tracking-[0.24em] text-slate-400">Focused symbol</p>
                  <h3 className="mt-2 text-2xl font-semibold text-white">{activeSymbol.name}</h3>
                </div>
                <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm text-slate-300">
                  #{activeSymbol.number}
                </div>
              </div>

              <div className="mt-6 flex items-center gap-4">
                <div
                  className={cn(
                    "flex h-20 w-20 items-center justify-center rounded-3xl border",
                    currentGroupMeta.border,
                    currentGroupMeta.soft,
                    currentGroupMeta.accent,
                  )}
                >
                  <SymbolIcon icon={activeSymbol.icon} className="h-12 w-12" />
                </div>
                <div>
                  <p className={cn("text-sm font-medium", currentGroupMeta.accent)}>
                    {groupMeta[activeSymbol.group].label}
                  </p>
                  <p className="mt-2 text-sm leading-6 text-slate-300">{activeSymbol.visualCue}</p>
                </div>
              </div>

              <div className="mt-6 space-y-5">
                <div className="rounded-2xl border border-white/10 bg-slate-950/60 p-4">
                  <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Core teaching</p>
                  <p className="mt-2 text-lg font-semibold text-white">{activeSymbol.teaches}</p>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Why it matters</p>
                  <p className="mt-2 text-sm leading-7 text-slate-300">{activeSymbol.description}</p>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.24em] text-slate-400">Search tags</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {activeSymbol.keywords.map((keyword) => (
                      <span
                        key={keyword}
                        className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300"
                      >
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </aside>

            <div className="space-y-6">
              <div className="rounded-[2rem] border border-white/10 bg-white/5 p-5 backdrop-blur">
                <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                  <div>
                    <p className="text-sm uppercase tracking-[0.24em] text-slate-400">Filter the atlas</p>
                    <p className="mt-2 text-sm text-slate-300">{searchResultsLabel}</p>
                  </div>
                  <label className="flex w-full max-w-md items-center gap-3 rounded-2xl border border-white/10 bg-slate-950/60 px-4 py-3 text-sm text-slate-300 focus-within:border-sky-300/40 xl:ml-auto">
                    <span className="text-slate-500">Search</span>
                    <input
                      value={query}
                      onChange={(event) => setQuery(event.target.value)}
                      type="search"
                      placeholder="Try time, geometry, hope, equality..."
                      className="w-full bg-transparent text-slate-100 outline-none placeholder:text-slate-500"
                    />
                  </label>
                </div>

                <div className="mt-4 flex flex-wrap gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveGroup("all")}
                    className={cn(
                      "rounded-full border px-4 py-2 text-sm transition",
                      activeGroup === "all"
                        ? "border-white/20 bg-white/10 text-white"
                        : "border-white/10 bg-slate-950/50 text-slate-300 hover:border-white/20 hover:bg-white/5",
                    )}
                  >
                    All 24
                  </button>
                  {(Object.keys(groupMeta) as SymbolGroupId[]).map((group) => (
                    <button
                      key={group}
                      type="button"
                      onClick={() => setActiveGroup(group)}
                      className={cn(
                        "rounded-full border px-4 py-2 text-sm transition",
                        activeGroup === group
                          ? `${groupMeta[group].border} ${groupMeta[group].soft} ${groupMeta[group].accent}`
                          : "border-white/10 bg-slate-950/50 text-slate-300 hover:border-white/20 hover:bg-white/5",
                      )}
                    >
                      {groupMeta[group].label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 2xl:grid-cols-3">
                {filteredSymbols.map((item) => {
                  const meta = groupMeta[item.group];
                  const isActive = item.id === activeSymbol.id;

                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveSymbolId(item.id)}
                      className={cn(
                        "rounded-[1.75rem] border p-5 text-left transition duration-200",
                        isActive
                          ? `${meta.border} ${meta.soft} shadow-xl shadow-black/20`
                          : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10",
                      )}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div
                          className={cn(
                            "flex h-14 w-14 items-center justify-center rounded-2xl border",
                            meta.border,
                            meta.soft,
                            meta.accent,
                          )}
                        >
                          <SymbolIcon icon={item.icon} className="h-8 w-8" />
                        </div>
                        <span className="rounded-full border border-white/10 bg-slate-950/60 px-3 py-1 text-xs text-slate-300">
                          #{item.number}
                        </span>
                      </div>

                      <div className="mt-4 space-y-3">
                        <div>
                          <p className={cn("text-xs uppercase tracking-[0.24em]", meta.accent)}>{meta.label}</p>
                          <h3 className="mt-2 text-xl font-semibold text-white">{item.name}</h3>
                        </div>
                        <p className="text-sm font-medium text-slate-200">{item.teaches}</p>
                        <p className="text-sm leading-6 text-slate-400">{item.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {filteredSymbols.length === 0 && (
                <div className="rounded-[1.75rem] border border-dashed border-white/15 bg-white/5 p-8 text-center">
                  <p className="text-lg font-semibold text-white">No symbols match that filter.</p>
                  <p className="mt-2 text-sm text-slate-400">
                    Clear the search or switch back to “All 24” to resume browsing.
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        <section id="notes" className="scroll-mt-24 space-y-8">
          <div className="max-w-4xl space-y-4">
            <p className="text-sm uppercase tracking-[0.28em] text-slate-400">Study notes</p>
            <h2 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">
              How to interpret the phrase without confusion.
            </h2>
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <article className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
              <h3 className="text-xl font-semibold text-white">1. A single symbol can answer the question.</h3>
              <p className="mt-3 text-sm leading-7 text-slate-300">
                When someone asks about the “24” in Masonic symbolism, the most direct answer is often the 24-Inch Gauge. Its meaning is especially clear because the number directly maps onto the 24 hours of the day.
              </p>
            </article>
            <article className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
              <h3 className="text-xl font-semibold text-white">2. Lists of 24 symbols are usually curated, not official universal canon.</h3>
              <p className="mt-3 text-sm leading-7 text-slate-300">
                Different writers emphasize slightly different emblems. The atlas in this app is a practical overview of widely recognized symbols rather than a claim that every lodge presents an identical numbered list.
              </p>
            </article>
            <article className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
              <h3 className="text-xl font-semibold text-white">3. The moral message is broader than the object itself.</h3>
              <p className="mt-3 text-sm leading-7 text-slate-300">
                Tools, stars, pillars, ropes, and stones are used as teaching devices. The real emphasis is on virtue, balance, accountability, industry, mortality, and self-improvement.
              </p>
            </article>
          </div>

          <div className="rounded-[2rem] border border-white/10 bg-gradient-to-br from-slate-900 to-slate-950 p-6 shadow-2xl shadow-black/20">
            <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
              <div>
                <p className="text-sm uppercase tracking-[0.24em] text-slate-400">Respectful context</p>
                <h3 className="mt-2 text-2xl font-semibold text-white">This app is an educational summary, not a ritual manual.</h3>
                <p className="mt-4 text-sm leading-7 text-slate-300">
                  The descriptions here follow common public-facing explanations of Freemasonry symbols. Vocabulary, emphasis, and symbolism can vary across jurisdictions, rites, and degrees. For study or heritage research, this overview works best as a visual orientation tool.
                </p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-sky-400/20 bg-sky-500/10 p-4">
                  <p className="text-3xl font-semibold text-white">24</p>
                  <p className="mt-2 text-sm text-sky-100">Interactive symbol entries</p>
                </div>
                <div className="rounded-2xl border border-teal-400/20 bg-teal-500/10 p-4">
                  <p className="text-3xl font-semibold text-white">3</p>
                  <p className="mt-2 text-sm text-teal-100">Time divisions in the gauge lesson</p>
                </div>
                <div className="rounded-2xl border border-amber-400/20 bg-amber-500/10 p-4">
                  <p className="text-3xl font-semibold text-white">4</p>
                  <p className="mt-2 text-sm text-amber-100">Study groups in the atlas</p>
                </div>
                <div className="rounded-2xl border border-rose-400/20 bg-rose-500/10 p-4">
                  <p className="text-3xl font-semibold text-white">1</p>
                  <p className="mt-2 text-sm text-rose-100">Core takeaway: symbols teach conduct</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
