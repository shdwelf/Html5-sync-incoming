// Geospatial orthorectification helpers — DEM parsing, hillshading,
// and terrain-displacement warping of topographic map imagery.
//
// True orthorectification requires rigorous collinear geometry (RPCs, GCPs,
// bundle adjustment). In a browser-only pipeline we approximate it:
//   1) Parse a DEM (raw 16-bit ENVI, SRTM-style HGT, or built-in synthetic
//      SRTM tile) into a Float32 elevation grid.
//   2) Generate a shaded relief layer via multi-directional hillshading.
//   3) Warp the source map image by sampling elevation offsets so that
//      "vertical" features (cliff faces, building edges) tilt away from the
//      sensor according to local slope — the visual signature of ortho
//      rectification over relief.
//   4) Composite shaded relief under the map, optionally drape the map
//      with hillshade modulation for a true orthophoto look.

export type DemGrid = {
  width: number;
  height: number;
  /** Elevation in meters, row-major. NaN = no data. */
  elev: Float32Array;
  /** Bounds in source-map pixel space (the DEM covers this rectangle). */
  bounds: { x0: number; y0: number; x1: number; y1: number };
  /** Resolution in meters per pixel (uniform assumed). */
  resolution: number;
  /** Approximate terrain origin in lat/lon ( informational ). */
  originLat: number;
  originLon: number;
};

export type OrthoParams = {
  /** Sun azimuth in degrees (0–360, 0=N). */
  azimuth: number;
  /** Sun elevation in degrees above horizon. */
  elevation: number;
  /** Multi-directional shading count (1–8). */
  directions: number;
  /** Relief intensity 0–2. */
  intensity: number;
  /** DEM-to-image vertical exaggeration. */
  zExaggeration: number;
  /** Blend shaded relief under the map (0–1). */
  reliefBlend: number;
  /** Drape hillshade onto map colors (0–1). */
  drape: number;
  /** DEM transparency 0–1. */
  demOpacity: number;
};

export const DEFAULT_ORHO_PARAMS: OrthoParams = {
  azimuth: 315,
  elevation: 45,
  directions: 4,
  intensity: 1.0,
  zExaggeration: 1.0,
  reliefBlend: 0.55,
  drape: 0.35,
  demOpacity: 1.0,
};

// ---------- DEM loading ----------

/** Parse raw 16-bit ENVI-style DEM (headerless, little-endian short). */
export function parseEnviShortDem(buffer: ArrayBuffer, w: number, h: number): DemGrid {
  const view = new DataView(buffer);
  const elev = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) {
    const s = view.getInt16(i * 2, true);
    elev[i] = s === -32768 ? NaN : s;
  }
  return finalizeGrid(elev, w, h);
}

/** Parse raw 32-bit float DEM (little-endian). */
export function parseEnviFloatDem(buffer: ArrayBuffer, w: number, h: number): DemGrid {
  const view = new DataView(buffer);
  const elev = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) elev[i] = view.getFloat32(i * 4, true);
  return finalizeGrid(elev, w, h);
}

function finalizeGrid(elev: Float32Array, w: number, h: number): DemGrid {
  let mn = Infinity, mx = -Infinity, sum = 0, n = 0;
  for (let i = 0; i < elev.length; i++) {
    const v = elev[i];
    if (Number.isFinite(v)) {
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      sum += v; n++;
    }
  }
  const mean = n ? sum / n : 0;
  return {
    width: w,
    height: h,
    elev,
    bounds: { x0: 0, y0: 0, x1: w, y1: h },
    resolution: 1, // pixels — caller sets real meters/pixel
    originLat: 0,
    originLon: 0,
    // attach stats on the fly via getter below
    // @ts-expect-error attach
    stats: { mn, mx, mean },
  };
}

export function demStats(g: DemGrid) {
  // @ts-expect-error attached
  return (g.stats ||= computeStats(g.elev));
}

function computeStats(elev: Float32Array) {
  let mn = Infinity, mx = -Infinity, sum = 0, n = 0, sq = 0;
  for (let i = 0; i < elev.length; i++) {
    const v = elev[i];
    if (Number.isFinite(v)) {
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      sum += v; sq += v * v; n++;
    }
  }
  const mean = n ? sum / n : 0;
  const variance = n ? sq / n - mean * mean : 0;
  return { mn, mx, mean, std: Math.sqrt(Math.max(0, variance)), count: n };
}

// ---------- Synthetic SRTM tile ----------

/** Build a procedural SRTM-like DEM using layered value-noise + ridges. */
export function buildSyntheticSrtm(width: number, height: number, seed = 7): DemGrid {
  const elev = new Float32Array(width * height);
  // simple seeded RNG
  let s = seed >>> 0;
  const rand = () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
  // value noise
  const noise = (x: number, y: number, scale: number) => {
    const xi = Math.floor(x / scale), yi = Math.floor(y / scale);
    const xf = (x / scale) - xi, yf = (y / scale) - yi;
    const tl = hash2(xi, yi, rand), tr = hash2(xi + 1, yi, rand);
    const bl = hash2(xi, yi + 1, rand), br = hash2(xi + 1, yi + 1, rand);
    const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    return lerp(tl, tr, u) * (1 - v) + lerp(bl, br, u) * v;
  };
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let v = 0;
      v += noise(x, y, 32) * 1.0;
      v += noise(x, y, 16) * 0.5;
      v += noise(x, y, 8) * 0.25;
      v += noise(x, y, 4) * 0.125;
      // ridges
      const r = Math.abs(noise(x, y, 24) - 0.5) * 2;
      v += Math.pow(1 - r, 4) * 0.6;
      // bowl shape so edges fall off (suggests a mountain basin)
      const cx = (x / width - 0.5) * 2, cy = (y / height - 0.5) * 2;
      const d = Math.sqrt(cx * cx + cy * cy);
      v = v * (1 - Math.pow(d, 1.5) * 0.7);
      elev[y * width + x] = v * 1800; // up to ~1800m
    }
  }
  const g = finalizeGrid(elev, width, height);
  return g;
}

function hash2(x: number, y: number, rand: () => number) {
  // deterministic-ish per call site — we use Math.random fallback via rand seed
  void x; void y;
  return rand();
}
function lerp(a: number, b: number, t: number) { return a + (b - a) * t; }

// ---------- Hillshading ----------

/** Compute shaded relief (0–255) for a DEM. */
export function hillshade(g: DemGrid, p: OrthoParams): ImageData {
  const { width: w, height: h, elev } = g;
  const out = new ImageData(w, h);
  const dst = out.data;
  const el = (p.elevation * Math.PI) / 180;
  const cosEl = Math.cos(el), sinEl = Math.sin(el);

  // Precompute slope/aspect per direction set
  const dirs = Math.max(1, Math.min(8, Math.round(p.directions)));
  const dirAz = new Array(dirs);
  const dirEl = new Array(dirs);
  for (let i = 0; i < dirs; i++) {
    dirAz[i] = ((p.azimuth + (i * 360) / dirs) * Math.PI) / 180;
    dirEl[i] = el;
  }

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const c = elev[i];
      if (!Number.isFinite(c)) {
        dst[i * 4 + 3] = 0;
        continue;
      }
      // sample neighbours with edge clamp
      const xl = x > 0 ? elev[i - 1] : c;
      const xr = x < w - 1 ? elev[i + 1] : c;
      const yu = y > 0 ? elev[i - w] : c;
      const yd = y < h - 1 ? elev[i + w] : c;
      const dzdx = (xr - xl) * 0.5;
      const dzdy = (yd - yu) * 0.5;

      let acc = 0;
      for (let d = 0; d < dirs; d++) {
        const a = dirAz[d];
        // proper illumination vector
        const lx = cosEl * Math.sin(a);
        const ly = cosEl * Math.cos(a);
        const lz = sinEl;
        // slope vector (dzdx, dzdy, 1) normalized
        const slope = Math.sqrt(dzdx * dzdx + dzdy * dzdy + 1);
        const nx = -dzdx / slope;
        const ny = -dzdy / slope;
        const nz = 1 / slope;
        // dot with light
        const dot = (nx * lx + ny * ly + nz * lz) / Math.sqrt(nx * nx + ny * ny + nz * nz);
        acc += Math.max(0, dot);
      }
      const v = (acc / dirs) * p.intensity;
      const px = Math.min(255, Math.max(0, (v * 255) | 0));
      dst[i * 4] = px;
      dst[i * 4 + 1] = px;
      dst[i * 4 + 2] = px;
      dst[i * 4 + 3] = 255;
    }
  }
  return out;
}

// ---------- Orthorectification warp ----------

/**
 * Warp a source map image using a DEM: for each output pixel we sample the
 * source at (x - dzdx * scale, y - dzdy * scale), so features tilt away from
 * the sensor along slopes — the visual essence of ortho correction.
 */
export function orthorectify(
  src: ImageData,
  dem: DemGrid,
  p: OrthoParams
): ImageData {
  const W = src.width, H = src.height;
  const s = src.data;
  const out = new ImageData(W, H);
  const d = out.data;
  const z = p.zExaggeration;
  // DEM covers the whole image for simplicity
  const demW = dem.width, demH = dem.height;
  const sx = demW / W, sy = demH / H;

  for (let y = 0; y < H; y++) {
    const dy = y * sy;
    for (let x = 0; x < W; x++) {
      const dx = x * sx;
      const ix = Math.min(demW - 1, Math.max(0, dx | 0));
      const iy = Math.min(demH - 1, Math.max(0, dy | 0));
      const dzdx = (dem.elev[iy * demW + Math.min(demW - 1, ix + 1)] -
                    dem.elev[iy * demW + Math.max(0, ix - 1)]) * 0.5 * sx;
      const dzdy = (dem.elev[Math.min(demH - 1, iy + 1) * demW + ix] -
                    dem.elev[Math.max(0, iy - 1) * demW + ix]) * 0.5 * sy;
      const ox = x - dzdx * z * 8;
      const oy = y - dzdy * z * 8;
      const oi = (y * W + x) * 4;
      // bilinear sample of source
      const u = Math.min(W - 1.001, Math.max(0, ox));
      const v = Math.min(H - 1.001, Math.max(0, oy));
      const x0 = u | 0, y0 = v | 0;
      const fx = u - x0, fy = v - y0;
      const i00 = (y0 * W + x0) * 4;
      const i10 = i00 + 4;
      const i01 = i00 + W * 4;
      const i11 = i01 + 4;
      const w00 = (1 - fx) * (1 - fy);
      const w10 = fx * (1 - fy);
      const w01 = (1 - fx) * fy;
      const w11 = fx * fy;
      d[oi]     = s[i00]     * w00 + s[i10]     * w10 + s[i01]     * w01 + s[i11]     * w11;
      d[oi + 1] = s[i00+1]   * w00 + s[i10+1]   * w10 + s[i01+1]   * w01 + s[i11+1]   * w11;
      d[oi + 2] = s[i00+2]   * w00 + s[i10+2]   * w10 + s[i01+2]   * w01 + s[i11+2]   * w11;
      d[oi + 3] = 255;
    }
  }
  return out;
}

// ---------- Color helpers ----------

/** Build a USGS-style hypsometric tint ramp (low=green → high=brown/snow). */
export function hypsometricTint(elev: Float32Array, w: number, h: number, mn: number, mx: number): ImageData {
  const out = new ImageData(w, h);
  const d = out.data;
  const range = mx - mn || 1;
  for (let i = 0, j = 0; i < elev.length; i++, j += 4) {
    const t = Number.isFinite(elev[i]) ? (elev[i] - mn) / range : 0;
    const [r, g, b] = hypsometricColor(t);
    d[j] = r; d[j + 1] = g; d[j + 2] = b; d[j + 3] = 255;
  }
  return out;
}

function hypsometricColor(t: number): [number, number, number] {
  // stops: water, plains, forest, rock, snow
  const stops: [number, [number, number, number]][] = [
    [0.00, [40, 70, 130]],     // deep water
    [0.18, [70, 110, 160]],    // shallow water
    [0.22, [180, 175, 130]],   // beach/sand
    [0.40, [110, 150, 80]],    // plains
    [0.60, [70, 120, 60]],     // forest
    [0.78, [120, 100, 75]],    // rock
    [0.90, [180, 170, 160]],   // bare rock
    [1.00, [250, 250, 255]],   // snow
  ];
  for (let i = 0; i < stops.length - 1; i++) {
    const [t0, c0] = stops[i];
    const [t1, c1] = stops[i + 1];
    if (t >= t0 && t <= t1) {
      const k = (t - t0) / (t1 - t0);
      return [
        c0[0] + (c1[0] - c0[0]) * k,
        c0[1] + (c1[1] - c0[1]) * k,
        c0[2] + (c1[2] - c0[2]) * k,
      ];
    }
  }
  return stops[stops.length - 1][1];
}

/** Blend two ImageData with a per-pixel alpha (a=0..1). */
export function blendImages(base: ImageData, overlay: ImageData, alpha: number): ImageData {
  const out = new ImageData(base.width, base.height);
  const a = base.data, b = overlay.data, c = out.data;
  for (let i = 0; i < a.length; i += 4) {
    const oa = alpha * (b[i + 3] / 255);
    c[i]     = a[i]     * (1 - oa) + b[i]     * oa;
    c[i + 1] = a[i + 1] * (1 - oa) + b[i + 1] * oa;
    c[i + 2] = a[i + 2] * (1 - oa) + b[i + 2] * oa;
    c[i + 3] = 255;
  }
  return out;
}

/** Modulate a base image by a grayscale hillshade (lightens/darkens). */
export function drape(base: ImageData, shade: ImageData, amount: number): ImageData {
  const out = new ImageData(base.width, base.height);
  const a = base.data, b = shade.data, c = out.data;
  for (let i = 0; i < a.length; i += 4) {
    const f = 1 + (b[i] / 255 - 0.5) * 2 * amount; // shade 0..1 -> 0..2
    c[i]     = Math.min(255, Math.max(0, a[i]     * f));
    c[i + 1] = Math.min(255, Math.max(0, a[i + 1] * f));
    c[i + 2] = Math.min(255, Math.max(0, a[i + 2] * f));
    c[i + 3] = 255;
  }
  return out;
}