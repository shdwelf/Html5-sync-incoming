// Image processing utilities using HTML5 Canvas API.
// All operations work on ImageData and can be chained.

export type Adjustments = {
  brightness: number; // -100..100
  contrast: number;   // -100..100
  saturation: number; // -100..100
  sharpness: number;  // 0..100
  denoise: number;    // 0..100
  equalize: number;   // 0..100
  quine: number;      // 0..100
};

export const DEFAULT_ADJUSTMENTS: Adjustments = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  sharpness: 0,
  denoise: 0,
  equalize: 0,
  quine: 0,
};

export function cloneImageData(src: ImageData): ImageData {
  const dst = new ImageData(src.width, src.height);
  dst.data.set(src.data);
  return dst;
}

// ---------- Brightness / Contrast / Saturation ----------

export function applyTone(img: ImageData, brightness: number, contrast: number, saturation: number): ImageData {
  const d = img.data;
  const b = brightness * 2.55; // -255..255
  const c = contrast / 100;    // -1..1
  const s = saturation / 100;  // -1..1

  // contrast factor
  const cf = (259 * (c * 255 + 255)) / (255 * (259 - c * 255));

  for (let i = 0; i < d.length; i += 4) {
    let r = d[i], g = d[i + 1], bl = d[i + 2];

    // brightness
    r += b; g += b; bl += b;

    // contrast
    r = cf * (r - 128) + 128;
    g = cf * (g - 128) + 128;
    bl = cf * (bl - 128) + 128;

    // saturation (around luminance)
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * bl;
    r = lum + (1 + s) * (r - lum);
    g = lum + (1 + s) * (g - lum);
    bl = lum + (1 + s) * (bl - lum);

    d[i] = clamp(r);
    d[i + 1] = clamp(g);
    d[i + 2] = clamp(bl);
  }
  return img;
}

function clamp(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : v | 0;
}

// ---------- Denoise (box blur, iterative) ----------

export function applyDenoise(img: ImageData, amount: number): ImageData {
  if (amount <= 0) return img;
  const radius = Math.max(1, Math.round((amount / 100) * 3)); // 1..3
  const passes = Math.max(1, Math.round((amount / 100) * 2));
  let src = cloneImageData(img);
  let dst = new ImageData(img.width, img.height);
  for (let p = 0; p < passes; p++) {
    boxBlur(src, dst, radius);
    const tmp = src;
    src = dst;
    dst = tmp;
  }
  return src;
}

function boxBlur(src: ImageData, dst: ImageData, r: number) {
  const w = src.width, h = src.height;
  const sd = src.data, dd = dst.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let rs = 0, gs = 0, bs = 0, c = 0;
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
          const idx = (ny * w + nx) * 4;
          rs += sd[idx]; gs += sd[idx + 1]; bs += sd[idx + 2]; c++;
        }
      }
      const i = (y * w + x) * 4;
      dd[i] = rs / c;
      dd[i + 1] = gs / c;
      dd[i + 2] = bs / c;
      dd[i + 3] = sd[i + 3];
    }
  }
}

// ---------- Sharpening (unsharp mask via 3x3 convolution) ----------

export function applySharpen(img: ImageData, amount: number): ImageData {
  if (amount <= 0) return img;
  const a = amount / 100; // 0..1
  // 3x3 sharpen kernel scaled by a
  const k = [
    0, -a, 0,
    -a, 1 + 4 * a, -a,
    0, -a, 0,
  ];
  return convolve(img, k, 1);
}

function convolve(img: ImageData, kernel: number[], divisor: number): ImageData {
  const w = img.width, h = img.height;
  const src = img.data;
  const out = new ImageData(w, h);
  const dst = out.data;
  const kSize = 3;
  const half = 1;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let r = 0, g = 0, b = 0;
      for (let ky = 0; ky < kSize; ky++) {
        for (let kx = 0; kx < kSize; kx++) {
          const nx = Math.min(w - 1, Math.max(0, x + kx - half));
          const ny = Math.min(h - 1, Math.max(0, y + ky - half));
          const idx = (ny * w + nx) * 4;
          const kv = kernel[ky * kSize + kx];
          r += src[idx] * kv;
          g += src[idx + 1] * kv;
          b += src[idx + 2] * kv;
        }
      }
      const i = (y * w + x) * 4;
      dst[i] = clamp(r / divisor);
      dst[i + 1] = clamp(g / divisor);
      dst[i + 2] = clamp(b / divisor);
      dst[i + 3] = src[i + 3];
    }
  }
  return out;
}

// ---------- Histogram Equalization (per channel, masked by luminance) ----------

export function applyEqualize(img: ImageData, amount: number): ImageData {
  if (amount <= 0) return img;
  const w = img.width, h = img.height;
  const d = img.data;
  const strength = amount / 100;

  // Build luminance histogram
  const hist = new Array(256).fill(0);
  const lum = new Float32Array(w * h);
  for (let i = 0, j = 0; i < d.length; i += 4, j++) {
    const l = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2];
    lum[j] = l;
    hist[Math.min(255, l | 0)]++;
  }
  const total = w * h;
  // CDF
  const cdf = new Array(256).fill(0);
  cdf[0] = hist[0];
  for (let i = 1; i < 256; i++) cdf[i] = cdf[i - 1] + hist[i];
  const cdfMin = cdf.find(v => v > 0) || 0;
  const lut = new Array(256);
  for (let i = 0; i < 256; i++) {
    lut[i] = ((cdf[i] - cdfMin) / (total - cdfMin)) * 255;
  }

  // Blend equalized with original by strength, only for mid-tones
  for (let i = 0, j = 0; i < d.length; i += 4, j++) {
    const l = lum[j];
    // mask: stronger in mid-tones, less at extremes
    const mask = Math.sin((l / 255) * Math.PI);
    const eqR = lut[Math.min(255, d[i] | 0)];
    const eqG = lut[Math.min(255, d[i + 1] | 0)];
    const eqB = lut[Math.min(255, d[i + 2] | 0)];
    d[i]     = clamp(d[i]     * (1 - strength * mask) + eqR * strength * mask);
    d[i + 1] = clamp(d[i + 1] * (1 - strength * mask) + eqG * strength * mask);
    d[i + 2] = clamp(d[i + 2] * (1 - strength * mask) + eqB * strength * mask);
  }
  return img;
}

// ---------- Quine Self: generative recursive pattern from image data ----------

export function applyQuine(img: ImageData, amount: number): ImageData {
  if (amount <= 0) return img;
  const w = img.width, h = img.height;
  const src = img.data;
  const out = new ImageData(w, h);
  const dst = out.data;
  const strength = amount / 100;

  // Sample palette from image (every Nth pixel, top-left quadrant)
  const palette: [number, number, number][] = [];
  const step = Math.max(1, Math.floor((w * h) / 4000));
  for (let i = 0; i < src.length; i += 4 * step) {
    palette.push([src[i], src[i + 1], src[i + 2]]);
  }
  if (palette.length === 0) palette.push([128, 128, 128]);

  // Compute average luminance & dominant colors for seed
  let lumSum = 0;
  for (let i = 0; i < src.length; i += 4) {
    lumSum += 0.2126 * src[i] + 0.7152 * src[i + 1] + 0.0722 * src[i + 2];
  }
  const avgLum = lumSum / (w * h);

  // Recursive self-similar squares: at each level, subdivide and color from palette.
  // We blend this over the original image by `strength`.
  const drawQuine = (x0: number, y0: number, x1: number, y1: number, depth: number, idx: number) => {
    if (depth <= 0 || x1 - x0 < 2 || y1 - y0 < 2) return;
    const pal = palette[(idx * 7 + depth * 13) % palette.length];
    // Mix palette color with image local average for "self" reference
    const lx = (x0 + x1) >> 1, ly = (y0 + y1) >> 1;
    const li = ((ly * w) + lx) * 4;
    const lr = src[li], lg = src[li + 1], lb = src[li + 2];
    const t = 0.5 + 0.5 * Math.sin(idx * 0.7 + depth);
    const r = pal[0] * (1 - t) + lr * t;
    const g = pal[1] * (1 - t) + lg * t;
    const b = pal[2] * (1 - t) + lb * t;

    // Fill this cell with the blended color, fading toward edges for soft look
    const cellW = x1 - x0, cellH = y1 - y0;
    const inset = Math.max(0, Math.floor(Math.min(cellW, cellH) * 0.08));
    for (let y = y0 + inset; y < y1 - inset; y++) {
      for (let x = x0 + inset; x < x1 - inset; x++) {
        const di = (y * w + x) * 4;
        dst[di]     = r;
        dst[di + 1] = g;
        dst[di + 2] = b;
        dst[di + 3] = 255;
      }
    }

    // Recurse into 4 quadrants
    const mx = (x0 + x1) >> 1;
    const my = (y0 + y1) >> 1;
    drawQuine(x0, y0, mx, my, depth - 1, idx * 4 + 1);
    drawQuine(mx, y0, x1, my, depth - 1, idx * 4 + 2);
    drawQuine(x0, my, mx, y1, depth - 1, idx * 4 + 3);
    drawQuine(mx, my, x1, y1, depth - 1, idx * 4 + 4);
  };

  // Fill background with image darkened by avgLum mapping
  for (let i = 0; i < src.length; i += 4) {
    const l = 0.2126 * src[i] + 0.7152 * src[i + 1] + 0.0722 * src[i + 2];
    const f = l / 255;
    dst[i]     = clamp(src[i]     * (0.25 + 0.5 * f));
    dst[i + 1] = clamp(src[i + 1] * (0.25 + 0.5 * f));
    dst[i + 2] = clamp(src[i + 2] * (0.25 + 0.5 * f));
    dst[i + 3] = 255;
  }

  drawQuine(0, 0, w, h, 6, 1);

  // Blend quine output with original image by strength
  for (let i = 0; i < src.length; i += 4) {
    dst[i]     = clamp(src[i]     * (1 - strength) + dst[i]     * strength);
    dst[i + 1] = clamp(src[i + 1] * (1 - strength) + dst[i + 1] * strength);
    dst[i + 2] = clamp(src[i + 2] * (1 - strength) + dst[i + 2] * strength);
    dst[i + 3] = 255;
  }
  // Suppress unused var warning
  void avgLum;
  return out;
}

// ---------- Master pipeline ----------

export function processImage(img: ImageData, adj: Adjustments): ImageData {
  // Order: denoise -> equalize -> tone -> sharpen -> quine
  let out = img;
  out = applyDenoise(out, adj.denoise);
  out = applyEqualize(out, adj.equalize);
  out = applyTone(out, adj.brightness, adj.contrast, adj.saturation);
  out = applySharpen(out, adj.sharpness);
  out = applyQuine(out, adj.quine);
  return out;
}

// ---------- Histogram (for the analysis tool) ----------

export function computeHistogram(img: ImageData): { r: number[]; g: number[]; b: number[]; l: number[] } {
  const r = new Array(256).fill(0);
  const g = new Array(256).fill(0);
  const b = new Array(256).fill(0);
  const l = new Array(256).fill(0);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    r[d[i]]++;
    g[d[i + 1]]++;
    b[d[i + 2]]++;
    const lum = (0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]) | 0;
    l[Math.min(255, lum)]++;
  }
  return { r, g, b, l };
}