// Procedural topographic map generator — produces a USGS-style shaded map
// drawn from a DEM. This stands in for a scanned USGS DRG / DOQ tile so the
// orthorectification pipeline has something to drape over the SRTM.

import { DemGrid, hillshade, hypsometricTint } from "./geospatial";

export function renderTopoMapFromDem(dem: DemGrid): ImageData {
  const { width: w, height: h, elev } = dem;
  const stats = computeStats(elev);
  const tint = hypsometricTint(elev, w, h, stats.mn, stats.mx);
  const shade = hillshade(dem, {
    azimuth: 315,
    elevation: 55,
    directions: 4,
    intensity: 0.9,
    zExaggeration: 1.5,
    reliefBlend: 0,
    drape: 0,
    demOpacity: 1,
  });
  // base = tint * shade (lighten/darken by hillshade)
  const out = new ImageData(w, h);
  const a = tint.data, b = shade.data, c = out.data;
  for (let i = 0; i < a.length; i += 4) {
    const f = 0.55 + (b[i] / 255) * 0.9;
    c[i]     = Math.min(255, a[i]     * f);
    c[i + 1] = Math.min(255, a[i + 1] * f);
    c[i + 2] = Math.min(255, a[i + 2] * f);
    c[i + 3] = 255;
  }
  // contour lines (every 50m, every 5th emphasized)
  drawContours(out, elev, w, h, stats.mn, stats.mx);
  // roads / rivers (procedural)
  drawStreams(out, elev, w, h);
  drawLabels(out, w, h, stats);
  return out;
}

function computeStats(elev: Float32Array) {
  let mn = Infinity, mx = -Infinity, sum = 0, n = 0, sq = 0;
  for (let i = 0; i < elev.length; i++) {
    const v = elev[i];
    if (Number.isFinite(v)) {
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      sum += v; sq += v * v; n++;
    }
  }
  return { mn, mx, mean: n ? sum / n : 0, count: n, std: 0 };
}

function drawContours(out: ImageData, elev: Float32Array, w: number, h: number, mn: number, mx: number) {
  const d = out.data;
  const range = mx - mn;
  const interval = range > 1500 ? 100 : range > 600 ? 50 : 25;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const cur = elev[i];
      // check right & down neighbour for interval crossing
      const right = elev[i + 1];
      const down = elev[i + w];
      let crossed = false, major = false;
      if (Math.floor(cur / interval) !== Math.floor(right / interval)) crossed = true;
      if (Math.floor(cur / interval) !== Math.floor(down / interval)) crossed = true;
      if (crossed) {
        const lvl = Math.floor(cur / interval) * interval;
        major = lvl % (interval * 4) === 0;
        const idx = i * 4;
        if (major) {
          d[idx] = 50; d[idx + 1] = 35; d[idx + 2] = 25;
        } else {
          d[idx] = 90; d[idx + 1] = 80; d[idx + 2] = 65;
        }
      }
    }
  }
}

function drawStreams(out: ImageData, elev: Float32Array, w: number, h: number) {
  const d = out.data;
  // Trace a few stream segments by following downhill gradients from high points.
  const seeds: [number, number][] = [];
  const N = 6;
  for (let s = 0; s < N; s++) {
    seeds.push([Math.floor(w * (0.15 + 0.7 * Math.random())), Math.floor(h * (0.15 + 0.7 * Math.random()))]);
  }
  for (const [sx, sy] of seeds) {
    let x = sx, y = sy;
    const visited = new Set<number>();
    for (let step = 0; step < 400; step++) {
      if (x < 1 || y < 1 || x >= w - 1 || y >= h - 1) break;
      const i = y * w + x;
      if (visited.has(i)) break;
      visited.add(i);
      // pick neighbour with smallest elevation
      const idx = [
        elev[i - 1], elev[i + 1], elev[i - w], elev[i + w],
      ];
      let best = 2, bestV = idx[2];
      for (let k = 0; k < 4; k++) if (idx[k] < bestV) { bestV = idx[k]; best = k; }
      if (bestV >= elev[i]) break;
      const px = i * 4;
      d[px] = 30; d[px + 1] = 70; d[px + 2] = 130;
      if (best === 0) x--; else if (best === 1) x++;
      else if (best === 2) y--; else y++;
    }
  }
}

function drawLabels(out: ImageData, w: number, h: number, stats: { mn: number; mx: number }) {
  const ctx = (out as any)._ctx as CanvasRenderingContext2D | undefined;
  // We don't have a ctx here; instead we paint a few label rectangles as
  // a stand-in. Real label rasterization would need a font.
  void ctx;
  const d = out.data;
  const labels = [
    { x: w * 0.08, y: h * 0.92, text: "QUADRANGLE 7.5-MINUTE" },
  ];
  for (const lab of labels) {
    const px = Math.floor(lab.x), py = Math.floor(lab.y);
    for (let dx = 0; dx < 220; dx++) {
      const i = ((py) * w + (px + dx)) * 4;
      if (i < 0 || i + 3 >= d.length) continue;
      d[i] = 25; d[i + 1] = 25; d[i + 2] = 25;
    }
  }
  // tick marks on the border
  for (let x = 0; x < w; x += Math.floor(w / 10)) {
    for (let t = 0; t < 12; t++) {
      const i = (t * w + x) * 4;
      d[i] = 30; d[i + 1] = 30; d[i + 2] = 30;
    }
  }
  for (let y = 0; y < h; y += Math.floor(h / 10)) {
    for (let t = 0; t < 12; t++) {
      const i = (y * w + t) * 4;
      d[i] = 30; d[i + 1] = 30; d[i + 2] = 30;
    }
  }
  void stats;
}