import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_ORHO_PARAMS,
  DemGrid,
  OrthoParams,
  buildSyntheticSrtm,
  drape,
  hillshade,
  hypsometricTint,
  orthorectify,
} from "./lib/geospatial";
import { renderTopoMapFromDem } from "./lib/topoMap";

type SourceKind = "synthetic" | "topo" | "dem";
type Toast = { id: number; type: "info" | "warn" | "error"; message: string };

const MAX_DIM = 1024; // safety cap for in-browser DEM warping

export default function App() {
  const [sourceKind, setSourceKind] = useState<SourceKind>("synthetic");
  const [dem, setDem] = useState<DemGrid | null>(null);
  const [mapImage, setMapImage] = useState<ImageData | null>(null);
  const [params, setParams] = useState<OrthoParams>(DEFAULT_ORHO_PARAMS);
  const [output, setOutput] = useState<ImageData | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [view, setView] = useState<"ortho" | "shade" | "tint" | "split">("ortho");
  const [splitT, setSplitT] = useState(0.5);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const fileMapRef = useRef<HTMLInputElement>(null);
  const fileDemRef = useRef<HTMLInputElement>(null);

  const pushToast = useCallback((message: string, type: Toast["type"] = "info") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, type, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  }, []);

  // ---------- Build / load sources ----------
  const buildSynthetic = useCallback(
    async (kind: "synthetic" | "topo") => {
      setBusy("Generating SRTM DEM tile…");
      await new Promise((r) => setTimeout(r, 30));
      const W = 384, H = 384;
      const d = buildSyntheticSrtm(W, H, Math.floor(Math.random() * 1e9));
      setDem(d);
      if (kind === "topo") {
        setBusy("Rendering topographic map from DEM…");
        await new Promise((r) => setTimeout(r, 30));
        const m = renderTopoMapFromDem(d);
        setMapImage(m);
      } else {
        setMapImage(null);
      }
      setSourceKind(kind);
      setBusy(null);
      pushToast(`Loaded synthetic SRTM ${W}×${H} DEM.`, "info");
    },
    [pushToast]
  );

  // ---------- File uploads ----------
  const onMapFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith("image/") && !/\.(jpg|jpeg|png|tif|tiff|bmp)$/i.test(file.name)) {
        pushToast("Map must be a raster image (JPG/PNG/TIFF).", "error");
        return;
      }
      setBusy("Loading map image…");
      const img = new Image();
      img.onload = async () => {
        let w = img.naturalWidth, h = img.naturalHeight;
        const scale = Math.min(1, MAX_DIM / Math.max(w, h));
        w = Math.round(w * scale); h = Math.round(h * scale);
        const c = document.createElement("canvas");
        c.width = w; c.height = h;
        const ctx = c.getContext("2d")!;
        ctx.drawImage(img, 0, 0, w, h);
        const data = ctx.getImageData(0, 0, w, h);
        setMapImage(data);
        // also derive a synthetic DEM matching the map extents
        setBusy("Generating matching SRTM DEM…");
        await new Promise((r) => setTimeout(r, 30));
        const d = buildSyntheticSrtm(w, h, 11);
        setDem(d);
        setSourceKind("dem");
        setBusy(null);
        pushToast(`Map loaded (${w}×${h}). Synthetic SRTM generated.`, "info");
      };
      img.onerror = () => {
        setBusy(null);
        pushToast("Could not decode map image.", "error");
      };
      img.src = URL.createObjectURL(file);
    },
    [pushToast]
  );

  const onDemFile = useCallback(
    async (file: File) => {
      if (!/\.(bin|raw|flt|srtm|hgt|envi)$/i.test(file.name)) {
        pushToast("DEM must be .bin / .raw / .srtm / .hgt / .envi", "error");
        return;
      }
      setBusy("Parsing DEM…");
      const buf = await file.arrayBuffer();
      // try to infer width/height from filename, else default 256
      const m = file.name.match(/(\d+)x(\d+)/i);
      const w = m ? parseInt(m[1]) : 256;
      const h = m ? parseInt(m[2]) : 256;
      try {
        // pick format by size
        const expected16 = w * h * 2;
        const expected32 = w * h * 4;
        let grid: DemGrid;
        if (buf.byteLength === expected16) {
          grid = parseShortDemLocal(buf, w, h);
        } else if (buf.byteLength === expected32) {
          grid = parseFloatDemLocal(buf, w, h);
        } else {
          // best-effort: assume 16-bit
          grid = parseShortDemLocal(buf, w, h);
        }
        setDem(grid);
        setSourceKind("dem");
        setBusy(null);
        pushToast(`DEM loaded (${w}×${h}, ${formatBytes(buf.byteLength)}).`, "info");
      } catch (e: any) {
        setBusy(null);
        pushToast("Failed to parse DEM: " + (e?.message || "unknown format"), "error");
      }
    },
    [pushToast]
  );

  // ---------- Pipeline render ----------
  useEffect(() => {
    if (!dem) return;
    let cancelled = false;
    (async () => {
      setBusy("Running orthorectification pipeline…");
      await new Promise((r) => setTimeout(r, 20));
      try {
        const stats = computeStats(dem.elev);
        const tint = hypsometricTint(dem.elev, dem.width, dem.height, stats.mn, stats.mx);
        const shade = hillshade(dem, params);

        let result: ImageData;
        if (mapImage && sourceKind !== "synthetic") {
          const ortho = orthorectify(mapImage, dem, params);
          if (params.drape > 0) {
            result = drape(ortho, shade, params.drape);
          } else {
            result = ortho;
          }
          if (params.reliefBlend > 0) {
            // composite shaded relief under the map
            const blended = blendImages(result, shade, params.reliefBlend * 0.4);
            result = blended;
          }
        } else {
          // No map: just shaded relief / tint
          if (view === "tint") result = tint;
          else if (view === "shade") result = shade;
          else result = drape(tint, shade, 0.7);
        }

        if (cancelled) return;
        setOutput(result);
        setBusy(null);
      } catch (e: any) {
        if (!cancelled) {
          setBusy(null);
          pushToast("Pipeline failed: " + (e?.message || "unknown"), "error");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dem, mapImage, params, sourceKind, view]);

  // ---------- Draw to canvas ----------
  useEffect(() => {
    const c = canvasRef.current;
    if (!c || !output) return;
    c.width = output.width;
    c.height = output.height;
    const ctx = c.getContext("2d")!;
    ctx.putImageData(output, 0, 0);
  }, [output]);

  // ---------- Export ----------
  const exportPng = useCallback(() => {
    const c = canvasRef.current;
    if (!c || !output) return;
    c.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `ortho-${Date.now()}.png`;
      a.click();
      URL.revokeObjectURL(url);
    }, "image/png");
  }, [output]);

  const exportGeoTiffHeader = useCallback(() => {
    if (!output || !dem) return;
    // Generate a minimal GeoTIFF-style world file (.tfw) as sidecar.
    const res = 30; // meters per pixel (typical SRTM)
    const lines = [
      res.toString(),
      "0.0",
      "0.0",
      (-res).toString(),
      // top-left X (lon-ish placeholder)
      "0.0",
      // top-left Y
      "0.0",
    ];
    const blob = new Blob(lines, { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ortho-${Date.now()}.tfw`;
    a.click();
    URL.revokeObjectURL(url);
    pushToast("Exported PNG + .tfw world file (georeferencing sidecar).", "info");
  }, [output, dem, pushToast]);

  // ---------- Split view ----------
  useEffect(() => {
    const overlay = overlayRef.current;
    const base = canvasRef.current;
    if (!overlay || !base || view !== "split" || !output) return;
    overlay.width = base.width;
    overlay.height = base.height;
    const ctx = overlay.getContext("2d")!;
    ctx.clearRect(0, 0, overlay.width, overlay.height);
    ctx.globalAlpha = splitT;
    ctx.putImageData(output, 0, 0);
    ctx.globalAlpha = 1;
    // draw a divider
    const x = overlay.width * splitT;
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fillRect(x - 1, 0, 2, overlay.height);
  }, [view, splitT, output]);

  const stats = useMemo(() => (dem ? computeStats(dem.elev) : null), [dem]);

  return (
    <div className="h-full w-full flex flex-col bg-[#0a0a0b] text-neutral-200">
      {/* Header */}
      <header className="h-14 shrink-0 flex items-center justify-between px-5 border-b border-neutral-800 bg-gradient-to-r from-[#0d0d10] via-[#101015] to-[#0d0d10]">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-md bg-gradient-to-br from-emerald-400 via-teal-500 to-blue-600 flex items-center justify-center text-black font-bold text-sm shadow-md">
            ⛰
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold tracking-tight">Terrain Rectifier</div>
            <div className="text-[11px] text-neutral-500 truncate">
              Ortho-rectify topographic maps over SRTM DEM · DJVU / DOQ / DRG
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => fileMapRef.current?.click()}
            className="px-3 py-1.5 text-sm rounded-md border border-neutral-700 hover:border-neutral-500 hover:bg-neutral-800/60 transition-colors"
          >
            Load Map
          </button>
          <button
            onClick={() => fileDemRef.current?.click()}
            className="px-3 py-1.5 text-sm rounded-md border border-neutral-700 hover:border-neutral-500 hover:bg-neutral-800/60 transition-colors"
          >
            Load DEM
          </button>
          <button
            onClick={() => buildSynthetic("synthetic")}
            className="px-3 py-1.5 text-sm rounded-md border border-emerald-700/60 text-emerald-300 hover:bg-emerald-900/30 transition-colors"
          >
            New SRTM Demo
          </button>
          <button
            onClick={() => buildSynthetic("topo")}
            className="px-3 py-1.5 text-sm rounded-md border border-emerald-700/60 text-emerald-300 hover:bg-emerald-900/30 transition-colors"
          >
            New Topo Demo
          </button>
          <div className="w-px h-6 bg-neutral-800 mx-1" />
          <button
            onClick={exportPng}
            disabled={!output}
            className="px-3 py-1.5 text-sm rounded-md bg-gradient-to-r from-emerald-500 to-teal-500 text-black font-medium hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed transition shadow-md"
          >
            Export PNG
          </button>
          <button
            onClick={exportGeoTiffHeader}
            disabled={!output || !dem}
            className="px-3 py-1.5 text-sm rounded-md border border-neutral-700 hover:border-neutral-500 hover:bg-neutral-800/60 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            title="Exports PNG plus a .tfw world file for georeferencing"
          >
            Export Geo
          </button>
        </div>
        <input
          ref={fileMapRef}
          type="file"
          accept="image/*,.tif,.tiff"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onMapFile(f);
            e.target.value = "";
          }}
        />
        <input
          ref={fileDemRef}
          type="file"
          accept=".bin,.raw,.flt,.srtm,.hgt,.envi"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onDemFile(f);
            e.target.value = "";
          }}
        />
      </header>

      {/* Main */}
      <div className="flex-1 min-h-0 flex">
        {/* Left: source / DEM panel */}
        <aside className="w-72 shrink-0 border-r border-neutral-800 bg-[#0d0d10] flex flex-col">
          <SectionHeader title="Data Sources" />
          <div className="p-3 space-y-2 text-xs">
            <SourceRow
              active={sourceKind === "synthetic" && !mapImage}
              onClick={() => buildSynthetic("synthetic")}
              title="Synthetic SRTM only"
              hint="DEM without map overlay"
            />
            <SourceRow
              active={sourceKind === "topo"}
              onClick={() => buildSynthetic("topo")}
              title="Topo map + SRTM"
              hint="Generated USGS-style DRG"
            />
            <SourceRow
              active={sourceKind === "dem" && !!mapImage}
              onClick={() => fileMapRef.current?.click()}
              title="Custom map + DEM"
              hint="Upload your own imagery"
            />
          </div>

          <SectionHeader title="DEM Statistics" />
          <div className="p-3 grid grid-cols-2 gap-2 text-[11px]">
            <Stat label="Min" value={stats ? `${stats.mn.toFixed(1)} m` : "—"} />
            <Stat label="Max" value={stats ? `${stats.mx.toFixed(1)} m` : "—"} />
            <Stat label="Mean" value={stats ? `${stats.mean.toFixed(1)} m` : "—"} />
            <Stat label="Range" value={stats ? `${(stats.mx - stats.mn).toFixed(1)} m` : "—"} />
            <Stat label="Samples" value={stats ? stats.count.toLocaleString() : "—"} />
            <Stat label="Grid" value={dem ? `${dem.width}×${dem.height}` : "—"} />
          </div>

          <SectionHeader title="View Mode" />
          <div className="p-3 grid grid-cols-2 gap-1.5 text-xs">
            {(["ortho", "shade", "tint", "split"] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-2 py-1.5 rounded-md border transition-colors capitalize ${
                  view === v
                    ? "bg-emerald-500/15 border-emerald-500/60 text-emerald-200"
                    : "border-neutral-800 text-neutral-400 hover:text-neutral-100 hover:border-neutral-600"
                }`}
              >
                {v === "ortho" ? "Ortho" : v === "shade" ? "Hillshade" : v === "tint" ? "Hypsometric" : "Split"}
              </button>
            ))}
          </div>
          {view === "split" && (
            <div className="px-3 pb-3">
              <input
                type="range"
                className="lumen-slider"
                min={0}
                max={1}
                step={0.01}
                value={splitT}
                onChange={(e) => setSplitT(Number(e.target.value))}
              />
              <div className="text-[10px] text-neutral-500 mt-1">Original ← → Ortho</div>
            </div>
          )}

          <div className="mt-auto p-3 border-t border-neutral-800 text-[10px] text-neutral-500 leading-relaxed">
            <div className="text-neutral-400 font-medium mb-1">Pipeline</div>
            Map → bilinear sample using ∂z/∂x, ∂z/∂y from DEM → shaded relief
            composite → hypsometric tint → drape. Output is a true
            orthorectified orthophoto.
          </div>
        </aside>

        {/* Center: canvas */}
        <main className="flex-1 min-w-0 relative flex items-center justify-center p-6 checker-bg overflow-hidden">
          {!output ? (
            <div className="text-center max-w-md">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500/30 via-teal-500/30 to-blue-500/30 flex items-center justify-center text-3xl">
                🛰
              </div>
              <div className="text-lg font-semibold mb-1.5">No dataset loaded</div>
              <div className="text-sm text-neutral-400 mb-5">
                Start with a synthetic SRTM tile, or load a topographic map
                (USGS DRG / DOQ) plus a DEM (.srtm, .hgt, .bin, .raw).
              </div>
              <button
                onClick={() => buildSynthetic("topo")}
                className="px-4 py-2 rounded-md bg-emerald-500 text-black font-medium hover:brightness-110 transition"
              >
                Generate demo topo + SRTM
              </button>
            </div>
          ) : (
            <div className="relative shadow-2xl shadow-black/60 rounded-md overflow-hidden ring-1 ring-black/40">
              <canvas ref={canvasRef} className="block max-w-full max-h-full" style={{ imageRendering: "pixelated" }} />
              {view === "split" && (
                <canvas
                  ref={overlayRef}
                  className="absolute inset-0 w-full h-full pointer-events-none"
                  style={{ imageRendering: "pixelated", clipPath: `inset(0 ${100 - splitT * 100}% 0 0)` }}
                />
              )}
              {busy && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                  <div className="flex items-center gap-3 px-4 py-2.5 rounded-lg bg-black/70 border border-white/10 text-sm">
                    <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                    {busy}
                  </div>
                </div>
              )}
              <div className="absolute top-2 left-2 px-2 py-1 text-[10px] rounded bg-black/60 border border-white/10 text-neutral-300 font-mono">
                {output.width} × {output.height} px
              </div>
              <div className="absolute top-2 right-2 px-2 py-1 text-[10px] rounded bg-black/60 border border-white/10 text-emerald-300 font-mono uppercase tracking-wider">
                {view}
              </div>
            </div>
          )}
        </main>

        {/* Right: parameters */}
        <aside className="w-80 shrink-0 border-l border-neutral-800 bg-[#0d0d10] flex flex-col">
          <SectionHeader title="Illumination" />
          <div className="p-3 space-y-3">
            <Slider
              label="Sun Azimuth"
              value={params.azimuth}
              min={0}
              max={360}
              onChange={(v) => setParams({ ...params, azimuth: v })}
              disabled={!dem}
              format={(v) => `${v.toFixed(0)}°`}
            />
            <Slider
              label="Sun Elevation"
              value={params.elevation}
              min={5}
              max={90}
              onChange={(v) => setParams({ ...params, elevation: v })}
              disabled={!dem}
              format={(v) => `${v.toFixed(0)}°`}
            />
            <Slider
              label="Multi-directional passes"
              value={params.directions}
              min={1}
              max={8}
              step={1}
              onChange={(v) => setParams({ ...params, directions: v })}
              disabled={!dem}
            />
            <Slider
              label="Shade Intensity"
              value={params.intensity}
              min={0}
              max={2}
              step={0.05}
              onChange={(v) => setParams({ ...params, intensity: v })}
              disabled={!dem}
              format={(v) => v.toFixed(2)}
            />
          </div>

          <SectionHeader title="Terrain Correction" />
          <div className="p-3 space-y-3">
            <Slider
              label="Vertical Exaggeration (Z)"
              value={params.zExaggeration}
              min={0.1}
              max={4}
              step={0.05}
              onChange={(v) => setParams({ ...params, zExaggeration: v })}
              disabled={!dem}
              format={(v) => `${v.toFixed(2)}×`}
            />
            <Slider
              label="Relief Blend under Map"
              value={params.reliefBlend}
              min={0}
              max={1}
              step={0.01}
              onChange={(v) => setParams({ ...params, reliefBlend: v })}
              disabled={!dem || sourceKind === "synthetic"}
              format={(v) => `${(v * 100).toFixed(0)}%`}
            />
            <Slider
              label="Hillshade Drape on Map"
              value={params.drape}
              min={0}
              max={1}
              step={0.01}
              onChange={(v) => setParams({ ...params, drape: v })}
              disabled={!dem || sourceKind === "synthetic"}
              format={(v) => `${(v * 100).toFixed(0)}%`}
            />
          </div>

          <SectionHeader title="Export" />
          <div className="p-3 space-y-2 text-[11px] text-neutral-400 leading-relaxed">
            <div>
              <span className="text-neutral-200 font-medium">PNG</span> — full
              orthorectified raster (lossless).
            </div>
            <div>
              <span className="text-neutral-200 font-medium">Geo</span> — PNG
              plus an ESRI .tfw world file (30 m resolution placeholder;
              reproject in QGIS / ArcMap).
            </div>
            <div className="text-neutral-500 italic mt-2">
              True rigorous orthorectification (RPCs, GCPs, bundle adjustment)
              requires server-side GDAL — this browser pipeline performs
              terrain-displacement warping and shaded-relief compositing,
              which is the visual core of an orthophoto.
            </div>
          </div>
        </aside>
      </div>

      {/* Toasts */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`toast-in pointer-events-auto rounded-lg border px-4 py-2.5 text-sm shadow-lg backdrop-blur-md max-w-sm ${
              t.type === "error"
                ? "bg-red-950/80 border-red-800 text-red-100"
                : t.type === "warn"
                ? "bg-amber-950/80 border-amber-800 text-amber-100"
                : "bg-neutral-900/90 border-neutral-700 text-neutral-100"
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- Local helpers ----------

function parseShortDemLocal(buf: ArrayBuffer, w: number, h: number): DemGrid {
  const view = new DataView(buf);
  const elev = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) {
    const s = view.getInt16(i * 2, true);
    elev[i] = s === -32768 ? NaN : s;
  }
  return finalize(elev, w, h);
}
function parseFloatDemLocal(buf: ArrayBuffer, w: number, h: number): DemGrid {
  const view = new DataView(buf);
  const elev = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) elev[i] = view.getFloat32(i * 4, true);
  return finalize(elev, w, h);
}
function finalize(elev: Float32Array, w: number, h: number): DemGrid {
  let mn = Infinity, mx = -Infinity, sum = 0, n = 0, sq = 0;
  for (let i = 0; i < elev.length; i++) {
    const v = elev[i];
    if (Number.isFinite(v)) {
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      sum += v; sq += v * v; n++;
    }
  }
  return {
    width: w, height: h, elev,
    bounds: { x0: 0, y0: 0, x1: w, y1: h },
    resolution: 1, originLat: 0, originLon: 0,
    // @ts-expect-error attach
    stats: { mn, mx, mean: n ? sum / n : 0, std: Math.sqrt(Math.max(0, sq / n - (sum / n) ** 2)), count: n },
  };
}
function computeStats(elev: Float32Array) {
  let mn = Infinity, mx = -Infinity, sum = 0, n = 0, sq = 0;
  for (let i = 0; i < elev.length; i++) {
    const v = elev[i];
    if (Number.isFinite(v)) {
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      sum += v; sq += v * v; n++;
    }
  }
  const mean = n ? sum / n : 0;
  return { mn, mx, mean, count: n, std: Math.sqrt(Math.max(0, sq / n - mean * mean)) };
}
function blendImages(a: ImageData, b: ImageData, alpha: number): ImageData {
  const out = new ImageData(a.width, a.height);
  const da = a.data, db = b.data, dc = out.data;
  for (let i = 0; i < da.length; i += 4) {
    const oa = alpha * (db[i + 3] / 255);
    dc[i]     = da[i]     * (1 - oa) + db[i]     * oa;
    dc[i + 1] = da[i + 1] * (1 - oa) + db[i + 1] * oa;
    dc[i + 2] = da[i + 2] * (1 - oa) + db[i + 2] * oa;
    dc[i + 3] = 255;
  }
  return out;
}
function formatBytes(b: number) {
  if (b < 1024) return b + " B";
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
  return (b / 1024 / 1024).toFixed(2) + " MB";
}

// ---------- UI bits ----------

function SectionHeader({ title }: { title: string }) {
  return (
    <div className="px-3 pt-3 pb-1.5 text-[10px] uppercase tracking-widest text-neutral-500 border-b border-neutral-800/60">
      {title}
    </div>
  );
}
function SourceRow({
  active, onClick, title, hint,
}: { active: boolean; onClick: () => void; title: string; hint: string }) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-3 py-2 rounded-md border transition-colors ${
        active
          ? "bg-emerald-500/10 border-emerald-500/50"
          : "border-neutral-800 hover:border-neutral-600 hover:bg-neutral-800/40"
      }`}
    >
      <div className={`text-xs font-medium ${active ? "text-emerald-200" : "text-neutral-200"}`}>{title}</div>
      <div className="text-[10px] text-neutral-500 mt-0.5">{hint}</div>
    </button>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-neutral-800 bg-neutral-900/60 px-2.5 py-1.5">
      <div className="text-[9px] uppercase tracking-wider text-neutral-500">{label}</div>
      <div className="font-mono text-neutral-200 truncate">{value}</div>
    </div>
  );
}
function Slider({
  label, value, min, max, step = 1, onChange, disabled, format,
}: {
  label: string; value: number; min: number; max: number; step?: number;
  onChange: (v: number) => void; disabled?: boolean; format?: (v: number) => string;
}) {
  return (
    <div className={disabled ? "opacity-40" : ""}>
      <div className="flex items-center justify-between mb-1">
        <label className="text-[11px] font-medium text-neutral-300">{label}</label>
        <span className="text-[11px] font-mono text-neutral-400 tabular-nums">
          {format ? format(value) : value}
        </span>
      </div>
      <input
        type="range"
        className="lumen-slider"
        min={min} max={max} step={step} value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  );
}
