export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'mythic';

export interface Attribute {
  id: string;
  name: string;
  emoji: string;
  rarity: Rarity;
  description: string;
  power: number;
}

export interface Upgrade {
  id: string;
  name: string;
  emoji: string;
  description: string;
  baseCost: number;
  costMultiplier: number;
  effect: 'miningPower' | 'autoMine' | 'luck' | 'critChance' | 'critMultiplier';
  effectValue: number;
  maxLevel: number;
}

export const RARITY_CONFIG: Record<Rarity, { color: string; bgColor: string; borderColor: string; glowColor: string; chance: number; label: string }> = {
  common: {
    color: 'text-gray-300',
    bgColor: 'bg-gray-800/50',
    borderColor: 'border-gray-600',
    glowColor: 'shadow-gray-500/20',
    chance: 0.50,
    label: 'Common'
  },
  uncommon: {
    color: 'text-green-400',
    bgColor: 'bg-green-900/30',
    borderColor: 'border-green-600',
    glowColor: 'shadow-green-500/30',
    chance: 0.25,
    label: 'Uncommon'
  },
  rare: {
    color: 'text-blue-400',
    bgColor: 'bg-blue-900/30',
    borderColor: 'border-blue-600',
    glowColor: 'shadow-blue-500/30',
    chance: 0.13,
    label: 'Rare'
  },
  epic: {
    color: 'text-purple-400',
    bgColor: 'bg-purple-900/30',
    borderColor: 'border-purple-600',
    glowColor: 'shadow-purple-500/40',
    chance: 0.07,
    label: 'Epic'
  },
  legendary: {
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-900/30',
    borderColor: 'border-yellow-500',
    glowColor: 'shadow-yellow-500/50',
    chance: 0.035,
    label: 'Legendary'
  },
  mythic: {
    color: 'text-red-400',
    bgColor: 'bg-red-900/30',
    borderColor: 'border-red-500',
    glowColor: 'shadow-red-500/50',
    chance: 0.015,
    label: 'Mythic'
  }
};

export const ATTRIBUTES: Attribute[] = [
  // Common
  { id: 'peel', name: 'Banana Peel', emoji: '🍌', rarity: 'common', description: 'A simple banana peel. Not much, but honest work.', power: 1 },
  { id: 'seed', name: 'Potassium Seed', emoji: '🌱', rarity: 'common', description: 'A tiny seed of potassium goodness.', power: 1 },
  { id: 'leaf', name: 'Banana Leaf', emoji: '🍃', rarity: 'common', description: 'A fresh leaf from the banana tree.', power: 1 },
  { id: 'smoothie', name: 'Banana Smoothie', emoji: '🥤', rarity: 'common', description: 'Blended banana refreshment.', power: 2 },
  { id: 'chip', name: 'Banana Chip', emoji: '🥜', rarity: 'common', description: 'Crispy dried banana snack.', power: 1 },

  // Uncommon
  { id: 'golden_peel', name: 'Golden Peel', emoji: '✨', rarity: 'uncommon', description: 'A shimmering golden banana peel.', power: 5 },
  { id: 'bunch', name: 'Perfect Bunch', emoji: '🍈', rarity: 'uncommon', description: 'A perfectly formed bunch of bananos.', power: 4 },
  { id: 'monkey', name: 'Monkey Friend', emoji: '🐒', rarity: 'uncommon', description: 'A helpful monkey assistant for mining.', power: 6 },
  { id: 'potassium', name: 'Pure Potassium', emoji: '⚗️', rarity: 'uncommon', description: 'Concentrated potassium element K.', power: 5 },
  { id: 'plantation', name: 'Mini Plantation', emoji: '🌴', rarity: 'uncommon', description: 'A small banana plantation.', power: 7 },

  // Rare
  { id: 'crystal', name: 'Banano Crystal', emoji: '💎', rarity: 'rare', description: 'Crystallized banana essence, quite rare.', power: 15 },
  { id: 'crown', name: 'Banana Crown', emoji: '👑', rarity: 'rare', description: 'A crown made of golden bananas.', power: 12 },
  { id: 'shield', name: 'Potassium Shield', emoji: '🛡️', rarity: 'rare', description: 'A protective shield infused with potassium.', power: 18 },
  { id: 'rocket', name: 'Banana Rocket', emoji: '🚀', rarity: 'rare', description: 'To the moon! A banana-powered rocket.', power: 20 },
  { id: 'telescope', name: 'Banano Scope', emoji: '🔭', rarity: 'rare', description: 'See rare bananos from far away.', power: 14 },

  // Epic
  { id: 'lightning', name: 'Lightning Banana', emoji: '⚡', rarity: 'epic', description: 'A banana charged with pure electricity!', power: 40 },
  { id: 'frost', name: 'Frost Banana', emoji: '❄️', rarity: 'epic', description: 'An ice-cold banana that freezes time.', power: 35 },
  { id: 'quantum', name: 'Quantum Peel', emoji: '🔮', rarity: 'epic', description: 'Exists in multiple states simultaneously.', power: 50 },
  { id: 'dragon', name: 'Dragon Banana', emoji: '🐉', rarity: 'epic', description: 'A banana guarded by an ancient dragon.', power: 45 },
  { id: 'vortex', name: 'Banana Vortex', emoji: '🌀', rarity: 'epic', description: 'A swirling vortex of banana energy.', power: 38 },

  // Legendary
  { id: 'flamethrower', name: 'Flamethrower', emoji: '🔥', rarity: 'legendary', description: 'THE legendary Flamethrower! Scorches through blocks instantly. The most sought-after attribute in Bananocoin mining!', power: 150 },
  { id: 'infinity', name: 'Infinity Banana', emoji: '♾️', rarity: 'legendary', description: 'An infinitely recursive banana. Mind-bending.', power: 120 },
  { id: 'supernova', name: 'Supernova Core', emoji: '💥', rarity: 'legendary', description: 'The explosive core of a banana supernova.', power: 130 },
  { id: 'nexus', name: 'Banano Nexus', emoji: '🌟', rarity: 'legendary', description: 'The central nexus connecting all bananos.', power: 140 },

  // Mythic
  { id: 'genesis', name: 'Genesis Banana', emoji: '🌌', rarity: 'mythic', description: 'The first banana ever created. Origin of all.', power: 500 },
  { id: 'cosmic', name: 'Cosmic Potassium', emoji: '🪐', rarity: 'mythic', description: 'Potassium from the edge of the universe.', power: 400 },
  { id: 'omega', name: 'Omega Peel', emoji: '☀️', rarity: 'mythic', description: 'The final evolution. Pure banana perfection.', power: 600 },
];

export const UPGRADES: Upgrade[] = [
  {
    id: 'pickaxe',
    name: 'Better Pickaxe',
    emoji: '⛏️',
    description: '+1 mining power per click',
    baseCost: 50,
    costMultiplier: 1.8,
    effect: 'miningPower',
    effectValue: 1,
    maxLevel: 50
  },
  {
    id: 'autoMiner',
    name: 'Auto Miner',
    emoji: '🤖',
    description: '+1 banano per second',
    baseCost: 100,
    costMultiplier: 1.6,
    effect: 'autoMine',
    effectValue: 1,
    maxLevel: 100
  },
  {
    id: 'luckyCharm',
    name: 'Lucky Charm',
    emoji: '🍀',
    description: '+2% luck for rarer finds',
    baseCost: 200,
    costMultiplier: 2.2,
    effect: 'luck',
    effectValue: 0.02,
    maxLevel: 30
  },
  {
    id: 'critPick',
    name: 'Critical Pickaxe',
    emoji: '💎',
    description: '+5% critical hit chance',
    baseCost: 300,
    costMultiplier: 2.5,
    effect: 'critChance',
    effectValue: 0.05,
    maxLevel: 15
  },
  {
    id: 'megaCrit',
    name: 'Mega Multiplier',
    emoji: '🔥',
    description: '+0.5x critical multiplier',
    baseCost: 500,
    costMultiplier: 3.0,
    effect: 'critMultiplier',
    effectValue: 0.5,
    maxLevel: 10
  }
];

export function formatNumber(n: number): string {
  if (n >= 1e12) return (n / 1e12).toFixed(1) + 'T';
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return Math.floor(n).toString();
}
