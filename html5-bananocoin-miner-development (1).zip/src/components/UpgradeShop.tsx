import { UPGRADES, formatNumber } from '../gameData';

interface Props {
  bananocoins: number;
  upgradeLevels: Record<string, number>;
  onBuyUpgrade: (id: string) => void;
}

export default function UpgradeShop({ bananocoins, upgradeLevels, onBuyUpgrade }: Props) {
  return (
    <div className="w-full">
      <h2 className="text-lg font-bold text-yellow-400 mb-3 flex items-center gap-2">
        <span>🏪</span> Upgrade Shop
      </h2>
      <div className="space-y-2">
        {UPGRADES.map(upgrade => {
          const level = upgradeLevels[upgrade.id] || 0;
          const cost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, level));
          const canAfford = bananocoins >= cost;
          const maxed = level >= upgrade.maxLevel;

          return (
            <button
              key={upgrade.id}
              onClick={() => !maxed && canAfford && onBuyUpgrade(upgrade.id)}
              disabled={!canAfford || maxed}
              className={`
                w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-all duration-200 text-left
                ${maxed 
                  ? 'bg-gray-800/20 border-gray-700/30 opacity-50 cursor-not-allowed'
                  : canAfford 
                    ? 'bg-gray-800/50 border-yellow-500/30 hover:border-yellow-400/60 hover:bg-gray-800/80 cursor-pointer hover:shadow-lg hover:shadow-yellow-500/10' 
                    : 'bg-gray-800/30 border-gray-700/30 opacity-60 cursor-not-allowed'
                }
              `}
            >
              <div className="text-2xl w-10 text-center flex-shrink-0">{upgrade.emoji}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-gray-200">{upgrade.name}</span>
                  <span className="text-xs text-gray-500 ml-2">Lv.{level}/{upgrade.maxLevel}</span>
                </div>
                <p className="text-xs text-gray-500 mt-0.5">{upgrade.description}</p>
              </div>
              <div className={`text-sm font-bold flex-shrink-0 ${canAfford ? 'text-yellow-400' : 'text-gray-600'}`}>
                {maxed ? 'MAX' : `🍌${formatNumber(cost)}`}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
