import { formatNumber } from '../gameData';

interface Props {
  bananocoins: number;
  miningPower: number;
  autoMineRate: number;
  luck: number;
  critChance: number;
  critMultiplier: number;
  totalClicks: number;
  hashRate: number;
}

export default function StatsBar({ bananocoins, miningPower, autoMineRate, luck, critChance, critMultiplier, totalClicks, hashRate }: Props) {
  return (
    <div className="w-full">
      {/* Main balance */}
      <div className="text-center mb-4">
        <div className="text-xs font-mono text-yellow-500/60 uppercase tracking-widest mb-1">Balance</div>
        <div className="text-4xl md:text-5xl font-bold text-yellow-400 flex items-center justify-center gap-2">
          <span className="animate-float">🍌</span>
          <span style={{ textShadow: '0 0 30px rgba(251,191,36,0.3)' }}>
            {formatNumber(bananocoins)}
          </span>
        </div>
        <div className="text-xs font-mono text-gray-500 mt-1">
          Hash Rate: {formatNumber(hashRate)} H/s
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2 text-center">
        <StatItem label="Power" value={formatNumber(miningPower)} emoji="⛏️" />
        <StatItem label="Auto/s" value={formatNumber(autoMineRate)} emoji="🤖" />
        <StatItem label="Luck" value={`${(luck * 100).toFixed(0)}%`} emoji="🍀" />
        <StatItem label="Crit %" value={`${(critChance * 100).toFixed(0)}%`} emoji="💥" />
        <StatItem label="Crit x" value={`${critMultiplier.toFixed(1)}x`} emoji="✨" />
        <StatItem label="Clicks" value={formatNumber(totalClicks)} emoji="👆" />
      </div>
    </div>
  );
}

function StatItem({ label, value, emoji }: { label: string; value: string; emoji: string }) {
  return (
    <div className="bg-gray-800/40 border border-gray-700/50 rounded-lg px-2 py-2">
      <div className="text-lg">{emoji}</div>
      <div className="text-yellow-400 font-bold text-sm">{value}</div>
      <div className="text-gray-500 text-[10px] uppercase tracking-wider">{label}</div>
    </div>
  );
}
