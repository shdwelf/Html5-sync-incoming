import { useEffect, useState } from 'react';
import { Attribute, RARITY_CONFIG } from '../gameData';

interface Props {
  attribute: Attribute | null;
  onClose: () => void;
}

export default function DiscoveryPopup({ attribute, onClose }: Props) {
  const [visible, setVisible] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (attribute) {
      setVisible(true);
      setLeaving(false);
      const timer = setTimeout(() => {
        handleClose();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [attribute]);

  const handleClose = () => {
    setLeaving(true);
    setTimeout(() => {
      setVisible(false);
      setLeaving(false);
      onClose();
    }, 400);
  };

  if (!visible || !attribute) return null;

  const config = RARITY_CONFIG[attribute.rarity];
  const isLegendaryPlus = attribute.rarity === 'legendary' || attribute.rarity === 'mythic';
  const isFlamethrower = attribute.id === 'flamethrower';

  return (
    <div
      className={`
        fixed top-4 right-4 z-50 max-w-sm
        ${leaving ? 'animate-slide-out' : 'animate-slide-in'}
      `}
      onClick={handleClose}
    >
      <div className={`
        relative overflow-hidden rounded-xl border-2 ${config.borderColor} ${config.bgColor}
        backdrop-blur-xl p-4 cursor-pointer
        shadow-2xl ${config.glowColor}
        ${isLegendaryPlus ? 'animate-pulse-glow' : ''}
      `}>
        {/* Background effects for rare+ */}
        {isLegendaryPlus && (
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent animate-pulse" />
        )}
        
        <div className="relative flex items-start gap-3">
          <div className={`text-4xl animate-pop-in ${isFlamethrower ? 'animate-flame' : ''}`}>
            {attribute.emoji}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-0.5">
              <span className={`text-[10px] uppercase tracking-wider font-bold ${config.color} px-2 py-0.5 rounded-full ${config.bgColor} border ${config.borderColor}`}>
                {config.label}
              </span>
              <span className="text-[10px] text-gray-500">NEW FIND!</span>
            </div>
            <h3 className={`font-bold text-lg ${config.color} ${isFlamethrower ? 'animate-rainbow' : ''}`}>
              {attribute.name}
            </h3>
            <p className="text-xs text-gray-400 mt-1 leading-relaxed">
              {attribute.description}
            </p>
            <div className="mt-2 text-xs text-yellow-400/80 font-mono">
              +{attribute.power} 🍌 bonus
            </div>
          </div>
        </div>

        {/* Sparkle effects for legendary+ */}
        {isLegendaryPlus && (
          <>
            <div className="absolute top-2 right-2 text-yellow-400/60 animate-pulse">✦</div>
            <div className="absolute bottom-2 left-2 text-yellow-400/40 animate-pulse" style={{ animationDelay: '0.5s' }}>✦</div>
            <div className="absolute top-1/2 right-6 text-yellow-400/30 animate-pulse" style={{ animationDelay: '1s' }}>✧</div>
          </>
        )}
      </div>
    </div>
  );
}
