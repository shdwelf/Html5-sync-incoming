import { useState } from 'react';
import { ATTRIBUTES, RARITY_CONFIG, Rarity } from '../gameData';

interface Props {
  discoveredAttributes: Record<string, number>;
}

const RARITY_ORDER: Rarity[] = ['mythic', 'legendary', 'epic', 'rare', 'uncommon', 'common'];

export default function AttributeCollection({ discoveredAttributes }: Props) {
  const [filterRarity, setFilterRarity] = useState<Rarity | 'all'>('all');
  const totalDiscovered = Object.keys(discoveredAttributes).length;
  const totalAttributes = ATTRIBUTES.length;

  const filteredAttrs = ATTRIBUTES.filter(a => {
    if (filterRarity !== 'all' && a.rarity !== filterRarity) return false;
    return true;
  });

  // Sort: discovered first, then by rarity
  const sortedAttrs = [...filteredAttrs].sort((a, b) => {
    const aDisc = discoveredAttributes[a.id] ? 1 : 0;
    const bDisc = discoveredAttributes[b.id] ? 1 : 0;
    if (aDisc !== bDisc) return bDisc - aDisc;
    return RARITY_ORDER.indexOf(a.rarity) - RARITY_ORDER.indexOf(b.rarity);
  });

  return (
    <div className="w-full">
      <h2 className="text-lg font-bold text-yellow-400 mb-1 flex items-center gap-2">
        <span>📦</span> Collection
        <span className="text-xs font-normal text-gray-500">
          {totalDiscovered}/{totalAttributes}
        </span>
      </h2>

      {/* Progress bar */}
      <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden mb-3">
        <div
          className="h-full bg-gradient-to-r from-yellow-500 to-amber-400 transition-all duration-500 rounded-full"
          style={{ width: `${(totalDiscovered / totalAttributes) * 100}%` }}
        />
      </div>

      {/* Rarity filter */}
      <div className="flex flex-wrap gap-1 mb-3">
        <FilterBtn active={filterRarity === 'all'} onClick={() => setFilterRarity('all')} label="All" color="text-gray-300" />
        {RARITY_ORDER.map(r => (
          <FilterBtn
            key={r}
            active={filterRarity === r}
            onClick={() => setFilterRarity(r)}
            label={RARITY_CONFIG[r].label}
            color={RARITY_CONFIG[r].color}
          />
        ))}
      </div>

      {/* Attribute grid */}
      <div className="grid grid-cols-1 gap-1.5 max-h-[400px] overflow-y-auto pr-1">
        {sortedAttrs.map(attr => {
          const count = discoveredAttributes[attr.id] || 0;
          const discovered = count > 0;
          const config = RARITY_CONFIG[attr.rarity];
          const isFlamethrower = attr.id === 'flamethrower';

          return (
            <div
              key={attr.id}
              className={`
                flex items-center gap-2.5 px-3 py-2 rounded-lg border transition-all
                ${discovered
                  ? `${config.bgColor} ${config.borderColor} shadow-md ${config.glowColor}`
                  : 'bg-gray-900/30 border-gray-800/50 opacity-40'
                }
                ${isFlamethrower && discovered ? 'animate-flame ring-1 ring-orange-500/30' : ''}
              `}
            >
              <div className={`text-2xl ${!discovered ? 'grayscale opacity-30' : ''}`}>
                {discovered ? attr.emoji : '❓'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-semibold ${discovered ? config.color : 'text-gray-600'} ${isFlamethrower && discovered ? 'animate-rainbow' : ''}`}>
                    {discovered ? attr.name : '???'}
                  </span>
                  {discovered && count > 1 && (
                    <span className="text-[10px] bg-gray-700/50 px-1.5 py-0.5 rounded text-gray-400">
                      x{count}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] uppercase tracking-wider font-bold ${config.color}`}>
                    {config.label}
                  </span>
                  {discovered && (
                    <span className="text-[10px] text-gray-500">
                      +{attr.power} power
                    </span>
                  )}
                </div>
                {discovered && (
                  <p className="text-[11px] text-gray-500 mt-0.5 leading-tight">{attr.description}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FilterBtn({ active, onClick, label, color }: { active: boolean; onClick: () => void; label: string; color: string }) {
  return (
    <button
      onClick={onClick}
      className={`
        text-[10px] px-2 py-1 rounded-md font-bold uppercase tracking-wider transition-all
        ${active
          ? `${color} bg-gray-700/60 border border-gray-600`
          : 'text-gray-600 bg-gray-800/30 border border-transparent hover:border-gray-700/50'
        }
      `}
    >
      {label}
    </button>
  );
}
