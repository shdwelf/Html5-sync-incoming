import { useEffect, useRef, useState } from 'react';

interface LogEntry {
  id: number;
  text: string;
  timestamp: number;
}

let logId = 0;

const HASH_CHARS = '0123456789abcdef';
function randomHash(len: number): string {
  let hash = '';
  for (let i = 0; i < len; i++) {
    hash += HASH_CHARS[Math.floor(Math.random() * HASH_CHARS.length)];
  }
  return hash;
}

const BLOCK_MESSAGES = [
  'Scanning mempool for banano transactions...',
  'Verifying potassium signatures...',
  'Computing DAG proof of work...',
  'Validating banana chain integrity...',
  'Mining block #{block}...',
  'Hashing nonce: 0x{hash}...',
  'Found valid hash: 0x{hash}',
  'Broadcasting to banana network...',
  'Confirming block #{block} on chain...',
  'Checking for rare attribute mutations...',
  'Analyzing potassium isotope ratios...',
  'Scanning for legendary patterns...',
  'Querying attribute oracle...',
  'Entropy pool seeded: 0x{hash}',
  'Block reward: +{reward} BAN',
];

interface Props {
  totalClicks: number;
  autoMineRate: number;
}

export default function MiningLog({ totalClicks, autoMineRate }: Props) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const logRef = useRef<HTMLDivElement>(null);
  const blockRef = useRef(1000 + Math.floor(Math.random() * 9000));

  useEffect(() => {
    const interval = setInterval(() => {
      if (totalClicks === 0 && autoMineRate === 0) return;
      
      blockRef.current++;
      const template = BLOCK_MESSAGES[Math.floor(Math.random() * BLOCK_MESSAGES.length)];
      const text = template
        .replace('{block}', blockRef.current.toString())
        .replace('{hash}', randomHash(12))
        .replace('{reward}', (Math.random() * 10 + 1).toFixed(2));

      setLogs(prev => {
        const newLogs = [...prev, { id: logId++, text, timestamp: Date.now() }];
        return newLogs.slice(-50);
      });
    }, 800 + Math.random() * 1200);

    return () => clearInterval(interval);
  }, [totalClicks, autoMineRate]);

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="w-full">
      <h2 className="text-lg font-bold text-yellow-400 mb-2 flex items-center gap-2">
        <span>📜</span> Mining Log
      </h2>
      <div
        ref={logRef}
        className="bg-gray-950/80 border border-gray-800/50 rounded-lg p-3 h-32 overflow-y-auto font-mono text-[11px] leading-relaxed"
      >
        {logs.length === 0 ? (
          <div className="text-gray-600 text-center mt-8">
            Start mining to see the log...
          </div>
        ) : (
          logs.map(log => (
            <div key={log.id} className="text-green-400/70 mb-0.5">
              <span className="text-gray-600">[{new Date(log.timestamp).toLocaleTimeString()}]</span>{' '}
              {log.text}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
