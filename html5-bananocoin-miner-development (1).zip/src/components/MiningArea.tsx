import { useState, useRef, useCallback } from 'react';

interface Particle {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
}

interface Props {
  onMine: () => void;
  lastClickAmount: number;
  isCrit: boolean;
  miningPower: number;
}

let particleId = 0;

export default function MiningArea({ onMine, lastClickAmount, isCrit, miningPower }: Props) {
  const [particles, setParticles] = useState<Particle[]>([]);
  const [isShaking, setIsShaking] = useState(false);
  const [clickScale, setClickScale] = useState(1);
  const btnRef = useRef<HTMLButtonElement>(null);

  const handleClick = useCallback((e: React.MouseEvent) => {
    onMine();
    
    setIsShaking(true);
    setClickScale(0.9);
    setTimeout(() => { setIsShaking(false); setClickScale(1); }, 150);

    const rect = btnRef.current?.getBoundingClientRect();
    if (rect) {
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const newParticles: Particle[] = [];
      // Main amount particle
      newParticles.push({
        id: particleId++,
        x: x + (Math.random() - 0.5) * 40,
        y: y - 20,
        text: `+${lastClickAmount || miningPower}`,
        color: isCrit ? '#fbbf24' : '#34d399'
      });

      // Banana emoji particles
      for (let i = 0; i < (isCrit ? 5 : 2); i++) {
        newParticles.push({
          id: particleId++,
          x: x + (Math.random() - 0.5) * 100,
          y: y + (Math.random() - 0.5) * 30,
          text: '🍌',
          color: '#fbbf24'
        });
      }

      setParticles(prev => [...prev, ...newParticles]);
      setTimeout(() => {
        setParticles(prev => prev.filter(p => !newParticles.includes(p)));
      }, 1000);
    }
  }, [onMine, lastClickAmount, isCrit, miningPower]);

  return (
    <div className="relative flex flex-col items-center">
      {/* Particles */}
      {particles.map(p => (
        <div
          key={p.id}
          className="pointer-events-none absolute animate-particle-up"
          style={{
            left: p.x,
            top: p.y,
            color: p.color,
            fontSize: p.text.startsWith('+') ? '1.5rem' : '1.2rem',
            fontWeight: 'bold',
            zIndex: 50,
            textShadow: `0 0 10px ${p.color}`
          }}
        >
          {p.text}
        </div>
      ))}

      {/* Mining button */}
      <button
        ref={btnRef}
        onClick={handleClick}
        className={`
          relative w-48 h-48 md:w-56 md:h-56 rounded-full 
          bg-gradient-to-br from-yellow-400 via-yellow-500 to-amber-600
          border-4 border-yellow-300/50
          flex items-center justify-center
          cursor-pointer select-none
          transition-transform duration-100
          hover:from-yellow-300 hover:via-yellow-400 hover:to-amber-500
          active:from-yellow-500 active:via-amber-600 active:to-orange-700
          ${isShaking ? 'animate-shake' : ''}
          animate-pulse-glow
        `}
        style={{ transform: `scale(${clickScale})` }}
      >
        {/* Rotating ring */}
        <div className="absolute inset-[-8px] rounded-full border-2 border-dashed border-yellow-400/30 animate-spin-slow" />
        <div className="absolute inset-[-16px] rounded-full border border-dashed border-yellow-400/15 animate-spin-slow" style={{ animationDirection: 'reverse', animationDuration: '12s' }} />
        
        {/* Banana icon */}
        <span className="text-7xl md:text-8xl" style={{ filter: 'drop-shadow(0 0 20px rgba(255,200,0,0.5))' }}>
          🍌
        </span>
      </button>

      <p className="mt-6 text-yellow-400/60 text-sm font-mono tracking-wider uppercase">
        Click to Mine
      </p>
    </div>
  );
}
