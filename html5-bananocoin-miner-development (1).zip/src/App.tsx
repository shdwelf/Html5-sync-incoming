import { useState } from 'react';
import { useGameState } from './useGameState';
import MiningArea from './components/MiningArea';
import StatsBar from './components/StatsBar';
import UpgradeShop from './components/UpgradeShop';
import AttributeCollection from './components/AttributeCollection';
import DiscoveryPopup from './components/DiscoveryPopup';
import MiningLog from './components/MiningLog';
import { ATTRIBUTES, RARITY_CONFIG, formatNumber } from './gameData';

type Tab = 'mine' | 'upgrades' | 'collection' | 'stats';

export default function App() {
  const { state, mine, buyUpgrade, clearRecentFind, resetGame } = useGameState();
  const [activeTab, setActiveTab] = useState<Tab>('mine');
  const [showReset, setShowReset] = useState(false);

  const discoveredCount = Object.keys(state.discoveredAttributes).length;
  const totalPower = Object.entries(state.discoveredAttributes).reduce((sum, [id, count]) => {
    const attr = ATTRIBUTES.find(a => a.id === id);
    return sum + (attr ? attr.power * count : 0);
  }, 0);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-gray-950 text-white relative overflow-hidden">
      {/* Background effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-yellow-500/3 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-amber-500/3 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-yellow-500/2 rounded-full blur-3xl" />
      </div>

      {/* Discovery Popup */}
      <DiscoveryPopup attribute={state.recentFind} onClose={clearRecentFind} />

      {/* Header */}
      <header className="relative z-10 border-b border-yellow-500/10 bg-gray-950/80 backdrop-blur-xl">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl animate-float">🍌</span>
            <div>
              <h1 className="text-lg font-bold text-yellow-400 leading-tight">Bananocoin Miner</h1>
              <p className="text-[10px] text-gray-500 font-mono uppercase tracking-wider">Mine Rare Attributes</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs text-gray-500">Balance</div>
              <div className="text-lg font-bold text-yellow-400 font-mono">{formatNumber(state.bananocoins)} BAN</div>
            </div>
            <button
              onClick={() => setShowReset(true)}
              className="text-gray-600 hover:text-red-400 transition-colors text-xs p-1"
              title="Reset Game"
            >
              ⟳
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-5xl mx-auto px-4 py-4 pb-24">
        {/* Stats Bar - always visible */}
        <div className="mb-6">
          <StatsBar
            bananocoins={state.bananocoins}
            miningPower={state.miningPower}
            autoMineRate={state.autoMineRate}
            luck={state.luck}
            critChance={state.critChance}
            critMultiplier={state.critMultiplier}
            totalClicks={state.totalClicks}
            hashRate={state.hashRate}
          />
        </div>

        {/* Tab Content */}
        <div className="min-h-[50vh]">
          {activeTab === 'mine' && (
            <div className="flex flex-col items-center gap-6">
              {/* Target attribute showcase */}
              <div className="w-full max-w-md bg-gradient-to-r from-orange-950/30 via-red-950/30 to-orange-950/30 border border-orange-500/20 rounded-xl p-3 text-center">
                <div className="text-[10px] uppercase tracking-widest text-orange-400/60 mb-1">🎯 Most Wanted Attribute</div>
                <div className="flex items-center justify-center gap-2">
                  <span className="text-2xl animate-flame">🔥</span>
                  <span className="text-xl font-bold text-orange-400 animate-flame">FLAMETHROWER</span>
                  <span className="text-2xl animate-flame">🔥</span>
                </div>
                <div className="text-xs text-orange-400/50 mt-1">
                  {state.discoveredAttributes['flamethrower']
                    ? `✅ FOUND! (x${state.discoveredAttributes['flamethrower']})`
                    : `Drop Rate: ~3.5% × Discovery Chance • Keep mining!`
                  }
                </div>
              </div>

              {/* Mining Area */}
              <MiningArea
                onMine={mine}
                lastClickAmount={state.lastClickAmount}
                isCrit={state.isCrit}
                miningPower={state.miningPower}
              />

              {/* Mining Log */}
              <div className="w-full max-w-lg mt-2">
                <MiningLog totalClicks={state.totalClicks} autoMineRate={state.autoMineRate} />
              </div>

              {/* Quick collection summary */}
              <div className="w-full max-w-lg">
                <div className="text-xs text-gray-500 mb-2 uppercase tracking-wider">Recent Discoveries</div>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(state.discoveredAttributes)
                    .sort(([, a], [, b]) => b - a)
                    .slice(0, 12)
                    .map(([id, count]) => {
                      const attr = ATTRIBUTES.find(a => a.id === id);
                      if (!attr) return null;
                      const config = RARITY_CONFIG[attr.rarity];
                      return (
                        <div
                          key={id}
                          className={`flex items-center gap-1 px-2 py-1 rounded-md ${config.bgColor} border ${config.borderColor} text-xs`}
                          title={`${attr.name} x${count}`}
                        >
                          <span>{attr.emoji}</span>
                          <span className={config.color}>{attr.name}</span>
                          {count > 1 && <span className="text-gray-500">x{count}</span>}
                        </div>
                      );
                    })
                  }
                  {discoveredCount === 0 && (
                    <div className="text-gray-600 text-xs">No attributes discovered yet. Start mining!</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'upgrades' && (
            <div className="max-w-lg mx-auto">
              <UpgradeShop
                bananocoins={state.bananocoins}
                upgradeLevels={state.upgradeLevels}
                onBuyUpgrade={buyUpgrade}
              />
            </div>
          )}

          {activeTab === 'collection' && (
            <div className="max-w-lg mx-auto">
              <AttributeCollection discoveredAttributes={state.discoveredAttributes} />
            </div>
          )}

          {activeTab === 'stats' && (
            <div className="max-w-lg mx-auto space-y-4">
              <h2 className="text-lg font-bold text-yellow-400 flex items-center gap-2">
                <span>📊</span> Statistics
              </h2>
              
              <div className="grid grid-cols-2 gap-3">
                <StatCard label="Total Mined" value={formatNumber(state.totalMined)} emoji="🍌" />
                <StatCard label="Total Clicks" value={formatNumber(state.totalClicks)} emoji="👆" />
                <StatCard label="Attributes Found" value={`${discoveredCount}/${ATTRIBUTES.length}`} emoji="📦" />
                <StatCard label="Collection Power" value={formatNumber(totalPower)} emoji="⚡" />
                <StatCard label="Mining Power" value={formatNumber(state.miningPower)} emoji="⛏️" />
                <StatCard label="Auto Mine/s" value={formatNumber(state.autoMineRate)} emoji="🤖" />
                <StatCard label="Luck Bonus" value={`${(state.luck * 100).toFixed(1)}%`} emoji="🍀" />
                <StatCard label="Crit Chance" value={`${(state.critChance * 100).toFixed(1)}%`} emoji="💥" />
              </div>

              {/* Rarity breakdown */}
              <div className="mt-6">
                <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wider">Rarity Breakdown</h3>
                {(['mythic', 'legendary', 'epic', 'rare', 'uncommon', 'common'] as const).map(rarity => {
                  const config = RARITY_CONFIG[rarity];
                  const total = ATTRIBUTES.filter(a => a.rarity === rarity).length;
                  const found = ATTRIBUTES.filter(a => a.rarity === rarity && state.discoveredAttributes[a.id]).length;

                  return (
                    <div key={rarity} className="flex items-center gap-3 mb-2">
                      <span className={`text-xs font-bold uppercase tracking-wider w-20 ${config.color}`}>
                        {config.label}
                      </span>
                      <div className="flex-1 h-3 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500`}
                          style={{
                            width: `${(found / total) * 100}%`,
                            background: rarity === 'mythic' ? 'linear-gradient(90deg, #ef4444, #f97316)' :
                              rarity === 'legendary' ? 'linear-gradient(90deg, #eab308, #f59e0b)' :
                              rarity === 'epic' ? 'linear-gradient(90deg, #a855f7, #7c3aed)' :
                              rarity === 'rare' ? 'linear-gradient(90deg, #3b82f6, #2563eb)' :
                              rarity === 'uncommon' ? 'linear-gradient(90deg, #22c55e, #16a34a)' :
                              'linear-gradient(90deg, #9ca3af, #6b7280)'
                          }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 w-10 text-right">{found}/{total}</span>
                    </div>
                  );
                })}
              </div>

              {/* Drop rates */}
              <div className="mt-6 bg-gray-900/50 border border-gray-800/50 rounded-xl p-4">
                <h3 className="text-sm font-semibold text-gray-400 mb-2 uppercase tracking-wider">Drop Rate Info</h3>
                <div className="text-xs text-gray-500 space-y-1">
                  <p>• Base discovery chance: 15% per mine action</p>
                  <p>• Luck upgrades increase discovery and rarity chances</p>
                  <p>• Pity system: +2% per mine without a find</p>
                  <p>• 🔥 <span className="text-orange-400">Flamethrower</span>: ~3.5% of legendary drops</p>
                  <p>• 🌌 <span className="text-red-400">Mythic</span> attributes: 1.5% base rarity</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-gray-950/95 backdrop-blur-xl border-t border-yellow-500/10">
        <div className="max-w-5xl mx-auto flex">
          <NavBtn active={activeTab === 'mine'} onClick={() => setActiveTab('mine')} emoji="⛏️" label="Mine" />
          <NavBtn active={activeTab === 'upgrades'} onClick={() => setActiveTab('upgrades')} emoji="🏪" label="Shop" badge={state.bananocoins >= 50 ? '!' : undefined} />
          <NavBtn active={activeTab === 'collection'} onClick={() => setActiveTab('collection')} emoji="📦" label="Collection" badge={discoveredCount > 0 ? discoveredCount.toString() : undefined} />
          <NavBtn active={activeTab === 'stats'} onClick={() => setActiveTab('stats')} emoji="📊" label="Stats" />
        </div>
      </nav>

      {/* Reset Confirmation Modal */}
      {showReset && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={() => setShowReset(false)}>
          <div className="bg-gray-900 border border-red-500/30 rounded-2xl p-6 max-w-sm w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <h3 className="text-xl font-bold text-red-400 mb-2">⚠️ Reset Game?</h3>
            <p className="text-gray-400 text-sm mb-4">
              This will delete ALL your progress including {formatNumber(state.bananocoins)} BAN, {discoveredCount} discovered attributes, and all upgrades. This cannot be undone!
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowReset(false)}
                className="flex-1 py-2 rounded-lg bg-gray-800 border border-gray-700 text-gray-300 font-semibold hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => { resetGame(); setShowReset(false); }}
                className="flex-1 py-2 rounded-lg bg-red-600 border border-red-500 text-white font-semibold hover:bg-red-500 transition-colors"
              >
                Reset Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function NavBtn({ active, onClick, emoji, label, badge }: { active: boolean; onClick: () => void; emoji: string; label: string; badge?: string }) {
  return (
    <button
      onClick={onClick}
      className={`
        flex-1 flex flex-col items-center py-2.5 transition-all relative
        ${active ? 'text-yellow-400' : 'text-gray-500 hover:text-gray-300'}
      `}
    >
      {active && <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-yellow-400 rounded-full" />}
      <span className="text-xl">{emoji}</span>
      <span className="text-[10px] font-semibold uppercase tracking-wider mt-0.5">{label}</span>
      {badge && (
        <span className="absolute top-1 right-1/4 bg-yellow-500 text-gray-900 text-[9px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
          {badge}
        </span>
      )}
    </button>
  );
}

function StatCard({ label, value, emoji }: { label: string; value: string; emoji: string }) {
  return (
    <div className="bg-gray-800/40 border border-gray-700/40 rounded-xl p-4 text-center">
      <div className="text-2xl mb-1">{emoji}</div>
      <div className="text-xl font-bold text-yellow-400">{value}</div>
      <div className="text-xs text-gray-500 uppercase tracking-wider mt-1">{label}</div>
    </div>
  );
}
