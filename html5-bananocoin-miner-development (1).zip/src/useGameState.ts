import { useState, useCallback, useRef, useEffect } from 'react';
import { Attribute, ATTRIBUTES, RARITY_CONFIG, UPGRADES, Rarity } from './gameData';

export interface GameState {
  bananocoins: number;
  totalMined: number;
  totalClicks: number;
  miningPower: number;
  autoMineRate: number;
  luck: number;
  critChance: number;
  critMultiplier: number;
  upgradeLevels: Record<string, number>;
  discoveredAttributes: Record<string, number>;
  recentFind: Attribute | null;
  lastClickAmount: number;
  isCrit: boolean;
  minesSinceLastFind: number;
  hashRate: number;
}

const INITIAL_STATE: GameState = {
  bananocoins: 0,
  totalMined: 0,
  totalClicks: 0,
  miningPower: 1,
  autoMineRate: 0,
  luck: 0,
  critChance: 0.05,
  critMultiplier: 2,
  upgradeLevels: {},
  discoveredAttributes: {},
  recentFind: null,
  lastClickAmount: 0,
  isCrit: false,
  minesSinceLastFind: 0,
  hashRate: 0,
};

function loadState(): GameState {
  try {
    const saved = localStorage.getItem('bananocoin_miner_state');
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...INITIAL_STATE, ...parsed, recentFind: null };
    }
  } catch {}
  return { ...INITIAL_STATE };
}

function rollForAttribute(luck: number, minesSinceLastFind: number): Attribute | null {
  // Base discovery chance: 15%, increases with pity system
  const pityBonus = Math.min(minesSinceLastFind * 0.02, 0.5);
  const discoveryChance = 0.15 + luck * 0.5 + pityBonus;
  
  if (Math.random() > discoveryChance) return null;

  // Roll for rarity - luck shifts probabilities toward rarer
  const rarityRoll = Math.random();
  const luckBonus = luck * 0.3;
  
  let rarity: Rarity;
  if (rarityRoll < RARITY_CONFIG.mythic.chance + luckBonus * 0.01) {
    rarity = 'mythic';
  } else if (rarityRoll < RARITY_CONFIG.mythic.chance + RARITY_CONFIG.legendary.chance + luckBonus * 0.03) {
    rarity = 'legendary';
  } else if (rarityRoll < 0.05 + 0.07 + luckBonus * 0.06) {
    rarity = 'epic';
  } else if (rarityRoll < 0.05 + 0.07 + 0.13 + luckBonus * 0.1) {
    rarity = 'rare';
  } else if (rarityRoll < 0.05 + 0.07 + 0.13 + 0.25 + luckBonus * 0.15) {
    rarity = 'uncommon';
  } else {
    rarity = 'common';
  }

  const pool = ATTRIBUTES.filter(a => a.rarity === rarity);
  return pool[Math.floor(Math.random() * pool.length)];
}

export function useGameState() {
  const [state, setState] = useState<GameState>(loadState);
  const saveTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hashCounterRef = useRef(0);

  // Save to localStorage periodically
  useEffect(() => {
    if (saveTimeout.current) clearTimeout(saveTimeout.current);
    saveTimeout.current = setTimeout(() => {
      const { recentFind, ...toSave } = state;
      localStorage.setItem('bananocoin_miner_state', JSON.stringify(toSave));
    }, 1000);
    return () => {
      if (saveTimeout.current) clearTimeout(saveTimeout.current);
    };
  }, [state]);

  // Auto mining
  useEffect(() => {
    if (state.autoMineRate <= 0) return;
    const interval = setInterval(() => {
      setState(prev => {
        const amount = prev.autoMineRate;
        const attr = rollForAttribute(prev.luck, prev.minesSinceLastFind);
        const newDiscovered = { ...prev.discoveredAttributes };
        let minesSinceLastFind = prev.minesSinceLastFind + 1;
        
        if (attr) {
          newDiscovered[attr.id] = (newDiscovered[attr.id] || 0) + 1;
          minesSinceLastFind = 0;
        }

        return {
          ...prev,
          bananocoins: prev.bananocoins + amount + (attr ? attr.power : 0),
          totalMined: prev.totalMined + amount + (attr ? attr.power : 0),
          discoveredAttributes: newDiscovered,
          recentFind: attr || prev.recentFind,
          minesSinceLastFind,
        };
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [state.autoMineRate, state.luck]);

  // Hash rate counter for visual effect
  useEffect(() => {
    const interval = setInterval(() => {
      hashCounterRef.current += Math.floor(Math.random() * 100 + 50) * (1 + state.miningPower * 0.5 + state.autoMineRate * 2);
      setState(prev => ({ ...prev, hashRate: hashCounterRef.current }));
    }, 200);
    return () => clearInterval(interval);
  }, [state.miningPower, state.autoMineRate]);

  const mine = useCallback(() => {
    setState(prev => {
      const isCrit = Math.random() < prev.critChance;
      const multiplier = isCrit ? prev.critMultiplier : 1;
      const amount = Math.floor(prev.miningPower * multiplier);
      
      const attr = rollForAttribute(prev.luck, prev.minesSinceLastFind);
      const newDiscovered = { ...prev.discoveredAttributes };
      let minesSinceLastFind = prev.minesSinceLastFind + 1;

      if (attr) {
        newDiscovered[attr.id] = (newDiscovered[attr.id] || 0) + 1;
        minesSinceLastFind = 0;
      }

      return {
        ...prev,
        bananocoins: prev.bananocoins + amount + (attr ? attr.power : 0),
        totalMined: prev.totalMined + amount + (attr ? attr.power : 0),
        totalClicks: prev.totalClicks + 1,
        discoveredAttributes: newDiscovered,
        recentFind: attr || prev.recentFind,
        lastClickAmount: amount,
        isCrit,
        minesSinceLastFind,
      };
    });
  }, []);

  const buyUpgrade = useCallback((upgradeId: string) => {
    setState(prev => {
      const upgrade = UPGRADES.find(u => u.id === upgradeId);
      if (!upgrade) return prev;

      const level = prev.upgradeLevels[upgradeId] || 0;
      if (level >= upgrade.maxLevel) return prev;

      const cost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, level));
      if (prev.bananocoins < cost) return prev;

      const newLevels = { ...prev.upgradeLevels, [upgradeId]: level + 1 };
      
      let newState = {
        ...prev,
        bananocoins: prev.bananocoins - cost,
        upgradeLevels: newLevels,
      };

      switch (upgrade.effect) {
        case 'miningPower':
          newState.miningPower = prev.miningPower + upgrade.effectValue;
          break;
        case 'autoMine':
          newState.autoMineRate = prev.autoMineRate + upgrade.effectValue;
          break;
        case 'luck':
          newState.luck = prev.luck + upgrade.effectValue;
          break;
        case 'critChance':
          newState.critChance = Math.min(prev.critChance + upgrade.effectValue, 0.8);
          break;
        case 'critMultiplier':
          newState.critMultiplier = prev.critMultiplier + upgrade.effectValue;
          break;
      }

      return newState;
    });
  }, []);

  const clearRecentFind = useCallback(() => {
    setState(prev => ({ ...prev, recentFind: null }));
  }, []);

  const resetGame = useCallback(() => {
    localStorage.removeItem('bananocoin_miner_state');
    setState({ ...INITIAL_STATE });
  }, []);

  return { state, mine, buyUpgrade, clearRecentFind, resetGame };
}
