import { useEffect, useMemo, useState } from "react";

type LaneFilter =
  | "Archive"
  | "Dial-up"
  | "Community"
  | "Encoding"
  | "Cryptography"
  | "Collectibles";

type Signal = {
  id: string;
  title: string;
  lane: LaneFilter;
  era: string;
  summary: string;
  detail: string;
  related: string[];
  year?: string;
  notes?: string[];
};

const laneFilters: LaneFilter[] = [
  "Archive",
  "Dial-up",
  "Community",
  "Encoding",
  "Cryptography",
  "Collectibles",
];

const routeRows = [
  {
    title: "Old routes",
    path: "UUCP  X.25  Tymnet  V.90",
    note: "Reachability over speed.",
  },
  {
    title: "Public rooms",
    path: "BBS  Prodigy  Telnet  Gopher",
    note: "Communities before feeds.",
  },
  {
    title: "Text transport",
    path: "UUEncode  yEnc  Usenet",
    note: "Pack binary into text.",
  },
  {
    title: "Key paths",
    path: "BIP39  BIP44  vanity generators",
    note: "Recovery, derivation, identity.",
  },
  {
    title: "Proof and objects",
    path: "Bitcoin  zSNARK  NFT  Black Lotus",
    note: "Scarcity, proof, display.",
  },
];

const findings = [
  {
    title: "The old net was social before it was graphical.",
    text: "Boards, directories, and terminal sessions were ways to find a person as much as a document.",
  },
  {
    title: "Encoding was transport, not ornament.",
    text: "UUEncode and yEnc existed to move data through systems that only trusted text.",
  },
  {
    title: "Modern crypto kept the same instincts.",
    text: "Keys, proofs, and collectible surfaces replaced phone lines and message boards, but the urge to route and preserve stayed the same.",
  },
];

const signals: Signal[] = [
  {
    id: "textfiles",
    title: "Textfiles.com",
    lane: "Archive",
    era: "archive shelf",
    summary: "A reference point for plain-text lore, utilities, and preservation.",
    detail:
      "Textfiles.com stands in this atlas as the archive instinct: keep the documents, keep the notes, and keep the weird edge cases readable.",
    related: ["BBS", "Usenet / newsgroups", "Gopher"],
    year: "1998",
    notes: [
      "Launched 1998 by Jason Scott, who later joined the Internet Archive.",
      "Grew to 58,227 files by 2005; sub-projects include artscene, audio, cd, bbslist, and timeline.",
      "Completionist outlook: collect every major textfile that traveled between BBSes.",
    ],
  },
  {
    id: "uucp",
    title: "UUCP",
    lane: "Dial-up",
    era: "store-and-forward",
    summary: "A hop-by-hop way to move mail and files through slow links.",
    detail:
      "UUCP makes the map feel patient. It assumes the network is uneven, then routes around that fact with queues, hops, and delayed delivery.",
    related: ["X.25", "Tymnet", "Usenet / newsgroups"],
    year: "1979",
    notes: [
      "Unix-to-Unix Copy, part of Version 7 Unix (1979).",
      "Powered the first Usenet hop from Duke University to UNC Chapel Hill in 1980.",
      "\"Bang paths\" (duke!unc!user) routed messages across autonomous sites.",
    ],
  },
  {
    id: "x25",
    title: "X.25",
    lane: "Dial-up",
    era: "packet switch",
    summary: "A routed network idea that treated the line as infrastructure.",
    detail:
      "X.25 belongs to the era when public networks felt engineered and formal. It reads like the bridge between private terminals and large-scale routing.",
    related: ["UUCP", "Tymnet", "Telnet"],
    year: "1976",
    notes: [
      "CCITT Recommendation X.25, adopted March 1976 by five nations building public packet networks.",
      "Original standard ran at 19.2 kbps across analog telephone lines with heavy error-correction overhead.",
      "Enabled the International Packet Switched Service (IPSS) in 1978, the first international commercial packet network.",
    ],
  },
  {
    id: "prodigy",
    title: "Prodigy classic",
    lane: "Community",
    era: "walled garden",
    summary: "A consumer online service before the web took over the front door.",
    detail:
      "Prodigy classic sits here as a reminder that the early network was also a product experience, not just a protocol stack.",
    related: ["BBS", "Contacts for secretary", "Gopher"],
    year: "1988",
    notes: [
      "Founded as the Trintex joint venture between IBM, Sears, and CBS in 1984; CBS withdrew 1986.",
      "Launched in test markets (Atlanta, San Francisco, Hartford) in 1988; national in 1990.",
      "First major online service to offer a web browser (January 1995) and the first hosted in HTML.",
    ],
  },
  {
    id: "v90",
    title: "V.90",
    lane: "Dial-up",
    era: "modem handshake",
    summary: "The dial-up standard that turned a phone line into a temporary tunnel.",
    detail:
      "V.90 marks the handshake era: the moment when connection noise, negotiation, and patience became part of getting online.",
    related: ["UUCP", "Tymnet", "BBS"],
    year: "1998",
    notes: [
      "ITU draft February 1998, ratified September 1998.",
      "Unified the rival K56flex (Rockwell / Lucent) and X2 (USRobotics) 56k protocols.",
      "Nicknamed \"V.Last\" — expected to be the last analog modem standard before broadband.",
    ],
  },
  {
    id: "secretary",
    title: "Contacts for secretary",
    lane: "Community",
    era: "directory",
    summary: "A human routing table before search became default.",
    detail:
      "This entry treats directories as social infrastructure. Sometimes the route was a name, an office, or the person who knew the next person to call.",
    related: ["Prodigy classic", "BBS", "Usenet / newsgroups"],
    notes: [
      "Pre-internet directories: phone books, rolodexes, and the office secretary who knew everyone.",
      "A reminder that routing was once a social skill, not a protocol.",
    ],
  },
  {
    id: "tymnet",
    title: "Tymnet",
    lane: "Dial-up",
    era: "terminal network",
    summary: "A backbone for the terminal-era public network.",
    detail:
      "Tymnet belongs to the older layer of public connectivity, where terminals and shared infrastructure mattered more than the browser model.",
    related: ["X.25", "Telnet", "V.90"],
    year: "1968",
    notes: [
      "Built by Tymshare (founded 1964, Cupertino); network development began 1967-1968.",
      "Designed by Norm Hardy and coded in assembly by LaRoy Tymes; \"Supervisor\" software rolled out November 1971.",
      "By 1972, linked 40 U.S. cities with statistical multiplexing, centralized passwords, and flow control.",
    ],
  },
  {
    id: "bbs",
    title: "BBS",
    lane: "Community",
    era: "bulletin board",
    summary: "Local communities built around a dial tone and a message board.",
    detail:
      "BBS culture turned a machine in a room into a social place. It was part forum, part file cabinet, part neighborhood noticeboard.",
    related: ["Prodigy classic", "Usenet / newsgroups", "Telnet"],
    year: "1978",
    notes: [
      "CBBS, the first public BBS, went online in Chicago in February 1978 (Ward Christensen and Randy Suess).",
      "Most BBSes were single-line; long-distance calls defined the economics of every connection.",
      "Jason Scott's 2005 film \"BBS: The Documentary\" catalogues the subculture.",
    ],
  },
  {
    id: "telnet",
    title: "Telnet",
    lane: "Dial-up",
    era: "remote login",
    summary: "The open door to a remote terminal session.",
    detail:
      "Telnet feels spare in the best way. It shows the network before the modern web wrapper, when the interface was still a shell prompt.",
    related: ["Gopher", "BBS", "Tymnet"],
    year: "1969",
    notes: [
      "Telnet protocol specified 1969; standardized in RFC 15 (1969) and later RFC 854 (1983).",
      "One of the earliest ARPANET applications, giving users a shell across the wire.",
      "Replaced in most contexts by SSH after 1995, but the idea of remote terminal access persisted.",
    ],
  },
  {
    id: "gopher",
    title: "Gopher",
    lane: "Dial-up",
    era: "menu tree",
    summary: "Typed paths and simple menus before hypertext won.",
    detail:
      "Gopher sits between file browsers and websites. It made the network feel like a tidy directory tree you could walk with intent.",
    related: ["Telnet", "Textfiles.com", "Usenet / newsgroups"],
    year: "1991",
    notes: [
      "Released in 1991 by Mark McCahill at the University of Minnesota.",
      "Named after the school's mascot and the verb \"to go for\" information.",
      "Declined after 1993 when the university announced license fees and the web took over.",
    ],
  },
  {
    id: "uue",
    title: "UUEncode / UUE",
    lane: "Encoding",
    era: "text wrapper",
    summary: "A way to carry binary payloads through text-only systems.",
    detail:
      "UUEncode is the classic reminder that transport constraints shape format design. It turns binary into something a text pipeline can survive.",
    related: ["yEnc", "Usenet / newsgroups", "Textfiles.com"],
    year: "1980",
    notes: [
      "\"Unix-to-Unix Encoding,\" introduced around 1980 as part of the BSD distribution.",
      "6-bit encoding produces 33-40% overhead for safe ASCII transport.",
      "Standard companion to Usenet binary distribution through the 1990s.",
    ],
  },
  {
    id: "yenc",
    title: "yEnc",
    lane: "Encoding",
    era: "binary wrapper",
    summary: "A later text transport trick built for faster binary distribution.",
    detail:
      "yEnc is the practical sibling in this family. It aims to move larger payloads through the same text-bound channels with less overhead.",
    related: ["UUEncode / UUE", "Usenet / newsgroups", "BBS"],
    year: "2001",
    notes: [
      "Draft proposal published 31 July 2001 by Jürgen Helbing; first decoder (yDec) in November 2001.",
      "Name is a wordplay on \"Why encode?\" — only escape the minimum.",
      "Overhead of 1-2% versus 33-40% for UUEncode / Base64; became the de facto Usenet binary standard by 2003.",
    ],
  },
  {
    id: "usenet",
    title: "Usenet / newsgroups",
    lane: "Community",
    era: "distributed forum",
    summary: "A network of conversations that acted like a distributed archive.",
    detail:
      "Usenet gave text a long memory. Posts, groups, and archives turned discussion into a navigable knowledge layer.",
    related: ["BBS", "UUEncode / UUE", "Gopher"],
    year: "1980",
    notes: [
      "Invented 1979 by Tom Truscott, Jim Ellis, and Steve Bellovin at Duke / UNC; first link January 1980.",
      "NNTP protocol (RFC 977) standardized posting and retrieval in 1986.",
      "\"Eternal September\" (1993) — the AOL influx that broke the old newsgroup culture.",
    ],
  },
  {
    id: "bitcoin",
    title: "Bitcoin",
    lane: "Cryptography",
    era: "ledger",
    summary: "Proof, scarcity, and consensus in one public system.",
    detail:
      "Bitcoin is the anchor point for the crypto half of the atlas. It turns value into a ledger problem and a coordination problem at the same time.",
    related: ["Hashcash", "zSNARK", "Wallet vanity generator"],
    year: "2009",
    notes: [
      "Whitepaper \"Bitcoin: A Peer-to-Peer Electronic Cash System\" published 31 October 2008.",
      "Genesis block mined 3 January 2009, embedding the Times of London headline about bank bailouts.",
      "Cited only two individuals: Scott Stornetta and Adam Back (for Hashcash).",
    ],
  },
  {
    id: "piratecoin",
    title: "Piratecoin",
    lane: "Cryptography",
    era: "fork lore",
    summary: "A reminder that chain culture also runs on jokes and side quests.",
    detail:
      "Piratecoin represents the unruly edge of the chain map, where naming, branding, and community taste matter as much as code.",
    related: ["Bitcoin", "Tron", "Dogenano"],
    notes: [
      "Part of a long tradition of meme and joke forks that double as culture carriers.",
      "Illustrates how chain identity can emerge from branding more than engineering.",
    ],
  },
  {
    id: "zsnark",
    title: "zSNARK",
    lane: "Cryptography",
    era: "zero knowledge",
    summary: "Proof machinery for selective disclosure.",
    detail:
      "zSNARKs move the map from simple transfer into proof. They let a system verify without exposing every internal detail.",
    related: ["Bitcoin", "Ethereum", "Hashcash"],
    notes: [
      "Zero-Knowledge Succinct Non-Interactive Argument of Knowledge; \"succinct\" proofs verified in milliseconds.",
      "Deployed in Zcash (2016) and widely adopted in Ethereum L2 rollups (zkSync, StarkNet) from the 2020s onward.",
    ],
  },
  {
    id: "tron",
    title: "Tron",
    lane: "Cryptography",
    era: "alt chain",
    summary: "An entertainment-facing chain in the broader token ecosystem.",
    detail:
      "Tron belongs to the branch of crypto where product, platform, and chain identity all blur together.",
    related: ["Ethereum", "WAX", "Piratecoin"],
    year: "2017",
    notes: [
      "Founded by Justin Sun; ICO in 2017, mainnet launched June 2018.",
      "Focuses on entertainment, gaming, and stablecoin transfer volume.",
    ],
  },
  {
    id: "wax",
    title: "WAX",
    lane: "Collectibles",
    era: "collectibles chain",
    summary: "A chain tuned for media, items, and trading surfaces.",
    detail:
      "WAX points at the collectible side of blockchain culture, where the object itself becomes the interface.",
    related: ["NFT", "Magic: The Gathering", "bitcoin stamp"],
    year: "2017",
    notes: [
      "Worldwide Asset eXchange; ICO in 2017 raised ~$60M, mainnet in 2019.",
      "Founded by William E. Quigley and Jonathan Yantis, operators of OPSkins.",
      "DPoS consensus with 500ms blocks and zero-fee transactions for consumers.",
    ],
  },
  {
    id: "ethereum",
    title: "Ethereum",
    lane: "Cryptography",
    era: "smart contract",
    summary: "A programmable chain that moved the conversation from transfer to execution.",
    detail:
      "Ethereum widened the crypto brief. The chain is not just a ledger anymore; it is a runtime for coordinated logic.",
    related: ["Bitcoin", "zSNARK", "NFT"],
    year: "2015",
    notes: [
      "Whitepaper published 2013 by Vitalik Buterin; mainnet launched 30 July 2015.",
      "Introduced the Ethereum Virtual Machine as a world-computer substrate.",
      "Transitioned from proof-of-work to proof-of-stake in \"The Merge,\" September 2022.",
    ],
  },
  {
    id: "litecoin",
    title: "Litecoin",
    lane: "Cryptography",
    era: "payments",
    summary: "A payments-first chain with a faster conversational tempo.",
    detail:
      "Litecoin shows the lineage where payment speed and familiar mechanics mattered more than spectacle.",
    related: ["Bitcoin", "Nano", "Banano"],
    year: "2011",
    notes: [
      "Released October 2011 by Charlie Lee, a former Google engineer.",
      "Scrypt proof-of-work and 2.5-minute blocks, roughly \"silver to Bitcoin's gold.\"",
    ],
  },
  {
    id: "banano",
    title: "Banano",
    lane: "Cryptography",
    era: "community fork",
    summary: "A playful chain culture that keeps the transfer idea lightweight.",
    detail:
      "Banano captures the social side of crypto: community, meme energy, and low-friction movement.",
    related: ["Nano", "Dogenano", "Litecoin"],
    year: "2018",
    notes: [
      "Forked from Nano on 1 April 2018 as an April Fools' joke that stuck.",
      "Feeless DAG architecture with potassium-themed meme culture.",
    ],
  },
  {
    id: "nano",
    title: "Nano",
    lane: "Cryptography",
    era: "minimal transfer",
    summary: "A design that tries to make value move with as little friction as possible.",
    detail:
      "Nano stays focused on the transport question, reducing the surface area between intent and settlement.",
    related: ["Banano", "Litecoin", "Wallet vanity generator"],
    year: "2015",
    notes: [
      "Launched as RaiBlocks in October 2015, rebranded to Nano in January 2018.",
      "Block-lattice DAG: every account has its own chain, enabling feeless instant transfers.",
    ],
  },
  {
    id: "dogenano",
    title: "Dogenano",
    lane: "Cryptography",
    era: "meme fork",
    summary: "A joke that still wants to settle.",
    detail:
      "Dogenano sits where humor and protocol meet. It is an expression of chain culture rather than a neutral utility layer.",
    related: ["Banano", "Nano", "Piratecoin"],
    notes: [
      "A meme fork in the Nano / Banano lineage that keeps the block-lattice idea and layers culture on top.",
    ],
  },
  {
    id: "wallet",
    title: "Wallet vanity generator",
    lane: "Cryptography",
    era: "address search",
    summary: "Identity theater for addresses and prefixes.",
    detail:
      "A vanity generator turns addressing into a search problem and, in the process, makes a wallet look like a name.",
    related: ["Ian Coleman / BIP39", "BIP44", "Bitcoin"],
    notes: [
      "Brute-force search for addresses with a chosen prefix; cost grows exponentially with prefix length.",
      "Classic tool: vanitygen (2012) for Bitcoin; similar tools exist for every major chain.",
    ],
  },
  {
    id: "bip39",
    title: "Ian Coleman / BIP39",
    lane: "Cryptography",
    era: "seed phrase",
    summary: "Seed phrase tooling and recovery logic for wallet workflows.",
    detail:
      "BIP39 is the seed layer in this map, where recovery, notation, and backup discipline matter as much as the funds themselves.",
    related: ["BIP44", "Wallet vanity generator", "Bitcoin"],
    year: "2013",
    notes: [
      "BIP39 proposed 2013 (Palatinus, Rusnov, Stick, Voisine); defines mnemonic code for generating HD keys.",
      "Ian Coleman's open-source, client-side tool supports BIP32, BIP39, BIP44, BIP49, and BIP84; runs offline.",
      "Seed Savior and related forks extend it for partial-phrase recovery.",
    ],
  },
  {
    id: "bip44",
    title: "BIP44",
    lane: "Cryptography",
    era: "derivation path",
    summary: "A convention for organizing key branches.",
    detail:
      "BIP44 gives the key tree a shape. It is part of the hidden structure that keeps wallet management readable.",
    related: ["Ian Coleman / BIP39", "Wallet vanity generator", "Bitcoin"],
    year: "2014",
    notes: [
      "BIP44 proposed 2014 (Palatinus and Rusnov); defines m / purpose' / coin' / account' / change / index.",
      "Extended by BIP49 (nested SegWit) and BIP84 (native SegWit) to track script type at the purpose level.",
    ],
  },
  {
    id: "hashcash",
    title: "Hashcash",
    lane: "Cryptography",
    era: "proof of work",
    summary: "A small proof-of-work idea that echoes through anti-spam and mining culture.",
    detail:
      "Hashcash is the compact precursor to a lot of proof thinking. It turns a tiny bit of computation into a signal.",
    related: ["Bitcoin", "zSNARK", "Ethereum"],
    year: "1997",
    notes: [
      "Invented 1997 by Adam Back; formally described in the 2002 paper \"Hashcash - A Denial of Service Counter-Measure.\"",
      "Cited in the Bitcoin whitepaper as the proof-of-work foundation; used by SpamAssassin and Microsoft's \"email postmark.\"",
      "Theoretical origins in Moni Naor and Cynthia Dwork (1993); Back developed the idea independently.",
    ],
  },
  {
    id: "magic",
    title: "Magic: The Gathering",
    lane: "Collectibles",
    era: "game object",
    summary: "Cards as mythic objects with rules, history, and value.",
    detail:
      "Magic belongs here because it made paper objects feel like systems, not just pieces of print.",
    related: ["Black Lotus", "playing card", "NFT"],
    year: "1993",
    notes: [
      "Designed by Richard Garfield; published by Wizards of the Coast.",
      "Limited Edition Alpha released August 1993 with 295 cards and ~2.61 million total printed.",
    ],
  },
  {
    id: "blacklotus",
    title: "Black Lotus",
    lane: "Collectibles",
    era: "scarcity myth",
    summary: "The archetype of scarce, coveted game artifacts.",
    detail:
      "Black Lotus is shorthand for desirability. In this atlas it links collectible culture to scarcity, memory, and lore.",
    related: ["Magic: The Gathering", "NFT", "bitcoin stamp"],
    year: "1993",
    notes: [
      "Alpha print: ~1,008 copies; part of the Power Nine.",
      "Illustrated by Christopher Rush; zero mana for three mana of any color.",
      "As of 2022, Beckett has graded 263 Alpha copies and PSA 110 — a hard scarcity ceiling.",
    ],
  },
  {
    id: "playingcard",
    title: "Playing card",
    lane: "Collectibles",
    era: "paper object",
    summary: "The original interface for chance and symbol.",
    detail:
      "A playing card is the simplest collectible object in the map: flat, portable, and rich with cultural encoding.",
    related: ["Magic: The Gathering", "Black Lotus", "bitcoin stamp"],
    notes: [
      "Paper playing cards in Europe date to the late 14th century; the modern 52-card French deck stabilized by the 16th century.",
    ],
  },
  {
    id: "nft",
    title: "NFT",
    lane: "Collectibles",
    era: "token object",
    summary: "A tokenized surface for provenance and display.",
    detail:
      "NFTs carry the object-layer idea forward. They make ownership, display, and provenance part of the interface.",
    related: ["WAX", "Black Lotus", "bitcoin stamp"],
    year: "2014",
    notes: [
      "Early experiments: Colored Coins (2012-2013), Counterparty (2014), Quantum by Kevin McCoy (May 2014).",
      "ERC-721 standard proposed 2017; boom years 2020-2021; \"NFT\" named Collins Dictionary's word of the year 2021.",
    ],
  },
  {
    id: "haikudisplay",
    title: "HaikuDisplay",
    lane: "Collectibles",
    era: "presentation",
    summary: "A display layer that turns short output into an object.",
    detail:
      "HaikuDisplay feels like a framed output surface, where brevity and presentation become part of the signal.",
    related: ["Enso generator", "playing card", "NFT"],
    notes: [
      "A display component pattern in generative-haiku projects (e.g. tarpediem/Haikugen, OpenRouter-powered).",
      "Treats the output itself as the collectible: 5-7-5 form as a constraint for display.",
    ],
  },
  {
    id: "enso",
    title: "Enso generator",
    lane: "Collectibles",
    era: "generative loop",
    summary: "A looping output system that treats repetition as ritual.",
    detail:
      "Enso generator belongs to the generative object layer, where the act of output is part of the artifact.",
    related: ["HaikuDisplay", "NFT", "playing card"],
    year: "2021",
    notes: [
      "enso.utsob.me (Utsab Roy, November 2021): draws a zen circle from a hash of input plus randomness.",
      "Pairs ensō with collected haiku; all rendering in-browser, no server-side storage.",
    ],
  },
  {
    id: "bitcoinstamp",
    title: "Bitcoin stamp",
    lane: "Collectibles",
    era: "printed artifact",
    summary: "A physical surface that folds money lore back into paper.",
    detail:
      "Bitcoin stamp bridges the digital and physical halves of the map, where a network idea becomes a collectible imprint.",
    related: ["Bitcoin", "NFT", "Black Lotus"],
    year: "2023",
    notes: [
      "Bitcoin Stamps (2023) store data in unspent transaction outputs (UTXOs) via the Counterparty protocol.",
      "Unlike Ordinals (January 2023, Casey Rodarmor), Stamps cannot be pruned — the chain retains them permanently.",
      "The acronym STAMPS = Secure Tradeable Art Maintained Securely.",
    ],
  },
];

const defaultRouteIds = ["textfiles", "uucp", "usenet", "hashcash", "bitcoin", "bitcoinstamp"];

const coinTypes = [
  { label: "Bitcoin", value: "0", symbol: "BTC" },
  { label: "Litecoin", value: "2", symbol: "LTC" },
  { label: "Ethereum", value: "60", symbol: "ETH" },
  { label: "WAX", value: "14001", symbol: "WAXP" },
  { label: "Nano", value: "165", symbol: "XNO" },
];

const routeModes = ["Archive", "Dial-up", "Community", "Encoding", "Cryptography", "Collectibles"];

const sourceRows = [
  {
    label: "Protocol docs",
    examples: "RFC 15, RFC 854, RFC 977, CCITT X.25, ITU V.90",
    use: "Dates, interface boundaries, standardization moments",
  },
  {
    label: "Archive records",
    examples: "Textfiles.com, Internet Archive, BBS lists, old shareware discs",
    use: "Preservation scope, filenames, cultural vocabulary",
  },
  {
    label: "Chain specs",
    examples: "Bitcoin whitepaper, BIPs 39/44, Ethereum docs, Bitcoin Wiki Hashcash",
    use: "Proof mechanics, derivation paths, seed and address conventions",
  },
  {
    label: "Collector history",
    examples: "Magic Alpha, Power Nine, WAX, Ordinals, Bitcoin Stamps",
    use: "Scarcity, provenance, display, and object value",
  },
];

function hashSeed(value: string) {
  let hash = 2166136261;

  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }

  return Math.abs(hash >>> 0);
}

function pick<T>(items: T[], seed: number, offset = 0) {
  return items[(seed + offset) % items.length];
}

function makeHaiku(signal: Signal) {
  const seed = hashSeed(`${signal.title}:${signal.lane}:${signal.era}`);
  const first = ["old packets whisper", "modems count every hop", "text waits in silence"];
  const second = [
    "keys bloom under terminal light",
    "archives route through hidden names",
    "proof turns noise into memory",
  ];
  const third = ["scarcity remains", "another node wakes", "paper becomes proof"];

  return [pick(first, seed), pick(second, seed, 1), pick(third, seed, 2)];
}

async function sha256Hex(message: string) {
  const data = new TextEncoder().encode(message);
  const digest = await crypto.subtle.digest("SHA-256", data);

  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

export default function App() {
  const [activeLane, setActiveLane] = useState<LaneFilter | "All">("All");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState(signals[0].id);
  const [routeIds, setRouteIds] = useState(defaultRouteIds);
  const [proofText, setProofText] = useState("Textfiles.com -> Hashcash -> Bitcoin stamp");
  const [proofDifficulty, setProofDifficulty] = useState(3);
  const [proofResult, setProofResult] = useState<{ nonce: number; hash: string } | null>(null);
  const [proofAttempts, setProofAttempts] = useState(0);
  const [isMining, setIsMining] = useState(false);
  const [coinType, setCoinType] = useState(coinTypes[0].value);
  const [accountIndex, setAccountIndex] = useState(0);
  const [addressIndex, setAddressIndex] = useState(0);

  const visibleSignals = useMemo(() => {
    const lowered = query.trim().toLowerCase();

    return signals.filter((signal) => {
      const laneMatches = activeLane === "All" || signal.lane === activeLane;
      const textMatches =
        lowered.length === 0 ||
        [
          signal.title,
          signal.summary,
          signal.detail,
          signal.era,
          signal.related.join(" "),
          signal.notes?.join(" ") ?? "",
        ]
          .join(" ")
          .toLowerCase()
          .includes(lowered);

      return laneMatches && textMatches;
    });
  }, [activeLane, query]);

  useEffect(() => {
    if (visibleSignals.length === 0) {
      return;
    }

    if (!visibleSignals.some((signal) => signal.id === selectedId)) {
      setSelectedId(visibleSignals[0].id);
    }
  }, [selectedId, visibleSignals]);

  const activeSignal =
    visibleSignals.find((signal) => signal.id === selectedId) ?? visibleSignals[0] ?? null;
  const activeIndex = activeSignal ? signals.findIndex((signal) => signal.id === activeSignal.id) + 1 : 0;
  const routeSignals = useMemo(
    () => routeIds.map((id) => signals.find((signal) => signal.id === id)).filter(Boolean) as Signal[],
    [routeIds],
  );
  const routeTranscript = routeSignals
    .map((signal, index) => `${String(index + 1).padStart(2, "0")} ${signal.title}`)
    .join("\n");
  const selectedCoin = coinTypes.find((coin) => coin.value === coinType) ?? coinTypes[0];
  const derivationPath = `m/44'/${coinType}'/${accountIndex}'/0/${addressIndex}`;
  const haikuLines = activeSignal ? makeHaiku(activeSignal) : [];
  const ensoSeed = activeSignal ? hashSeed(`${activeSignal.id}:${routeIds.join("-")}`) : 0;
  const ensoDash = 420 + (ensoSeed % 110);
  const ensoGap = 36 + (ensoSeed % 72);

  const toggleRouteSignal = (id: string) => {
    setRouteIds((current) => {
      if (current.includes(id)) {
        return current.length > 1 ? current.filter((item) => item !== id) : current;
      }

      return [...current, id].slice(-8);
    });
  };

  const runProofSearch = async () => {
    if (isMining) {
      return;
    }

    setIsMining(true);
    setProofResult(null);
    setProofAttempts(0);

    const prefix = "0".repeat(proofDifficulty);

    for (let nonce = 0; nonce < 250000; nonce += 1) {
      const hash = await sha256Hex(`${proofText}:${nonce}`);

      if (nonce % 25 === 0) {
        setProofAttempts(nonce);
        await new Promise<void>((resolve) => window.setTimeout(resolve, 0));
      }

      if (hash.startsWith(prefix)) {
        setProofAttempts(nonce + 1);
        setProofResult({ nonce, hash });
        setIsMining(false);
        return;
      }
    }

    setIsMining(false);
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-slate-950 text-slate-100">
      <div className="pointer-events-none absolute inset-0 signal-grid opacity-[0.35]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(34,211,238,0.16),_transparent_40%),radial-gradient(circle_at_bottom_left,_rgba(251,191,36,0.12),_transparent_32%),linear-gradient(to_bottom,_rgba(2,6,23,0.25),_rgba(2,6,23,0.92))]" />
      <div className="pointer-events-none hero-orb absolute -top-40 right-[-8rem] h-[32rem] w-[32rem] rounded-full bg-cyan-400/10 blur-3xl" />
      <div className="pointer-events-none hero-orb secondary absolute bottom-[-8rem] left-[-6rem] h-[24rem] w-[24rem] rounded-full bg-amber-400/10 blur-3xl" />

      <section className="relative isolate">
        <div className="mx-auto grid min-h-screen max-w-7xl gap-12 px-6 py-8 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:px-8 lg:py-10">
          <div className="flex flex-col justify-center pt-10 lg:pt-0">
            <p className="text-xs uppercase tracking-[0.5em] text-cyan-200/70">Research first</p>
            <h1 className="mt-6 max-w-4xl text-5xl font-semibold tracking-tight text-white sm:text-7xl lg:text-8xl">
              Signal Atlas
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300 sm:text-xl">
              A field guide from Textfiles.com to BIP39, mapping the road from UUCP, X.25,
              BBSes, and Gopher to Bitcoin, zSNARKs, and collectible on-chain objects.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href="#archive"
                className="inline-flex items-center justify-center rounded-full bg-cyan-300 px-5 py-3 text-sm font-medium text-slate-950 transition hover:bg-cyan-200"
              >
                Open archive
              </a>
              <a
                href="#findings"
                className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-medium text-white transition hover:border-white/30 hover:bg-white/10"
              >
                Read findings
              </a>
              <a
                href="#lab"
                className="inline-flex items-center justify-center rounded-full border border-emerald-300/30 bg-emerald-300/10 px-5 py-3 text-sm font-medium text-emerald-50 transition hover:border-emerald-300/50 hover:bg-emerald-300/15"
              >
                Use workbench
              </a>
            </div>
            <p className="mt-8 max-w-2xl text-sm leading-7 text-slate-400">
              Textfiles.com / UUCP / X.25 / Prodigy / V.90 / Tymnet / BBS / Telnet / Gopher /
              UUEncode / yEnc / Usenet / Bitcoin / hashcash / BIP39 / NFT
            </p>
          </div>

          <div className="flex items-center">
            <div className="relative w-full overflow-hidden rounded-[2rem] border border-white/10 bg-slate-950/80 p-6 shadow-[0_30px_100px_rgba(0,0,0,0.45)] backdrop-blur">
              <div className="scanline pointer-events-none absolute inset-0 bg-[linear-gradient(to_bottom,transparent,rgba(255,255,255,0.06),transparent)] opacity-[0.45]" />
              <div className="relative flex items-center justify-between text-xs uppercase tracking-[0.35em] text-slate-400">
                <span>Live synthesis</span>
                <span className="flex items-center gap-2 text-emerald-300">
                  <span className="pulse-dot h-2 w-2 rounded-full bg-emerald-300" />
                  tracing
                </span>
              </div>

              <div className="relative mt-8 space-y-4">
                {routeRows.map((row, index) => (
                  <div
                    key={row.title}
                    className="reveal border-t border-white/10 pt-4"
                    style={{ animationDelay: `${index * 110}ms` }}
                  >
                    <div className="flex items-start gap-4">
                      <div className="mt-1 font-mono text-xs uppercase tracking-[0.35em] text-slate-500">
                        {String(index + 1).padStart(2, "0")}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-4">
                          <h2 className="text-lg font-medium text-white">{row.title}</h2>
                          <span className="text-xs uppercase tracking-[0.35em] text-slate-500">
                            lane {index + 1}
                          </span>
                        </div>
                        <p className="mt-2 font-mono text-sm leading-7 text-cyan-100/80">
                          {row.path}
                        </p>
                        <p className="mt-2 text-sm leading-6 text-slate-400">{row.note}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="relative mt-8 border-t border-white/10 pt-5 text-sm leading-7 text-slate-300">
                Research notes do not split old internet culture from crypto culture. They show the
                route from text transport to keys, proofs, and collectible surfaces.
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="archive" className="relative border-t border-white/10 bg-slate-950/70">
        <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem] lg:items-end">
            <div>
              <p className="text-xs uppercase tracking-[0.45em] text-amber-200/70">
                Archive browser
              </p>
              <h2 className="mt-4 max-w-3xl text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                Filter the map and open one signal at a time.
              </h2>
              <p className="mt-3 max-w-2xl text-slate-300">
                Each node is a keyword from the prompt, grouped by the kind of system it helped
                shape.
              </p>
            </div>

            <label className="block">
              <span className="sr-only">Search signals</span>
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                type="search"
                placeholder="Search Textfiles, UUCP, BIP39, NFT..."
                className="w-full rounded-full border border-white/10 bg-white/5 px-5 py-3 text-sm text-white outline-none ring-0 placeholder:text-slate-500 focus:border-cyan-300/50 focus:bg-white/10"
              />
            </label>
          </div>

          <div className="mt-10 grid gap-8 lg:grid-cols-[16rem_minmax(0,1fr)] xl:grid-cols-[18rem_minmax(0,1fr)]">
            <aside className="space-y-4">
              <div className="rounded-[1.5rem] border border-white/10 bg-white/5 p-4">
                <p className="text-xs uppercase tracking-[0.35em] text-slate-400">Lanes</p>
                <div className="mt-4 space-y-2">
                  <button
                    type="button"
                    onClick={() => setActiveLane("All")}
                    className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-left text-sm transition ${
                      activeLane === "All"
                        ? "border-cyan-300/40 bg-cyan-300/10 text-white"
                        : "border-white/10 bg-slate-950/40 text-slate-300 hover:border-white/20 hover:bg-white/5"
                    }`}
                  >
                    <span>All</span>
                    <span className="text-xs uppercase tracking-[0.35em] text-slate-500">
                      {signals.length}
                    </span>
                  </button>
                  {laneFilters.map((lane) => {
                    const count = signals.filter((signal) => signal.lane === lane).length;

                    return (
                      <button
                        type="button"
                        key={lane}
                        onClick={() => setActiveLane(lane)}
                        className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-left text-sm transition ${
                          activeLane === lane
                            ? "border-cyan-300/40 bg-cyan-300/10 text-white"
                            : "border-white/10 bg-slate-950/40 text-slate-300 hover:border-white/20 hover:bg-white/5"
                        }`}
                      >
                        <span>{lane}</span>
                        <span className="text-xs uppercase tracking-[0.35em] text-slate-500">
                          {count}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="rounded-[1.5rem] border border-white/10 bg-white/5 p-4">
                <p className="text-xs uppercase tracking-[0.35em] text-slate-400">
                  Visible signals
                </p>
                <p className="mt-3 text-4xl font-semibold text-white">{visibleSignals.length}</p>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  Search narrows the set without changing the underlying route.
                </p>
              </div>
            </aside>

            <div className="grid gap-6 xl:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]">
              <section className="overflow-hidden rounded-[1.75rem] border border-white/10 bg-white/5">
                <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
                  <p className="text-xs uppercase tracking-[0.35em] text-slate-400">Signal list</p>
                  <p className="text-xs uppercase tracking-[0.35em] text-slate-500">
                    {activeLane === "All" ? "All lanes" : activeLane}
                  </p>
                </div>

                {visibleSignals.length > 0 ? (
                  <div className="max-h-[44rem] overflow-y-auto">
                    {visibleSignals.map((signal, index) => {
                      const isActive = signal.id === selectedId;

                      return (
                        <button
                          type="button"
                          key={signal.id}
                          onClick={() => setSelectedId(signal.id)}
                          aria-pressed={isActive}
                          className={`group block w-full border-l-2 transition ${
                            isActive
                              ? "border-cyan-300 bg-white/[0.07]"
                              : "border-transparent hover:border-white/20 hover:bg-white/[0.04]"
                          }`}
                        >
                          <div className="flex items-start gap-4 px-5 py-4 text-left">
                            <div className="mt-1 font-mono text-xs uppercase tracking-[0.35em] text-slate-500">
                              {String(index + 1).padStart(2, "0")}
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                                <h3 className="text-base font-medium text-white">{signal.title}</h3>
                                <span className="text-xs uppercase tracking-[0.35em] text-slate-500">
                                  {signal.era}
                                </span>
                              </div>
                              <p className="mt-2 text-sm leading-6 text-slate-300">
                                {signal.summary}
                              </p>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="flex min-h-[18rem] items-center justify-center px-6 text-center text-sm text-slate-400">
                    <div>
                      <p className="text-xs uppercase tracking-[0.35em] text-slate-500">No matches</p>
                      <p className="mt-3 max-w-sm leading-7">
                        Try a different lane or clear the search to bring the archive back into view.
                      </p>
                      <button
                        type="button"
                        onClick={() => setQuery("")}
                        className="mt-5 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.35em] text-white transition hover:border-white/20 hover:bg-white/10"
                      >
                        Clear search
                      </button>
                    </div>
                  </div>
                )}
              </section>

              <article
                key={activeSignal ? activeSignal.id : "empty"}
                className="reveal sticky top-8 overflow-hidden rounded-[1.75rem] border border-cyan-300/20 bg-slate-950/90 p-6 shadow-[0_20px_80px_rgba(0,0,0,0.35)] backdrop-blur"
              >
                {activeSignal ? (
                  <div>
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-xs uppercase tracking-[0.35em] text-cyan-200/70">
                          {activeSignal.lane}
                          {activeSignal.year ? ` · ${activeSignal.year}` : ""}
                        </p>
                        <h3 className="mt-3 text-3xl font-semibold tracking-tight text-white">
                          {activeSignal.title}
                        </h3>
                      </div>
                      <div className="text-right text-xs uppercase tracking-[0.35em] text-slate-500">
                        <p>Node</p>
                        <p className="mt-2 text-2xl font-semibold tracking-tight text-white">
                          {String(activeIndex).padStart(2, "0")}
                        </p>
                      </div>
                    </div>

                    <p className="mt-6 text-base leading-8 text-slate-300">{activeSignal.detail}</p>

                    {activeSignal.notes && activeSignal.notes.length > 0 && (
                      <div className="mt-6 rounded-2xl border border-amber-200/20 bg-amber-100/[0.04] p-5">
                        <p className="flex items-center gap-2 text-xs uppercase tracking-[0.35em] text-amber-200/80">
                          <span className="inline-block h-1.5 w-1.5 rounded-full bg-amber-200/80" />
                          Field notes
                        </p>
                        <ul className="mt-4 space-y-3 text-sm leading-7 text-slate-200">
                          {activeSignal.notes.map((note, index) => (
                            <li key={index} className="flex gap-3">
                              <span className="mt-[0.55rem] h-[3px] w-3 flex-none rounded-full bg-amber-200/50" />
                              <span>{note}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="mt-8 grid gap-4 border-t border-white/10 pt-6 sm:grid-cols-2">
                      <div>
                        <p className="text-xs uppercase tracking-[0.35em] text-slate-500">
                          Why it is here
                        </p>
                        <p className="mt-2 text-sm leading-7 text-slate-300">
                          It reveals how the archive moves from terminals and message boards into
                          keys, proofs, and collectible surfaces.
                        </p>
                      </div>
                      <div>
                        <p className="text-xs uppercase tracking-[0.35em] text-slate-500">
                          Related signals
                        </p>
                        <ul className="mt-2 space-y-2 text-sm leading-6 text-slate-300">
                          {activeSignal.related.map((item) => (
                            <li key={item}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex min-h-[24rem] items-center justify-center text-center text-slate-400">
                    <div>
                      <p className="text-xs uppercase tracking-[0.35em] text-slate-500">No active signal</p>
                      <p className="mt-3 max-w-sm text-sm leading-7">
                        Clear the search or switch lanes to restore the detail pane.
                      </p>
                    </div>
                  </div>
                )}
              </article>
            </div>
          </div>
        </div>
      </section>

      <section id="lab" className="relative border-t border-white/10 bg-slate-950/80">
        <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="grid gap-6 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:items-end">
            <div>
              <p className="text-xs uppercase tracking-[0.45em] text-emerald-200/70">
                Workbench
              </p>
              <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                Turn the research into working artifacts.
              </h2>
              <p className="mt-3 max-w-2xl text-slate-300">
                Compose a route, derive a wallet-style path, search for a Hashcash-like proof,
                and render the active node as a small haiku and ensō object.
              </p>
            </div>
            <div className="grid grid-cols-3 border border-white/10 text-center">
              {routeModes.slice(0, 3).map((mode) => (
                <div key={mode} className="border-r border-white/10 p-4 last:border-r-0">
                  <p className="text-2xl font-semibold text-white">
                    {signals.filter((signal) => signal.lane === mode).length}
                  </p>
                  <p className="mt-2 text-xs uppercase tracking-[0.35em] text-slate-500">
                    {mode}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-12 grid gap-6 lg:grid-cols-2">
            <section className="rounded-[1.75rem] border border-white/10 bg-white/[0.04] p-6">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.35em] text-slate-400">
                    Route builder
                  </p>
                  <h3 className="mt-3 text-2xl font-semibold tracking-tight text-white">
                    Select nodes to make a path.
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setRouteIds(defaultRouteIds)}
                  className="self-start rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.35em] text-white transition hover:border-white/20 hover:bg-white/10"
                >
                  Reset
                </button>
              </div>

              <div className="mt-6 grid max-h-72 gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
                {signals.map((signal) => {
                  const isSelected = routeIds.includes(signal.id);

                  return (
                    <button
                      key={signal.id}
                      type="button"
                      onClick={() => toggleRouteSignal(signal.id)}
                      className={`rounded-2xl border px-4 py-3 text-left text-sm transition ${
                        isSelected
                          ? "border-emerald-300/40 bg-emerald-300/10 text-white"
                          : "border-white/10 bg-slate-950/50 text-slate-300 hover:border-white/20 hover:bg-white/5"
                      }`}
                    >
                      <span className="block font-medium">{signal.title}</span>
                      <span className="mt-1 block text-xs uppercase tracking-[0.28em] text-slate-500">
                        {signal.lane}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="mt-6 rounded-2xl border border-emerald-300/20 bg-emerald-300/[0.04] p-5">
                <p className="text-xs uppercase tracking-[0.35em] text-emerald-200/80">
                  Transcript
                </p>
                <pre className="mt-4 whitespace-pre-wrap font-mono text-sm leading-7 text-emerald-50/90">
                  {routeTranscript}
                </pre>
              </div>
            </section>

            <section className="rounded-[1.75rem] border border-white/10 bg-white/[0.04] p-6">
              <p className="text-xs uppercase tracking-[0.35em] text-slate-400">Proof search</p>
              <h3 className="mt-3 text-2xl font-semibold tracking-tight text-white">
                Find a small Hashcash-style stamp.
              </h3>
              <p className="mt-3 text-sm leading-7 text-slate-300">
                This uses browser SHA-256 to find a nonce whose hash starts with your chosen
                number of zeroes. It is intentionally tiny, but it shows the asymmetry: hard to
                find, easy to verify.
              </p>

              <label className="mt-6 block">
                <span className="text-xs uppercase tracking-[0.35em] text-slate-500">Payload</span>
                <textarea
                  value={proofText}
                  onChange={(event) => setProofText(event.target.value)}
                  className="mt-3 min-h-24 w-full rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3 font-mono text-sm leading-7 text-white outline-none placeholder:text-slate-600 focus:border-emerald-300/40"
                />
              </label>

              <div className="mt-5 flex flex-col gap-4 sm:flex-row sm:items-end">
                <label className="block sm:w-48">
                  <span className="text-xs uppercase tracking-[0.35em] text-slate-500">
                    Difficulty
                  </span>
                  <select
                    value={proofDifficulty}
                    onChange={(event) => setProofDifficulty(Number(event.target.value))}
                    className="mt-3 w-full rounded-full border border-white/10 bg-slate-950/70 px-4 py-3 text-sm text-white outline-none focus:border-emerald-300/40"
                  >
                    {[2, 3, 4].map((level) => (
                      <option key={level} value={level}>
                        {level} leading zeroes
                      </option>
                    ))}
                  </select>
                </label>
                <button
                  type="button"
                  onClick={runProofSearch}
                  disabled={isMining}
                  className="rounded-full bg-emerald-300 px-5 py-3 text-sm font-medium text-slate-950 transition hover:bg-emerald-200 disabled:cursor-wait disabled:bg-slate-600 disabled:text-slate-300"
                >
                  {isMining ? "Searching..." : "Run proof search"}
                </button>
              </div>

              <div className="mt-6 rounded-2xl border border-white/10 bg-slate-950/60 p-5 font-mono text-sm leading-7 text-slate-300">
                <p>Attempts: {proofAttempts.toLocaleString()}</p>
                <p>Target: {"0".repeat(proofDifficulty)}...</p>
                {proofResult ? (
                  <div className="mt-4 space-y-2 text-emerald-200">
                    <p>nonce={proofResult.nonce}</p>
                    <p className="break-all">hash={proofResult.hash}</p>
                  </div>
                ) : (
                  <p className="mt-4 text-slate-500">No proof found yet.</p>
                )}
              </div>
            </section>

            <section className="rounded-[1.75rem] border border-white/10 bg-white/[0.04] p-6">
              <p className="text-xs uppercase tracking-[0.35em] text-slate-400">Path lab</p>
              <h3 className="mt-3 text-2xl font-semibold tracking-tight text-white">
                Build a BIP44-style derivation path.
              </h3>

              <div className="mt-6 grid gap-4 sm:grid-cols-3">
                <label className="block sm:col-span-1">
                  <span className="text-xs uppercase tracking-[0.35em] text-slate-500">Coin</span>
                  <select
                    value={coinType}
                    onChange={(event) => setCoinType(event.target.value)}
                    className="mt-3 w-full rounded-full border border-white/10 bg-slate-950/70 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/40"
                  >
                    {coinTypes.map((coin) => (
                      <option key={coin.value} value={coin.value}>
                        {coin.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="text-xs uppercase tracking-[0.35em] text-slate-500">
                    Account
                  </span>
                  <input
                    value={accountIndex}
                    onChange={(event) => setAccountIndex(Math.max(0, Number(event.target.value)))}
                    type="number"
                    min="0"
                    className="mt-3 w-full rounded-full border border-white/10 bg-slate-950/70 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/40"
                  />
                </label>
                <label className="block">
                  <span className="text-xs uppercase tracking-[0.35em] text-slate-500">Index</span>
                  <input
                    value={addressIndex}
                    onChange={(event) => setAddressIndex(Math.max(0, Number(event.target.value)))}
                    type="number"
                    min="0"
                    className="mt-3 w-full rounded-full border border-white/10 bg-slate-950/70 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/40"
                  />
                </label>
              </div>

              <div className="mt-6 rounded-2xl border border-cyan-300/20 bg-cyan-300/[0.04] p-5">
                <p className="text-xs uppercase tracking-[0.35em] text-cyan-200/80">
                  {selectedCoin.symbol} path
                </p>
                <p className="mt-4 break-all font-mono text-xl text-white">{derivationPath}</p>
                <p className="mt-4 text-sm leading-7 text-slate-300">
                  Purpose 44 marks BIP44. Coin type, account, change, and index form a readable
                  key tree rather than a loose pile of private keys.
                </p>
              </div>
            </section>

            <section className="rounded-[1.75rem] border border-white/10 bg-white/[0.04] p-6">
              <p className="text-xs uppercase tracking-[0.35em] text-slate-400">
                Generative object
              </p>
              <h3 className="mt-3 text-2xl font-semibold tracking-tight text-white">
                HaikuDisplay plus ensō output.
              </h3>

              <div className="mt-6 grid gap-6 sm:grid-cols-[13rem_1fr] sm:items-center">
                <div className="relative mx-auto h-48 w-48">
                  <svg viewBox="0 0 200 200" className="h-full w-full rotate-[-18deg]">
                    <circle
                      cx="100"
                      cy="100"
                      r="72"
                      fill="none"
                      stroke="rgba(103,232,249,0.85)"
                      strokeWidth="13"
                      strokeLinecap="round"
                      strokeDasharray={`${ensoDash} ${ensoGap}`}
                    />
                    <circle
                      cx="100"
                      cy="100"
                      r="58"
                      fill="none"
                      stroke="rgba(251,191,36,0.22)"
                      strokeWidth="2"
                      strokeDasharray="2 10"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-xs uppercase tracking-[0.35em] text-cyan-200/70">
                    {activeSignal?.title ?? "No node"}
                  </p>
                  <div className="mt-5 space-y-3 font-serif text-2xl leading-tight text-white">
                    {haikuLines.map((line) => (
                      <p key={line}>{line}</p>
                    ))}
                  </div>
                  <p className="mt-5 text-sm leading-7 text-slate-400">
                    The active archive node seeds a compact visual object, linking haiku display,
                    ensō generation, and hash-derived collectible output.
                  </p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </section>

      <section id="findings" className="relative border-t border-white/10 bg-white/[0.02]">
        <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-[0.45em] text-cyan-200/70">Findings</p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Research notes before implementation.
            </h2>
          </div>

          <div className="mt-10 grid border border-white/10 sm:grid-cols-3">
            {findings.map((item, index) => (
              <div
                key={item.title}
                className={`p-6 ${index < findings.length - 1 ? "border-b border-white/10 sm:border-b-0 sm:border-r" : ""}`}
              >
                <p className="text-xs uppercase tracking-[0.35em] text-slate-500">
                  0{index + 1}
                </p>
                <h3 className="mt-4 text-xl font-medium text-white">{item.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-300">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="timeline" className="relative border-t border-white/10 bg-slate-950/70">
        <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
            <div className="max-w-2xl">
              <p className="text-xs uppercase tracking-[0.45em] text-cyan-200/70">Timeline</p>
              <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                Signals sorted by origin year.
              </h2>
              <p className="mt-3 text-slate-300">
                A chronology assembled from the field notes. Each date traces a point where
                protocol, culture, or proof changed hands.
              </p>
            </div>
            <p className="text-xs uppercase tracking-[0.35em] text-slate-500">
              {signals.filter((s) => s.year).length} dated signals
            </p>
          </div>

          <ol className="mt-12 space-y-4">
            {[...signals]
              .filter((signal) => signal.year)
              .sort((a, b) => (a.year && b.year ? a.year.localeCompare(b.year) : 0))
              .map((signal) => {
                const primaryNote = signal.notes?.[0];

                return (
                  <li
                    key={signal.id}
                    className="group grid gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-5 transition hover:border-cyan-300/30 hover:bg-white/[0.06] sm:grid-cols-[7rem_1fr_auto] sm:items-center"
                  >
                    <div className="flex items-center gap-4 sm:block">
                      <p className="text-3xl font-semibold tracking-tight text-cyan-200">
                        {signal.year}
                      </p>
                      <p className="text-xs uppercase tracking-[0.35em] text-slate-500">
                        {signal.lane}
                      </p>
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-lg font-medium text-white">{signal.title}</h3>
                      {primaryNote && (
                        <p className="mt-1 text-sm leading-7 text-slate-400">{primaryNote}</p>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveLane("All");
                        setQuery("");
                        setSelectedId(signal.id);
                        const target = document.getElementById("archive");
                        if (target) {
                          target.scrollIntoView({ behavior: "smooth", block: "start" });
                        }
                      }}
                      className="justify-self-start rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.35em] text-white transition hover:border-cyan-300/40 hover:bg-cyan-300/10 sm:justify-self-end"
                    >
                      Open node
                    </button>
                  </li>
                );
              })}
          </ol>
        </div>
      </section>

      <section className="border-t border-white/10 bg-white/[0.02]">
        <div className="mx-auto max-w-7xl px-6 py-10 lg:px-8">
          <p className="text-xs uppercase tracking-[0.45em] text-slate-500">Sources</p>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-400">
            Field notes draw on primary documentation including Wikipedia entries for
            textfiles.com, Usenet, X.25, Prodigy, Tymnet, Hashcash, yEnc, WAX, and Bitcoin
            Ordinals; Britannica on packet switching; the PC World \"lost world of Prodigy\"
            retrospective; the Grokipedia Tymnet and Prodigy histories; the Bitcoin Wiki
            entry on Hashcash; the Ian Coleman BIP39 tool and its forks; and community
            histories of Bitcoin Stamps and Ordinals (Casey Rodarmor, January 2023).
          </p>
          <div className="mt-8 grid border border-white/10 lg:grid-cols-4">
            {sourceRows.map((source, index) => (
              <div
                key={source.label}
                className={`p-5 ${index < sourceRows.length - 1 ? "border-b border-white/10 lg:border-b-0 lg:border-r" : ""}`}
              >
                <h3 className="text-sm font-medium text-white">{source.label}</h3>
                <p className="mt-3 text-xs leading-6 text-cyan-100/70">{source.examples}</p>
                <p className="mt-3 text-sm leading-7 text-slate-400">{source.use}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 px-6 py-8 text-center text-xs uppercase tracking-[0.35em] text-slate-500 lg:px-8">
        Signal Atlas · research-first field notes from Textfiles.com to BIP39
      </footer>
    </main>
  );
}
