Turtle Identd version 2.11 by Ben Collver
-----------------------------------------

  Turtle Identd is a free, configurable, win32 app that is an ident
or auth service.  Some servers require that you run auth, and not all
clients have an ident daemon built in.

  I have seen several other windows ident daemons floating around on the net,
but recently was only able to obtain one.  It was written in Visual Basic,
and required a library from another company.  The library was nagware, and
nagware is really annoying.  So I decided to write my own identd.

  Turtle identd is released under the GNU license.

  Gena (svarovsk@inp.nsk.ru) modified identd to build with Borland C.  His
version fixed a bug, does not depend on cygwin.dll, and has a nice smiley
face for a tray icon.  His version is named identd3.exe and is included in
this package.  I carried over his bug fixes to my version.

INSTALLATION
------------

  Unzip the file to a separate directory.  If you already have
cygwinb19.dll then delete any copy included with t-identd.zip
Otherwise move cygwinb19.dll to your equivalent of C:\WINDOWS\

  If you wish to install from source, take a moment to read the
comments in the beginning of identd.c


USAGE
-----

identd [options]
 --userid <user name>
 --osname <operating system name>
 --logfile <name of file to log to>
 --noresolv <do not resolve name of remote host for logs>
 --lowercase <reply in only lowercase>

  Identd will look for the username in the USERNAME environment
variable.  I've been told that NT sets this to reflect the
registry.  Since I don't have NT, I cannot verify this.  If it
does not find the USERNAME variable, then it will use a
username of 'unknown'.  To specify a username on the command
line, use the --userid option.

  Identd defaults to 'unix' for the operating system name.

  Identd does not log by default.  To turn logging on, supply it
with a file name for the --logfile option.

  Identd resolves the hostname of the remote host on each
connection for the logs.  You can speed it up by disabling this
with --noresolv.


MISC
----

  A decent windows 95 IRC client can be found at:
ftp://ftp.blarg.net/users/amol/irc/ircii-NT-2.03.tar.gz

  Use winzip to extract the above.  Winzip can be found at:
http://www.winzip.com/

  Please do e-mail me about anything!  My address is collver@dnc.net
This program is free, copy it around all you want.  If you modify
the source, please share the changes with me.
