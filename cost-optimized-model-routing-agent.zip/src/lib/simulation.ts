export type ModelChoice = "local" | "fireworks";

export interface Task {
  id: string;
  name: string;
  timestamp: number;
  trueComplexity: number; // 0 to 100
  predictedComplexity: number; // 0 to 100
}

export interface ProcessedTask extends Task {
  routedTo: ModelChoice;
  predictedAccuracy: number;
  actualAccuracy: number;
  isSuccess: boolean;
  cost: number;
  latency: number; // ms
  cumulativeAccuracy?: number;
}

export const TASK_TYPES = [
  { name: "Summarize email thread", baseComplexity: 20 },
  { name: "Format JSON payload", baseComplexity: 10 },
  { name: "Extract entities from text", baseComplexity: 35 },
  { name: "Write Python unit tests", baseComplexity: 60 },
  { name: "Translate complex legal doc", baseComplexity: 85 },
  { name: "Generate React component", baseComplexity: 70 },
  { name: "Explain quantum computing", baseComplexity: 90 },
  { name: "Fix regex pattern", baseComplexity: 50 },
  { name: "Draft marketing tweet", baseComplexity: 15 },
  { name: "Analyze SQL query performance", baseComplexity: 75 },
  { name: "Classify support ticket", baseComplexity: 25 },
  { name: "Generate bash script", baseComplexity: 55 },
  { name: "Write a haiku about servers", baseComplexity: 5 },
  { name: "Rewrite paragraph for clarity", baseComplexity: 30 },
  { name: "Solve differential equation", baseComplexity: 95 },
  { name: "Create database schema", baseComplexity: 80 }
];

export const FIREWORKS_COST_PER_TASK = 0.005; // $0.005 per task
export const LOCAL_COST_PER_TASK = 0.0001; // $0.0001 per task (electricity/compute)

// Calculate accuracy based on complexity
export function getLocalAccuracy(complexity: number): number {
  // Local model drops off heavily after 50 complexity
  return Math.max(0, Math.min(100, 100 - Math.pow(complexity / 10, 2)));
}

export function getFireworksAccuracy(complexity: number): number {
  // Fireworks (e.g. Mixtral/Llama3 70b) stays highly accurate
  return Math.max(0, Math.min(100, 99 - (complexity / 50)));
}

export function generateTask(id: number): Task {
  const taskType = TASK_TYPES[Math.floor(Math.random() * TASK_TYPES.length)];
  // Add some variance to true complexity
  const trueComplexity = Math.max(0, Math.min(100, taskType.baseComplexity + (Math.random() * 20 - 10)));
  
  // Router's prediction has some error (+/- 15)
  const predictedComplexity = Math.max(0, Math.min(100, trueComplexity + (Math.random() * 30 - 15)));

  return {
    id: `tsk_${id.toString().padStart(5, '0')}`,
    name: taskType.name,
    timestamp: Date.now(),
    trueComplexity,
    predictedComplexity
  };
}

export function processTask(task: Task, threshold: number): ProcessedTask {
  const localPredictedAcc = getLocalAccuracy(task.predictedComplexity);
  
  let routedTo: ModelChoice;
  let predictedAccuracy: number;
  let actualAccuracy: number;
  let cost: number;
  let latency: number;

  // The Agent's Core Logic: Route to cheapest (local) IF predicted accuracy >= threshold
  if (localPredictedAcc >= threshold) {
    routedTo = "local";
    predictedAccuracy = localPredictedAcc;
    actualAccuracy = getLocalAccuracy(task.trueComplexity);
    cost = LOCAL_COST_PER_TASK;
    latency = 50 + Math.random() * 100; // Fast latency for local
  } else {
    routedTo = "fireworks";
    predictedAccuracy = getFireworksAccuracy(task.predictedComplexity);
    actualAccuracy = getFireworksAccuracy(task.trueComplexity);
    cost = FIREWORKS_COST_PER_TASK;
    latency = 200 + Math.random() * 300; // Network latency + larger model
  }

  // Determine if it actually succeeded based on actual probability
  const isSuccess = (Math.random() * 100) <= actualAccuracy;

  return {
    ...task,
    routedTo,
    predictedAccuracy,
    actualAccuracy,
    isSuccess,
    cost,
    latency
  };
}
