import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateTask, processTask, ProcessedTask, FIREWORKS_COST_PER_TASK } from './lib/simulation';
import { BrainCircuit, Activity, DollarSign, Target, Settings, Cpu, Zap, ArrowRight, ShieldCheck, Play, Pause } from 'lucide-react';
import { cn } from './lib/utils';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';

function MetricCard({ title, value, subtext, icon: Icon, trend }: { title: string; value: string; subtext: string; icon: React.ElementType, trend?: "up" | "down" | "neutral" }) {
  return (
    <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl shadow-lg relative overflow-hidden">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-slate-400 font-medium text-sm mb-1">{title}</p>
          <h3 className="text-3xl font-bold text-white mb-2">{value}</h3>
          <p className={cn("text-sm", 
            trend === "up" ? "text-emerald-400" : 
            trend === "down" ? "text-rose-400" : "text-slate-500"
          )}>
            {subtext}
          </p>
        </div>
        <div className="p-3 bg-slate-800 rounded-lg">
          <Icon className="w-6 h-6 text-indigo-400" />
        </div>
      </div>
      <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
    </div>
  );
}

export default function App() {
  const [isRunning, setIsRunning] = useState(false);
  const [tasks, setTasks] = useState<ProcessedTask[]>([]);
  const [threshold, setThreshold] = useState(85);
  const taskCountRef = useRef(0);
  const [speed, setSpeed] = useState(1000); // ms between tasks
  
  // Accumulated metrics
  const [metrics, setMetrics] = useState({
    totalProcessed: 0,
    successful: 0,
    localCount: 0,
    fwCount: 0,
    actualCost: 0,
    savings: 0,
  });

  const addTasks = useCallback(() => {
    taskCountRef.current += 1;
    const newTask = generateTask(taskCountRef.current);
    const processed = processTask(newTask, threshold);
    
    let currentCumulative = 0;
    
    setMetrics(prev => {
      const maxCost = (prev.totalProcessed + 1) * FIREWORKS_COST_PER_TASK;
      const newActualCost = prev.actualCost + processed.cost;
      const newTotalProcessed = prev.totalProcessed + 1;
      const newSuccessful = prev.successful + (processed.isSuccess ? 1 : 0);
      
      currentCumulative = (newSuccessful / newTotalProcessed) * 100;
      
      return {
        totalProcessed: newTotalProcessed,
        successful: newSuccessful,
        localCount: prev.localCount + (processed.routedTo === 'local' ? 1 : 0),
        fwCount: prev.fwCount + (processed.routedTo === 'fireworks' ? 1 : 0),
        actualCost: newActualCost,
        savings: maxCost - newActualCost,
      };
    });

    setTasks(prev => {
      const taskWithCumulative = { ...processed, cumulativeAccuracy: currentCumulative };
      return [taskWithCumulative, ...prev].slice(0, 100); // Keep last 100 in memory for UI
    });
  }, [threshold]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isRunning) {
      interval = setInterval(addTasks, speed);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, addTasks, speed]);

  // Derived stats
  const overallAccuracy = metrics.totalProcessed > 0 ? (metrics.successful / metrics.totalProcessed) * 100 : 0;
  const maxCostIfOnlyFW = metrics.totalProcessed * FIREWORKS_COST_PER_TASK;

  // Chart data
  const chartData = [...tasks].reverse().map((t, i) => ({
    index: i,
    accuracy: t.cumulativeAccuracy,
    predicted: t.predictedAccuracy,
    threshold: threshold,
    cost: t.cost * 1000 // scale up for visibility or keep separate
  }));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30 relative">
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none mix-blend-overlay"></div>
      <div className="absolute top-0 left-0 right-0 h-[500px] bg-gradient-to-b from-indigo-900/20 to-transparent pointer-events-none"></div>
      
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-lg">
              <BrainCircuit className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h1 className="font-bold text-white leading-tight">Neural Router Agent</h1>
              <p className="text-xs text-slate-400">Standardized Env • Dynamic Fallback</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex flex-col text-right mr-4 text-xs">
              <span className="text-slate-400">Environment Status: <span className="text-emerald-400">Standardized</span></span>
              <span className="text-slate-400">Evaluation: <span className="text-indigo-400">Routing Intelligence</span></span>
            </div>
            <div className="flex items-center gap-2 bg-slate-900 rounded-lg p-1 border border-slate-800">
              <button 
                onClick={() => setIsRunning(!isRunning)}
                className={cn(
                  "px-4 py-2 rounded-md font-medium text-sm flex items-center gap-2 transition-colors",
                  isRunning ? "bg-rose-500/10 text-rose-400 hover:bg-rose-500/20" : "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                )}
              >
                {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isRunning ? "Pause Stream" : "Start Stream"}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-12 gap-8">
        
        {/* Left Column: Stats & Chart */}
        <div className="col-span-12 lg:col-span-8 space-y-8">
          
          {/* Top Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard 
              title="Overall Accuracy" 
              value={`${overallAccuracy.toFixed(1)}%`}
              subtext={`Target: ${threshold}%`}
              icon={Target}
              trend={overallAccuracy >= threshold ? "up" : "down"}
            />
            <MetricCard 
              title="Total Cost Savings" 
              value={`$${metrics.savings.toFixed(4)}`}
              subtext={`vs $${maxCostIfOnlyFW.toFixed(4)} FW only`}
              icon={DollarSign}
              trend="up"
            />
            <MetricCard 
              title="Active Model Split" 
              value={`${metrics.localCount} / ${metrics.fwCount}`}
              subtext="Local / Fireworks"
              icon={Activity}
            />
          </div>

          {/* Chart Section */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-bold text-white">Accuracy Tracking</h3>
                <p className="text-sm text-slate-400">Monitoring real-time model accuracy vs threshold</p>
              </div>
              <div className="flex gap-4 text-xs font-medium">
                <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-indigo-500"></span>Actual Acc.</div>
                <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-slate-600"></span>Threshold</div>
              </div>
            </div>
            
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="index" hide />
                  <YAxis domain={[0, 100]} stroke="#475569" tick={{ fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.5rem' }}
                    itemStyle={{ color: '#e2e8f0' }}
                  />
                  <Line type="monotone" dataKey="accuracy" stroke="#6366f1" strokeWidth={2} dot={false} isAnimationActive={false} />
                  <Line type="step" dataKey="threshold" stroke="#475569" strokeWidth={2} strokeDasharray="5 5" dot={false} isAnimationActive={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

        {/* Right Column: Settings & Live Feed */}
        <div className="col-span-12 lg:col-span-4 space-y-8 flex flex-col h-[calc(100vh-8rem)]">
          
          {/* Settings Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg shrink-0">
            <div className="flex items-center gap-2 mb-6">
              <Settings className="w-5 h-5 text-slate-400" />
              <h3 className="font-bold text-white">Agent Configuration</h3>
            </div>
            
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-300">Accuracy Threshold</label>
                  <span className="text-indigo-400 font-bold">{threshold}%</span>
                </div>
                <input 
                  type="range" 
                  min="50" max="99" 
                  value={threshold} 
                  onChange={(e) => setThreshold(Number(e.target.value))}
                  className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                <p className="text-xs text-slate-500 mt-2">
                  Minimum predicted accuracy required to route to the cheaper local model.
                </p>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-300">Simulation Speed</label>
                  <span className="text-slate-400 font-medium">{speed}ms</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[2000, 1000, 200].map(val => (
                    <button
                      key={val}
                      onClick={() => setSpeed(val)}
                      className={cn(
                        "py-1.5 text-xs font-medium rounded-md border transition-colors",
                        speed === val 
                          ? "bg-indigo-500/20 border-indigo-500/50 text-indigo-300" 
                          : "bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800"
                      )}
                    >
                      {val === 2000 ? "Slow" : val === 1000 ? "Normal" : "Fast"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-slate-800">
              <h4 className="text-sm font-bold text-slate-300 mb-2">Routing Intelligence</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                The router dynamically evaluates the complexity of incoming tasks. If the free local model is predicted to maintain the required accuracy threshold, it processes the task. Complex tasks automatically fall back to the premium Fireworks AI API, ensuring we always pick the cheapest option without sacrificing quality.
              </p>
            </div>
          </div>

          {/* Live Feed */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-lg flex-1 flex flex-col overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-900/90 z-10">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-slate-400" />
                <h3 className="font-bold text-white">Live Task Feed</h3>
              </div>
              <span className="flex h-2 w-2 relative">
                <span className={cn("animate-ping absolute inline-flex h-full w-full rounded-full opacity-75", isRunning ? "bg-emerald-400" : "bg-slate-500")}></span>
                <span className={cn("relative inline-flex rounded-full h-2 w-2", isRunning ? "bg-emerald-500" : "bg-slate-500")}></span>
              </span>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
              {tasks.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-3">
                  <ShieldCheck className="w-10 h-10 opacity-20" />
                  <p className="text-sm">Waiting for incoming tasks...</p>
                </div>
              ) : (
                tasks.slice(0, 50).map(task => (
                  <div key={`${task.id}-${task.timestamp}`} className="bg-slate-800/50 border border-slate-700/50 rounded-lg p-3 text-sm animate-in slide-in-from-top-2 fade-in duration-300">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-medium text-slate-200 truncate pr-2">{task.name}</span>
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider shrink-0",
                        task.isSuccess ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"
                      )}>
                        {task.isSuccess ? "Success" : "Failed"}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-3 text-xs text-slate-400 mt-2">
                      <div className="flex items-center gap-1">
                        {task.routedTo === 'local' ? (
                          <><Cpu className="w-3.5 h-3.5 text-blue-400" /> <span className="text-blue-400 font-medium">Local (Llama 8B)</span></>
                        ) : (
                          <><Zap className="w-3.5 h-3.5 text-amber-400" /> <span className="text-amber-400 font-medium">Fireworks AI</span></>
                        )}
                      </div>
                      <div className="text-slate-500 flex items-center gap-1">
                        <ArrowRight className="w-3 h-3" /> {task.latency.toFixed(0)}ms
                      </div>
                      <div className="ml-auto flex items-center gap-2">
                         <span title="Predicted Accuracy" className="text-slate-500">Pred: <span className={task.predictedAccuracy >= threshold ? "text-slate-300" : "text-amber-300"}>{task.predictedAccuracy.toFixed(0)}%</span></span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
