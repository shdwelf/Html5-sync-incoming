# Rodger Ramrod MS-DOS Historical Archive

## Overview
A comprehensive HTML5 historical archive documenting **Rodger Ramrod** (1996), an obscure MS-DOS adult game by Nonaz Inc. of St Charles, Illinois.

## Archive Contents
```
/
├── index.html          # Main archive application (1941 lines)
├── manifest.json       # PWA manifest for offline capability
├── sw.js              # Service Worker for offline functionality
└── image-search/      # Downloaded screenshots
    ├── rodger-ramrod-dos-game-screenshot-gamepl-1.jpg
    ├── rodger-ramrod-dos-game-screenshot-gamepl-2.png
    └── rodger-ramrod-dos-game-screenshot-gamepl-3.png
```

## Archive Features

### 20 Sections Covering:
1. **Overview** - Game info, technical specs, archive statistics
2. **Historical Context** - Timeline from 1996 development to present
3. **Gameplay Mechanics** - Weapons system, story, resource management
4. **Ten Levels** - S&M, FAG, FAT, PRINCES, DYKE, HOLLYWOOD, BIKER, HILLBILLY, COWBOY, SPACE
5. **Preserved Archive** - Multiple source links and mirrors
6. **Technical Notes** - Engine details, graphics, distribution
7. **Original Files** - File listings from eXoDOS archive
8. **Original Documentation** - 1996 shareware license
9. **Cultural Significance** - Adult gaming era context
10. **Development Team** - The Stringini Bros, current careers
11. **Gameplay Media** - Longplay videos, screenshots
12. **Legacy & Controversy** - Reputation management, preservation
13. **Archive Archaeology** - Original 4chan discovery (July 2016)
14. **Reddit Rediscovery** - 2020 community identification
15. **Technical Breakdown** - Requirements, audio files
16. **Related Communities** - Subreddit, archives
17. **Sources & References** - All archive links
18. **Mirrors & Archive Sources** - Comprehensive source list
19. **Knowledge Quiz** - 8 trivia questions
20. **Retro Audio Vibe** - Animated audio visualizer

### Interactive Features:
- **28 rotating game facts** (press T key)
- **Interactive quiz** (8 questions)
- **Dark mode toggle**
- **CRT scanline effect**
- **Animated audio visualizer**
- **Scroll progress bar**
- **Keyboard shortcuts** (T=fact, Q=quiz, ?=help)
- **Konami code easter egg**
- **Smooth navigation**
- **Offline-capable (PWA)**

### Aesthetic:
- VT323 and Press Start 2P retro fonts
- Neon color scheme (green/pink/cyan/yellow/orange)
- CRT monitor effects
- Dark terminal aesthetic

## Game Information

**Title:** Rodger Ramrod (1996)
**Developer:** Nonaz Inc. - St Charles, Illinois
**Team:** Frank Settimio Stringini, Paul Stringini, Derrick Stringini
**Release Date:** December 28, 1996
**Price:** $39.99 + $5 shipping
**Platform:** MS-DOS, 640x400 max, 256 colors
**Engine:** Doom-like pseudo-3D, DOS4GW.EXE DOS extender

### Gameplay
- Unconventional weapons: masturbation (semen), urination, flatulation
- HUD showing penis status/ammo
- 10 themed levels with cartoon animation
- Refill stations at burrito carts and beer barrels

### Full Version Sources:
- **Internet Archive (Shareware):** https://archive.org/details/msdos_Rodger_Ramrod_1996
- **Internet Archive (Full):** https://archive.org/details/cdfwps (74.5 MB RAR)
- **eXoDOS Collection:** https://ia601701.us.archive.org/view_archive.php?archive=/18/items/exov5_2/eXo/eXoDOS/Rodger%20Ramrod%20%281996%29.zip

### Alternative Sources:
- **WoWroms:** https://wowroms.com/en/roms/dos/rodger-ramrod-1996/149385.html
- **PlayOnline-Games.com:** https://playonline-games.com/rodger-ramrod/
- **RomStation (France):** https://www.romstation.fr/games/dos/rodger-ramrod-r57522/

## Preservation Notes

- Former staff reportedly attempted to "bury all evidence" of the game's existence
- Full version first shared publicly on 4chan /vr/ in July 2016 via anonymous archivist
- Uploaded to Internet Archive by sharkie7878 on April 30, 2022
- "Barneghetto Piratesoft" credited as original uploader
- Active community maintained on r/RodgerRamrod

## Research Documentation

This archive compiles information from:
- Internet Archive metadata and file listings
- Reddit discussions (r/tipofmyjoystick, r/RodgerRamrod)
- Archived 4chan /vr/ threads (multiple sources)
- Gaming databases (Zeden.net FR, WoWroms, RomStation)
- Artist profiles (YouTube, IMDb, Newgrounds, LinkedIn)
- Community screenshots and longplay documentation

## Usage

To view the archive locally:
1. Open `index.html` in a modern web browser
2. For offline capability, serve via a local HTTP server
3. All external links lead to preserved archives and archives

## License

This is a historical preservation project. Original game copyright remains with Nonaz Inc. (defunct). The original shareware license permitted free distribution.

---

*Compiled July 2026 | Historical documentation only*