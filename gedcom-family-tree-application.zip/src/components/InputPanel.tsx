import { useRef, useState } from "react";
import { extractGedcom, looksLikeGedcom } from "../utils/gedcom";

interface SourcePart {
  id: string;
  name: string;
  text: string;
  source: "clipboard" | "url" | "file" | "paste";
}

interface Props {
  parts: SourcePart[];
  onAddPart: (part: SourcePart) => void;
  onRemovePart: (id: string) => void;
  onLoad: () => void;
  onClearAll: () => void;
  onLoadSample: () => void;
}

export default function InputPanel({
  parts,
  onAddPart,
  onRemovePart,
  onLoad,
  onClearAll,
  onLoadSample,
}: Props) {
  const [url, setUrl] = useState("");
  const [pasteText, setPasteText] = useState("");
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addFromText = (text: string, source: SourcePart["source"], name: string) => {
    const extracted = extractGedcom(text);
    if (!extracted) {
      setError(`No valid GEDCOM data found in ${name}.`);
      return false;
    }
    onAddPart({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name,
      text: extracted,
      source,
    });
    setError(null);
    return true;
  };

  const handlePasteClipboard = async () => {
    setLoading("clipboard");
    setError(null);
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        setError("Clipboard is empty.");
      } else {
        const ok = addFromText(text, "clipboard", `Clipboard ${new Date().toLocaleTimeString()}`);
        if (!ok) {
          // still allow paste textarea to be filled
          setPasteText(text);
        }
      }
    } catch (err: any) {
      setError("Clipboard read failed. Try pasting into the textarea below. (" + err.message + ")");
    } finally {
      setLoading(null);
    }
  };

  const handleFetchUrl = async () => {
    if (!url.trim()) return;
    setLoading("url");
    setError(null);
    try {
      // Use a CORS proxy for cross-origin scraping
      const targets = [
        url,
        `https://corsproxy.io/?${encodeURIComponent(url)}`,
        `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
      ];
      let text = "";
      let lastErr: any;
      for (const t of targets) {
        try {
          const res = await fetch(t);
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          text = await res.text();
          if (text) break;
        } catch (e) {
          lastErr = e;
        }
      }
      if (!text) throw lastErr || new Error("All fetch attempts failed");

      const ok = addFromText(text, "url", shortenUrl(url));
      if (ok) setUrl("");
    } catch (err: any) {
      setError(`Failed to fetch URL: ${err.message}`);
    } finally {
      setLoading(null);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    setError(null);
    for (const file of Array.from(files)) {
      const text = await file.text();
      addFromText(text, "file", file.name);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handlePasteSubmit = () => {
    if (!pasteText.trim()) return;
    setError(null);
    const ok = addFromText(pasteText, "paste", `Pasted ${new Date().toLocaleTimeString()}`);
    if (ok) setPasteText("");
  };

  return (
    <div className="space-y-5">
      {/* Clipboard */}
      <Section title="Clipboard" icon="📋">
        <button
          onClick={handlePasteClipboard}
          disabled={loading === "clipboard"}
          className="w-full rounded-lg bg-gradient-to-r from-indigo-500 to-violet-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md transition hover:from-indigo-600 hover:to-violet-700 disabled:opacity-50"
        >
          {loading === "clipboard" ? "Reading…" : "Paste from clipboard"}
        </button>
      </Section>

      {/* URL */}
      <Section title="Fetch from URL" icon="🌐">
        <div className="space-y-2">
          <input
            type="url"
            placeholder="https://example.com/family.ged"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleFetchUrl()}
            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
          />
          <button
            onClick={handleFetchUrl}
            disabled={loading === "url" || !url.trim()}
            className="w-full rounded-lg bg-slate-800 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-900 disabled:opacity-50"
          >
            {loading === "url" ? "Scraping…" : "Fetch & scrape"}
          </button>
          <p className="text-xs text-slate-500">
            Auto-extracts GEDCOM from raw files or HTML pages. Falls back to CORS proxies if needed.
          </p>
        </div>
      </Section>

      {/* File upload */}
      <Section title="Upload .ged file(s)" icon="📁">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".ged,.gedcom,.txt"
          onChange={handleFileChange}
          className="block w-full text-xs text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-slate-100 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-slate-700 hover:file:bg-slate-200"
        />
      </Section>

      {/* Manual paste */}
      <Section title="Paste manually" icon="✏️">
        <textarea
          placeholder="Paste GEDCOM text here…"
          value={pasteText}
          onChange={(e) => setPasteText(e.target.value)}
          rows={4}
          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
        />
        <button
          onClick={handlePasteSubmit}
          disabled={!pasteText.trim()}
          className="mt-2 w-full rounded-lg bg-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-300 disabled:opacity-50"
        >
          Add as part
        </button>
      </Section>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
          {error}
        </div>
      )}

      {/* Parts list */}
      {parts.length > 0 && (
        <Section title={`Multipart sources (${parts.length})`} icon="🧩">
          <ul className="space-y-1.5">
            {parts.map((p) => (
              <li
                key={p.id}
                className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5"
              >
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-medium text-slate-700">{p.name}</div>
                  <div className="text-[10px] uppercase tracking-wide text-slate-400">
                    {p.source} · {Math.round(p.text.length / 1024)} KB
                    {!looksLikeGedcom(p.text) && (
                      <span className="ml-1 text-amber-600">⚠ unverified</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => onRemovePart(p.id)}
                  className="rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-600"
                  title="Remove"
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            <button
              onClick={onLoad}
              className="flex-1 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md transition hover:from-emerald-600 hover:to-teal-700"
            >
              Recombine & visualize ({parts.length})
            </button>
            <button
              onClick={onClearAll}
              className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100"
              title="Clear all parts"
            >
              Clear
            </button>
          </div>
        </Section>
      )}

      <button
        onClick={onLoadSample}
        className="w-full rounded-lg border border-dashed border-slate-300 px-4 py-2 text-xs font-medium text-slate-500 hover:bg-slate-50 hover:text-slate-700"
      >
        Try with sample data
      </button>
    </div>
  );
}

function Section({
  title,
  icon,
  children,
}: {
  title: string;
  icon: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-500">
        <span>{icon}</span>
        <span>{title}</span>
      </h3>
      {children}
    </div>
  );
}

function shortenUrl(url: string): string {
  try {
    const u = new URL(url);
    return u.hostname + (u.pathname.length > 1 ? u.pathname : "");
  } catch {
    return url.slice(0, 40);
  }
}

export type { SourcePart };
