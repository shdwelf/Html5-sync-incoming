import { useEffect, useMemo, useRef, useState } from "react";
import type { GedcomData } from "../utils/gedcom";
import { formatLifeSpan } from "../utils/gedcom";
import { computeLayout, NODE_DIM } from "../utils/layout";

interface Props {
  data: GedcomData;
  rootId: string;
  onSelectPerson: (id: string) => void;
  selectedId?: string;
}

export default function FamilyTree({ data, rootId, onSelectPerson, selectedId }: Props) {
  const layout = useMemo(() => computeLayout(data, rootId), [data, rootId]);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0, panX: 0, panY: 0 });

  // Fit to view when layout changes
  useEffect(() => {
    if (!containerRef.current || layout.width === 0) return;
    const cw = containerRef.current.clientWidth;
    const ch = containerRef.current.clientHeight;
    const padding = 60;
    const sx = (cw - padding) / (layout.width + NODE_DIM.w);
    const sy = (ch - padding) / (layout.height + NODE_DIM.h);
    const newZoom = Math.min(1, Math.max(0.2, Math.min(sx, sy)));
    setZoom(newZoom);
    setPan({
      x: cw / 2 - (layout.width / 2 + NODE_DIM.w / 2) * newZoom,
      y: 40,
    });
  }, [layout]);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = -e.deltaY * 0.001;
    const newZoom = Math.min(3, Math.max(0.1, zoom * (1 + delta)));
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    // Zoom around mouse
    const k = newZoom / zoom;
    setPan({
      x: mx - (mx - pan.x) * k,
      y: my - (my - pan.y) * k,
    });
    setZoom(newZoom);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest("[data-node]")) return;
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
  };
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: dragStart.current.panX + (e.clientX - dragStart.current.x),
      y: dragStart.current.panY + (e.clientY - dragStart.current.y),
    });
  };
  const stopDrag = () => setIsDragging(false);

  const resetView = () => {
    if (!containerRef.current || layout.width === 0) return;
    const cw = containerRef.current.clientWidth;
    const padding = 60;
    const sx = (cw - padding) / (layout.width + NODE_DIM.w);
    const newZoom = Math.min(1, Math.max(0.2, sx));
    setZoom(newZoom);
    setPan({
      x: cw / 2 - (layout.width / 2 + NODE_DIM.w / 2) * newZoom,
      y: 40,
    });
  };

  if (layout.nodes.length === 0) {
    return (
      <div className="flex h-full items-center justify-center text-slate-500">
        No individuals to display.
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative h-full w-full overflow-hidden bg-gradient-to-br from-slate-50 to-slate-100"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={stopDrag}
      onMouseLeave={stopDrag}
      style={{ cursor: isDragging ? "grabbing" : "grab" }}
    >
      {/* Pattern background */}
      <svg className="absolute inset-0 h-full w-full opacity-40" aria-hidden="true">
        <defs>
          <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="1" fill="#cbd5e1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>

      {/* Tree */}
      <div
        className="absolute origin-top-left"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
        }}
      >
        <svg
          width={layout.width + NODE_DIM.w}
          height={layout.height + NODE_DIM.h + 20}
          className="overflow-visible"
        >
          {/* Couple links (horizontal between spouses) */}
          {layout.couples.map((c) => (
            <line
              key={`c-${c.famId}`}
              x1={c.x1}
              y1={c.y1}
              x2={c.x2}
              y2={c.y2}
              stroke="#f59e0b"
              strokeWidth={3}
              strokeLinecap="round"
            />
          ))}

          {/* Parent-child links */}
          {layout.parentLinks.map((p, i) => {
            const midY = (p.parentMidY + p.childY) / 2;
            const path = `M ${p.parentMidX} ${p.parentMidY} L ${p.parentMidX} ${midY} L ${p.childX} ${midY} L ${p.childX} ${p.childY}`;
            return (
              <path
                key={`p-${p.famId}-${p.childId}-${i}`}
                d={path}
                fill="none"
                stroke="#64748b"
                strokeWidth={2}
              />
            );
          })}

          {/* Nodes */}
          {layout.nodes.map((n) => {
            const isRoot = n.id === layout.rootId;
            const isSelected = n.id === selectedId;
            const sex = n.individual.sex;
            const bg =
              sex === "M"
                ? "url(#gradM)"
                : sex === "F"
                ? "url(#gradF)"
                : "url(#gradU)";
            return (
              <g
                key={n.id}
                data-node
                transform={`translate(${n.x}, ${n.y})`}
                style={{ cursor: "pointer" }}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectPerson(n.id);
                }}
              >
                <rect
                  width={NODE_DIM.w}
                  height={NODE_DIM.h}
                  rx={12}
                  fill={bg}
                  stroke={isSelected ? "#6366f1" : isRoot ? "#10b981" : "#cbd5e1"}
                  strokeWidth={isSelected || isRoot ? 3 : 1.5}
                  filter="url(#shadow)"
                />
                <text
                  x={NODE_DIM.w / 2}
                  y={26}
                  textAnchor="middle"
                  fontSize={13}
                  fontWeight={600}
                  fill="#0f172a"
                >
                  {truncate(n.individual.name, 24)}
                </text>
                <text
                  x={NODE_DIM.w / 2}
                  y={46}
                  textAnchor="middle"
                  fontSize={11}
                  fill="#475569"
                >
                  {formatLifeSpan(n.individual)}
                </text>
                {n.individual.birth?.place && (
                  <text
                    x={NODE_DIM.w / 2}
                    y={60}
                    textAnchor="middle"
                    fontSize={10}
                    fill="#64748b"
                  >
                    {truncate(n.individual.birth.place, 28)}
                  </text>
                )}
              </g>
            );
          })}

          <defs>
            <linearGradient id="gradM" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#dbeafe" />
              <stop offset="100%" stopColor="#bfdbfe" />
            </linearGradient>
            <linearGradient id="gradF" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#fce7f3" />
              <stop offset="100%" stopColor="#fbcfe8" />
            </linearGradient>
            <linearGradient id="gradU" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f1f5f9" />
              <stop offset="100%" stopColor="#e2e8f0" />
            </linearGradient>
            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.15" />
            </filter>
          </defs>
        </svg>
      </div>

      {/* Controls */}
      <div className="absolute right-4 bottom-4 flex flex-col gap-2 rounded-lg border border-slate-200 bg-white/95 p-2 shadow-lg backdrop-blur">
        <button
          className="flex h-9 w-9 items-center justify-center rounded text-lg font-semibold text-slate-700 hover:bg-slate-100"
          onClick={() => setZoom((z) => Math.min(3, z * 1.2))}
          title="Zoom in"
        >
          +
        </button>
        <button
          className="flex h-9 w-9 items-center justify-center rounded text-lg font-semibold text-slate-700 hover:bg-slate-100"
          onClick={() => setZoom((z) => Math.max(0.1, z / 1.2))}
          title="Zoom out"
        >
          −
        </button>
        <button
          className="flex h-9 w-9 items-center justify-center rounded text-xs font-semibold text-slate-700 hover:bg-slate-100"
          onClick={resetView}
          title="Fit to view"
        >
          ⊡
        </button>
      </div>

      <div className="absolute bottom-4 left-4 rounded-lg border border-slate-200 bg-white/95 px-3 py-1.5 text-xs text-slate-600 shadow-lg backdrop-blur">
        {layout.nodes.length} people · zoom {Math.round(zoom * 100)}% · drag to pan · scroll to zoom
      </div>
    </div>
  );
}

function truncate(s: string, n: number) {
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}
