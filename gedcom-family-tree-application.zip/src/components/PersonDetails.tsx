import type { GedcomData, Individual } from "../utils/gedcom";
import { formatLifeSpan } from "../utils/gedcom";

interface Props {
  data: GedcomData;
  personId: string;
  onSelect: (id: string) => void;
  onClose: () => void;
}

export default function PersonDetails({ data, personId, onSelect, onClose }: Props) {
  const person = data.individuals.get(personId);
  if (!person) return null;

  const parents: Individual[] = [];
  for (const famId of person.famc) {
    const fam = data.families.get(famId);
    if (!fam) continue;
    if (fam.husb) {
      const p = data.individuals.get(fam.husb);
      if (p) parents.push(p);
    }
    if (fam.wife) {
      const p = data.individuals.get(fam.wife);
      if (p) parents.push(p);
    }
  }

  const spousesAndChildren: { spouse?: Individual; children: Individual[]; marriage?: string }[] = [];
  for (const famId of person.fams) {
    const fam = data.families.get(famId);
    if (!fam) continue;
    const spouseId = fam.husb === personId ? fam.wife : fam.husb;
    const spouse = spouseId ? data.individuals.get(spouseId) : undefined;
    const children = fam.children
      .map((c) => data.individuals.get(c))
      .filter((c): c is Individual => !!c);
    spousesAndChildren.push({
      spouse,
      children,
      marriage: fam.marriage?.date,
    });
  }

  const siblings: Individual[] = [];
  for (const famId of person.famc) {
    const fam = data.families.get(famId);
    if (!fam) continue;
    for (const cid of fam.children) {
      if (cid !== personId) {
        const s = data.individuals.get(cid);
        if (s) siblings.push(s);
      }
    }
  }

  return (
    <div className="flex h-full flex-col overflow-hidden bg-white">
      <div className="flex items-start justify-between gap-2 border-b border-slate-200 bg-gradient-to-br from-indigo-50 to-violet-50 px-5 py-4">
        <div className="min-w-0 flex-1">
          <div className="text-xs font-semibold uppercase tracking-wide text-indigo-600">
            {person.sex === "M" ? "♂ Male" : person.sex === "F" ? "♀ Female" : "Unknown"}
          </div>
          <h2 className="mt-1 truncate text-lg font-bold text-slate-900">{person.name}</h2>
          <div className="text-sm text-slate-600">{formatLifeSpan(person)}</div>
        </div>
        <button
          onClick={onClose}
          className="rounded p-1 text-slate-400 hover:bg-white hover:text-slate-700"
        >
          ✕
        </button>
      </div>

      <div className="flex-1 space-y-5 overflow-y-auto px-5 py-4">
        {(person.birth || person.death || person.occupation) && (
          <div className="space-y-2">
            {person.birth && (
              <Fact label="Born" value={fmtEvent(person.birth)} />
            )}
            {person.death && (
              <Fact label="Died" value={fmtEvent(person.death)} />
            )}
            {person.occupation && (
              <Fact label="Occupation" value={person.occupation} />
            )}
          </div>
        )}

        {parents.length > 0 && (
          <Group title="Parents">
            {parents.map((p) => (
              <PersonChip key={p.id} person={p} onClick={() => onSelect(p.id)} />
            ))}
          </Group>
        )}

        {siblings.length > 0 && (
          <Group title={`Siblings (${siblings.length})`}>
            {siblings.map((p) => (
              <PersonChip key={p.id} person={p} onClick={() => onSelect(p.id)} />
            ))}
          </Group>
        )}

        {spousesAndChildren.map((sc, idx) => (
          <div key={idx}>
            {sc.spouse && (
              <Group title={`Spouse${sc.marriage ? ` · m. ${sc.marriage}` : ""}`}>
                <PersonChip person={sc.spouse} onClick={() => onSelect(sc.spouse!.id)} />
              </Group>
            )}
            {sc.children.length > 0 && (
              <Group title={`Children (${sc.children.length})`}>
                {sc.children.map((c) => (
                  <PersonChip key={c.id} person={c} onClick={() => onSelect(c.id)} />
                ))}
              </Group>
            )}
          </div>
        ))}

        {person.notes.length > 0 && (
          <Group title="Notes">
            {person.notes.map((n, i) => (
              <p key={i} className="whitespace-pre-wrap rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-700">
                {n}
              </p>
            ))}
          </Group>
        )}

        <div className="border-t border-slate-100 pt-3 text-[10px] uppercase tracking-wider text-slate-400">
          ID: {person.id}
        </div>
      </div>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2 text-sm">
      <span className="w-20 shrink-0 font-semibold text-slate-500">{label}</span>
      <span className="text-slate-800">{value}</span>
    </div>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
        {title}
      </h3>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

function PersonChip({ person, onClick }: { person: Individual; onClick: () => void }) {
  const bg =
    person.sex === "M"
      ? "from-blue-50 to-blue-100 border-blue-200"
      : person.sex === "F"
      ? "from-pink-50 to-pink-100 border-pink-200"
      : "from-slate-50 to-slate-100 border-slate-200";
  return (
    <button
      onClick={onClick}
      className={`w-full rounded-lg border bg-gradient-to-r ${bg} px-3 py-2 text-left transition hover:scale-[1.02] hover:shadow-sm`}
    >
      <div className="text-sm font-semibold text-slate-900">{person.name}</div>
      <div className="text-xs text-slate-600">{formatLifeSpan(person)}</div>
    </button>
  );
}

function fmtEvent(e: { date?: string; place?: string }) {
  return [e.date, e.place].filter(Boolean).join(" · ");
}
