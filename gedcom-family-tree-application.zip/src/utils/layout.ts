import type { GedcomData, Individual } from "./gedcom";

export interface NodePos {
  id: string;
  individual: Individual;
  x: number;
  y: number;
  generation: number;
}

export interface CoupleLink {
  famId: string;
  a: string;
  b: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  midX: number;
  midY: number;
}

export interface ParentChildLink {
  famId: string;
  parentMidX: number;
  parentMidY: number;
  childId: string;
  childX: number;
  childY: number;
}

export interface LayoutResult {
  nodes: NodePos[];
  couples: CoupleLink[];
  parentLinks: ParentChildLink[];
  rootId: string;
  width: number;
  height: number;
}

const NODE_W = 180;
const NODE_H = 70;
const COL_GAP = 40;
const ROW_GAP = 140;

/**
 * Compute a layered ancestor/descendant layout centered on rootId.
 * - Ancestors go up (negative generation).
 * - Descendants go down (positive generation).
 */
export function computeLayout(data: GedcomData, rootId: string): LayoutResult {
  const root = data.individuals.get(rootId);
  if (!root) {
    return { nodes: [], couples: [], parentLinks: [], rootId, width: 0, height: 0 };
  }

  // Assign generations using BFS through family relationships
  const generation = new Map<string, number>();
  const visited = new Set<string>();
  const queue: { id: string; gen: number }[] = [{ id: rootId, gen: 0 }];
  generation.set(rootId, 0);

  while (queue.length > 0) {
    const { id, gen } = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const indi = data.individuals.get(id);
    if (!indi) continue;

    // Parents -> gen - 1
    for (const famId of indi.famc) {
      const fam = data.families.get(famId);
      if (!fam) continue;
      for (const p of [fam.husb, fam.wife]) {
        if (p && !generation.has(p)) {
          generation.set(p, gen - 1);
          queue.push({ id: p, gen: gen - 1 });
        }
      }
    }
    // Spouses -> same gen, children -> gen + 1
    for (const famId of indi.fams) {
      const fam = data.families.get(famId);
      if (!fam) continue;
      for (const s of [fam.husb, fam.wife]) {
        if (s && s !== id && !generation.has(s)) {
          generation.set(s, gen);
          queue.push({ id: s, gen });
        }
      }
      for (const c of fam.children) {
        if (!generation.has(c)) {
          generation.set(c, gen + 1);
          queue.push({ id: c, gen: gen + 1 });
        }
      }
    }
  }

  // Group by generation
  const genGroups = new Map<number, string[]>();
  for (const [id, gen] of generation) {
    if (!genGroups.has(gen)) genGroups.set(gen, []);
    genGroups.get(gen)!.push(id);
  }

  // Sort each generation: try to keep spouses adjacent and children near parents
  const sortedGens = Array.from(genGroups.keys()).sort((a, b) => a - b);

  // Build ordering: for each gen, order by family relationships
  const orderedByGen = new Map<number, string[]>();
  for (const g of sortedGens) {
    orderedByGen.set(g, orderGeneration(data, genGroups.get(g)!, generation));
  }

  // Compute positions
  const nodes: NodePos[] = [];
  const posMap = new Map<string, NodePos>();
  const minGen = sortedGens[0];

  let maxRowWidth = 0;
  for (const g of sortedGens) {
    const row = orderedByGen.get(g)!;
    const width = row.length * NODE_W + (row.length - 1) * COL_GAP;
    if (width > maxRowWidth) maxRowWidth = width;
  }

  for (const g of sortedGens) {
    const row = orderedByGen.get(g)!;
    const width = row.length * NODE_W + (row.length - 1) * COL_GAP;
    const startX = (maxRowWidth - width) / 2;
    const y = (g - minGen) * ROW_GAP;
    row.forEach((id, i) => {
      const indi = data.individuals.get(id);
      if (!indi) return;
      const x = startX + i * (NODE_W + COL_GAP);
      const node: NodePos = { id, individual: indi, x, y, generation: g };
      nodes.push(node);
      posMap.set(id, node);
    });
  }

  // Build couple links and parent-child links
  const couples: CoupleLink[] = [];
  const parentLinks: ParentChildLink[] = [];
  const seenFams = new Set<string>();

  for (const [famId, fam] of data.families) {
    const husbPos = fam.husb ? posMap.get(fam.husb) : undefined;
    const wifePos = fam.wife ? posMap.get(fam.wife) : undefined;

    let midX: number | undefined;
    let midY: number | undefined;

    if (husbPos && wifePos) {
      const x1 = husbPos.x + NODE_W / 2;
      const y1 = husbPos.y + NODE_H / 2;
      const x2 = wifePos.x + NODE_W / 2;
      const y2 = wifePos.y + NODE_H / 2;
      couples.push({
        famId,
        a: fam.husb!,
        b: fam.wife!,
        x1,
        y1,
        x2,
        y2,
        midX: (x1 + x2) / 2,
        midY: (y1 + y2) / 2,
      });
      midX = (x1 + x2) / 2;
      midY = (y1 + y2) / 2;
    } else if (husbPos || wifePos) {
      const p = (husbPos || wifePos)!;
      midX = p.x + NODE_W / 2;
      midY = p.y + NODE_H / 2;
    }

    if (midX === undefined || midY === undefined) continue;
    seenFams.add(famId);

    for (const childId of fam.children) {
      const childPos = posMap.get(childId);
      if (!childPos) continue;
      parentLinks.push({
        famId,
        parentMidX: midX,
        parentMidY: midY,
        childId,
        childX: childPos.x + NODE_W / 2,
        childY: childPos.y,
      });
    }
  }

  const width = maxRowWidth;
  const height = (sortedGens.length - 1) * ROW_GAP + NODE_H;

  return { nodes, couples, parentLinks, rootId, width, height };
}

function orderGeneration(
  data: GedcomData,
  ids: string[],
  generation: Map<string, number>
): string[] {
  // Use a deterministic ordering: group spouses together, and try to keep siblings together
  const placed = new Set<string>();
  const result: string[] = [];

  // First, group by parent family if present
  const familyGroups = new Map<string, string[]>();
  const orphans: string[] = [];

  for (const id of ids) {
    const indi = data.individuals.get(id);
    if (!indi) continue;
    if (indi.famc.length > 0) {
      const key = indi.famc[0];
      if (!familyGroups.has(key)) familyGroups.set(key, []);
      familyGroups.get(key)!.push(id);
    } else {
      orphans.push(id);
    }
  }

  const orderedFamKeys = Array.from(familyGroups.keys()).sort();

  const placeWithSpouses = (id: string) => {
    if (placed.has(id)) return;
    placed.add(id);
    result.push(id);
    const indi = data.individuals.get(id);
    if (!indi) return;
    for (const famId of indi.fams) {
      const fam = data.families.get(famId);
      if (!fam) continue;
      for (const sp of [fam.husb, fam.wife]) {
        if (sp && sp !== id && !placed.has(sp) && generation.get(sp) === generation.get(id)) {
          placed.add(sp);
          result.push(sp);
        }
      }
    }
  };

  for (const key of orderedFamKeys) {
    for (const id of familyGroups.get(key)!) {
      placeWithSpouses(id);
    }
  }
  for (const id of orphans) {
    placeWithSpouses(id);
  }
  // Anyone leftover
  for (const id of ids) placeWithSpouses(id);

  return result;
}

export const NODE_DIM = { w: NODE_W, h: NODE_H };
