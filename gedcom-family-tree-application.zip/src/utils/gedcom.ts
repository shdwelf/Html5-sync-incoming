// GEDCOM parser - supports GEDCOM 5.5 / 5.5.1 / 7.0 basics

export interface GedcomNode {
  level: number;
  xref?: string;
  tag: string;
  value: string;
  children: GedcomNode[];
  parent?: GedcomNode;
}

export interface Individual {
  id: string;
  name: string;
  givenName: string;
  surname: string;
  sex: "M" | "F" | "U";
  birth?: { date?: string; place?: string };
  death?: { date?: string; place?: string };
  famc: string[]; // families where this person is a child
  fams: string[]; // families where this person is a spouse
  notes: string[];
  occupation?: string;
}

export interface Family {
  id: string;
  husb?: string;
  wife?: string;
  children: string[];
  marriage?: { date?: string; place?: string };
}

export interface GedcomData {
  individuals: Map<string, Individual>;
  families: Map<string, Family>;
  header?: GedcomNode;
  source: string;
}

// Tokenize raw GEDCOM text into nodes
export function parseGedcom(text: string): GedcomNode[] {
  // Normalize line endings
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  const roots: GedcomNode[] = [];
  const stack: GedcomNode[] = [];

  for (let rawLine of lines) {
    const line = rawLine.replace(/^\uFEFF/, "").trimEnd();
    if (!line.trim()) continue;

    // GEDCOM line: LEVEL [XREF] TAG [VALUE]
    const m = line.match(/^(\d+)\s+(?:(@[^@]+@)\s+)?(\S+)(?:\s(.*))?$/);
    if (!m) continue;
    const level = parseInt(m[1], 10);
    const xref = m[2];
    const tag = m[3];
    const value = m[4] ?? "";

    const node: GedcomNode = {
      level,
      xref,
      tag,
      value,
      children: [],
    };

    // Handle CONT/CONC for multi-line values
    if ((tag === "CONT" || tag === "CONC") && stack.length > 0) {
      const parent = stack[stack.length - 1];
      // Find the actual data node at level-1 by walking up
      let target = parent;
      while (target && target.level >= level) {
        target = target.parent as GedcomNode;
      }
      if (target) {
        if (tag === "CONT") target.value += "\n" + value;
        else target.value += value;
      }
      continue;
    }

    // Pop stack until we find correct parent
    while (stack.length > 0 && stack[stack.length - 1].level >= level) {
      stack.pop();
    }

    if (stack.length === 0) {
      roots.push(node);
    } else {
      const parent = stack[stack.length - 1];
      node.parent = parent;
      parent.children.push(node);
    }
    stack.push(node);
  }

  return roots;
}

function findChild(node: GedcomNode, tag: string): GedcomNode | undefined {
  return node.children.find((c) => c.tag === tag);
}
function findChildren(node: GedcomNode, tag: string): GedcomNode[] {
  return node.children.filter((c) => c.tag === tag);
}

function parseEvent(node: GedcomNode): { date?: string; place?: string } {
  return {
    date: findChild(node, "DATE")?.value,
    place: findChild(node, "PLAC")?.value,
  };
}

function parseName(node: GedcomNode): { full: string; given: string; surname: string } {
  // NAME line can be "Given /Surname/ suffix"
  const raw = node.value || "";
  const surnameMatch = raw.match(/\/([^/]*)\//);
  const surname = surnameMatch ? surnameMatch[1].trim() : findChild(node, "SURN")?.value || "";
  const given = raw.replace(/\/[^/]*\//, "").trim() || findChild(node, "GIVN")?.value || "";
  const full = raw.replace(/\//g, "").replace(/\s+/g, " ").trim() || `${given} ${surname}`.trim();
  return { full, given, surname };
}

export function buildGedcomData(text: string): GedcomData {
  const roots = parseGedcom(text);
  const individuals = new Map<string, Individual>();
  const families = new Map<string, Family>();
  let header: GedcomNode | undefined;

  for (const node of roots) {
    if (node.tag === "HEAD") header = node;
    if (!node.xref) continue;

    if (node.tag === "INDI") {
      const nameNode = findChild(node, "NAME");
      const { full, given, surname } = nameNode
        ? parseName(nameNode)
        : { full: "Unknown", given: "", surname: "" };
      const sexVal = (findChild(node, "SEX")?.value || "U").toUpperCase();
      const birth = findChild(node, "BIRT");
      const death = findChild(node, "DEAT");
      const occu = findChild(node, "OCCU")?.value;
      const notes = findChildren(node, "NOTE").map((n) => n.value);

      individuals.set(node.xref, {
        id: node.xref,
        name: full || "Unknown",
        givenName: given,
        surname,
        sex: (sexVal === "M" || sexVal === "F" ? sexVal : "U") as "M" | "F" | "U",
        birth: birth ? parseEvent(birth) : undefined,
        death: death ? parseEvent(death) : undefined,
        famc: findChildren(node, "FAMC").map((n) => n.value),
        fams: findChildren(node, "FAMS").map((n) => n.value),
        notes,
        occupation: occu,
      });
    } else if (node.tag === "FAM") {
      const marr = findChild(node, "MARR");
      families.set(node.xref, {
        id: node.xref,
        husb: findChild(node, "HUSB")?.value,
        wife: findChild(node, "WIFE")?.value,
        children: findChildren(node, "CHIL").map((n) => n.value),
        marriage: marr ? parseEvent(marr) : undefined,
      });
    }
  }

  return { individuals, families, header, source: text };
}

// Merge multiple GEDCOM data sets (for multipart files)
export function mergeGedcomData(parts: GedcomData[]): GedcomData {
  const individuals = new Map<string, Individual>();
  const families = new Map<string, Family>();
  let combinedSource = "";

  for (const part of parts) {
    combinedSource += part.source + "\n";
    for (const [id, indi] of part.individuals) {
      const existing = individuals.get(id);
      if (existing) {
        individuals.set(id, mergeIndividual(existing, indi));
      } else {
        individuals.set(id, { ...indi, famc: [...indi.famc], fams: [...indi.fams] });
      }
    }
    for (const [id, fam] of part.families) {
      const existing = families.get(id);
      if (existing) {
        families.set(id, mergeFamily(existing, fam));
      } else {
        families.set(id, { ...fam, children: [...fam.children] });
      }
    }
  }

  return { individuals, families, source: combinedSource };
}

function mergeIndividual(a: Individual, b: Individual): Individual {
  return {
    id: a.id,
    name: a.name || b.name,
    givenName: a.givenName || b.givenName,
    surname: a.surname || b.surname,
    sex: a.sex !== "U" ? a.sex : b.sex,
    birth: a.birth || b.birth,
    death: a.death || b.death,
    famc: Array.from(new Set([...a.famc, ...b.famc])),
    fams: Array.from(new Set([...a.fams, ...b.fams])),
    notes: Array.from(new Set([...a.notes, ...b.notes])),
    occupation: a.occupation || b.occupation,
  };
}

function mergeFamily(a: Family, b: Family): Family {
  return {
    id: a.id,
    husb: a.husb || b.husb,
    wife: a.wife || b.wife,
    children: Array.from(new Set([...a.children, ...b.children])),
    marriage: a.marriage || b.marriage,
  };
}

// Detect if text looks like GEDCOM
export function looksLikeGedcom(text: string): boolean {
  const trimmed = text.trim();
  if (!trimmed) return false;
  // GEDCOM starts with "0 HEAD" or contains "0 @...@ INDI"
  return /^0\s+(HEAD|@[^@]+@)/m.test(trimmed) && /\b(INDI|FAM|GEDC)\b/.test(trimmed);
}

// Extract GEDCOM content from arbitrary text/HTML (for web scraping)
export function extractGedcom(text: string): string | null {
  // Try direct
  if (looksLikeGedcom(text)) return text;

  // Try to find embedded GEDCOM in HTML <pre> or <textarea>
  const blockRegex = /<(?:pre|textarea|code)[^>]*>([\s\S]*?)<\/(?:pre|textarea|code)>/gi;
  let m: RegExpExecArray | null;
  while ((m = blockRegex.exec(text)) !== null) {
    const decoded = decodeHtmlEntities(m[1]);
    if (looksLikeGedcom(decoded)) return decoded;
  }

  // Try to find a substring starting with "0 HEAD"
  const headIdx = text.indexOf("0 HEAD");
  if (headIdx !== -1) {
    const sub = text.slice(headIdx);
    if (looksLikeGedcom(sub)) {
      // Trim to last "0 TRLR" if present
      const trlIdx = sub.indexOf("0 TRLR");
      return trlIdx !== -1 ? sub.slice(0, trlIdx + 6) : sub;
    }
  }
  return null;
}

function decodeHtmlEntities(s: string): string {
  return s
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ");
}

export function formatLifeSpan(indi: Individual): string {
  const b = indi.birth?.date ? extractYear(indi.birth.date) : "";
  const d = indi.death?.date ? extractYear(indi.death.date) : "";
  if (!b && !d) return "";
  return `${b || "?"} – ${d || (indi.death ? "?" : "")}`;
}

function extractYear(date: string): string {
  const m = date.match(/\b(\d{3,4})\b/);
  return m ? m[1] : date;
}
