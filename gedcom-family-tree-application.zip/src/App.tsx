import { useEffect, useMemo, useState } from "react";
import InputPanel, { type SourcePart } from "./components/InputPanel";
import FamilyTree from "./components/FamilyTree";
import PersonDetails from "./components/PersonDetails";
import {
  buildGedcomData,
  mergeGedcomData,
  extractGedcom,
  type GedcomData,
} from "./utils/gedcom";
import { SAMPLE_GEDCOM } from "./utils/sample";

export default function App() {
  const [parts, setParts] = useState<SourcePart[]>([]);
  const [data, setData] = useState<GedcomData | null>(null);
  const [rootId, setRootId] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  // Parse URL params for ?url= and ?gedcom= on load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlParam = params.get("url") || params.get("gedcom_url");
    const gedcomParam = params.get("gedcom");

    const autoLoad = async () => {
      const newParts: SourcePart[] = [];

      if (gedcomParam) {
        const extracted = extractGedcom(decodeURIComponent(gedcomParam));
        if (extracted) {
          newParts.push({
            id: `url-inline-${Date.now()}`,
            name: "URL parameter (inline)",
            text: extracted,
            source: "paste",
          });
        }
      }

      // Support multiple url params separated by comma
      if (urlParam) {
        const urls = urlParam.split(",").map((u) => u.trim()).filter(Boolean);
        for (const u of urls) {
          try {
            const proxies = [
              u,
              `https://corsproxy.io/?${encodeURIComponent(u)}`,
              `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
            ];
            let text = "";
            for (const p of proxies) {
              try {
                const r = await fetch(p);
                if (r.ok) {
                  text = await r.text();
                  if (text) break;
                }
              } catch {}
            }
            if (!text) continue;
            const extracted = extractGedcom(text);
            if (extracted) {
              newParts.push({
                id: `url-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                name: shortUrl(u),
                text: extracted,
                source: "url",
              });
            }
          } catch {}
        }
      }

      if (newParts.length > 0) {
        setParts(newParts);
        const merged = mergeGedcomData(newParts.map((p) => buildGedcomData(p.text)));
        loadData(merged);
        setStatusMsg(`Auto-loaded ${newParts.length} source(s) from URL params`);
      }
    };

    autoLoad();
  }, []);

  const loadData = (merged: GedcomData) => {
    setData(merged);
    // Pick the person with the most descendants as root, or first
    const root = pickRoot(merged);
    setRootId(root);
    setSelectedId(root);
  };

  const handleLoad = () => {
    if (parts.length === 0) return;
    const merged = mergeGedcomData(parts.map((p) => buildGedcomData(p.text)));
    loadData(merged);
    setStatusMsg(
      `Loaded ${merged.individuals.size} people, ${merged.families.size} families from ${parts.length} source(s)`
    );
    if (window.innerWidth < 1024) setSidebarOpen(false);
  };

  const handleLoadSample = () => {
    const samplePart: SourcePart = {
      id: `sample-${Date.now()}`,
      name: "Sample: Shakespeare family",
      text: SAMPLE_GEDCOM,
      source: "paste",
    };
    setParts([samplePart]);
    const merged = buildGedcomData(SAMPLE_GEDCOM);
    loadData(merged);
    setStatusMsg("Sample loaded — Shakespeare family tree");
  };

  const searchResults = useMemo(() => {
    if (!data || !search.trim()) return [];
    const q = search.toLowerCase();
    const results: { id: string; name: string }[] = [];
    for (const [id, p] of data.individuals) {
      if (p.name.toLowerCase().includes(q)) {
        results.push({ id, name: p.name });
        if (results.length >= 20) break;
      }
    }
    return results;
  }, [data, search]);

  const shareUrl = () => {
    const urls = parts.filter((p) => p.source === "url").map((p) => p.name);
    if (urls.length === 0) {
      alert("No URL-sourced parts to share. Add a URL source first.");
      return;
    }
    const u = new URL(window.location.href);
    u.searchParams.set("url", urls.join(","));
    navigator.clipboard.writeText(u.toString());
    setStatusMsg("Shareable URL copied to clipboard");
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100">
      {/* Sidebar */}
      <aside
        className={`flex h-full flex-col border-r border-slate-200 bg-white transition-all duration-300 ${
          sidebarOpen ? "w-80" : "w-0"
        } overflow-hidden`}
      >
        <div className="flex shrink-0 items-center gap-2 border-b border-slate-200 bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-3 text-white">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/20 text-lg">
            🌳
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-sm font-bold">GEDCOM Tree Visualizer</h1>
            <p className="truncate text-[10px] text-indigo-100">
              Clipboard · URL · Multipart
            </p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-4">
          <InputPanel
            parts={parts}
            onAddPart={(p) => setParts((prev) => [...prev, p])}
            onRemovePart={(id) => setParts((prev) => prev.filter((x) => x.id !== id))}
            onLoad={handleLoad}
            onClearAll={() => setParts([])}
            onLoadSample={handleLoadSample}
          />
        </div>

        {data && (
          <div className="shrink-0 border-t border-slate-200 bg-slate-50 px-4 py-3">
            <div className="mb-2 grid grid-cols-2 gap-2 text-center">
              <div className="rounded-lg bg-white px-2 py-1.5 shadow-sm">
                <div className="text-base font-bold text-indigo-600">{data.individuals.size}</div>
                <div className="text-[10px] uppercase tracking-wide text-slate-500">People</div>
              </div>
              <div className="rounded-lg bg-white px-2 py-1.5 shadow-sm">
                <div className="text-base font-bold text-emerald-600">{data.families.size}</div>
                <div className="text-[10px] uppercase tracking-wide text-slate-500">Families</div>
              </div>
            </div>
            <button
              onClick={shareUrl}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100"
            >
              🔗 Copy shareable URL
            </button>
          </div>
        )}
      </aside>

      {/* Main content */}
      <main className="relative flex flex-1 flex-col overflow-hidden">
        {/* Top bar */}
        <div className="flex shrink-0 items-center gap-3 border-b border-slate-200 bg-white px-4 py-2.5">
          <button
            onClick={() => setSidebarOpen((o) => !o)}
            className="rounded-lg p-2 text-slate-600 hover:bg-slate-100"
            title="Toggle sidebar"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>

          {data && (
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="Search people…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-slate-50 px-3 py-1.5 pl-8 text-sm focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-200"
              />
              <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400">
                🔍
              </span>
              {searchResults.length > 0 && (
                <ul className="absolute left-0 right-0 top-full z-20 mt-1 max-h-64 overflow-y-auto rounded-lg border border-slate-200 bg-white shadow-lg">
                  {searchResults.map((r) => (
                    <li key={r.id}>
                      <button
                        onClick={() => {
                          setRootId(r.id);
                          setSelectedId(r.id);
                          setDetailsOpen(true);
                          setSearch("");
                        }}
                        className="block w-full px-3 py-2 text-left text-sm hover:bg-indigo-50"
                      >
                        {r.name}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {statusMsg && (
            <div className="ml-auto truncate rounded-full bg-emerald-50 px-3 py-1 text-xs text-emerald-700">
              {statusMsg}
            </div>
          )}
        </div>

        {/* Canvas */}
        <div className="relative flex-1 overflow-hidden">
          {data && rootId ? (
            <FamilyTree
              data={data}
              rootId={rootId}
              selectedId={selectedId ?? undefined}
              onSelectPerson={(id) => {
                setSelectedId(id);
                setDetailsOpen(true);
              }}
            />
          ) : (
            <EmptyState onLoadSample={handleLoadSample} />
          )}

          {/* Details drawer */}
          {data && selectedId && detailsOpen && (
            <div className="absolute right-0 top-0 z-10 h-full w-80 border-l border-slate-200 bg-white shadow-xl">
              <PersonDetails
                data={data}
                personId={selectedId}
                onSelect={(id) => {
                  setSelectedId(id);
                  setRootId(id);
                }}
                onClose={() => setDetailsOpen(false)}
              />
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function EmptyState({ onLoadSample }: { onLoadSample: () => void }) {
  return (
    <div className="flex h-full items-center justify-center p-8">
      <div className="max-w-md space-y-5 text-center">
        <div className="mx-auto inline-flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-indigo-500 to-violet-600 text-4xl shadow-lg shadow-indigo-200">
          🌳
        </div>
        <h2 className="text-2xl font-bold text-slate-900">No tree loaded yet</h2>
        <p className="text-sm text-slate-600">
          Add GEDCOM data from one or more sources using the sidebar — paste from clipboard,
          fetch from a URL, upload a file, or paste manually. Multiple sources will be
          intelligently recombined into a single tree.
        </p>
        <div className="grid grid-cols-3 gap-2 text-center">
          <Feature icon="📋" label="Clipboard" />
          <Feature icon="🌐" label="URL scrape" />
          <Feature icon="🧩" label="Multipart" />
        </div>
        <button
          onClick={onLoadSample}
          className="rounded-lg bg-gradient-to-r from-indigo-500 to-violet-600 px-6 py-2.5 text-sm font-semibold text-white shadow-md transition hover:from-indigo-600 hover:to-violet-700"
        >
          Load sample tree →
        </button>
        <div className="text-xs text-slate-400">
          Tip: append <code className="rounded bg-slate-200 px-1">?url=https://...</code> to the URL to auto-load
        </div>
      </div>
    </div>
  );
}

function Feature({ icon, label }: { icon: string; label: string }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-2 py-3">
      <div className="text-xl">{icon}</div>
      <div className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
        {label}
      </div>
    </div>
  );
}

function pickRoot(data: GedcomData): string {
  // Find a person with the most descendants (rough heuristic)
  let bestId = "";
  let bestScore = -1;
  for (const [id, p] of data.individuals) {
    const score = p.fams.length * 3 + p.famc.length;
    if (score > bestScore) {
      bestScore = score;
      bestId = id;
    }
  }
  if (!bestId) {
    const first = data.individuals.keys().next();
    if (!first.done) bestId = first.value;
  }
  return bestId;
}

function shortUrl(url: string): string {
  try {
    const u = new URL(url);
    return u.hostname + u.pathname;
  } catch {
    return url;
  }
}
