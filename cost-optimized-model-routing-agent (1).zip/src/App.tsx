import { useCallback, useEffect, useRef, useState } from "react";
import { AccuracyPlot } from "./components/AccuracyPlot";
import { DecisionLog } from "./components/DecisionLog";
import { ModelCards } from "./components/ModelCards";
import { Pipeline } from "./components/Pipeline";
import { Playground } from "./components/Playground";
import { StatsBar } from "./components/StatsBar";
import { ThresholdControl } from "./components/ThresholdControl";
import { randomTask, routeTask, type RoutingDecision } from "./lib/router";

const MAX_LOG = 40;

export default function App() {
  const [decisions, setDecisions] = useState<RoutingDecision[]>([]);
  const [active, setActive] = useState<RoutingDecision | null>(null);
  const [threshold, setThreshold] = useState(0.78);
  const [running, setRunning] = useState(true);
  const timer = useRef<number | null>(null);

  const submitTask = useCallback(
    (prompt: string) => {
      const d = routeTask(prompt, threshold);
      setActive(d);
      setDecisions((prev) => {
        const next = [...prev, d];
        return next.length > MAX_LOG ? next.slice(next.length - MAX_LOG) : next;
      });
    },
    [threshold],
  );

  // Synthetic feed: a new task every 1.6–3.2s while running
  useEffect(() => {
    if (!running) return;
    const tick = () => {
      submitTask(randomTask());
      const delay = 1600 + Math.random() * 1600;
      timer.current = window.setTimeout(tick, delay);
    };
    // Kick off immediately
    tick();
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [running, submitTask]);

  const currentComplexity = active ? active.report.score : null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 antialiased">
      {/* Background grid + glow */}
      <div className="pointer-events-none fixed inset-0 -z-0 overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(148,163,184,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.6) 1px, transparent 1px)",
            backgroundSize: "48px 48px",
          }}
        />
        <div className="absolute left-1/2 top-0 h-[600px] w-[1000px] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-[400px] w-[700px] rounded-full bg-amber-500/5 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-[1400px] px-6 py-8">
        {/* Header */}
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400/30 to-emerald-400/20 ring-1 ring-white/10">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.8}
                className="h-5 w-5 text-cyan-300"
              >
                <path d="M4 6h4l2 4-2 4H4" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M14 6h6" strokeLinecap="round" />
                <path d="M14 10h6" strokeLinecap="round" />
                <path d="M14 14h4" strokeLinecap="round" />
                <path d="M14 18h6" strokeLinecap="round" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-mono text-xl font-semibold tracking-tight">
                  router<span className="text-cyan-400">/</span>agent
                </h1>
                <span className="rounded border border-emerald-400/30 bg-emerald-400/10 px-1.5 py-0.5 font-mono text-[10px] text-emerald-300">
                  LIVE
                </span>
              </div>
              <p className="mt-0.5 text-sm text-slate-400">
                Real-time cost-optimized routing between a local model and Fireworks AI.
                <span className="text-slate-500"> Routing intelligence wins, not raw compute.</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono text-[11px] text-slate-500">
            <span className="rounded border border-white/10 bg-white/[0.03] px-2 py-1">
              env: standardized
            </span>
            <span className="rounded border border-white/10 bg-white/[0.03] px-2 py-1">
              local · llama-3.2-3b
            </span>
            <span className="rounded border border-white/10 bg-white/[0.03] px-2 py-1">
              fireworks · llama-3.1-405b
            </span>
          </div>
        </header>

        {/* Threshold + run control */}
        <div className="mt-6">
          <ThresholdControl
            threshold={threshold}
            onChange={setThreshold}
            running={running}
            onToggle={() => setRunning((r) => !r)}
          />
        </div>

        {/* Stats */}
        <div className="mt-5">
          <StatsBar decisions={decisions} threshold={threshold} />
        </div>

        {/* Main grid */}
        <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-[1fr_340px]">
          {/* Left column */}
          <div className="space-y-5">
            <Pipeline active={active} />

            <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
              <ModelCards threshold={threshold} currentComplexity={currentComplexity} />
              <AccuracyPlot threshold={threshold} currentComplexity={currentComplexity} />
            </div>

            <Playground onSubmit={submitTask} lastDecision={active} />
          </div>

          {/* Right column: log */}
          <div className="lg:min-h-[640px] lg:[&>*]:h-full">
            <DecisionLog decisions={decisions} />
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-10 flex flex-wrap items-center justify-between gap-2 border-t border-white/5 pt-4 font-mono text-[11px] text-slate-600">
          <div>
            router/agent · every task scored on the same pipeline · decisions are deterministic given complexity & threshold
          </div>
          <div>
            cost = tokens × $3/1M (fireworks) · local = $0 · threshold ∈ [55%, 96%]
          </div>
        </footer>
      </div>
    </div>
  );
}
