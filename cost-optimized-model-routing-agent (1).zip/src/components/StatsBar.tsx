import { fmtPct, fmtUsd, type RoutingDecision } from "../lib/router";

interface Props {
  decisions: RoutingDecision[];
  threshold: number;
}

export function StatsBar({ decisions, threshold }: Props) {
  const total = decisions.length;
  const localCount = decisions.filter((d) => d.chosen === "local").length;
  const localPct = total ? localCount / total : 0;
  const costActual = decisions.reduce((s, d) => s + d.costUsd, 0);
  // Counterfactual: cost if everything went to Fireworks
  const costBaseline = decisions.reduce((s, d) => {
    const inT = d.report.estimatedInputTokens;
    const outT = d.report.estimatedOutputTokens;
    return s + (inT + outT) * 0.000003;
  }, 0);
  const saved = Math.max(0, costBaseline - costActual);
  const avgAcc =
    total ? decisions.reduce((s, d) => s + d.accuracyEstimate, 0) / total : 0;
  const meetsThreshold =
    total ? decisions.filter((d) => d.accuracyEstimate >= threshold).length / total : 0;

  const cards: { label: string; value: string; sub: string; tone: string }[] = [
    {
      label: "Tasks routed",
      value: total.toString(),
      sub: `${localCount} local · ${total - localCount} fireworks`,
      tone: "text-slate-100",
    },
    {
      label: "Routed locally",
      value: fmtPct(localPct),
      sub: "cheaper path taken when safe",
      tone: "text-emerald-300",
    },
    {
      label: "Est. accuracy",
      value: fmtPct(avgAcc),
      sub: `≥ ${fmtPct(threshold)} on ${fmtPct(meetsThreshold)} of tasks`,
      tone: "text-cyan-300",
    },
    {
      label: "Cost saved",
      value: fmtUsd(saved),
      sub: `vs. always-Fireworks (${fmtUsd(costBaseline)})`,
      tone: "text-amber-300",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {cards.map((c) => (
        <div
          key={c.label}
          className="rounded-lg border border-white/5 bg-white/[0.02] p-4 backdrop-blur"
        >
          <div className="text-[11px] uppercase tracking-[0.18em] text-slate-500">
            {c.label}
          </div>
          <div className={`mt-2 font-mono text-2xl font-semibold ${c.tone}`}>
            {c.value}
          </div>
          <div className="mt-1 text-xs text-slate-500">{c.sub}</div>
        </div>
      ))}
    </div>
  );
}
