import { MODELS, fmtPct } from "../lib/router";

interface Props {
  threshold: number;
  currentComplexity: number | null;
}

export function ModelCards({ threshold, currentComplexity }: Props) {
  const c = currentComplexity ?? 50;
  const localAcc = MODELS.local.accuracyAt(c);
  const fwAcc = MODELS.fireworks.accuracyAt(c);
  const localMeets = localAcc >= threshold;
  const fwMeets = fwAcc >= threshold;

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      <ModelCard
        tone="emerald"
        name={MODELS.local.name}
        tagline={MODELS.local.tagline}
        accuracy={localAcc}
        meets={localMeets}
        cost="$0.00 / task"
        latency="~90–400ms"
        threshold={threshold}
      />
      <ModelCard
        tone="amber"
        name={MODELS.fireworks.name}
        tagline={MODELS.fireworks.tagline}
        accuracy={fwAcc}
        meets={fwMeets}
        cost="$3 / 1M tok"
        latency="~420–1200ms"
        threshold={threshold}
      />
    </div>
  );
}

function ModelCard({
  tone,
  name,
  tagline,
  accuracy,
  meets,
  cost,
  latency,
  threshold,
}: {
  tone: "emerald" | "amber";
  name: string;
  tagline: string;
  accuracy: number;
  meets: boolean;
  cost: string;
  latency: string;
  threshold: number;
}) {
  const ring =
    tone === "emerald"
      ? meets
        ? "border-emerald-400/40 shadow-[0_0_30px_-10px_rgba(16,185,129,0.6)]"
        : "border-white/10"
      : meets
        ? "border-amber-400/40 shadow-[0_0_30px_-10px_rgba(251,191,36,0.55)]"
        : "border-white/10";
  const dot = tone === "emerald" ? "bg-emerald-400" : "bg-amber-400";
  const bar = tone === "emerald" ? "bg-emerald-400" : "bg-amber-400";
  const label = tone === "emerald" ? "text-emerald-300" : "text-amber-300";

  return (
    <div
      className={`relative overflow-hidden rounded-lg border bg-white/[0.02] p-4 transition ${ring}`}
    >
      <div className="flex items-center gap-2">
        <span className={`inline-block h-2 w-2 rounded-full ${dot} ${meets ? "animate-pulse" : "opacity-40"}`} />
        <div className={`text-[11px] font-medium uppercase tracking-[0.18em] ${label}`}>
          {meets ? "eligible" : "below threshold"}
        </div>
      </div>
      <div className="mt-3 font-semibold text-slate-100">{name}</div>
      <div className="text-xs text-slate-500">{tagline}</div>

      <div className="mt-4">
        <div className="flex items-baseline justify-between">
          <span className="text-[11px] uppercase tracking-wider text-slate-500">
            est. accuracy
          </span>
          <span className="font-mono text-sm text-slate-200">{fmtPct(accuracy)}</span>
        </div>
        <div className="relative mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-white/5">
          <div
            className={`absolute inset-y-0 left-0 ${bar}`}
            style={{ width: `${Math.round(accuracy * 100)}%` }}
          />
          {/* threshold tick */}
          <div
            className="absolute inset-y-0 w-px bg-rose-400/80"
            style={{ left: `${threshold * 100}%` }}
          />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
        <div>
          <div className="text-slate-500">cost</div>
          <div className="font-mono text-slate-200">{cost}</div>
        </div>
        <div>
          <div className="text-slate-500">latency</div>
          <div className="font-mono text-slate-200">{latency}</div>
        </div>
      </div>
    </div>
  );
}
