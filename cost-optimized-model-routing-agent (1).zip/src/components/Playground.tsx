import { useState } from "react";
import { MODELS, fmtPct, fmtUsd, type RoutingDecision } from "../lib/router";

interface Props {
  onSubmit: (prompt: string) => void;
  lastDecision: RoutingDecision | null;
}

const SUGGESTIONS = [
  "What's a haiku about autumn?",
  "Step-by-step: derive the quadratic formula.",
  "Implement Dijkstra's algorithm in Python.",
  "Summarize the Efficient Market Hypothesis.",
  "Draft a HIPAA compliance memo for an AI triage bot.",
];

export function Playground({ onSubmit, lastDecision }: Props) {
  const [value, setValue] = useState("");

  const handleSubmit = () => {
    const v = value.trim();
    if (!v) return;
    onSubmit(v);
    setValue("");
  };

  const d = lastDecision;
  const accent = d ? MODELS[d.chosen].accent : null;

  return (
    <div className="rounded-lg border border-white/5 bg-white/[0.02] p-5">
      <div className="flex items-center justify-between">
        <div className="text-[11px] font-medium uppercase tracking-[0.18em] text-slate-400">
          Playground
        </div>
        <div className="text-[11px] text-slate-500">
          Submit any prompt and watch the router decide.
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === "Enter") handleSubmit();
          }}
          rows={2}
          placeholder="Paste a prompt… (⌘/Ctrl+Enter to submit)"
          className="flex-1 resize-none rounded-md border border-white/10 bg-black/30 p-3 font-mono text-sm text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/40 focus:outline-none"
        />
        <button
          onClick={handleSubmit}
          className="rounded-md bg-cyan-400/90 px-4 font-medium text-slate-950 transition hover:bg-cyan-300 active:scale-[0.98]"
        >
          Route →
        </button>
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => setValue(s)}
            className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[11px] text-slate-400 transition hover:border-white/20 hover:text-slate-200"
          >
            {s}
          </button>
        ))}
      </div>

      {/* Last decision */}
      <div className="mt-4 rounded-md border border-white/5 bg-black/20 p-3">
        {!d && (
          <div className="font-mono text-xs text-slate-600">
            // no submission yet — try a prompt above
          </div>
        )}
        {d && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span
                className={`rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider ${
                  accent === "emerald"
                    ? "bg-emerald-400/20 text-emerald-300"
                    : "bg-amber-400/20 text-amber-300"
                }`}
              >
                → {d.chosen === "local" ? "LOCAL" : "FIREWORKS"}
              </span>
              <span className="font-mono text-[11px] text-slate-500">
                complexity {Math.round(d.report.score)}/100 · acc {fmtPct(d.accuracyEstimate)} · {fmtUsd(d.costUsd)} · {d.latencyMs}ms
              </span>
            </div>
            <div className="font-mono text-xs text-slate-400">{d.reason}</div>
          </div>
        )}
      </div>
    </div>
  );
}
