import { MODELS } from "../lib/router";

interface Props {
  threshold: number;
  currentComplexity: number | null;
}

// SVG plot of accuracy vs. complexity for both models, with threshold line
// and a marker for the current task.
export function AccuracyPlot({ threshold, currentComplexity }: Props) {
  const W = 360;
  const H = 160;
  const padL = 32;
  const padR = 12;
  const padT = 10;
  const padB = 22;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;

  const yMin = 0.5;
  const yMax = 1.0;

  const xToPx = (c: number) => padL + (c / 100) * innerW;
  const yToPx = (a: number) => padT + (1 - (a - yMin) / (yMax - yMin)) * innerH;

  const buildPath = (fn: (c: number) => number) => {
    const pts: string[] = [];
    for (let c = 0; c <= 100; c += 2) {
      const v = Math.max(yMin, Math.min(yMax, fn(c)));
      pts.push(`${c === 0 ? "M" : "L"} ${xToPx(c).toFixed(1)} ${yToPx(v).toFixed(1)}`);
    }
    return pts.join(" ");
  };

  const localPath = buildPath(MODELS.local.accuracyAt);
  const fwPath = buildPath(MODELS.fireworks.accuracyAt);

  const thresholdY = yToPx(Math.max(yMin, Math.min(yMax, threshold)));

  return (
    <div className="rounded-lg border border-white/5 bg-white/[0.02] p-4">
      <div className="flex items-center justify-between">
        <div className="text-[11px] font-medium uppercase tracking-[0.18em] text-slate-400">
          Routing surface
        </div>
        <div className="flex items-center gap-3 font-mono text-[10px] text-slate-500">
          <span className="flex items-center gap-1">
            <span className="inline-block h-0.5 w-3 bg-emerald-400" /> local
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block h-0.5 w-3 bg-amber-400" /> fireworks
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block h-0.5 w-3 border-t border-dashed border-rose-400/80" /> threshold
          </span>
        </div>
      </div>
      <div className="mt-2 text-[11px] text-slate-500">
        accuracy vs. task complexity — local is chosen wherever its curve sits above the threshold.
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} className="mt-3 w-full">
        {/* grid */}
        {[0, 25, 50, 75, 100].map((c) => (
          <g key={c}>
            <line
              x1={xToPx(c)}
              x2={xToPx(c)}
              y1={padT}
              y2={padT + innerH}
              stroke="rgba(255,255,255,0.04)"
            />
            <text
              x={xToPx(c)}
              y={H - 6}
              textAnchor="middle"
              className="fill-slate-600 font-mono text-[9px]"
            >
              {c}
            </text>
          </g>
        ))}
        {[0.5, 0.6, 0.7, 0.8, 0.9, 1.0].map((a) => (
          <g key={a}>
            <line
              x1={padL}
              x2={padL + innerW}
              y1={yToPx(a)}
              y2={yToPx(a)}
              stroke="rgba(255,255,255,0.04)"
            />
            <text
              x={padL - 6}
              y={yToPx(a) + 3}
              textAnchor="end"
              className="fill-slate-600 font-mono text-[9px]"
            >
              {Math.round(a * 100)}
            </text>
          </g>
        ))}

        {/* "cheap zone" fill: where local is above threshold */}
        {/* approximate: find complexity where local accuracy = threshold */}
        {(() => {
          let cutoff = 0;
          for (let c = 0; c <= 100; c++) {
            if (MODELS.local.accuracyAt(c) >= threshold) cutoff = c;
          }
          return (
            <rect
              x={xToPx(0)}
              y={padT}
              width={xToPx(cutoff) - xToPx(0)}
              height={innerH}
              fill="rgba(16,185,129,0.06)"
            />
          );
        })()}

        {/* threshold */}
        <line
          x1={padL}
          x2={padL + innerW}
          y1={thresholdY}
          y2={thresholdY}
          stroke="rgba(251,113,133,0.8)"
          strokeDasharray="3 3"
        />

        {/* curves */}
        <path d={fwPath} fill="none" stroke="rgb(251,191,36)" strokeWidth={1.6} />
        <path d={localPath} fill="none" stroke="rgb(52,211,153)" strokeWidth={1.6} />

        {/* current task marker */}
        {currentComplexity != null && (
          <g>
            <line
              x1={xToPx(currentComplexity)}
              x2={xToPx(currentComplexity)}
              y1={padT}
              y2={padT + innerH}
              stroke="rgba(34,211,238,0.6)"
              strokeWidth={1}
            />
            <circle
              cx={xToPx(currentComplexity)}
              cy={yToPx(MODELS.local.accuracyAt(currentComplexity))}
              r={3.5}
              fill="rgb(52,211,153)"
            />
            <circle
              cx={xToPx(currentComplexity)}
              cy={yToPx(MODELS.fireworks.accuracyAt(currentComplexity))}
              r={3.5}
              fill="rgb(251,191,36)"
            />
          </g>
        )}

        {/* axis label */}
        <text
          x={padL + innerW / 2}
          y={H - 0}
          textAnchor="middle"
          className="fill-slate-600 font-mono text-[9px]"
        >
          complexity →
        </text>
      </svg>
    </div>
  );
}
