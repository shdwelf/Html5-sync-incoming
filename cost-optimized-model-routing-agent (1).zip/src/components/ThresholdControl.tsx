import { fmtPct } from "../lib/router";

interface Props {
  threshold: number;
  onChange: (v: number) => void;
  running: boolean;
  onToggle: () => void;
}

export function ThresholdControl({ threshold, onChange, running, onToggle }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-4 rounded-lg border border-white/5 bg-white/[0.02] p-4">
      <div className="min-w-[140px]">
        <div className="text-[11px] uppercase tracking-[0.18em] text-slate-500">
          Accuracy threshold
        </div>
        <div className="mt-1 font-mono text-xl text-slate-100">
          {fmtPct(threshold)}
        </div>
        <div className="text-[11px] text-slate-500">
          Lower = more local traffic · Higher = more Fireworks
        </div>
      </div>

      <div className="min-w-[220px] flex-1">
        <input
          type="range"
          min={0.55}
          max={0.96}
          step={0.01}
          value={threshold}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="w-full accent-cyan-400"
        />
        <div className="mt-1 flex justify-between font-mono text-[10px] text-slate-500">
          <span>55% cheap-first</span>
          <span>96% accuracy-first</span>
        </div>
      </div>

      <button
        onClick={onToggle}
        className={`rounded-md px-4 py-2 font-mono text-xs uppercase tracking-wider transition ${
          running
            ? "bg-rose-500/15 text-rose-300 hover:bg-rose-500/25"
            : "bg-emerald-400/15 text-emerald-300 hover:bg-emerald-400/25"
        }`}
      >
        {running ? "◼ Pause feed" : "▶ Start feed"}
      </button>
    </div>
  );
}
