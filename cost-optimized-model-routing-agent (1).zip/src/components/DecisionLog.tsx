import { MODELS, fmtPct, fmtUsd, type RoutingDecision } from "../lib/router";

interface Props {
  decisions: RoutingDecision[];
}

export function DecisionLog({ decisions }: Props) {
  return (
    <div className="flex h-full flex-col rounded-lg border border-white/5 bg-white/[0.02]">
      <div className="flex items-center justify-between border-b border-white/5 p-4">
        <div className="text-[11px] font-medium uppercase tracking-[0.18em] text-slate-400">
          Decision log
        </div>
        <div className="font-mono text-[11px] text-slate-500">
          last {decisions.length}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {decisions.length === 0 && (
          <div className="p-4 font-mono text-xs text-slate-600">
            // awaiting first task…
          </div>
        )}
        <ul className="divide-y divide-white/5">
          {decisions
            .slice()
            .reverse()
            .map((d) => {
              const accent = MODELS[d.chosen].accent;
              const pill =
                accent === "emerald"
                  ? "bg-emerald-400/15 text-emerald-300"
                  : "bg-amber-400/15 text-amber-300";
              return (
                <li key={d.id} className="p-3 transition hover:bg-white/[0.02]">
                  <div className="flex items-start gap-2">
                    <span
                      className={`mt-0.5 inline-flex shrink-0 rounded px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider ${pill}`}
                    >
                      {d.chosen === "local" ? "LOC" : "FW"}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="line-clamp-2 font-mono text-xs text-slate-300">
                        {d.prompt}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 font-mono text-[10px] text-slate-500">
                        <span>c {Math.round(d.report.score)}</span>
                        <span>acc {fmtPct(d.accuracyEstimate)}</span>
                        <span>{fmtUsd(d.costUsd)}</span>
                        <span>{d.latencyMs}ms</span>
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
        </ul>
      </div>
    </div>
  );
}
