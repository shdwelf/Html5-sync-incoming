import { useEffect, useState } from "react";
import { MODELS, fmtPct, fmtUsd, type RoutingDecision } from "../lib/router";

interface Props {
  active: RoutingDecision | null;
}

const STAGES = [
  { key: "ingest", label: "INGEST" },
  { key: "score", label: "SCORE" },
  { key: "route", label: "ROUTE" },
  { key: "exec", label: "EXECUTE" },
] as const;

export function Pipeline({ active }: Props) {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    if (!active) {
      setStage(0);
      return;
    }
    setStage(0);
    const t1 = setTimeout(() => setStage(1), 180);
    const t2 = setTimeout(() => setStage(2), 380);
    const t3 = setTimeout(() => setStage(3), 620);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [active?.id]);

  const accent = active ? MODELS[active.chosen].accent : "slate";
  const glow =
    accent === "emerald"
      ? "shadow-[0_0_40px_-8px_rgba(16,185,129,0.7)]"
      : accent === "amber"
        ? "shadow-[0_0_40px_-8px_rgba(251,191,36,0.6)]"
        : "";

  return (
    <div
      className={`rounded-lg border border-white/5 bg-white/[0.02] p-5 transition ${glow}`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-cyan-400" />
          </span>
          <span className="text-[11px] font-medium uppercase tracking-[0.18em] text-slate-400">
            Live pipeline
          </span>
        </div>
        <div className="font-mono text-[11px] text-slate-500">
          {active ? active.id : "awaiting task"}
        </div>
      </div>

      {/* Stages */}
      <div className="mt-5 grid grid-cols-4 gap-2">
        {STAGES.map((s, i) => {
          const done = active && stage >= i;
          const current = active && stage === i;
          const barBg = done
            ? accent === "emerald"
              ? "bg-emerald-400/80"
              : "bg-amber-400/80"
            : "bg-white/5";
          return (
            <div key={s.key} className="flex flex-col items-start">
              <div className={`mb-1 text-[10px] tracking-[0.18em] ${current ? "text-slate-100" : "text-slate-500"}`}>
                {s.label}
              </div>
              <div className="relative h-1 w-full overflow-hidden rounded-full bg-white/5">
                <div
                  className={`absolute inset-y-0 left-0 transition-all duration-200 ${barBg}`}
                  style={{ width: done ? "100%" : "0%" }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Detail */}
      <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-[1.4fr_1fr]">
        <div className="min-w-0">
          <div className="text-[11px] uppercase tracking-[0.18em] text-slate-500">
            Task
          </div>
          <div className="mt-1 line-clamp-3 min-h-[3.75rem] font-mono text-sm text-slate-200">
            {active ? `"${active.prompt}"` : "—"}
          </div>
          {active && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {active.report.tags.slice(0, 5).map((t) => (
                <span
                  key={t.tag}
                  className="rounded border border-white/10 bg-white/[0.03] px-1.5 py-0.5 font-mono text-[10px] text-slate-400"
                >
                  {t.tag}
                  {t.weight > 0 && <span className="ml-1 text-emerald-400">+{t.weight}</span>}
                  {t.weight < 0 && <span className="ml-1 text-rose-400">{t.weight}</span>}
                </span>
              ))}
              {active.report.tags.length === 0 && (
                <span className="rounded border border-white/10 bg-white/[0.03] px-1.5 py-0.5 font-mono text-[10px] text-slate-400">
                  general
                </span>
              )}
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <Stat label="complexity" value={active ? `${Math.round(active.report.score)}/100` : "—"} />
          <Stat label="threshold" value={active ? fmtPct(active.threshold) : "—"} />
          <Stat label="chosen acc." value={active ? fmtPct(active.accuracyEstimate) : "—"} />
          <Stat label="cost" value={active ? fmtUsd(active.costUsd) : "—"} />
          <Stat label="latency" value={active ? `${active.latencyMs}ms` : "—"} />
          <Stat
            label="decision"
            value={
              active ? (
                <span className={accent === "emerald" ? "text-emerald-300" : "text-amber-300"}>
                  {active.chosen === "local" ? "LOCAL" : "FIREWORKS"}
                </span>
              ) : (
                "—"
              )
            }
          />
        </div>
      </div>

      {active && (
        <div className="mt-4 rounded border border-white/5 bg-black/20 p-3 font-mono text-[11px] leading-relaxed text-slate-400">
          <span className="text-slate-600">// reason</span>
          <br />
          {active.reason}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded border border-white/5 bg-black/20 p-2">
      <div className="text-[10px] uppercase tracking-[0.14em] text-slate-500">
        {label}
      </div>
      <div className="mt-0.5 font-mono text-sm text-slate-100">{value}</div>
    </div>
  );
}
