// Routing engine: scores task complexity and picks the cheapest model
// that still meets the user's accuracy threshold.

export type ModelId = "local" | "fireworks";

export interface ModelSpec {
  id: ModelId;
  name: string;
  tagline: string;
  // accuracy as a function of complexity (0..100) -> 0..1
  accuracyAt: (complexity: number) => number;
  // cost per task in USD (rough)
  costForTokens: (inputTokens: number, outputTokens: number) => number;
  // latency in ms as a function of output tokens
  latencyMs: (outputTokens: number) => number;
  accent: string; // tailwind class fragment
}

export const MODELS: Record<ModelId, ModelSpec> = {
  local: {
    id: "local",
    name: "Local · Llama-3.2-3B",
    tagline: "On-device, zero per-token cost",
    accuracyAt: (c) => {
      // Graceful degradation: ~0.94 at c=0, ~0.58 at c=100
      const x = c / 100;
      return 0.94 - 0.36 * Math.pow(x, 1.35);
    },
    costForTokens: () => 0,
    latencyMs: (out) => 90 + out * 6,
    accent: "emerald",
  },
  fireworks: {
    id: "fireworks",
    name: "Fireworks · Llama-3.1-405B",
    tagline: "Frontier-class, metered API",
    accuracyAt: (c) => {
      // High, slow decline: ~0.98 at c=0, ~0.86 at c=100
      const x = c / 100;
      return 0.98 - 0.12 * Math.pow(x, 1.6);
    },
    // $3 / 1M in, $3 / 1M out  -> $0.000003 per token
    costForTokens: (inT, outT) => (inT + outT) * 0.000003,
    latencyMs: (out) => 420 + out * 18,
    accent: "amber",
  },
};

// --- Complexity features ---------------------------------------------------

const PATTERNS: { re: RegExp; weight: number; tag: string }[] = [
  { re: /\b(step[- ]by[- ]step|chain[- ]of[- ]thought|reasoning)\b/i, weight: 18, tag: "reasoning" },
  { re: /\b(explain why|justify|prove|derive|deduce)\b/i, weight: 16, tag: "reasoning" },
  { re: /\b(compare|contrast|trade[- ]?offs|pros and cons|versus)\b/i, weight: 12, tag: "analysis" },
  { re: /\b(analyze|evaluate|critique|assess)\b/i, weight: 10, tag: "analysis" },
  { re: /\b(write|implement|debug|refactor|optimize)\s+(a|the|some)?\s*(code|function|class|algorithm|script|program)/i, weight: 22, tag: "code" },
  { re: /```|function\s+\w+\s*\(|=>\s*{|import\s+\w+|def\s+\w+\(/, weight: 18, tag: "code" },
  { re: /\b(calculate|compute|solve|differentiate|integrate)\b/i, weight: 18, tag: "math" },
  { re: /\d+\s*[+\-*/^]\s*\d+/, weight: 8, tag: "math" },
  { re: /\b(legal|medical|clinical|financial|tax|regulatory|compliance)\b/i, weight: 14, tag: "domain" },
  { re: /\b(translate|in|to)\s+(french|spanish|german|japanese|mandarin|chinese|korean|russian)\b/i, weight: 12, tag: "translation" },
  { re: /\b(story|poem|novel|screenplay|lyrics)\b/i, weight: 6, tag: "creative" },
  { re: /\b(summarize|tl;dr|bullet points|in brief)\b/i, weight: -6, tag: "simple" },
  { re: /\b(what is|define|meaning of)\b/i, weight: -4, tag: "simple" },
  { re: /\?/, weight: 1, tag: "question" },
];

export interface ComplexityReport {
  score: number; // 0..100
  lengthScore: number;
  patternScore: number;
  tags: { tag: string; weight: number }[];
  estimatedInputTokens: number;
  estimatedOutputTokens: number;
}

export function scoreComplexity(prompt: string): ComplexityReport {
  const text = prompt.trim();
  const words = text.split(/\s+/).filter(Boolean);
  const chars = text.length;

  // Token estimate (rough: 1 token ~ 4 chars, floor 8, cap 2048)
  const estimatedInputTokens = Math.max(8, Math.min(2048, Math.round(chars / 4)));
  // Output scales with complexity and request verbosity
  const baseOut = 80 + words.length * 3;

  // Length contribution: 0..25
  const lengthScore = Math.min(25, (words.length / 120) * 25);

  // Pattern contribution (additive, capped)
  let patternScore = 0;
  const tags: { tag: string; weight: number }[] = [];
  for (const p of PATTERNS) {
    const m = text.match(p.re);
    if (m) {
      patternScore += p.weight;
      tags.push({ tag: p.tag, weight: p.weight });
    }
  }
  patternScore = Math.max(-10, Math.min(75, patternScore));

  const raw = lengthScore + patternScore;
  const score = Math.max(0, Math.min(100, raw));

  // Scale output tokens by complexity (complex answers are longer)
  const estimatedOutputTokens = Math.round(baseOut * (1 + score / 120));

  return {
    score,
    lengthScore,
    patternScore,
    tags,
    estimatedInputTokens,
    estimatedOutputTokens,
  };
}

// --- Routing decision ------------------------------------------------------

export interface RoutingDecision {
  id: string;
  prompt: string;
  report: ComplexityReport;
  chosen: ModelId;
  reason: string;
  accuracyEstimate: number; // for chosen model
  droppedModelAccuracy: number; // for the non-chosen model
  threshold: number;
  costUsd: number;
  latencyMs: number;
  timestamp: number;
}

export function routeTask(
  prompt: string,
  threshold: number,
  rng: () => number = Math.random,
): RoutingDecision {
  const report = scoreComplexity(prompt);
  const c = report.score;

  const localAcc = MODELS.local.accuracyAt(c);
  const fwAcc = MODELS.fireworks.accuracyAt(c);

  // Pick cheapest that meets threshold; if neither meets, pick higher accuracy.
  let chosen: ModelId;
  let reason: string;

  const localMeets = localAcc >= threshold;
  const fwMeets = fwAcc >= threshold;

  if (localMeets) {
    chosen = "local";
    reason = `Local accuracy ${fmtPct(localAcc)} ≥ threshold ${fmtPct(threshold)} — $0.00 wins.`;
  } else if (fwMeets) {
    chosen = "fireworks";
    reason = `Local ${fmtPct(localAcc)} falls below threshold ${fmtPct(threshold)}; Fireworks ${fmtPct(fwAcc)} clears it.`;
  } else {
    // Neither clears — pick the more accurate one to minimize damage.
    chosen = fwAcc >= localAcc ? "fireworks" : "local";
    reason = `Neither model clears ${fmtPct(threshold)}; picked ${chosen} for higher accuracy (${fmtPct(chosen === "local" ? localAcc : fwAcc)}).`;
  }

  const spec = MODELS[chosen];
  const dropped = chosen === "local" ? fwAcc : localAcc;
  const costUsd = spec.costForTokens(report.estimatedInputTokens, report.estimatedOutputTokens);
  // Add a tiny jitter so latency feels live
  const latencyMs = Math.round(spec.latencyMs(report.estimatedOutputTokens) * (0.9 + rng() * 0.25));

  return {
    id: `t_${Date.now().toString(36)}_${Math.floor(rng() * 1e6).toString(36)}`,
    prompt,
    report,
    chosen,
    reason,
    accuracyEstimate: chosen === "local" ? localAcc : fwAcc,
    droppedModelAccuracy: dropped,
    threshold,
    costUsd,
    latencyMs,
    timestamp: Date.now(),
  };
}

export function fmtPct(x: number): string {
  return `${(x * 100).toFixed(1)}%`;
}

export function fmtUsd(x: number): string {
  if (x === 0) return "$0.00";
  if (x < 0.0001) return `$${(x * 1_000_000).toFixed(2)}µ`;
  if (x < 0.01) return `$${(x * 1000).toFixed(3)}m`;
  return `$${x.toFixed(4)}`;
}

// --- Synthetic workload ----------------------------------------------------

const SYNTHETIC_TASKS: string[] = [
  "What is the capital of Mongolia?",
  "Summarize the plot of Inception in three bullet points.",
  "Write a haiku about autumn rain.",
  "Define entropy in plain language.",
  "Translate 'The meeting is postponed until Friday' into Japanese.",
  "Compare React Server Components with traditional client rendering.",
  "Implement a function in Python that detects cycles in a directed graph using DFS.",
  "Debug why this useEffect runs twice on mount in strict mode.",
  "Step-by-step: derive the quadratic formula from ax² + bx + c = 0.",
  "Calculate the integral of sin(x)·e^x from 0 to π.",
  "Analyze the trade-offs of microservices vs. a monolith for a 20-person startup.",
  "Evaluate the legal risks of scraping publicly-available LinkedIn profiles under the CFAA.",
  "Explain why transformers use multi-head attention instead of a single attention head.",
  "Draft a compliance memo on HIPAA considerations for an AI chatbot in clinical triage.",
  "Optimize this SQL query that joins 5 tables on a 200M row events table.",
  "Design an algorithm to schedule 14 nurses across 3 shifts with fairness constraints.",
  "TL;DR the key findings of the 2023 IPCC synthesis report.",
  "Refactor this React class component into hooks without changing behavior.",
  "Prove that the square root of 2 is irrational.",
  "Write a short noir scene set in a rainy Tokyo alley.",
  "List 5 quick vegetarian dinner recipes under 30 minutes.",
  "What's the difference between TCP and UDP, and when would you pick each?",
  "Critique the Efficient Market Hypothesis with three concrete counterexamples.",
  "Solve for x: 3^(2x-1) = 27.",
];

export function randomTask(rng: () => number = Math.random): string {
  return SYNTHETIC_TASKS[Math.floor(rng() * SYNTHETIC_TASKS.length)];
}
