import { useEffect, useMemo, useRef, useState } from "react";
import {
  ACCESSORIES,
  AccessoryDef,
  Category,
  oneInN,
  probability,
  rarityTier,
} from "./data/accessories";
import { FoundMonkey, Miner } from "./lib/miner";

const CATEGORY_LABEL: Record<Category, string> = {
  misc: "Misc / Items",
  hat: "Hats",
  glasses: "Glasses",
  mouth: "Mouth",
  shirt_and_pants: "Shirt & Pants",
  shoes: "Shoes",
  tail: "Tail",
};

const CATEGORY_ORDER: Category[] = [
  "misc",
  "hat",
  "glasses",
  "mouth",
  "shirt_and_pants",
  "shoes",
  "tail",
];

const STORAGE_KEY = "monkey-miner-state-v1";

interface PersistedState {
  filterIds: string[];
  matchMode: "any" | "all";
  concurrency: number;
  accountsPerSeed: number;
}

function loadState(): PersistedState {
  try {
    const s = localStorage.getItem(STORAGE_KEY);
    if (s) return JSON.parse(s);
  } catch {/* ignore */}
  return {
    filterIds: ["flamethrower"],
    matchMode: "any",
    concurrency: 6,
    accountsPerSeed: 16,
  };
}

function saveState(s: PersistedState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {/* ignore */}
}

export default function App() {
  const initial = loadState();
  const [filterIds, setFilterIds] = useState<Set<string>>(new Set(initial.filterIds));
  const [matchMode, setMatchMode] = useState<"any" | "all">(initial.matchMode);
  const [concurrency, setConcurrency] = useState(initial.concurrency);
  const [accountsPerSeed, setAccountsPerSeed] = useState(initial.accountsPerSeed);

  const [running, setRunning] = useState(false);
  const [checked, setChecked] = useState(0);
  const [found, setFound] = useState<FoundMonkey[]>([]);
  const [errors, setErrors] = useState(0);
  const [lastError, setLastError] = useState<string | null>(null);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);

  const minerRef = useRef<Miner | null>(null);

  useEffect(() => {
    saveState({
      filterIds: Array.from(filterIds),
      matchMode,
      concurrency,
      accountsPerSeed,
    });
  }, [filterIds, matchMode, concurrency, accountsPerSeed]);

  // tick for rate display
  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, [running]);

  function toggle(id: string) {
    setFilterIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function start() {
    if (filterIds.size === 0) {
      setLastError("Select at least one target attribute to mine for.");
      return;
    }
    setLastError(null);
    setStartedAt(Date.now());
    const miner = new Miner(
      {
        concurrency,
        accountsPerSeed,
        filterIds: Array.from(filterIds),
        matchMode,
      },
      {
        onChecked: (c) => setChecked(c),
        onFound: (m) => {
          setFound((prev) => [m, ...prev].slice(0, 200));
        },
        onError: (e) => {
          setErrors((n) => n + 1);
          const msg = e instanceof Error ? e.message : String(e);
          setLastError(msg);
        },
      }
    );
    minerRef.current = miner;
    miner.start();
    setRunning(true);
  }

  function stop() {
    minerRef.current?.stop();
    minerRef.current = null;
    setRunning(false);
  }

  function clearResults() {
    setFound([]);
    setChecked(0);
    setErrors(0);
    setLastError(null);
    setStartedAt(null);
    setSelectedIdx(null);
  }

  useEffect(() => () => minerRef.current?.stop(), []);

  // Apply live config updates while running
  useEffect(() => {
    minerRef.current?.setConfig({
      filterIds: Array.from(filterIds),
      matchMode,
    });
  }, [filterIds, matchMode]);

  const grouped = useMemo(() => {
    const g: Record<Category, AccessoryDef[]> = {
      misc: [], hat: [], glasses: [], mouth: [],
      shirt_and_pants: [], shoes: [], tail: [],
    };
    for (const a of ACCESSORIES) g[a.category].push(a);
    for (const cat of CATEGORY_ORDER) {
      g[cat].sort((a, b) => probability(a) - probability(b));
    }
    return g;
  }, []);

  const elapsed = startedAt ? (now - startedAt) / 1000 : 0;
  const rate = elapsed > 0 ? checked / elapsed : 0;

  // Combined probability of a single random monkey matching the current filter
  const combinedP = useMemo(() => {
    const targets = ACCESSORIES.filter((a) => filterIds.has(a.id));
    if (targets.length === 0) return 0;
    if (matchMode === "any") {
      // approx: 1 - product(1 - p_i)
      let q = 1;
      for (const t of targets) q *= 1 - probability(t);
      return 1 - q;
    } else {
      // multiplicative independence approximation
      let p = 1;
      for (const t of targets) p *= probability(t);
      return p;
    }
  }, [filterIds, matchMode]);

  const expectedSeconds = combinedP > 0 && rate > 0 ? 1 / combinedP / rate : Infinity;

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-amber-50 to-orange-50 text-stone-900">
      <Banner />

      <div className="max-w-7xl mx-auto px-4 pb-24">
        {/* Stats bar */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 -mt-10 mb-6 relative z-10">
          <StatCard label="Status" value={running ? "Mining…" : "Idle"} accent={running ? "bg-emerald-500" : "bg-stone-400"} />
          <StatCard label="Checked" value={checked.toLocaleString()} hint={running ? `${rate.toFixed(1)}/s` : undefined} />
          <StatCard label="Found" value={found.length.toString()} hint={errors > 0 ? `${errors} errors` : undefined} />
          <StatCard label="Target chance" value={combinedP > 0 ? `1 in ${Math.round(1 / combinedP).toLocaleString()}` : "—"} />
          <StatCard
            label="ETA / hit"
            value={
              isFinite(expectedSeconds) && expectedSeconds > 0
                ? formatDuration(expectedSeconds)
                : "—"
            }
          />
        </div>

        <div className="grid lg:grid-cols-[360px_1fr] gap-6">
          {/* CONTROL PANEL */}
          <aside className="space-y-4">
            <div className="bg-white rounded-2xl shadow-sm border border-amber-100 p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-stone-800">Mining controls</h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                  {filterIds.size} target{filterIds.size === 1 ? "" : "s"}
                </span>
              </div>

              <div className="flex gap-2 mb-3">
                {!running ? (
                  <button
                    onClick={start}
                    className="flex-1 bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-500 hover:to-amber-600 text-white font-bold py-3 rounded-xl shadow transition active:scale-[0.98]"
                  >
                    ⛏️ Start Mining
                  </button>
                ) : (
                  <button
                    onClick={stop}
                    className="flex-1 bg-stone-800 hover:bg-stone-900 text-white font-bold py-3 rounded-xl shadow transition active:scale-[0.98]"
                  >
                    ■ Stop
                  </button>
                )}
                <button
                  onClick={clearResults}
                  className="px-3 py-3 rounded-xl border border-stone-200 hover:bg-stone-50 text-stone-600 transition"
                  title="Clear results"
                >
                  🗑
                </button>
              </div>

              <div className="space-y-3 text-sm">
                <div>
                  <label className="block text-stone-600 mb-1">Match mode</label>
                  <div className="grid grid-cols-2 gap-1 bg-stone-100 rounded-lg p-1">
                    <button
                      onClick={() => setMatchMode("any")}
                      className={`py-1.5 rounded-md transition ${
                        matchMode === "any" ? "bg-white shadow font-medium" : "text-stone-500"
                      }`}
                    >
                      Any selected
                    </button>
                    <button
                      onClick={() => setMatchMode("all")}
                      className={`py-1.5 rounded-md transition ${
                        matchMode === "all" ? "bg-white shadow font-medium" : "text-stone-500"
                      }`}
                    >
                      All selected
                    </button>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between">
                    <label className="text-stone-600">Concurrency</label>
                    <span className="font-medium">{concurrency}</span>
                  </div>
                  <input
                    type="range" min={1} max={16} value={concurrency}
                    onChange={(e) => setConcurrency(parseInt(e.target.value))}
                    disabled={running}
                    className="w-full accent-amber-500"
                  />
                  <p className="text-xs text-stone-400">Higher = faster, but be polite to the API.</p>
                </div>

                <div>
                  <div className="flex justify-between">
                    <label className="text-stone-600">Accounts per seed</label>
                    <span className="font-medium">{accountsPerSeed}</span>
                  </div>
                  <input
                    type="range" min={1} max={50} value={accountsPerSeed}
                    onChange={(e) => setAccountsPerSeed(parseInt(e.target.value))}
                    disabled={running}
                    className="w-full accent-amber-500"
                  />
                  <p className="text-xs text-stone-400">Kalium wallets support up to 50 accounts/seed.</p>
                </div>
              </div>

              {lastError && (
                <div className="mt-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg p-2">
                  ⚠ {lastError}
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-amber-100 p-4">
              <h2 className="font-semibold text-stone-800 mb-3">Quick targets</h2>
              <div className="flex flex-wrap gap-2">
                <QuickBtn onClick={() => setFilterIds(new Set(["flamethrower"]))}>🔥 Flamethrower only</QuickBtn>
                <QuickBtn onClick={() => setFilterIds(new Set(["jester"]))}>🤡 Jester</QuickBtn>
                <QuickBtn onClick={() => setFilterIds(new Set(["joint"]))}>🚬 Joint</QuickBtn>
                <QuickBtn onClick={() => setFilterIds(new Set(["crown"]))}>👑 Crown</QuickBtn>
                <QuickBtn
                  onClick={() =>
                    setFilterIds(
                      new Set(["flamethrower", "jester", "joint", "monocle", "crown"])
                    )
                  }
                >
                  💎 The Holy Grail
                </QuickBtn>
                <QuickBtn onClick={() => setFilterIds(new Set())}>Clear</QuickBtn>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-xs text-amber-900 leading-relaxed">
              <p className="font-semibold mb-1">💡 How it works</p>
              <p>
                Each "monkey" is a deterministic avatar generated from a Banano address.
                We generate random Kalium-compatible seeds, derive accounts and ask
                the MonKey API which accessories each address has. When one matches your
                filter, save the <em>seed</em> — that's what owns the wallet.
              </p>
            </div>
          </aside>

          {/* MAIN PANEL */}
          <main className="space-y-6">
            {/* Targets */}
            <div className="bg-white rounded-2xl shadow-sm border border-amber-100 p-4">
              <h2 className="font-semibold text-stone-800 mb-3">Pick attributes to mine for</h2>
              <div className="space-y-5">
                {CATEGORY_ORDER.map((cat) => (
                  <div key={cat}>
                    <h3 className="text-xs uppercase tracking-wider text-stone-400 mb-2">
                      {CATEGORY_LABEL[cat]}
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                      {grouped[cat].map((a) => {
                        const checkedT = filterIds.has(a.id);
                        const p = probability(a);
                        const tier = rarityTier(p);
                        return (
                          <button
                            key={a.id}
                            onClick={() => toggle(a.id)}
                            className={`relative text-left p-2 rounded-lg border transition group ${
                              checkedT
                                ? "border-amber-500 bg-amber-50 ring-2 ring-amber-300"
                                : "border-stone-200 bg-white hover:border-amber-300"
                            }`}
                          >
                            <div className="flex items-start gap-2">
                              <span className="text-lg">{a.emoji}</span>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-medium truncate">{a.name}</div>
                                <div className="text-[10px] text-stone-500">
                                  1 in {oneInN(a).toLocaleString()}
                                </div>
                              </div>
                            </div>
                            <span
                              className="absolute top-1 right-1 w-2 h-2 rounded-full"
                              style={{ background: tier.color }}
                              title={tier.label}
                            />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Results */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-stone-800">
                  Found MonKeys <span className="text-stone-400">({found.length})</span>
                </h2>
                {running && (
                  <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-1 rounded-full">
                    🟢 Live
                  </span>
                )}
              </div>

              {found.length === 0 ? (
                <div className="bg-white border border-dashed border-amber-300 rounded-2xl p-10 text-center text-stone-500">
                  {running ? (
                    <>
                      <div className="text-3xl mb-2">🐒</div>
                      <div>Hunting…</div>
                      <div className="text-xs mt-1">Found MonKeys will appear here.</div>
                    </>
                  ) : (
                    <>
                      <div className="text-3xl mb-2">🍌</div>
                      <div>Press <strong>Start Mining</strong> to begin.</div>
                    </>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
                  {found.map((m, i) => (
                    <MonkeyCard
                      key={m.id}
                      monkey={m}
                      onClick={() => setSelectedIdx(i)}
                    />
                  ))}
                </div>
              )}
            </div>
          </main>
        </div>
      </div>

      {selectedIdx !== null && found[selectedIdx] && (
        <DetailModal
          monkey={found[selectedIdx]}
          onClose={() => setSelectedIdx(null)}
        />
      )}

      <footer className="text-center text-xs text-stone-500 py-6">
        Not affiliated with Banano. Built with the public MonKey API at monkey.banano.cc.
        Generated seeds are random — back them up immediately if you intend to keep one.
      </footer>
    </div>
  );
}

function Banner() {
  return (
    <header className="bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-400 text-stone-900 pt-10 pb-20 px-4 shadow-inner">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">🍌</span>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight">
            MonKey Miner
          </h1>
          <span className="text-xs bg-stone-900/80 text-amber-100 px-2 py-1 rounded-full ml-2">
            HTML5
          </span>
        </div>
        <p className="text-stone-800/90 max-w-2xl">
          Generate Banano wallets and hunt for the rarest MonKey attributes —
          🔥 Flamethrower, 🤡 Jester Hat, 👑 Crown, 🚬 Joint, 🧐 Monocle and more.
        </p>
      </div>
    </header>
  );
}

function StatCard({
  label, value, hint, accent,
}: { label: string; value: string; hint?: string; accent?: string }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-amber-100 px-3 py-2.5 flex flex-col">
      <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-stone-500">
        {accent && <span className={`w-1.5 h-1.5 rounded-full ${accent}`} />}
        {label}
      </div>
      <div className="text-lg font-bold leading-tight">{value}</div>
      {hint && <div className="text-[11px] text-stone-400">{hint}</div>}
    </div>
  );
}

function QuickBtn({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="text-xs bg-stone-50 hover:bg-amber-50 border border-stone-200 hover:border-amber-300 px-2.5 py-1.5 rounded-full transition"
    >
      {children}
    </button>
  );
}

function MonkeyCard({ monkey, onClick }: { monkey: FoundMonkey; onClick: () => void }) {
  const tier = rarityTier(monkey.rarestProbability);
  const url = `https://monkey.banano.cc/api/v1/monkey/${monkey.address}?format=svg&background=true`;
  return (
    <button
      onClick={onClick}
      className="text-left bg-white rounded-2xl border border-amber-100 hover:border-amber-400 hover:shadow-lg transition overflow-hidden group"
    >
      <div className="relative aspect-square bg-gradient-to-br from-amber-50 to-orange-50">
        <img
          src={url}
          alt={monkey.address}
          loading="lazy"
          className="w-full h-full object-contain p-1 group-hover:scale-105 transition"
        />
        <span
          className="absolute top-2 left-2 text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full text-white shadow"
          style={{ background: tier.color }}
        >
          {tier.label}
        </span>
      </div>
      <div className="p-2.5">
        <div className="flex flex-wrap gap-1 mb-1.5">
          {monkey.matched.map((m) => (
            <span
              key={m.id}
              className="text-[11px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-full font-medium"
            >
              {m.emoji} {m.name}
            </span>
          ))}
        </div>
        <div className="text-[10px] text-stone-500 font-mono truncate">
          {monkey.address}
        </div>
        <div className="text-[10px] text-stone-400">idx {monkey.index}</div>
      </div>
    </button>
  );
}

function DetailModal({ monkey, onClose }: { monkey: FoundMonkey; onClose: () => void }) {
  const url = `https://monkey.banano.cc/api/v1/monkey/${monkey.address}?format=svg&background=true`;
  return (
    <div
      className="fixed inset-0 bg-stone-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="grid sm:grid-cols-[260px_1fr]">
          <div className="bg-gradient-to-br from-amber-100 to-orange-100 aspect-square sm:aspect-auto sm:h-full flex items-center justify-center">
            <img src={url} alt={monkey.address} className="w-full h-full object-contain p-3" />
          </div>
          <div className="p-5 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-bold text-lg">Rare MonKey Found 🎉</h3>
                <div className="flex flex-wrap gap-1 mt-1">
                  {monkey.accessories.map((a) => (
                    <span
                      key={a.id}
                      className="text-xs bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full"
                    >
                      {a.emoji} {a.name}
                    </span>
                  ))}
                </div>
              </div>
              <button
                onClick={onClose}
                className="text-stone-400 hover:text-stone-700 text-2xl leading-none"
              >
                ×
              </button>
            </div>

            <Field label="Address" value={monkey.address} />
            <Field label="Seed (KEEP SAFE)" value={monkey.seed} secret />
            <Field label="Account index" value={String(monkey.index)} />
            <Field label="Private key" value={monkey.privateKey} secret />

            <div className="text-xs text-stone-500 pt-2 border-t border-stone-100">
              Import the seed in Kalium / Banano wallet to take ownership.
              <br />
              ⚠ Anyone with this seed controls the address. Don't share it.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, secret }: { label: string; value: string; secret?: boolean }) {
  const [show, setShow] = useState(!secret);
  const [copied, setCopied] = useState(false);
  const display = show ? value : value.replace(/./g, "•");
  return (
    <div>
      <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-stone-500 mb-1">
        <span>{label}</span>
        <div className="flex gap-2">
          {secret && (
            <button
              onClick={() => setShow((s) => !s)}
              className="hover:text-stone-800"
            >
              {show ? "hide" : "show"}
            </button>
          )}
          <button
            onClick={() => {
              navigator.clipboard.writeText(value);
              setCopied(true);
              setTimeout(() => setCopied(false), 1200);
            }}
            className="hover:text-stone-800"
          >
            {copied ? "✓ copied" : "copy"}
          </button>
        </div>
      </div>
      <div className="font-mono text-xs bg-stone-50 border border-stone-200 rounded-md px-2 py-1.5 break-all">
        {display}
      </div>
    </div>
  );
}

function formatDuration(s: number) {
  if (s < 60) return `${s.toFixed(0)}s`;
  if (s < 3600) return `${(s / 60).toFixed(1)}m`;
  if (s < 86400) return `${(s / 3600).toFixed(1)}h`;
  return `${(s / 86400).toFixed(1)}d`;
}
