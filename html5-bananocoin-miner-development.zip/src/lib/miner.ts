// Mining controller — generates Banano seeds, derives accounts and queries the
// MonKey API to identify accessories. Designed to run several concurrent
// "workers" that each independently produce candidate addresses.

import { wallet } from "bananocurrency-web";
import { ACCESSORIES, AccessoryDef, identifyAccessories } from "../data/accessories";

const API_BASE = "https://monkey.banano.cc/api/v1/monkey";

export interface FoundMonkey {
  id: string;
  seed: string;
  index: number;
  privateKey: string;
  address: string;
  matched: AccessoryDef[]; // matched targets from user filter
  accessories: AccessoryDef[]; // ALL identified accessories from catalog
  rawFilenames: string[];
  rarestProbability: number;
}

export interface MinerCallbacks {
  onChecked?: (count: number) => void;
  onFound?: (m: FoundMonkey) => void;
  onError?: (e: unknown) => void;
}

interface DtlResponse {
  accessories?: Record<string, unknown>;
  address?: string;
  status?: string;
}

function flattenAccessories(res: DtlResponse): string[] {
  const out: string[] = [];
  if (!res || !res.accessories) return out;
  for (const v of Object.values(res.accessories)) {
    if (Array.isArray(v)) {
      for (const item of v) {
        if (typeof item === "string") out.push(item);
        else if (item && typeof item === "object") {
          const o = item as Record<string, unknown>;
          if (typeof o.filename === "string") out.push(o.filename);
          else if (typeof o.name === "string") out.push(o.name);
          else if (typeof o.svg === "string") out.push(o.svg);
        }
      }
    } else if (typeof v === "string") {
      out.push(v);
    }
  }
  return out;
}

async function fetchAccessories(address: string, signal: AbortSignal): Promise<DtlResponse> {
  const res = await fetch(`${API_BASE}/dtl/${address}`, { signal });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return (await res.json()) as DtlResponse;
}

export interface MinerConfig {
  concurrency: number;
  accountsPerSeed: number; // number of indexes to derive per seed (Kalium uses up to 50)
  filterIds: string[];
  matchMode: "any" | "all";
}

export class Miner {
  running = false;
  private abort = new AbortController();
  totalChecked = 0;
  totalFound = 0;
  startedAt = 0;

  constructor(private cfg: MinerConfig, private cb: MinerCallbacks) {}

  setConfig(cfg: Partial<MinerConfig>) {
    this.cfg = { ...this.cfg, ...cfg };
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.startedAt = Date.now();
    this.abort = new AbortController();
    for (let i = 0; i < this.cfg.concurrency; i++) {
      void this.workerLoop(i);
    }
  }

  stop() {
    this.running = false;
    this.abort.abort();
  }

  private async workerLoop(_id: number) {
    while (this.running) {
      try {
        // 64-char hex random seed → Kalium-compatible legacy wallet
        const w = wallet.generateLegacy();
        const accounts = wallet.legacyAccounts(
          w.seed,
          0,
          Math.max(0, this.cfg.accountsPerSeed - 1)
        );

        for (const acc of accounts) {
          if (!this.running) return;
          try {
            const res = await fetchAccessories(acc.address, this.abort.signal);
            this.totalChecked += 1;
            this.cb.onChecked?.(this.totalChecked);

            const files = flattenAccessories(res);
            const allFound = identifyAccessories(files);

            const wantedIds = new Set(this.cfg.filterIds);
            const matched = allFound.filter((a) => wantedIds.has(a.id));

            let isMatch = false;
            if (wantedIds.size === 0) {
              isMatch = false; // nothing to look for
            } else if (this.cfg.matchMode === "any") {
              isMatch = matched.length > 0;
            } else {
              isMatch = matched.length === wantedIds.size;
            }

            if (isMatch) {
              const rarest = Math.min(
                ...matched.map((m) => {
                  const total: Record<string, number> = {
                    glasses: 8, hat: 19.4, misc: 11.29, mouth: 5.56,
                    shirt_and_pants: 6, shoes: 6, tail: 1,
                  };
                  const odds: Record<string, number> = {
                    glasses: 0.25, hat: 0.35, misc: 0.3, mouth: 1,
                    shirt_and_pants: 0.25, shoes: 0.22, tail: 0.2,
                  };
                  return (m.weight / total[m.category]) * odds[m.category];
                })
              );

              const found: FoundMonkey = {
                id: `${w.seed}-${acc.accountIndex}`,
                seed: w.seed,
                index: acc.accountIndex,
                privateKey: acc.privateKey,
                address: acc.address,
                matched,
                accessories: allFound,
                rawFilenames: files,
                rarestProbability: rarest,
              };
              this.totalFound += 1;
              this.cb.onFound?.(found);
            }
          } catch (e) {
            if ((e as Error)?.name === "AbortError") return;
            this.cb.onError?.(e);
            await sleep(400);
          }
        }
      } catch (e) {
        this.cb.onError?.(e);
        await sleep(400);
      }
    }
  }
}

function sleep(ms: number) {
  return new Promise<void>((r) => setTimeout(r, ms));
}

export { ACCESSORIES };
