from __future__ import annotations

import os

from linucb import featurize_context, score as linucb_score
from policy import LearnedPolicy
from router import CheapestThresholdRouter


def choose_decision(prompt: str, threshold: float | None = None, policy_path: str | None = None, latency_weight: float = 0.0):
    if policy_path and os.path.exists(policy_path):
        policy = LearnedPolicy.from_file(policy_path, threshold=threshold)
        features, _norm, quotes = policy.predict_quotes(prompt)
        router = CheapestThresholdRouter(threshold=threshold, latency_weight=latency_weight)
        decision = router.route(prompt)
        for key, q in quotes.items():
            if key in decision.quotes:
                decision.quotes[key]["predicted_accuracy"] = q.predicted_accuracy
        eligible = [q for q in quotes.values() if q.predicted_accuracy >= decision.threshold]
        context = featurize_context(features, latency_weight, decision.threshold)
        if eligible:
            chosen = sorted(
                eligible,
                key=lambda q: (
                    -(linucb_score(q.model, context) + q.predicted_accuracy - q.estimated_cost - latency_weight * q.estimated_latency_ms / 1000.0),
                    q.estimated_cost + latency_weight * q.estimated_latency_ms / 1000.0,
                    -q.predicted_accuracy,
                ),
            )[0]
        else:
            chosen = sorted(quotes.values(), key=lambda q: (-q.predicted_accuracy, q.estimated_cost + latency_weight * q.estimated_latency_ms / 1000.0))[0]
        decision.chosen_provider = chosen.provider
        decision.chosen_model = chosen.model
        decision.predicted_accuracy = chosen.predicted_accuracy
        decision.estimated_cost = chosen.estimated_cost
        decision.estimated_latency_ms = chosen.estimated_latency_ms
        decision.features = features
        return decision
    router = CheapestThresholdRouter(threshold=threshold, latency_weight=latency_weight)
    return router.route(prompt)
