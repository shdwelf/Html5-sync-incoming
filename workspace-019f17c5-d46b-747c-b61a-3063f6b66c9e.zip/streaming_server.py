from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Generator, List, Optional

import requests

from config import settings


@dataclass
class StreamChunk:
    text: str
    t_rel_ms: float


@dataclass
class StreamTrace:
    provider: str
    model: str
    chunks: List[StreamChunk]
    ttft_ms: float
    total_latency_ms: float
    output_tokens_est: int
    tps: float
    text: str


def _calc_token_metrics(chunks: List[StreamChunk], text: str, total_latency_ms: float, ttft_ms: float, output_tokens_est: int, explicit_tps: float | None = None):
    if explicit_tps is not None:
        tps = explicit_tps
    else:
        decode_ms = max(1.0, total_latency_ms - ttft_ms)
        tps = 1000.0 * float(max(output_tokens_est, 1)) / decode_ms
    if len(chunks) >= 2:
        gaps = [chunks[i].t_rel_ms - chunks[i - 1].t_rel_ms for i in range(1, len(chunks))]
        gaps_sorted = sorted(gaps)
        p50 = gaps_sorted[len(gaps_sorted) // 2]
        p95 = gaps_sorted[min(len(gaps_sorted) - 1, int(0.95 * (len(gaps_sorted) - 1)))]
        avg = sum(gaps) / len(gaps)
    else:
        avg = p50 = p95 = 0.0
    return {"output_tps": tps, "avg_itl_ms": avg, "p50_itl_ms": p50, "p95_itl_ms": p95, "chunk_count": len(chunks)}


def stream_local(prompt: str, model: str, max_tokens: int = 400) -> Generator[dict, None, StreamTrace]:
    url = settings.local_base_url.rstrip("/") + "/api/generate"
    payload = {"model": model, "prompt": prompt, "stream": True, "options": {"num_predict": max_tokens}}
    t0 = time.perf_counter()
    first_token_t = None
    chunks: List[StreamChunk] = []
    text_parts = []
    eval_count = None
    eval_duration_ns = None
    with requests.post(url, json=payload, timeout=120, stream=True) as r:
        r.raise_for_status()
        for raw in r.iter_lines(decode_unicode=True):
            if not raw:
                continue
            obj = json.loads(raw)
            piece = obj.get("response", "") or ""
            now = time.perf_counter()
            if piece and first_token_t is None:
                first_token_t = now
            if piece:
                rel_ms = (now - t0) * 1000.0
                chunks.append(StreamChunk(text=piece, t_rel_ms=rel_ms))
                text_parts.append(piece)
                yield {"event": "token", "data": piece}
            if obj.get("done"):
                eval_count = obj.get("eval_count")
                eval_duration_ns = obj.get("eval_duration")
    t1 = time.perf_counter()
    text = "".join(text_parts)
    ttft_ms = ((first_token_t or t1) - t0) * 1000.0
    total_ms = (t1 - t0) * 1000.0
    output_tokens_est = int(eval_count) if eval_count else max(1, len(text) // 4)
    explicit_tps = float(eval_count) / (float(eval_duration_ns) / 1_000_000_000.0) if eval_count and eval_duration_ns and float(eval_duration_ns) > 0 else None
    metrics = _calc_token_metrics(chunks, text, total_ms, ttft_ms, output_tokens_est, explicit_tps=explicit_tps)
    return StreamTrace(provider="local", model=model, chunks=chunks, ttft_ms=ttft_ms, total_latency_ms=total_ms, output_tokens_est=output_tokens_est, tps=metrics["output_tps"], text=text)


def stream_fireworks(prompt: str, model: str, max_tokens: int = 400) -> Generator[dict, None, StreamTrace]:
    url = "https://api.fireworks.ai/inference/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {settings.fireworks_api_key}",
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
    }
    payload = {"model": model, "max_tokens": max_tokens, "stream": True, "messages": [{"role": "user", "content": prompt}]}
    t0 = time.perf_counter()
    first_token_t = None
    chunks: List[StreamChunk] = []
    text_parts = []
    completion_tokens = None
    with requests.post(url, headers=headers, json=payload, timeout=120, stream=True) as r:
        r.raise_for_status()
        for line in r.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data:"):
                continue
            data = line[len("data:"):].strip()
            if data == "[DONE]":
                break
            obj = json.loads(data)
            choices = obj.get("choices", [])
            if choices:
                delta = choices[0].get("delta", {})
                piece = delta.get("content", "") or ""
                now = time.perf_counter()
                if piece and first_token_t is None:
                    first_token_t = now
                if piece:
                    rel_ms = (now - t0) * 1000.0
                    chunks.append(StreamChunk(text=piece, t_rel_ms=rel_ms))
                    text_parts.append(piece)
                    yield {"event": "token", "data": piece}
            usage = obj.get("usage")
            if usage and usage.get("completion_tokens"):
                completion_tokens = usage.get("completion_tokens")
    t1 = time.perf_counter()
    text = "".join(text_parts)
    ttft_ms = ((first_token_t or t1) - t0) * 1000.0
    total_ms = (t1 - t0) * 1000.0
    output_tokens_est = int(completion_tokens) if completion_tokens else max(1, len(text) // 4)
    metrics = _calc_token_metrics(chunks, text, total_ms, ttft_ms, output_tokens_est)
    return StreamTrace(provider="fireworks", model=model, chunks=chunks, ttft_ms=ttft_ms, total_latency_ms=total_ms, output_tokens_est=output_tokens_est, tps=metrics["output_tps"], text=text)


def trace_metrics(trace: StreamTrace) -> dict:
    m = _calc_token_metrics(trace.chunks, trace.text, trace.total_latency_ms, trace.ttft_ms, trace.output_tokens_est, explicit_tps=trace.tps)
    return {
        "ttft_ms": trace.ttft_ms,
        "total_latency_ms": trace.total_latency_ms,
        "output_tokens_est": trace.output_tokens_est,
        "output_tps": m["output_tps"],
        "avg_itl_ms": m["avg_itl_ms"],
        "p50_itl_ms": m["p50_itl_ms"],
        "p95_itl_ms": m["p95_itl_ms"],
        "chunk_count": m["chunk_count"],
    }
