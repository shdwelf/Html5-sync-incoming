from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from statistics import mean

from policy import LearnedPolicy
from router import CheapestThresholdRouter


BASELINES = [
    "always-local",
    "always-fireworks-8b",
    "always-fireworks-70b",
    "heuristic-router",
    "learned-router",
]


def provider_cost(provider: str, model: str) -> float:
    if provider == "local":
        return 0.0
    if "70b" in model.lower():
        return 0.00028
    return 0.00018


def provider_latency(provider: str, model: str) -> float:
    if provider == "local":
        return 4200.0
    if "70b" in model.lower():
        return 2280.0
    return 1600.0


def choose(method: str, prompt: str, learned=None, heuristic=None):
    if method == "always-local":
        return ("local", "local-8b", 0.0, 4200.0)
    if method == "always-fireworks-8b":
        return ("fireworks", "accounts/fireworks/models/llama-v3p1-8b-instruct", 0.00018, 1600.0)
    if method == "always-fireworks-70b":
        return ("fireworks", "accounts/fireworks/models/llama-v3p3-70b-instruct", 0.00028, 2280.0)
    if method == "heuristic-router":
        d = heuristic.route(prompt)
        return (d.chosen_provider, d.chosen_model, d.estimated_cost, d.estimated_latency_ms)
    if method == "learned-router":
        features, _norm, quotes = learned.predict_quotes(prompt)
        eligible = [q for q in quotes.values() if q.predicted_accuracy >= learned.threshold]
        chosen = sorted(eligible, key=lambda q: (q.estimated_cost, q.estimated_latency_ms, -q.predicted_accuracy))[0] if eligible else sorted(quotes.values(), key=lambda q: (-q.predicted_accuracy, q.estimated_cost))[0]
        return (chosen.provider, chosen.model, chosen.estimated_cost, chosen.estimated_latency_ms)
    raise ValueError(method)


def suite(input_path: str, policy_path: str = "", threshold: float | None = None):
    learned = LearnedPolicy.from_file(policy_path, threshold=threshold) if policy_path else None
    heuristic = CheapestThresholdRouter(threshold=threshold)

    grouped = defaultdict(list)
    with open(input_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            grouped[row["prompt"]].append(row)

    oracle_rewards = []
    oracle_costs = []
    oracle_lats = []
    method_rows = {m: [] for m in BASELINES if m != "learned-router" or learned is not None}

    for prompt, rows in grouped.items():
        oracle_candidates = []
        for r in rows:
            success = int(r.get("success", 0))
            provider = r["provider"]
            model = "local-8b" if provider == "local" else ("accounts/fireworks/models/llama-v3p1-8b-instruct" if success == 1 else "accounts/fireworks/models/llama-v3p3-70b-instruct")
            cost = provider_cost(provider, model)
            lat = provider_latency(provider, model)
            reward = float(success) - cost - 0.0001 * lat
            oracle_candidates.append((reward, cost, lat, provider, model, success))
        oracle = sorted(oracle_candidates, key=lambda x: (-x[0], x[1], x[2]))[0]
        oracle_rewards.append(oracle[0])
        oracle_costs.append(oracle[1])
        oracle_lats.append(oracle[2])

        for method in method_rows.keys():
            provider, model, est_cost, est_lat = choose(method, prompt, learned=learned, heuristic=heuristic)
            match = [r for r in rows if r["provider"] == provider]
            success = int(match[0].get("success", 0)) if match else 0
            reward = float(success) - est_cost - 0.0001 * est_lat
            method_rows[method].append({
                "reward": reward,
                "cost": est_cost,
                "latency": est_lat,
                "success": success,
                "regret": oracle[0] - reward,
                "cost_regret": est_cost - oracle[1],
                "latency_regret": est_lat - oracle[2],
            })

    report = {"oracle": {"avg_reward": mean(oracle_rewards), "avg_cost": mean(oracle_costs), "avg_latency": mean(oracle_lats)}, "methods": {}}
    for method, rows in method_rows.items():
        report["methods"][method] = {
            "avg_reward": mean(r["reward"] for r in rows),
            "avg_cost": mean(r["cost"] for r in rows),
            "avg_latency": mean(r["latency"] for r in rows),
            "success_rate": mean(r["success"] for r in rows),
            "avg_regret": mean(r["regret"] for r in rows),
            "avg_cost_regret": mean(r["cost_regret"] for r in rows),
            "avg_latency_regret": mean(r["latency_regret"] for r in rows),
        }
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Full benchmark suite")
    parser.add_argument("--input", required=True)
    parser.add_argument("--policy", default="")
    parser.add_argument("--threshold", type=float, default=None)
    args = parser.parse_args()
    print(json.dumps(suite(args.input, args.policy, args.threshold), indent=2))
