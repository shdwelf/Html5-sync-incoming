# Strategy notes

## Core idea

Use **selective escalation**:

- send easy extraction/summarization tasks to the local model
- send difficult reasoning/math/long-context tasks to Fireworks
- only pay remote cost when the predicted error risk of local exceeds tolerance

## How to win in a standardized environment

Because compute is standardized, direct model size advantage is muted. The edge comes from:

1. better task difficulty estimation
2. better calibration of predicted accuracy
3. lower false escalations to expensive models
4. safe fallback when both options look weak

## Good competition upgrades

- Fit a logistic regressor on benchmark traces for each provider
- Add a verifier that checks local answers before escalating
- Include expected latency in objective:
  - minimize `cost + lambda * latency`
- Add dynamic threshold by task type
- Learn from online feedback
