# Research notes: streaming latency, queue-aware routing, and benchmark baselines

## Streaming latency decomposition
A better latency estimate for streaming systems separates:
- TTFT: request start to first chunk
- decode throughput / TPS: tokens generated after first token
- queue time: time spent waiting before model work starts

Practical observability guidance recommends capturing first-token time on streaming callbacks and using post-first-token timing for throughput [1](https://futureagi.com/glossary/time-to-first-token/) [5](https://phillippe.siclait.com/blog/llm-benchmarking-from-scratch).

## Queue-aware routing
Queue delay should be tracked independently from raw model speed because contention can dominate experienced latency [4](https://infercom.ai/blog/llm-inference-speed-explained/).

## Benchmarks and regret
Modern routing evaluation benefits from oracle, best-single, and random baselines, plus latency-aware analysis and Pareto views [1](https://www.emergentmind.com/topics/llmrouterbench) [2](https://arxiv.org/html/2601.07206v1).

## What was implemented
- dispatch-aware queue tracking
- LinUCB state and feature-conditioned updates
- expanded metrics endpoints
- benchmark suite with separate cost and latency regret
