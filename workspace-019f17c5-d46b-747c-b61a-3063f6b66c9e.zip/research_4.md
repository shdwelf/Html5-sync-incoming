# Research notes: true streaming TTFT/TPS

## Key idea
The best practical way to measure streaming responsiveness is:
- start timer at request dispatch
- mark TTFT when first token/chunk arrives
- mark completion when final chunk arrives
- estimate TPS from completion tokens over post-TTFT decode window

This aligns with current streaming observability guidance [1](https://futureagi.com/glossary/time-to-first-token/) and benchmarking practice [2](https://docs.fireworks.ai/getting-started/quickstart) [5](https://phillippe.siclait.com/blog/llm-benchmarking-from-scratch).

## Provider-specific notes
- Fireworks supports streaming chat completions and includes usage in the final chunk [2](https://docs.fireworks.ai/getting-started/quickstart) [4](https://docs.fireworks.ai/guides/querying-text-models).
- Ollama-style local backends stream NDJSON lines; final objects can include eval counts and durations, enabling more direct TPS estimation [5](https://github.com/ollama/ollama/blob/main/docs/api.md).

## What was implemented
- streaming local adapter with TTFT and TPS capture
- streaming Fireworks adapter with first-chunk TTFT capture
- runtime logging of TTFT/TPS/output token estimate
- dashboard/metrics support for TTFT/TPS aggregates
