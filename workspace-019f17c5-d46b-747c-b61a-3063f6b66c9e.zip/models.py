from __future__ import annotations

import json
import requests
from dataclasses import dataclass
from typing import Dict

from catalog import ModelSpec, get_model_catalog
from config import settings
from online_learning import get_adjustment


@dataclass
class ProviderQuote:
    provider: str
    model: str
    predicted_accuracy: float
    estimated_cost: float
    estimated_latency_ms: float
    reason: str


class Pricing:
    @staticmethod
    def estimate_cost(tokens_in: int, tokens_out: int, input_per_1k: float, output_per_1k: float) -> float:
        return (tokens_in / 1000.0) * input_per_1k + (tokens_out / 1000.0) * output_per_1k


class AccuracyModel:
    @staticmethod
    def predict_local(features: Dict) -> float:
        base = 0.90
        base -= min(features["tokens_est"] / 4000.0, 0.18)
        if features["has_math"]:
            base -= 0.16
        if features["has_reasoning"]:
            base -= 0.10
        if features["has_code"]:
            base -= 0.05
        if features["has_ambiguity"]:
            base -= 0.07
        if features["question_count"] > 2:
            base -= 0.04
        return max(0.35, min(0.97, base))

    @staticmethod
    def predict_fireworks(features: Dict) -> float:
        base = 0.95
        base -= min(features["tokens_est"] / 8000.0, 0.08)
        if features["has_math"]:
            base -= 0.05
        if features["has_reasoning"]:
            base -= 0.03
        if features["has_ambiguity"]:
            base -= 0.02
        return max(0.55, min(0.99, base))


class LocalAdapter:
    @staticmethod
    def generate(prompt: str, max_tokens: int = 400, model: str | None = None) -> str:
        url = settings.local_base_url.rstrip("/") + "/api/generate"
        payload = {
            "model": model or settings.local_model_name,
            "prompt": prompt,
            "stream": False,
            "options": {"num_predict": max_tokens},
        }
        try:
            r = requests.post(url, json=payload, timeout=60)
            r.raise_for_status()
            data = r.json()
            return data.get("response", "") or data.get("output", "") or json.dumps(data)
        except Exception as e:
            return f"[local generation failed] {e}"


class FireworksAdapter:
    @staticmethod
    def generate(prompt: str, max_tokens: int = 400, model: str | None = None) -> str:
        if not settings.fireworks_api_key:
            return "[fireworks disabled: missing FIREWORKS_API_KEY]"
        url = "https://api.fireworks.ai/inference/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {settings.fireworks_api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": model or settings.fireworks_model,
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=60)
            r.raise_for_status()
            data = r.json()
            return data["choices"][0]["message"]["content"]
        except Exception as e:
            return f"[fireworks generation failed] {e}"


def estimate_latency_ms(spec: ModelSpec, tokens_out: int) -> float:
    return float(spec.ttft_ms) + (1000.0 * float(tokens_out) / max(spec.tps, 1.0))


def build_quotes(features: Dict, tokens_in: int, tokens_out: int = 300) -> Dict[str, ProviderQuote]:
    quotes = {}
    for spec in get_model_catalog():
        if spec.provider == "local":
            acc = AccuracyModel.predict_local(features) + spec.quality_bias
        else:
            acc = AccuracyModel.predict_fireworks(features) + spec.quality_bias
        acc += get_adjustment(spec.provider, spec.model)
        acc = max(0.05, min(0.995, acc))
        cost = Pricing.estimate_cost(tokens_in, tokens_out, spec.input_cost_per_1k, spec.output_cost_per_1k)
        latency = estimate_latency_ms(spec, tokens_out)
        key = f"{spec.provider}:{spec.model}"
        quotes[key] = ProviderQuote(
            provider=spec.provider,
            model=spec.model,
            predicted_accuracy=acc,
            estimated_cost=cost,
            estimated_latency_ms=latency,
            reason="quote from heuristic+online calibrated accuracy model, catalog pricing, and latency estimate",
        )
    return quotes
