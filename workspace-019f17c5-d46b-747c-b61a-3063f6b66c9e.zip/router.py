from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Dict

from config import settings
from features import featurize
from models import build_quotes


@dataclass
class RouteDecision:
    chosen_provider: str
    chosen_model: str
    predicted_accuracy: float
    estimated_cost: float
    estimated_latency_ms: float
    threshold: float
    fallback_used: bool
    rationale: str
    features: Dict
    quotes: Dict


class CheapestThresholdRouter:
    def __init__(self, threshold: float | None = None, latency_weight: float | None = None):
        self.threshold = threshold if threshold is not None else settings.accuracy_threshold
        self.latency_weight = 0.0 if latency_weight is None else latency_weight

    def route(self, prompt: str) -> RouteDecision:
        features = featurize(prompt)
        quotes = build_quotes(features, tokens_in=features["tokens_est"])

        eligible = [q for q in quotes.values() if q.predicted_accuracy >= self.threshold]
        fallback_used = False

        if eligible:
            chosen = sorted(
                eligible,
                key=lambda q: (q.estimated_cost + self.latency_weight * q.estimated_latency_ms / 1000.0, -q.predicted_accuracy),
            )[0]
            rationale = (
                f"Selected lowest objective among providers meeting threshold {self.threshold:.2f}. "
                f"objective=cost+{self.latency_weight:.4f}*latency_s, cost={chosen.estimated_cost:.6f}, "
                f"latency_ms={chosen.estimated_latency_ms:.1f}, acc={chosen.predicted_accuracy:.3f}."
            )
        else:
            fallback_used = True
            chosen = sorted(
                quotes.values(),
                key=lambda q: (-q.predicted_accuracy, q.estimated_cost + self.latency_weight * q.estimated_latency_ms / 1000.0),
            )[0]
            rationale = (
                f"No provider met threshold {self.threshold:.2f}; chose highest predicted accuracy with cost/latency tie-break. "
                f"cost={chosen.estimated_cost:.6f}, latency_ms={chosen.estimated_latency_ms:.1f}, acc={chosen.predicted_accuracy:.3f}."
            )

        return RouteDecision(
            chosen_provider=chosen.provider,
            chosen_model=chosen.model,
            predicted_accuracy=chosen.predicted_accuracy,
            estimated_cost=chosen.estimated_cost,
            estimated_latency_ms=chosen.estimated_latency_ms,
            threshold=self.threshold,
            fallback_used=fallback_used,
            rationale=rationale,
            features=features,
            quotes={k: asdict(v) for k, v in quotes.items()},
        )
