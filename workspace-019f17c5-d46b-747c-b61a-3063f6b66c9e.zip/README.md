# Cost-Aware Hybrid LLM Router

A practical AI agent that routes each task between a **local model** and **Fireworks AI** in real time, always choosing the **lowest-cost option** that still meets an **accuracy threshold**.

This project is designed for standardized environments where **routing intelligence wins, not raw compute**.

## What it does

- Classifies each incoming task
- Estimates expected accuracy for:
  - a **local model**
  - a **Fireworks-hosted model**
- Chooses the **cheapest provider** whose predicted accuracy is above a configurable threshold
- Falls back safely when confidence is low
- Logs routing decisions for offline evaluation
- Includes a simulator/eval harness to measure cost, threshold hit rate, provider mix, and policy behavior
- Supports a learned calibration policy trained from trace CSV data
- Exposes an HTTP API with FastAPI

## Routing objective

For each provider `p`:

- predicted accuracy: `A_p(x)`
- expected cost: `C_p(x)`

Choose:

```text
argmin_p C_p(x)
subject to A_p(x) >= tau
```

If no provider meets `tau`, choose the provider with highest `A_p(x)` or abstain, depending on policy.

## Files

- `main.py` — CLI entrypoint
- `router.py` — heuristic routing policy
- `policy.py` — learned calibration support
- `trainer.py` — trains per-provider success calibrators from CSV traces
- `replay.py` — offline replay evaluator
- `service.py` — FastAPI service
- `models.py` — provider adapters and pricing metadata
- `features.py` — task featurization
- `simulator.py` — synthetic benchmark
- `logging_utils.py` — JSONL route logging
- `data/sample_traces.csv` — example training data

## Quick start

### CLI

```bash
python3 main.py --prompt "Summarize this policy memo in 5 bullets"
python3 simulator.py
```

### Train learned policy

```bash
python3 trainer.py --input data/sample_traces.csv --output artifacts/calibrators.json
python3 replay.py --input data/sample_traces.csv --policy artifacts/calibrators.json
```

### API service

```bash
uvicorn service:app --reload --port 8000
```

Example request:

```bash
curl -X POST http://127.0.0.1:8000/route \
  -H 'Content-Type: application/json' \
  -d '{"prompt": "Solve this probability puzzle", "execute": false}'
```

With learned policy:

```bash
curl -X POST http://127.0.0.1:8000/route \
  -H 'Content-Type: application/json' \
  -d '{"prompt": "Optimize this SQL query", "policy_path": "artifacts/calibrators.json"}'
```

## Environment

Set these if you want live Fireworks calls:

- `FIREWORKS_API_KEY`
- `FIREWORKS_MODEL`

Optional local model settings:

- `LOCAL_MODEL_NAME`
- `LOCAL_BASE_URL`

Pricing settings:

- `LOCAL_INPUT_COST_PER_1K`
- `LOCAL_OUTPUT_COST_PER_1K`
- `FIREWORKS_INPUT_COST_PER_1K`
- `FIREWORKS_OUTPUT_COST_PER_1K`
- `ACCURACY_THRESHOLD`

## Strategy for competitive standardized environments

The winning approach is not to always use the strongest model. It is to:

1. estimate task difficulty
2. predict per-provider success probability
3. send only difficult tasks to the expensive model
4. minimize unnecessary escalations
5. continually recalibrate from logs

## New capabilities

### Latency-aware routing
The router now supports a latency-aware objective:

```text
minimize cost + lambda * latency_seconds
subject to predicted_accuracy >= threshold
```

Latency is estimated from model TTFT and tokens/sec.

### Verifier-based two-stage escalation
The service can:
1. route to a cheap local model first
2. verify the answer heuristically
3. escalate to Fireworks if verification fails

### Multiple candidate models
The catalog now includes multiple local and Fireworks candidates, and the router chooses among them.

### Metrics and feedback
- `GET /metrics` returns aggregate routing stats from JSONL logs
- `POST /feedback` updates online quality adjustments from outcomes

### Benchmarking
- `benchmark.py` produces a simple leaderboard summary
- `notebooks/router_benchmark.ipynb` provides a notebook scaffold

## Additional advanced capabilities

### Route IDs and linked feedback
Every routed request is assigned a `route_id`. Feedback can be submitted later using that ID so the system can update model adjustments and online bandit state from actual outcomes.

### Stronger verifiers
The verifier now includes task-shaped checks for:
- JSON/schema outputs
- code/debug answers
- extraction tasks
- summaries
- reasoning tasks

### Live latency logging
When `execute=true`, the service records observed end-to-end latency in milliseconds.

### Pareto / dashboard analytics
- `analytics.py` renders `dashboard_rendered.html`
- computes a simple Pareto frontier over logged route decisions

### Online exploration scaffold
A lightweight UCB-style bandit score is used as a learned preference signal when a learned policy file is supplied.

### Live API metrics expansion
Additional endpoints now expose internal model/routing state:
- `GET /metrics/models`
- `GET /metrics/latency_state`
- `GET /metrics/queue_state`
- `GET /metrics/bandit_state`

### Contextual bandit upgrade
The project now includes a feature-conditioned LinUCB router state that can be updated from route outcomes.

### Stronger benchmark suite
Use `benchmark_suite.py` for reward, cost, latency, and regret comparisons across:
- always-local
- always-fireworks-8b
- always-fireworks-70b
- heuristic-router
- learned-router

### Browser demo for streaming
Open `demo_stream.html` to test `/route/stream` from a browser using `fetch()` + `ReadableStream` parsing.

### Raw chunk-trace persistence
Streaming runs now persist per-chunk timing traces to `logs/chunk_traces.jsonl`.
Use `GET /metrics/trace_histograms` or `trace_analytics.py` for histogram summaries.

### Stream-time learned/LinUCB routing and escalation
The `/route/stream` endpoint now uses the same learned/LinUCB-aware selection path and supports verifier-driven escalation from local to Fireworks during streamed execution.

### Queue/load-aware estimates
Estimated latency now includes a queue penalty derived from simple per-model queue depth and average service time.

### Oracle/regret evaluation
Use `evaluator.py` to compare router choices against an oracle baseline and compute average regret.
