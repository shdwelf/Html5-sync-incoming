from __future__ import annotations

import math
from typing import Dict

from online_learning import load_state, save_state


STATE_PATH = "artifacts/bandit_state.json"


def _default():
    return {"arms": {}, "total_pulls": 0}


def load_bandit_state(path: str = STATE_PATH):
    state = load_state(path) if False else None
    try:
        import json, os
        if not os.path.exists(path):
            return _default()
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return _default()


def save_bandit_state(state, path: str = STATE_PATH):
    import json, os
    os.makedirs("artifacts", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def arm_score(model: str, predicted_reward: float, path: str = STATE_PATH) -> float:
    state = load_bandit_state(path)
    arms = state.get("arms", {})
    arm = arms.get(model, {"pulls": 0, "reward_sum": 0.0})
    pulls = int(arm.get("pulls", 0))
    total = max(1, int(state.get("total_pulls", 0)))
    mean_reward = float(arm.get("reward_sum", 0.0)) / max(1, pulls)
    bonus = math.sqrt(2.0 * math.log(total + 1) / max(1, pulls)) if pulls > 0 else 0.5
    return 0.7 * predicted_reward + 0.3 * mean_reward + 0.05 * bonus


def update_bandit(model: str, reward: float, path: str = STATE_PATH):
    state = load_bandit_state(path)
    arms = state.setdefault("arms", {})
    arm = arms.setdefault(model, {"pulls": 0, "reward_sum": 0.0})
    arm["pulls"] += 1
    arm["reward_sum"] += reward
    state["total_pulls"] = int(state.get("total_pulls", 0)) + 1
    save_bandit_state(state, path)
    return state
