from __future__ import annotations

from typing import Dict

from latency_learning import update_latency
from linucb import featurize_context, score as linucb_score
from logging_utils import log_event
from models import FireworksAdapter, LocalAdapter
from policy import LearnedPolicy
from queue_state import on_complete, on_dispatch
from route_store import append_route
from router import CheapestThresholdRouter
from streaming import StreamingFireworksAdapter, StreamingLocalAdapter
from verifier import verify_response
import os
import time


def route_and_maybe_execute(prompt: str, execute: bool = False, threshold: float | None = None, policy_path: str | None = None, latency_weight: float = 0.0, verify: bool = True, max_tokens: int = 400, stream: bool = False) -> Dict:
    decision = choose_decision(prompt, threshold=threshold, policy_path=policy_path, latency_weight=latency_weight)

    response_text = None
    verifier = None
    escalation = None
    observed_latency_ms = None
    ttft_ms = None
    output_tps = None
    output_tokens_est = None

    if execute:
        on_dispatch(decision.chosen_model)
        if stream:
            result = StreamingLocalAdapter.generate(prompt, model=decision.chosen_model, max_tokens=max_tokens) if decision.chosen_provider == "local" else StreamingFireworksAdapter.generate(prompt, model=decision.chosen_model, max_tokens=max_tokens)
            response_text = result.text
            observed_latency_ms = result.total_latency_ms
            ttft_ms = result.ttft_ms
            output_tps = result.tps
            output_tokens_est = result.output_tokens_est
        else:
            t0 = time.perf_counter()
            response_text = LocalAdapter.generate(prompt, max_tokens=max_tokens, model=decision.chosen_model) if decision.chosen_provider == "local" else FireworksAdapter.generate(prompt, max_tokens=max_tokens, model=decision.chosen_model)
            observed_latency_ms = (time.perf_counter() - t0) * 1000.0
            output_tokens_est = max(1, len(str(response_text or "")) // 4)

        if verify:
            ok, reason = verify_response(prompt, response_text)
            verifier = {"passed": ok, "reason": reason}
            if not ok and decision.chosen_provider == "local":
                escalation = {"from": decision.chosen_model, "to": "fireworks"}
                if stream:
                    esc = StreamingFireworksAdapter.generate(prompt, model="accounts/fireworks/models/llama-v3p1-8b-instruct", max_tokens=max_tokens)
                    response_text = esc.text
                    observed_latency_ms = (observed_latency_ms or 0.0) + esc.total_latency_ms
                    if ttft_ms is None:
                        ttft_ms = esc.ttft_ms
                    output_tokens_est = esc.output_tokens_est
                    output_tps = esc.tps
                else:
                    t1 = time.perf_counter()
                    response_text = FireworksAdapter.generate(prompt, max_tokens=max_tokens)
                    observed_latency_ms = (observed_latency_ms or 0.0) + (time.perf_counter() - t1) * 1000.0
                    output_tokens_est = max(1, len(str(response_text or "")) // 4)

        update_latency(decision.chosen_model, observed_latency_ms or 0.0, output_tokens_est or 1, ttft_ms=ttft_ms, tps=output_tps)
        on_complete(decision.chosen_model, observed_latency_ms or 0.0)

    payload = log_event({
        "decision": decision.__dict__,
        "response": response_text,
        "verifier": verifier,
        "escalation": escalation,
        "observed_latency_ms": observed_latency_ms,
        "ttft_ms": ttft_ms,
        "output_tps": output_tps,
        "output_tokens_est": output_tokens_est,
        "streaming": stream,
    })
    append_route(payload)
    return payload
