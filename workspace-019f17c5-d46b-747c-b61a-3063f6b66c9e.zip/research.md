# Research notes for routing upgrades

## Key takeaways

### Latency-aware routing
- Latency should be included alongside cost and predicted accuracy, not treated as a secondary afterthought.
- Useful practical metrics include TTFT, tokens/sec, P50/P95 latency, and estimated end-to-end latency.
- A simple first model is:
  - `latency_ms = ttft_ms + 1000 * expected_output_tokens / tps`
- Better systems learn latency online from live traffic and queue effects.

Evidence:
- Predicted-latency scheduling can reduce TTFT and improve end-to-end latency substantially [2](https://llm-d.ai/blog/predicted-latency-based-scheduling-for-llms).
- LLM routing benchmarks now explicitly discuss performance-cost-latency tradeoffs [5](https://arxiv.org/html/2601.07206v1).

### Verifier-based escalation
- A strong pattern is to try a cheaper model first, then verify the output, and escalate only when verification fails.
- Verification can be heuristic initially:
  - structured output validity
  - minimum completeness checks
  - code fence / JSON parseability checks
  - contradiction / uncertainty markers
- More advanced versions use model-based critics or task-specific tests.

### Multi-model support
- Bigger ensembles are not automatically better; curated subsets often outperform larger indiscriminate pools [5](https://arxiv.org/html/2601.07206v1).
- Practical routing should support multiple local and remote candidates, but model curation matters.

### Fireworks notes
- Fireworks exposes chat-completions style inference endpoints and supports low-latency serving patterns [3](https://futureagi.com/blog/evaluating-fireworks-together-inference-2026/).
- Public third-party benchmarks report strong latency and reliability for Fireworks-served open models, though exact numbers vary by source [2](https://tokenmix.ai/blog/ai-api-latency-benchmark) [5](https://tokenmix.ai/blog/fireworks-ai-review).

## What was implemented from this research
- latency-aware scoring
- multiple local + Fireworks candidates
- verifier-based two-stage escalation
- metrics endpoint and JSONL aggregation
- online adjustment from route outcomes
- benchmark / leaderboard script
