from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Optional

import requests

from config import settings


@dataclass
class StreamResult:
    text: str
    ttft_ms: float
    total_latency_ms: float
    output_tokens_est: int
    tps: float
    model: str
    provider: str


class StreamingLocalAdapter:
    @staticmethod
    def generate(prompt: str, model: str, max_tokens: int = 400) -> StreamResult:
        url = settings.local_base_url.rstrip("/") + "/api/generate"
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": True,
            "options": {"num_predict": max_tokens},
        }
        t0 = time.perf_counter()
        first_token_t = None
        text_parts = []
        eval_count = None
        eval_duration_ns = None
        try:
            with requests.post(url, json=payload, timeout=120, stream=True) as r:
                r.raise_for_status()
                for raw in r.iter_lines(decode_unicode=True):
                    if not raw:
                        continue
                    obj = json.loads(raw)
                    piece = obj.get("response", "") or ""
                    if piece and first_token_t is None:
                        first_token_t = time.perf_counter()
                    if piece:
                        text_parts.append(piece)
                    if obj.get("done"):
                        eval_count = obj.get("eval_count")
                        eval_duration_ns = obj.get("eval_duration")
            t1 = time.perf_counter()
            text = "".join(text_parts)
            ttft_ms = ((first_token_t or t1) - t0) * 1000.0
            total_ms = (t1 - t0) * 1000.0
            output_tokens_est = int(eval_count) if eval_count else max(1, len(text) // 4)
            if eval_count and eval_duration_ns and float(eval_duration_ns) > 0:
                tps = float(eval_count) / (float(eval_duration_ns) / 1_000_000_000.0)
            else:
                decode_ms = max(1.0, total_ms - ttft_ms)
                tps = 1000.0 * float(output_tokens_est) / decode_ms
            return StreamResult(text=text, ttft_ms=ttft_ms, total_latency_ms=total_ms, output_tokens_est=output_tokens_est, tps=tps, model=model, provider="local")
        except Exception as e:
            t1 = time.perf_counter()
            return StreamResult(text=f"[local streaming failed] {e}", ttft_ms=(t1 - t0) * 1000.0, total_latency_ms=(t1 - t0) * 1000.0, output_tokens_est=1, tps=1.0, model=model, provider="local")


class StreamingFireworksAdapter:
    @staticmethod
    def generate(prompt: str, model: str, max_tokens: int = 400) -> StreamResult:
        if not settings.fireworks_api_key:
            t = time.perf_counter()
            return StreamResult(text="[fireworks disabled: missing FIREWORKS_API_KEY]", ttft_ms=0.0, total_latency_ms=0.0, output_tokens_est=1, tps=1.0, model=model, provider="fireworks")
        url = "https://api.fireworks.ai/inference/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {settings.fireworks_api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "stream": True,
            "messages": [{"role": "user", "content": prompt}],
        }
        t0 = time.perf_counter()
        first_token_t = None
        text_parts = []
        usage_completion_tokens = None
        try:
            with requests.post(url, headers=headers, json=payload, timeout=120, stream=True) as r:
                r.raise_for_status()
                for line in r.iter_lines(decode_unicode=True):
                    if not line:
                        continue
                    if not line.startswith("data:"):
                        continue
                    data = line[len("data:"):].strip()
                    if data == "[DONE]":
                        break
                    obj = json.loads(data)
                    choices = obj.get("choices", [])
                    if choices:
                        delta = choices[0].get("delta", {})
                        piece = delta.get("content", "") or ""
                        if piece and first_token_t is None:
                            first_token_t = time.perf_counter()
                        if piece:
                            text_parts.append(piece)
                    usage = obj.get("usage")
                    if usage and usage.get("completion_tokens"):
                        usage_completion_tokens = usage.get("completion_tokens")
            t1 = time.perf_counter()
            text = "".join(text_parts)
            ttft_ms = ((first_token_t or t1) - t0) * 1000.0
            total_ms = (t1 - t0) * 1000.0
            output_tokens_est = int(usage_completion_tokens) if usage_completion_tokens else max(1, len(text) // 4)
            decode_ms = max(1.0, total_ms - ttft_ms)
            tps = 1000.0 * float(output_tokens_est) / decode_ms
            return StreamResult(text=text, ttft_ms=ttft_ms, total_latency_ms=total_ms, output_tokens_est=output_tokens_est, tps=tps, model=model, provider="fireworks")
        except Exception as e:
            t1 = time.perf_counter()
            return StreamResult(text=f"[fireworks streaming failed] {e}", ttft_ms=(t1 - t0) * 1000.0, total_latency_ms=(t1 - t0) * 1000.0, output_tokens_est=1, tps=1.0, model=model, provider="fireworks")
