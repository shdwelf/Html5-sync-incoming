from __future__ import annotations

import json
import os
from typing import Dict

STATE_PATH = "artifacts/queue_state.json"


def _default():
    return {"models": {}}


def load_queue_state(path: str = STATE_PATH) -> Dict:
    if not os.path.exists(path):
        return _default()
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_queue_state(state: Dict, path: str = STATE_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def get_queue_penalty_ms(model: str, path: str = STATE_PATH) -> float:
    state = load_queue_state(path)
    row = state.get("models", {}).get(model, {})
    depth = float(row.get("depth", 0.0))
    avg_service_ms = float(row.get("avg_service_ms", 0.0))
    return depth * avg_service_ms


def on_dispatch(model: str, path: str = STATE_PATH):
    state = load_queue_state(path)
    row = state.setdefault("models", {}).setdefault(model, {"depth": 0.0, "avg_service_ms": 0.0, "completed": 0})
    row["depth"] = float(row.get("depth", 0.0)) + 1.0
    save_queue_state(state, path)
    return state


def on_complete(model: str, service_ms: float, alpha: float = 0.2, path: str = STATE_PATH):
    state = load_queue_state(path)
    row = state.setdefault("models", {}).setdefault(model, {"depth": 0.0, "avg_service_ms": 0.0, "completed": 0})
    row["depth"] = max(0.0, float(row.get("depth", 0.0)) - 1.0)
    prev = float(row.get("avg_service_ms", 0.0))
    row["avg_service_ms"] = service_ms if prev <= 0 else (1 - alpha) * prev + alpha * service_ms
    row["completed"] = int(row.get("completed", 0)) + 1
    save_queue_state(state, path)
    return state
