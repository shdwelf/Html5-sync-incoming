from __future__ import annotations

import json
from typing import Dict, List

from latency_learning import load_latency_state
from linucb import load_state as load_linucb_state
from metrics import read_jsonl, summarize_logs
from queue_state import load_queue_state
from trace_analytics import summarize_traces


def pareto_frontier(points: List[Dict]) -> List[Dict]:
    frontier = []
    for p in points:
        dominated = False
        for q in points:
            if q is p:
                continue
            q_cost = q.get("estimated_cost", 0.0)
            q_lat = q.get("estimated_latency_ms", 0.0)
            q_acc = q.get("predicted_accuracy", 0.0)
            p_cost = p.get("estimated_cost", 0.0)
            p_lat = p.get("estimated_latency_ms", 0.0)
            p_acc = p.get("predicted_accuracy", 0.0)
            if q_cost <= p_cost and q_lat <= p_lat and q_acc >= p_acc and (q_cost < p_cost or q_lat < p_lat or q_acc > p_acc):
                dominated = True
                break
        if not dominated:
            frontier.append(p)
    return sorted(frontier, key=lambda x: (x.get("estimated_cost", 0.0), x.get("estimated_latency_ms", 0.0), -x.get("predicted_accuracy", 0.0)))


def render_dashboard(log_path: str = "logs/routes.jsonl", out_path: str = "dashboard_rendered.html"):
    summary = summarize_logs(log_path)
    rows = read_jsonl(log_path)
    route_points = []
    for r in rows:
        d = r.get("decision", {})
        route_points.append({
            "route_id": r.get("route_id"),
            "provider": d.get("chosen_provider"),
            "model": d.get("chosen_model"),
            "estimated_cost": d.get("estimated_cost", 0.0),
            "estimated_latency_ms": d.get("estimated_latency_ms", 0.0),
            "predicted_accuracy": d.get("predicted_accuracy", 0.0),
        })
    frontier = pareto_frontier(route_points)
    recent = rows[-10:]
    latency_state = load_latency_state()
    queue_state = load_queue_state()
    bandit_state = load_linucb_state()
    trace_hist = summarize_traces()

    per_model = {}
    for p in route_points:
        m = p.get("model", "unknown")
        row = per_model.setdefault(m, {"count": 0, "costs": [], "lats": [], "accs": []})
        row["count"] += 1
        row["costs"].append(p.get("estimated_cost", 0.0))
        row["lats"].append(p.get("estimated_latency_ms", 0.0))
        row["accs"].append(p.get("predicted_accuracy", 0.0))
    per_model_summary = {
        m: {
            "count": v["count"],
            "avg_cost": (sum(v["costs"]) / len(v["costs"]) if v["costs"] else 0.0),
            "avg_latency_ms": (sum(v["lats"]) / len(v["lats"]) if v["lats"] else 0.0),
            "avg_predicted_accuracy": (sum(v["accs"]) / len(v["accs"]) if v["accs"] else 0.0),
        }
        for m, v in per_model.items()
    }

    with open("dashboard.html", "r", encoding="utf-8") as f:
        html = f.read()

    cost_points = [p.get("estimated_cost", 0.0) for p in route_points]
    lat_points = [p.get("estimated_latency_ms", 0.0) for p in route_points]
    svg = ['<svg width="760" height="260" viewBox="0 0 760 260" xmlns="http://www.w3.org/2000/svg" style="background:#020617;border:1px solid #334155;border-radius:12px">']
    svg.append('<text x="16" y="24" fill="#94a3b8" font-size="14">Cost vs Latency (color = predicted accuracy)</text>')
    max_cost = max(cost_points) if cost_points else 1.0
    max_lat = max(lat_points) if lat_points else 1.0
    for p in route_points:
        x = 40 + (680 * (p.get("estimated_cost", 0.0) / max_cost if max_cost else 0.0))
        y = 220 - (160 * (p.get("estimated_latency_ms", 0.0) / max_lat if max_lat else 0.0))
        acc = p.get("predicted_accuracy", 0.0)
        r = int(255 * (1 - acc))
        g = int(255 * acc)
        color = f'rgb({r},{g},120)'
        label = f"{p.get('route_id','')} {p.get('provider','')} {p.get('model','')} cost={p.get('estimated_cost',0):.6f} lat={p.get('estimated_latency_ms',0):.1f} acc={acc:.3f}"
        svg.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="5" fill="{color}"><title>{label}</title></circle>')
    svg.append('</svg>')
    chart_svg = ''.join(svg)

    html = html.replace("{{count}}", str(summary["count"]))
    html = html.replace("{{avg_cost}}", f"{summary['avg_estimated_cost']:.6f}")
    html = html.replace("{{avg_acc}}", f"{summary['avg_predicted_accuracy']:.3f}")
    html = html.replace("{{avg_lat}}", f"{summary['avg_estimated_latency_ms']:.1f}")
    html = html.replace("{{avg_ttft}}", f"{summary.get('avg_ttft_ms', 0.0):.1f}")
    html = html.replace("{{avg_tps}}", f"{summary.get('avg_output_tps', 0.0):.1f}")
    html = html.replace("{{avg_itl}}", f"{summary.get('avg_itl_ms', 0.0):.1f}")
    html = html.replace("{{p95_itl}}", f"{summary.get('p95_itl_ms', 0.0):.1f}")
    html = html.replace("{{provider_counts}}", json.dumps(summary["provider_counts"], indent=2))
    html = html.replace("{{pareto}}", json.dumps(frontier, indent=2))
    html = html.replace("{{recent}}", json.dumps(recent, indent=2))
    html = html.replace("{{per_model}}", json.dumps(per_model_summary, indent=2))
    html = html.replace("{{latency_state}}", json.dumps(latency_state, indent=2))
    html = html.replace("{{queue_state}}", json.dumps(queue_state, indent=2))
    html = html.replace("{{bandit_state}}", json.dumps(bandit_state, indent=2))
    html = html.replace("{{chart}}", chart_svg)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    return {"out_path": out_path, "frontier_points": len(frontier), "rows": len(rows)}


if __name__ == "__main__":
    print(json.dumps(render_dashboard(), indent=2))
