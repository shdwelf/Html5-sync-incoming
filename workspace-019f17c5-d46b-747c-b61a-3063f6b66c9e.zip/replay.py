from __future__ import annotations

import argparse
import csv
import json
from statistics import mean

from policy import LearnedPolicy
from router import CheapestThresholdRouter


def main():
    parser = argparse.ArgumentParser(description="Replay a CSV dataset through the router")
    parser.add_argument("--input", required=True, help="CSV with prompt,provider,success columns or prompt-only column")
    parser.add_argument("--policy", default="", help="Optional learned policy JSON")
    parser.add_argument("--threshold", type=float, default=None)
    args = parser.parse_args()

    static_router = CheapestThresholdRouter(threshold=args.threshold)
    learned = LearnedPolicy.from_file(args.policy, threshold=args.threshold) if args.policy else None

    rows = []
    with open(args.input, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            prompt = row["prompt"]
            if learned:
                features, _norm, quotes = learned.predict_quotes(prompt)
                eligible = [q for q in quotes.values() if q.predicted_accuracy >= learned.threshold]
                chosen = sorted(eligible, key=lambda q: (q.estimated_cost, -q.predicted_accuracy))[0] if eligible else sorted(quotes.values(), key=lambda q: (-q.predicted_accuracy, q.estimated_cost))[0]
                provider = chosen.provider
                pred_acc = chosen.predicted_accuracy
                cost = chosen.estimated_cost
            else:
                d = static_router.route(prompt)
                provider = d.chosen_provider
                pred_acc = d.predicted_accuracy
                cost = d.estimated_cost
            rows.append({"provider": provider, "pred_acc": pred_acc, "cost": cost})

    report = {
        "n": len(rows),
        "avg_cost": mean(r["cost"] for r in rows) if rows else 0.0,
        "local_share": mean(1.0 if r["provider"] == "local" else 0.0 for r in rows) if rows else 0.0,
        "fireworks_share": mean(1.0 if r["provider"] == "fireworks" else 0.0 for r in rows) if rows else 0.0,
        "avg_pred_acc": mean(r["pred_acc"] for r in rows) if rows else 0.0,
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
