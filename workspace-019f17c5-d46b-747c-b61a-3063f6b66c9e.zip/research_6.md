# Research notes: browser SSE UX and chunk-trace histograms

## Browser streaming pattern
For POST-based AI streaming, `fetch()` + `ReadableStream` is the practical browser pattern because native `EventSource` only supports GET and cannot set custom headers. This is a widely recommended SSE consumption strategy in modern AI apps [1](https://dev.to/napster_rj/what-are-server-sent-events-sse-a-developers-guide-for-2026-4jb6) [5](https://www.channel.tel/blog/streaming-ai-responses-sse-websockets-real-time).

## Observability
Useful production streaming metrics include:
- TTFT
- total stream duration
- average ITL
- p95 ITL
- stream completion/error rate
- token throughput

This aligns with current observability guidance for streaming AI systems [2](https://oneuptime.com/blog/post/2026-01-30-llmops-latency-monitoring/view) [4](https://phillippe.siclait.com/blog/llm-benchmarking-from-scratch) [5](https://www.truefoundry.com/blog/observability-in-ai-gateway).

## What was implemented
- browser stream demo page
- chunk-trace persistence
- histogram analytics endpoint/script
- stream endpoint unified with learned/LinUCB selection
- verifier-driven streamed escalation
