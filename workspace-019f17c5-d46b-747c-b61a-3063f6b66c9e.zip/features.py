from __future__ import annotations

import math
import re
from typing import Any, Dict


def featurize(prompt: str) -> Dict[str, Any]:
    text = prompt.strip()
    lower = text.lower()
    words = re.findall(r"\w+", text)
    chars = len(text)
    tokens_est = max(1, math.ceil(chars / 4))

    code_markers = ["def ", "class ", "```", "import ", "stack trace", "error:", "sql", "regex"]
    math_markers = ["solve", "proof", "equation", "integral", "derivative", "matrix", "probability"]
    extraction_markers = ["extract", "json", "table", "entities", "fields", "schema"]
    reasoning_markers = ["why", "compare", "tradeoff", "analyze", "reason", "critique"]
    ambiguity_markers = ["best", "improve", "optimize", "strategy", "creative", "brainstorm"]

    def has_any(markers):
        return any(m in lower for m in markers)

    question_count = text.count("?")
    newline_count = text.count("\n")
    num_count = len(re.findall(r"\d", text))

    return {
        "chars": chars,
        "words": len(words),
        "tokens_est": tokens_est,
        "has_code": has_any(code_markers),
        "has_math": has_any(math_markers),
        "has_extraction": has_any(extraction_markers),
        "has_reasoning": has_any(reasoning_markers),
        "has_ambiguity": has_any(ambiguity_markers),
        "question_count": question_count,
        "newline_count": newline_count,
        "digit_density": 0 if chars == 0 else num_count / chars,
    }
