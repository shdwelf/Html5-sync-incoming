from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from typing import Dict, List, Tuple

from features import featurize
from policy import LearnedPolicy


FEATURE_KEYS = [
    "tokens_est",
    "has_code",
    "has_math",
    "has_extraction",
    "has_reasoning",
    "has_ambiguity",
    "question_count",
    "newline_count",
    "digit_density",
]


def sigmoid(z: float) -> float:
    z = max(min(z, 30), -30)
    return 1.0 / (1.0 + math.exp(-z))


def normalize(features: Dict) -> Dict:
    return LearnedPolicy._normalize(features)


def load_rows(path: str) -> Dict[str, List[Tuple[Dict, int]]]:
    by_provider = defaultdict(list)
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            prompt = row["prompt"]
            provider = row["provider"]
            success = int(row["success"])
            feats = normalize(featurize(prompt))
            by_provider[provider].append((feats, success))
    return by_provider


def fit_logreg(rows: List[Tuple[Dict, int]], epochs: int = 400, lr: float = 0.2, l2: float = 1e-4):
    weights = {k: 0.0 for k in FEATURE_KEYS}
    bias = 0.0

    for _ in range(epochs):
        grad_w = {k: 0.0 for k in FEATURE_KEYS}
        grad_b = 0.0
        n = max(1, len(rows))
        for feats, y in rows:
            z = bias + sum(weights[k] * float(feats[k]) for k in FEATURE_KEYS)
            p = sigmoid(z)
            err = p - y
            grad_b += err
            for k in FEATURE_KEYS:
                grad_w[k] += err * float(feats[k])
        bias -= lr * grad_b / n
        for k in FEATURE_KEYS:
            weights[k] -= lr * (grad_w[k] / n + l2 * weights[k])

    return {"bias": bias, "weights": weights}


def main():
    parser = argparse.ArgumentParser(description="Train provider success calibrators from trace CSV")
    parser.add_argument("--input", required=True, help="CSV with prompt,provider,success columns")
    parser.add_argument("--output", required=True, help="Path to write JSON calibrators")
    args = parser.parse_args()

    rows = load_rows(args.input)
    out = {}
    for provider, provider_rows in rows.items():
        out[provider] = fit_logreg(provider_rows)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    print(json.dumps({"providers": list(out.keys()), "output": args.output}, indent=2))


if __name__ == "__main__":
    main()
