from __future__ import annotations

import json
from statistics import mean
from typing import Dict, List

from trace_store import read_traces


def histogram(values: List[float], buckets: List[float]) -> List[Dict]:
    out = []
    prev = float('-inf')
    for b in buckets:
        count = sum(1 for v in values if prev < v <= b)
        out.append({"le": b, "count": count})
        prev = b
    out.append({"le": "+Inf", "count": sum(1 for v in values if v > buckets[-1]) if buckets else len(values)})
    return out


def summarize_traces() -> Dict:
    rows = read_traces()
    ttfts = [r.get("ttft_ms", 0.0) for r in rows if r.get("ttft_ms") is not None]
    itls = [r.get("avg_itl_ms", 0.0) for r in rows if r.get("avg_itl_ms") is not None]
    tpss = [r.get("output_tps", 0.0) for r in rows if r.get("output_tps") is not None]
    return {
        "count": len(rows),
        "avg_ttft_ms": mean(ttfts) if ttfts else 0.0,
        "avg_itl_ms": mean(itls) if itls else 0.0,
        "avg_output_tps": mean(tpss) if tpss else 0.0,
        "ttft_histogram": histogram(ttfts, [100, 250, 500, 1000, 2000, 5000]),
        "itl_histogram": histogram(itls, [10, 25, 50, 100, 200, 500]),
        "tps_histogram": histogram(tpss, [5, 10, 20, 40, 80, 160, 320]),
    }


if __name__ == "__main__":
    print(json.dumps(summarize_traces(), indent=2))
