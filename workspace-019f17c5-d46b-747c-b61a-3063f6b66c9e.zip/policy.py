from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from config import settings
from features import featurize
from models import build_quotes


@dataclass
class CalibratedModel:
    provider: str
    weights: Dict[str, float]
    bias: float

    def predict(self, features: Dict) -> float:
        z = self.bias
        for k, w in self.weights.items():
            z += w * float(features.get(k, 0.0) if not isinstance(features.get(k), bool) else int(features.get(k)))
        return 1.0 / (1.0 + math.exp(-max(min(z, 30), -30)))


class LearnedPolicy:
    def __init__(self, threshold: float | None = None, models: Optional[Dict[str, CalibratedModel]] = None):
        self.threshold = threshold if threshold is not None else settings.accuracy_threshold
        self.models = models or {}

    @staticmethod
    def _normalize(features: Dict) -> Dict:
        return {
            "bias": 1.0,
            "tokens_est": min(features.get("tokens_est", 0) / 512.0, 8.0),
            "has_code": int(features.get("has_code", False)),
            "has_math": int(features.get("has_math", False)),
            "has_extraction": int(features.get("has_extraction", False)),
            "has_reasoning": int(features.get("has_reasoning", False)),
            "has_ambiguity": int(features.get("has_ambiguity", False)),
            "question_count": min(features.get("question_count", 0), 10) / 10.0,
            "newline_count": min(features.get("newline_count", 0), 20) / 20.0,
            "digit_density": float(features.get("digit_density", 0.0)),
        }

    @classmethod
    def from_file(cls, path: str, threshold: float | None = None) -> "LearnedPolicy":
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        models = {
            provider: CalibratedModel(provider=provider, weights=spec["weights"], bias=spec["bias"])
            for provider, spec in raw.items()
        }
        return cls(threshold=threshold, models=models)

    def predict_quotes(self, prompt: str):
        features = featurize(prompt)
        norm = self._normalize(features)
        quotes = build_quotes(features, tokens_in=features["tokens_est"])
        for provider, model in self.models.items():
            if provider in quotes:
                quotes[provider].predicted_accuracy = model.predict(norm)
        return features, norm, quotes
