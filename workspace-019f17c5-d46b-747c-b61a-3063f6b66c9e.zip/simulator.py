from __future__ import annotations

import json
import random
from statistics import mean

from router import CheapestThresholdRouter


TASKS = [
    "Summarize a 2 paragraph article in 3 bullets.",
    "Solve this probability puzzle and explain each step.",
    "Extract name, email, and company from this message into JSON.",
    "Debug this Python traceback and propose a fix.",
    "Compare two pricing strategies and recommend one.",
    "Rewrite this landing page copy to improve conversion.",
    "Given a SQL query and schema, optimize performance.",
    "Read these meeting notes and list action items.",
]


def latent_accuracy(provider: str, prompt: str) -> float:
    p = prompt.lower()
    score = 0.9 if provider == "fireworks" else 0.82
    if "probability" in p or "solve" in p:
        score -= 0.10 if provider == "fireworks" else 0.22
    if "debug" in p or "python" in p or "sql" in p:
        score -= 0.05 if provider == "fireworks" else 0.12
    if "extract" in p or "json" in p:
        score += 0.02 if provider == "local" else 0.0
    if "rewrite" in p or "conversion" in p:
        score -= 0.02
    return max(0.3, min(0.98, score))


def simulate(n: int = 200):
    router = CheapestThresholdRouter()
    rows = []
    for _ in range(n):
        prompt = random.choice(TASKS)
        decision = router.route(prompt)
        success_prob = latent_accuracy(decision.chosen_provider, prompt)
        success = random.random() < success_prob
        rows.append({
            "prompt": prompt,
            "provider": decision.chosen_provider,
            "pred_acc": decision.predicted_accuracy,
            "success_prob": success_prob,
            "success": success,
            "cost": decision.estimated_cost,
            "met_threshold_prediction": decision.predicted_accuracy >= decision.threshold,
        })

    report = {
        "n": len(rows),
        "avg_cost": mean(r["cost"] for r in rows),
        "success_rate": mean(1.0 if r["success"] else 0.0 for r in rows),
        "predicted_threshold_hit_rate": mean(1.0 if r["met_threshold_prediction"] else 0.0 for r in rows),
        "local_share": mean(1.0 if r["provider"] == "local" else 0.0 for r in rows),
        "fireworks_share": mean(1.0 if r["provider"] == "fireworks" else 0.0 for r in rows),
    }
    return report, rows


if __name__ == "__main__":
    report, rows = simulate()
    print(json.dumps(report, indent=2))
