from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any, Dict
from uuid import uuid4


LOG_PATH = os.getenv("ROUTER_LOG_PATH", "logs/routes.jsonl")


def ensure_parent(path: str):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)


def log_event(event: Dict[str, Any], path: str = LOG_PATH):
    ensure_parent(path)
    payload = {
        "route_id": event.get("route_id") or str(uuid4()),
        "ts": datetime.now(timezone.utc).isoformat(),
        **event,
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(payload) + "\n")
    return payload
