from __future__ import annotations

import argparse
import json

from runtime import route_and_maybe_execute


def run(prompt: str, execute: bool = False, threshold: float | None = None, policy_path: str | None = None, latency_weight: float = 0.0, verify: bool = True, max_tokens: int = 400, stream: bool = False) -> dict:
    return route_and_maybe_execute(
        prompt=prompt,
        execute=execute,
        threshold=threshold,
        policy_path=policy_path,
        latency_weight=latency_weight,
        verify=verify,
        max_tokens=max_tokens,
        stream=stream,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Cost-aware hybrid LLM router")
    parser.add_argument("--prompt", required=True, help="Task prompt to route")
    parser.add_argument("--execute", action="store_true", help="Actually call the selected backend")
    parser.add_argument("--threshold", type=float, default=None)
    parser.add_argument("--policy-path", default=None)
    parser.add_argument("--latency-weight", type=float, default=0.0)
    parser.add_argument("--no-verify", action="store_true")
    parser.add_argument("--max-tokens", type=int, default=400)
    parser.add_argument("--stream", action="store_true")
    args = parser.parse_args()

    print(json.dumps(run(args.prompt, execute=args.execute, threshold=args.threshold, policy_path=args.policy_path, latency_weight=args.latency_weight, verify=not args.no_verify, max_tokens=args.max_tokens, stream=args.stream), indent=2))
