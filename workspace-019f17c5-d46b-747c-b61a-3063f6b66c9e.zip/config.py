import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


def _f(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


@dataclass
class Settings:
    fireworks_api_key: str = os.getenv("FIREWORKS_API_KEY", "")
    fireworks_model: str = os.getenv(
        "FIREWORKS_MODEL",
        "accounts/fireworks/models/llama-v3p1-8b-instruct",
    )
    local_model_name: str = os.getenv("LOCAL_MODEL_NAME", "local-8b")
    local_base_url: str = os.getenv("LOCAL_BASE_URL", "http://localhost:11434")
    accuracy_threshold: float = _f("ACCURACY_THRESHOLD", 0.82)
    local_input_cost_per_1k: float = _f("LOCAL_INPUT_COST_PER_1K", 0.0)
    local_output_cost_per_1k: float = _f("LOCAL_OUTPUT_COST_PER_1K", 0.0)
    fireworks_input_cost_per_1k: float = _f("FIREWORKS_INPUT_COST_PER_1K", 0.0002)
    fireworks_output_cost_per_1k: float = _f("FIREWORKS_OUTPUT_COST_PER_1K", 0.0006)


settings = Settings()
