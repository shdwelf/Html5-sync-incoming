# Research notes: SSE forwarding and per-token analytics

## SSE endpoint design
A practical streaming API should emit:
- an initial route/metadata event
- token events as they arrive
- a final metrics event
- error events on failure

This pattern preserves live UX while still producing structured observability.

## Token timing metrics
Once chunk timestamps are available, useful metrics include:
- TTFT
- average ITL / TPOT
- p50 ITL
- p95 ITL
- chunk count

These are aligned with current streaming observability recommendations emphasizing first-token and post-first-token behavior [1](https://futureagi.com/glossary/time-to-first-token/) [3](https://zylos.ai/research/2026-03-28-llm-output-streaming-token-delivery-architectures/) [5](https://phillippe.siclait.com/blog/llm-benchmarking-from-scratch).

## What was implemented
- FastAPI SSE `/route/stream`
- route event + token events + metrics event
- per-token chunk timestamps
- ITL summary metrics in logs and dashboards
