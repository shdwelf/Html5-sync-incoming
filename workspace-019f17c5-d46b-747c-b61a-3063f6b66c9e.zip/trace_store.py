from __future__ import annotations

import json
import os
from typing import Any, Dict, List

TRACE_PATH = "logs/chunk_traces.jsonl"


def append_trace(payload: Dict[str, Any], path: str = TRACE_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(payload) + "\n")


def read_traces(path: str = TRACE_PATH) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows
