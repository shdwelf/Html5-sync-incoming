from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from statistics import mean

from policy import LearnedPolicy
from router import CheapestThresholdRouter


def latent_cost(provider: str) -> float:
    return 0.0 if provider == "local" else 0.0002


def oracle_choice(rows_for_prompt):
    success_rows = [r for r in rows_for_prompt if int(r.get("success", 0)) == 1]
    if success_rows:
        return sorted(success_rows, key=lambda r: latent_cost(r["provider"]))[0]
    return sorted(rows_for_prompt, key=lambda r: (0 if int(r.get("success", 0)) == 1 else 1, latent_cost(r["provider"])))[0]


def evaluate(input_path: str, policy_path: str = "", threshold: float | None = None):
    learned = LearnedPolicy.from_file(policy_path, threshold=threshold) if policy_path else None
    router = CheapestThresholdRouter(threshold=threshold)

    grouped = defaultdict(list)
    with open(input_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        for row in rows:
            grouped[row["prompt"]].append(row)

    regrets = []
    chosen_providers = []
    for prompt, candidates in grouped.items():
        oracle = oracle_choice(candidates)
        oracle_reward = float(int(oracle.get("success", 0))) - latent_cost(oracle["provider"])
        if learned:
            features, _norm, quotes = learned.predict_quotes(prompt)
            eligible = [q for q in quotes.values() if q.predicted_accuracy >= learned.threshold]
            chosen = sorted(eligible, key=lambda q: (q.estimated_cost, q.estimated_latency_ms, -q.predicted_accuracy))[0] if eligible else sorted(quotes.values(), key=lambda q: (-q.predicted_accuracy, q.estimated_cost))[0]
            chosen_provider = chosen.provider
            chosen_cost = chosen.estimated_cost
        else:
            d = router.route(prompt)
            chosen_provider = d.chosen_provider
            chosen_cost = d.estimated_cost

        matching = [r for r in candidates if r["provider"] == chosen_provider]
        chosen_success = float(int(matching[0].get("success", 0))) if matching else 0.0
        chosen_reward = chosen_success - chosen_cost
        regrets.append(oracle_reward - chosen_reward)
        chosen_providers.append(chosen_provider)

    return {
        "n_prompts": len(grouped),
        "avg_regret": mean(regrets) if regrets else 0.0,
        "max_regret": max(regrets) if regrets else 0.0,
        "provider_mix": {
            "local": mean(1.0 if p == "local" else 0.0 for p in chosen_providers) if chosen_providers else 0.0,
            "fireworks": mean(1.0 if p == "fireworks" else 0.0 for p in chosen_providers) if chosen_providers else 0.0,
        },
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Oracle/regret evaluator")
    parser.add_argument("--input", required=True)
    parser.add_argument("--policy", default="")
    parser.add_argument("--threshold", type=float, default=None)
    args = parser.parse_args()
    print(json.dumps(evaluate(args.input, args.policy, args.threshold), indent=2))
