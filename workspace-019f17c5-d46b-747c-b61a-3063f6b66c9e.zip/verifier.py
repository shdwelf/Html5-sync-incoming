from __future__ import annotations

import json
import re
from typing import Tuple


def _extract_code_block(text: str) -> str:
    blocks = re.findall(r"```(?:python|json|javascript|js|sql)?\n(.*?)```", text, re.S)
    return blocks[0] if blocks else text


def verify_response(prompt: str, response: str) -> Tuple[bool, str]:
    text = (response or "").strip()
    p = prompt.lower()

    if not text or text.startswith("[") and "failed" in text.lower():
        return False, "empty or failed generation"

    if "json" in p or "schema" in p:
        candidate = _extract_code_block(text)
        try:
            obj = json.loads(candidate)
            if isinstance(obj, (dict, list)):
                return True, "valid json"
            return False, "json parsed but wrong top-level type"
        except Exception:
            return False, "invalid json"

    if any(k in p for k in ["python", "javascript", "sql", "debug", "traceback", "error"]):
        candidate = _extract_code_block(text)
        if len(candidate.split()) < 12:
            return False, "code/debug answer too short"
        if not any(tok in text.lower() for tok in ["fix", "change", "because", "issue", "error", "solution"]):
            return False, "missing remediation explanation"
        return True, "code/debug answer passes heuristic checks"

    if any(k in p for k in ["extract", "fields", "entities"]):
        if len(text.split()) < 6:
            return False, "extraction answer too short"
        return True, "extraction answer passes minimum completeness"

    if any(k in p for k in ["summarize", "summary", "bullets"]):
        bullet_like = len(re.findall(r"^\s*[-*•]", text, re.M))
        if bullet_like >= 2 or len(text.splitlines()) >= 3:
            return True, "summary structure looks complete"
        return False, "summary too short or missing bullet structure"

    if any(k in p for k in ["solve", "proof", "compare", "analyze", "why"]):
        if len(text.split()) < 40:
            return False, "reasoning answer too short"
        if any(m in text.lower() for m in ["not sure", "maybe", "uncertain", "cannot determine"]):
            return False, "contains uncertainty markers"
        return True, "reasoning answer passes heuristic checks"

    return len(text.split()) >= 12, "generic minimum completeness check"
