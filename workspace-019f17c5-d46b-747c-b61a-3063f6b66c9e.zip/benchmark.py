from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from statistics import mean

from policy import LearnedPolicy
from router import CheapestThresholdRouter


def leaderboard(input_path: str, policy_path: str = "", threshold: float | None = None):
    learned = LearnedPolicy.from_file(policy_path, threshold=threshold) if policy_path else None
    router = CheapestThresholdRouter(threshold=threshold)
    provider_rows = defaultdict(list)
    route_rows = []

    with open(input_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            prompt = row["prompt"]
            provider = row.get("provider", "")
            success = int(row.get("success", 0)) if row.get("success") not in (None, "") else None
            if provider:
                provider_rows[provider].append(success)
            if learned:
                features, _norm, quotes = learned.predict_quotes(prompt)
                eligible = [q for q in quotes.values() if q.predicted_accuracy >= learned.threshold]
                chosen = sorted(eligible, key=lambda q: (q.estimated_cost, q.estimated_latency_ms, -q.predicted_accuracy))[0] if eligible else sorted(quotes.values(), key=lambda q: (-q.predicted_accuracy, q.estimated_cost))[0]
            else:
                d = router.route(prompt)
                chosen = type("Obj", (), {"provider": d.chosen_provider, "predicted_accuracy": d.predicted_accuracy, "estimated_cost": d.estimated_cost})
            route_rows.append(chosen)

    report = {"baselines": {}, "router": {}}
    for provider, vals in provider_rows.items():
        clean = [v for v in vals if v is not None]
        report["baselines"][provider] = {"success_rate": mean(clean) if clean else None, "n": len(clean)}

    report["router"] = {
        "n": len(route_rows),
        "avg_cost": mean(getattr(r, "estimated_cost", 0.0) for r in route_rows) if route_rows else 0.0,
        "avg_pred_acc": mean(getattr(r, "predicted_accuracy", 0.0) for r in route_rows) if route_rows else 0.0,
        "provider_mix": {
            "local": mean(1.0 if getattr(r, "provider", "") == "local" else 0.0 for r in route_rows) if route_rows else 0.0,
            "fireworks": mean(1.0 if getattr(r, "provider", "") == "fireworks" else 0.0 for r in route_rows) if route_rows else 0.0,
        },
    }
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Leaderboard / benchmark summary")
    parser.add_argument("--input", required=True)
    parser.add_argument("--policy", default="")
    parser.add_argument("--threshold", type=float, default=None)
    args = parser.parse_args()
    print(json.dumps(leaderboard(args.input, args.policy, args.threshold), indent=2))
