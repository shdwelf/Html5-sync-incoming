from __future__ import annotations

from dataclasses import dataclass
from typing import List

from config import settings


@dataclass
class ModelSpec:
    provider: str
    model: str
    input_cost_per_1k: float
    output_cost_per_1k: float
    ttft_ms: float
    tps: float
    quality_bias: float = 0.0
    endpoint: str = ""


def get_model_catalog() -> List[ModelSpec]:
    return [
        ModelSpec(
            provider="local",
            model="local-3b",
            input_cost_per_1k=0.0,
            output_cost_per_1k=0.0,
            ttft_ms=120,
            tps=90,
            quality_bias=-0.10,
            endpoint=settings.local_base_url,
        ),
        ModelSpec(
            provider="local",
            model=settings.local_model_name,
            input_cost_per_1k=settings.local_input_cost_per_1k,
            output_cost_per_1k=settings.local_output_cost_per_1k,
            ttft_ms=180,
            tps=65,
            quality_bias=0.0,
            endpoint=settings.local_base_url,
        ),
        ModelSpec(
            provider="fireworks",
            model="accounts/fireworks/models/llama-v3p1-8b-instruct",
            input_cost_per_1k=0.0002,
            output_cost_per_1k=0.0006,
            ttft_ms=180,
            tps=210,
            quality_bias=0.03,
            endpoint="https://api.fireworks.ai/inference/v1/chat/completions",
        ),
        ModelSpec(
            provider="fireworks",
            model="accounts/fireworks/models/llama-v3p3-70b-instruct",
            input_cost_per_1k=0.0009,
            output_cost_per_1k=0.0009,
            ttft_ms=220,
            tps=145,
            quality_bias=0.08,
            endpoint="https://api.fireworks.ai/inference/v1/chat/completions",
        ),
    ]
    adjusted = []
    for spec in specs:
        ttft_ms, tps = get_latency_overrides(spec.model)
        spec.ttft_ms = float(ttft_ms) if ttft_ms is not None else spec.ttft_ms
        spec.tps = float(tps) if tps is not None else spec.tps
        spec.ttft_ms += get_queue_penalty_ms(spec.model)
        adjusted.append(spec)
    return adjusted
