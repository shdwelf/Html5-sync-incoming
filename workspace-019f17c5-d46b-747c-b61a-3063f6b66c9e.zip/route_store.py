from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional

STORE_PATH = "logs/route_store.jsonl"


def append_route(payload: Dict[str, Any], path: str = STORE_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(payload) + "\n")


def get_route(route_id: str, path: str = STORE_PATH) -> Optional[Dict[str, Any]]:
    if not os.path.exists(path):
        return None
    found = None
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            if row.get("route_id") == route_id:
                found = row
    return found
