from __future__ import annotations


def shaped_reward(success: int, cost: float, latency_ms: float, alpha: float = 1.0, beta: float = 0.0001) -> float:
    return float(success) - alpha * float(cost) - beta * float(latency_ms)
