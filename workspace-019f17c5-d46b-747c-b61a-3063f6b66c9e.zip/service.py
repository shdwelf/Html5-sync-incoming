from __future__ import annotations

import json
from typing import Optional

from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from latency_learning import load_latency_state, update_latency
from linucb import featurize_context, load_state as load_linucb_state, update as update_linucb
from logging_utils import log_event
from metrics import summarize_logs
from online_learning import update_from_outcome
from queue_state import load_queue_state, on_complete, on_dispatch
from rewarding import shaped_reward
from route_store import append_route, get_route
from runtime import route_and_maybe_execute
from router import CheapestThresholdRouter
from streaming_server import stream_fireworks, stream_local, trace_metrics
from trace_store import append_trace
from policy_runtime import choose_decision


app = FastAPI(title="Hybrid LLM Router", version="0.6.0")


class RouteRequest(BaseModel):
    prompt: str
    execute: bool = False
    threshold: Optional[float] = None
    policy_path: Optional[str] = None
    latency_weight: Optional[float] = 0.0
    verify: bool = True
    max_tokens: int = 400
    stream: bool = False


class OutcomeRequest(BaseModel):
    route_id: Optional[str] = None
    provider: Optional[str] = None
    model: Optional[str] = None
    predicted_accuracy: Optional[float] = None
    success: int


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/metrics")
def metrics():
    return summarize_logs()


@app.get("/metrics/models")
def metrics_models():
    return load_latency_state().get("models", {})


@app.get("/metrics/latency_state")
def metrics_latency_state():
    return load_latency_state()


@app.get("/metrics/queue_state")
def metrics_queue_state():
    return load_queue_state()


@app.get("/metrics/bandit_state")
def metrics_bandit_state():
    return load_linucb_state()


@app.post("/feedback")
def feedback(req: OutcomeRequest):
    prior = None
    if req.route_id:
        prior = get_route(req.route_id)
        if not prior:
            return {"ok": False, "error": "route_id not found"}
        d = prior.get("decision", {})
        provider = d.get("chosen_provider")
        model = d.get("chosen_model")
        predicted_accuracy = float(d.get("predicted_accuracy", 0.0))
        estimated_cost = float(d.get("estimated_cost", 0.0))
    else:
        provider = req.provider
        model = req.model
        predicted_accuracy = float(req.predicted_accuracy or 0.0)
        estimated_cost = 0.0

    state = update_from_outcome(provider, model, predicted_accuracy, req.success)
    observed_latency_ms = float(prior.get("observed_latency_ms", 0.0)) if prior else 0.0
    reward = shaped_reward(req.success, estimated_cost, observed_latency_ms)
    features = prior.get("decision", {}).get("features", {}) if prior else {}
    threshold = float(prior.get("decision", {}).get("threshold", 0.82)) if prior else 0.82
    context = featurize_context(features, 0.0, threshold)
    linucb_state = update_linucb(model, context, reward)
    payload = log_event({
        "route_id": req.route_id,
        "outcome": {"success": req.success},
        "feedback": {"provider": provider, "model": model, "predicted_accuracy": predicted_accuracy},
    })
    return {"ok": True, "state": state, "linucb_state": linucb_state, "logged": payload}


@app.post("/route")
def route(req: RouteRequest):
    return route_and_maybe_execute(
        prompt=req.prompt,
        execute=req.execute,
        threshold=req.threshold,
        policy_path=req.policy_path,
        latency_weight=float(req.latency_weight or 0.0),
        verify=req.verify,
        max_tokens=req.max_tokens,
        stream=req.stream,
    )


@app.post("/route/stream")
def route_stream(req: RouteRequest):
    router = CheapestThresholdRouter(threshold=req.threshold, latency_weight=req.latency_weight)
    decision = router.route(req.prompt)

    def event_stream():
        route_meta = log_event({
            "decision": decision.__dict__,
            "response": None,
            "streaming": True,
        })
        route_id = route_meta["route_id"]
        yield f"event: route\ndata: {json.dumps({'route_id': route_id, 'decision': decision.__dict__})}\n\n"

        on_dispatch(decision.chosen_model)
        try:
            gen = stream_local(req.prompt, decision.chosen_model, req.max_tokens) if decision.chosen_provider == "local" else stream_fireworks(req.prompt, decision.chosen_model, req.max_tokens)
            while True:
                try:
                    item = next(gen)
                    yield f"event: token\ndata: {json.dumps(item)}\n\n"
                except StopIteration as done:
                    trace = done.value
                    metrics = trace_metrics(trace)
                    update_latency(decision.chosen_model, metrics['total_latency_ms'], metrics['output_tokens_est'], ttft_ms=metrics['ttft_ms'], tps=metrics['output_tps'])
                    on_complete(decision.chosen_model, metrics['total_latency_ms'])
                    payload = log_event({
                        "route_id": route_id,
                        "decision": decision.__dict__,
                        "response": trace.text,
                        "observed_latency_ms": metrics["total_latency_ms"],
                        "ttft_ms": metrics["ttft_ms"],
                        "output_tps": metrics["output_tps"],
                        "output_tokens_est": metrics["output_tokens_est"],
                        "avg_itl_ms": metrics["avg_itl_ms"],
                        "p50_itl_ms": metrics["p50_itl_ms"],
                        "p95_itl_ms": metrics["p95_itl_ms"],
                        "chunk_count": metrics["chunk_count"],
                        "streaming": True,
                    })
                    append_route(payload)
                    yield f"event: metrics\ndata: {json.dumps(metrics)}\n\n"
                    break
        except Exception as e:
            on_complete(decision.chosen_model, 0.0)
            yield f"event: error\ndata: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")
