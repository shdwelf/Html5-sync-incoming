# Additional research notes

## Online latency learning
A practical latency model can start with:
- TTFT estimate
- decode TPS estimate
- queue penalty

A common decomposition is:
- total latency = TTFT + decode_time + queue/network overhead
- decode_time ≈ output_tokens / TPS

This matches standard benchmarking guidance around TTFT, TPOT/TBT, and end-to-end latency [1](https://phillippe.siclait.com/blog/llm-benchmarking-from-scratch) [3](https://www.digitalocean.com/blog/llm-inference-benchmarking) [4](https://www.databricks.com/blog/llm-inference-performance-engineering-best-practices).

## Reward-shaped bandits
Multi-objective routing is naturally modeled as contextual bandits. Reward shaping that mixes quality, cost, and latency is aligned with recent routing work [1](https://www.researchgate.net/publication/396374011_Learning_to_Route_LLMs_from_Bandit_Feedback_One_Policy_Many_Trade-offs) [3](https://arxiv.org/html/2508.21141v1) [4](https://arxiv.org/html/2510.07429v1).

## Queue-aware routing
Queue time can dominate user-perceived latency under load, so routing should include service depth and average service time estimates, not just raw model speed [2](https://infercom.ai/blog/llm-inference-speed-explained/) [5](https://www.clarifai.com/blog/llm-inference-optimization/).

## What was implemented
- unified runtime path for CLI + API
- observed latency updates into model state
- queue penalty into estimated latency
- oracle/regret evaluator
- richer dashboard scatter plot and route tooltips
