from __future__ import annotations

import json
import math
import os
from typing import Dict, List

STATE_PATH = "artifacts/linucb_state.json"
FEATURE_KEYS = [
    "tokens_est",
    "has_code",
    "has_math",
    "has_extraction",
    "has_reasoning",
    "has_ambiguity",
    "question_count",
    "newline_count",
    "digit_density",
    "latency_weight",
    "threshold",
]


def _default():
    return {"arms": {}, "alpha": 0.8}


def load_state(path: str = STATE_PATH) -> Dict:
    if not os.path.exists(path):
        return _default()
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_state(state: Dict, path: str = STATE_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def featurize_context(features: Dict, latency_weight: float, threshold: float) -> List[float]:
    return [
        min(float(features.get("tokens_est", 0)) / 512.0, 8.0),
        float(int(bool(features.get("has_code", False)))),
        float(int(bool(features.get("has_math", False)))),
        float(int(bool(features.get("has_extraction", False)))),
        float(int(bool(features.get("has_reasoning", False)))),
        float(int(bool(features.get("has_ambiguity", False)))),
        min(float(features.get("question_count", 0)), 10.0) / 10.0,
        min(float(features.get("newline_count", 0)), 20.0) / 20.0,
        float(features.get("digit_density", 0.0)),
        float(latency_weight),
        float(threshold),
    ]


def _identity(n: int):
    return [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]


def _mat_vec(A, x):
    return [sum(A[i][j] * x[j] for j in range(len(x))) for i in range(len(A))]


def _vec_dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def _outer_add(A, x):
    n = len(x)
    for i in range(n):
        for j in range(n):
            A[i][j] += x[i] * x[j]
    return A


def _invert(matrix):
    n = len(matrix)
    A = [row[:] for row in matrix]
    I = _identity(n)
    for i in range(n):
        pivot = A[i][i]
        if abs(pivot) < 1e-9:
            pivot = 1e-9
            A[i][i] = pivot
        inv_pivot = 1.0 / pivot
        for j in range(n):
            A[i][j] *= inv_pivot
            I[i][j] *= inv_pivot
        for k in range(n):
            if k == i:
                continue
            factor = A[k][i]
            for j in range(n):
                A[k][j] -= factor * A[i][j]
                I[k][j] -= factor * I[i][j]
    return I


def score(model: str, context: List[float], path: str = STATE_PATH) -> float:
    state = load_state(path)
    alpha = float(state.get("alpha", 0.8))
    n = len(context)
    arm = state.setdefault("arms", {}).setdefault(model, {"A": _identity(n), "b": [0.0] * n, "pulls": 0})
    A_inv = _invert(arm["A"])
    theta = _mat_vec(A_inv, arm["b"])
    exploit = _vec_dot(theta, context)
    Ax = _mat_vec(A_inv, context)
    explore = math.sqrt(max(1e-9, _vec_dot(context, Ax)))
    return exploit + alpha * explore


def update(model: str, context: List[float], reward: float, path: str = STATE_PATH):
    state = load_state(path)
    n = len(context)
    arm = state.setdefault("arms", {}).setdefault(model, {"A": _identity(n), "b": [0.0] * n, "pulls": 0})
    arm["A"] = _outer_add(arm["A"], context)
    arm["b"] = [float(arm["b"][i]) + float(reward) * float(context[i]) for i in range(n)]
    arm["pulls"] = int(arm.get("pulls", 0)) + 1
    save_state(state, path)
    return state
