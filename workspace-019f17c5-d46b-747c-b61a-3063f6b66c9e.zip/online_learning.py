from __future__ import annotations

import json
import os
from collections import defaultdict
from typing import Dict


STATE_PATH = "artifacts/online_state.json"


def _default_state():
    return {
        "provider_adjustments": {},
        "model_adjustments": {},
        "counts": {},
    }


def load_state(path: str = STATE_PATH) -> Dict:
    if not os.path.exists(path):
        return _default_state()
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_state(state: Dict, path: str = STATE_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def get_adjustment(provider: str, model: str, path: str = STATE_PATH) -> float:
    state = load_state(path)
    return float(state.get("provider_adjustments", {}).get(provider, 0.0)) + float(state.get("model_adjustments", {}).get(model, 0.0))


def update_from_outcome(provider: str, model: str, predicted_accuracy: float, success: int, lr: float = 0.05, path: str = STATE_PATH):
    state = load_state(path)
    p_adj = float(state.setdefault("provider_adjustments", {}).get(provider, 0.0))
    m_adj = float(state.setdefault("model_adjustments", {}).get(model, 0.0))
    err = float(success) - float(predicted_accuracy)
    state["provider_adjustments"][provider] = max(min(p_adj + lr * err * 0.6, 0.2), -0.2)
    state["model_adjustments"][model] = max(min(m_adj + lr * err * 0.4, 0.2), -0.2)
    counts = state.setdefault("counts", {})
    counts[model] = int(counts.get(model, 0)) + 1
    save_state(state, path)
    return state
