from __future__ import annotations

import json
import os
from typing import Dict

STATE_PATH = "artifacts/latency_state.json"


def _default():
    return {"models": {}}


def load_latency_state(path: str = STATE_PATH) -> Dict:
    if not os.path.exists(path):
        return _default()
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_latency_state(state: Dict, path: str = STATE_PATH):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def get_latency_overrides(model: str, path: str = STATE_PATH):
    state = load_latency_state(path)
    m = state.get("models", {}).get(model, {})
    return m.get("ttft_ms"), m.get("tps")


def update_latency(model: str, observed_latency_ms: float, output_tokens: int, ttft_ms: float | None = None, tps: float | None = None, alpha: float = 0.2, path: str = STATE_PATH):
    state = load_latency_state(path)
    models = state.setdefault("models", {})
    current = models.setdefault(model, {"ttft_ms": None, "tps": None, "n": 0})
    n = int(current.get("n", 0)) + 1

    if ttft_ms is None:
        ttft_ms = max(20.0, 0.25 * float(observed_latency_ms))
    if tps is None:
        decode_ms = max(1.0, float(observed_latency_ms) - float(ttft_ms))
        tps = max(1.0, 1000.0 * float(max(output_tokens, 1)) / decode_ms)

    prev_ttft = current.get("ttft_ms")
    prev_tps = current.get("tps")
    current["ttft_ms"] = float(ttft_ms) if prev_ttft is None else (1 - alpha) * float(prev_ttft) + alpha * float(ttft_ms)
    current["tps"] = float(tps) if prev_tps is None else (1 - alpha) * float(prev_tps) + alpha * float(tps)
    current["n"] = n
    save_latency_state(state, path)
    return state
