from __future__ import annotations

import json
import os
from collections import Counter
from statistics import mean
from typing import Dict, List


def read_jsonl(path: str) -> List[Dict]:
    if not os.path.exists(path):
        return []
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def summarize_logs(path: str = "logs/routes.jsonl") -> Dict:
    rows = read_jsonl(path)
    if not rows:
        return {
            "count": 0,
            "avg_estimated_cost": 0.0,
            "avg_predicted_accuracy": 0.0,
            "avg_estimated_latency_ms": 0.0,
            "avg_ttft_ms": 0.0,
            "avg_output_tps": 0.0,
            "provider_counts": {},
            "success_rate": None,
        }

    provider_counts = Counter(r.get("decision", {}).get("chosen_provider", "unknown") for r in rows)
    costs = [r.get("decision", {}).get("estimated_cost", 0.0) for r in rows]
    accs = [r.get("decision", {}).get("predicted_accuracy", 0.0) for r in rows]
    lats = [r.get("decision", {}).get("estimated_latency_ms", 0.0) for r in rows]
    ttfts = [r.get("ttft_ms", 0.0) for r in rows if r.get("ttft_ms") is not None]
    tpss = [r.get("output_tps", 0.0) for r in rows if r.get("output_tps") is not None]
    itls = [r.get("avg_itl_ms", 0.0) for r in rows if r.get("avg_itl_ms") is not None]
    p50s = [r.get("p50_itl_ms", 0.0) for r in rows if r.get("p50_itl_ms") is not None]
    p95s = [r.get("p95_itl_ms", 0.0) for r in rows if r.get("p95_itl_ms") is not None]
    outcomes = [r.get("outcome", {}).get("success") for r in rows if isinstance(r.get("outcome"), dict) and "success" in r.get("outcome", {})]

    return {
        "count": len(rows),
        "avg_estimated_cost": mean(costs) if costs else 0.0,
        "avg_predicted_accuracy": mean(accs) if accs else 0.0,
        "avg_estimated_latency_ms": mean(lats) if lats else 0.0,
        "avg_ttft_ms": mean(ttfts) if ttfts else 0.0,
        "avg_output_tps": mean(tpss) if tpss else 0.0,
        "avg_itl_ms": mean(itls) if itls else 0.0,
        "p50_itl_ms": mean(p50s) if p50s else 0.0,
        "p95_itl_ms": mean(p95s) if p95s else 0.0,
        "provider_counts": dict(provider_counts),
        "success_rate": mean(outcomes) if outcomes else None,
    }
