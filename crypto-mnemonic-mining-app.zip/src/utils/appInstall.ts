// Utilities for downloading the app as a standalone HTML file
// and installing it to the browser as a PWA.

// Download the entire running application as a single, offline-capable HTML file.
// Because the production build is inlined into one index.html (vite-singlefile),
// the current document's outerHTML *is* the complete standalone application.
export function downloadSelf(): void {
  // Capture the full document including doctype
  const doctype = document.doctype
    ? `<!DOCTYPE ${document.doctype.name}>`
    : '<!DOCTYPE html>';
  const html = document.documentElement.outerHTML;
  const fullHtml = `${doctype}\n${html}`;

  const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = 'bip39-exhaustive-recovery-standalone.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  // Clean up the object URL after a short delay
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

// --- PWA / Install to Browser support ---

let deferredPrompt: any = null;

export function registerInstallPrompt(onAvailable: (available: boolean) => void): () => void {
  const handler = (e: Event) => {
    e.preventDefault();
    deferredPrompt = e;
    onAvailable(true);
  };

  const installedHandler = () => {
    deferredPrompt = null;
    onAvailable(false);
  };

  window.addEventListener('beforeinstallprompt', handler);
  window.addEventListener('appinstalled', installedHandler);

  return () => {
    window.removeEventListener('beforeinstallprompt', handler);
    window.removeEventListener('appinstalled', installedHandler);
  };
}

export async function installToBrowser(): Promise<'accepted' | 'dismissed' | 'unavailable'> {
  if (!deferredPrompt) {
    return 'unavailable';
  }
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  deferredPrompt = null;
  return outcome;
}

export function isStandalone(): boolean {
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    // iOS Safari
    (window.navigator as any).standalone === true
  );
}

// Register a service worker generated at runtime so the app caches itself for offline use.
export function registerServiceWorker(): void {
  if (!('serviceWorker' in navigator)) return;

  // Build a minimal service worker as a blob so we don't need a separate file in the
  // single-file build. It caches the start URL (the inlined index.html) for offline use.
  const swSource = `
    const CACHE = 'bip39-recovery-v1';
    self.addEventListener('install', (e) => {
      self.skipWaiting();
    });
    self.addEventListener('activate', (e) => {
      e.waitUntil(self.clients.claim());
    });
    self.addEventListener('fetch', (e) => {
      e.respondWith(
        caches.open(CACHE).then(async (cache) => {
          const cached = await cache.match(e.request);
          if (cached) return cached;
          try {
            const resp = await fetch(e.request);
            if (e.request.method === 'GET' && resp.ok) {
              cache.put(e.request, resp.clone());
            }
            return resp;
          } catch (err) {
            const fallback = await cache.match('./');
            if (fallback) return fallback;
            throw err;
          }
        })
      );
    });
  `;

  try {
    const blob = new Blob([swSource], { type: 'text/javascript' });
    const swUrl = URL.createObjectURL(blob);
    navigator.serviceWorker.register(swUrl).catch(() => {
      /* registration may fail in sandboxed iframes; ignore silently */
    });
  } catch (e) {
    /* ignore */
  }
}

// Generate a web app manifest at runtime and inject it so "Install to Browser" works
// even in the single-file build (no external manifest.json needed).
export function injectManifest(): void {
  const icon =
    'data:image/svg+xml;base64,' +
    btoa(`<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
      <rect width="512" height="512" rx="96" fill="#0f172a"/>
      <text x="50%" y="54%" font-size="280" text-anchor="middle" dominant-baseline="middle">🔐</text>
    </svg>`);

  const manifest = {
    name: 'BIP39 Exhaustive Recovery Engine',
    short_name: 'BIP39 Recovery',
    description: 'Offline cryptocurrency wallet recovery, BIP39 explorer and vanity miner.',
    start_url: '.',
    scope: '.',
    display: 'standalone',
    background_color: '#020617',
    theme_color: '#4f46e5',
    icons: [
      { src: icon, sizes: '192x192', type: 'image/svg+xml', purpose: 'any maskable' },
      { src: icon, sizes: '512x512', type: 'image/svg+xml', purpose: 'any maskable' },
    ],
  };

  const blob = new Blob([JSON.stringify(manifest)], { type: 'application/json' });
  const manifestUrl = URL.createObjectURL(blob);

  let link = document.querySelector('link[rel="manifest"]') as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement('link');
    link.rel = 'manifest';
    document.head.appendChild(link);
  }
  link.href = manifestUrl;

  // Theme color meta
  if (!document.querySelector('meta[name="theme-color"]')) {
    const meta = document.createElement('meta');
    meta.name = 'theme-color';
    meta.content = '#4f46e5';
    document.head.appendChild(meta);
  }
}
