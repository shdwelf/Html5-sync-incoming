import * as bip39 from 'bip39';
import { ethers } from 'ethers';
import bananojs from '@bananocoin/bananojs';

export const BIP39_WORDLIST = (bip39 as any).wordlists.english;

export function validateMnemonic(mnemonic: string): boolean {
  return bip39.validateMnemonic(mnemonic);
}

// Base58Check Encoder for Bitcoin Address Derivation
const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

export function encodeBase58(buffer: Uint8Array): string {
  let x = BigInt(0);
  for (let i = 0; i < buffer.length; i++) {
    x = (x << 8n) + BigInt(buffer[i]);
  }
  
  let result = '';
  while (x > 0n) {
    const remainder = Number(x % 58n);
    result = BASE58_ALPHABET[remainder] + result;
    x = x / 58n;
  }
  
  for (let i = 0; i < buffer.length; i++) {
    if (buffer[i] === 0) {
      result = '1' + result;
    } else {
      break;
    }
  }
  
  return result;
}

export function encodeBase58Check(version: number, payload: Uint8Array): string {
  const buf = new Uint8Array(payload.length + 1);
  buf[0] = version;
  buf.set(payload, 1);
  
  const hash1 = ethers.getBytes(ethers.sha256(buf));
  const hash2 = ethers.getBytes(ethers.sha256(hash1));
  
  const finalBuf = new Uint8Array(buf.length + 4);
  finalBuf.set(buf);
  finalBuf.set(hash2.slice(0, 4), buf.length);
  
  return encodeBase58(finalBuf);
}

// Derive a legacy Bitcoin (P2PKH) address from a compressed public key
export function deriveBitcoinAddress(publicKeyHex: string): string {
  const cleanPub = publicKeyHex.startsWith('0x') ? publicKeyHex : '0x' + publicKeyHex;
  const sha256Hash = ethers.getBytes(ethers.sha256(cleanPub));
  const ripemd160Hash = ethers.getBytes(ethers.ripemd160(sha256Hash));
  return encodeBase58Check(0x00, ripemd160Hash);
}

// Derive Banano address from private key
export async function deriveBananoAddress(privateKeyHex: string): Promise<string> {
  const bjs = bananojs as any;
  const cleanPriv = privateKeyHex.startsWith('0x') ? privateKeyHex.slice(2) : privateKeyHex;
  const publicKey = await bjs.getPublicKey(cleanPriv);
  return bjs.getBananoAccount(publicKey);
}

// Levenshtein distance for typo matching
export function levenshteinDistance(a: string, b: string): number {
  const tmp: number[][] = [];
  for (let i = 0; i <= a.length; i++) {
    tmp[i] = [i];
  }
  for (let j = 0; j <= b.length; j++) {
    tmp[0][j] = j;
  }
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      tmp[i][j] = Math.min(
        tmp[i - 1][j] + 1,
        tmp[i][j - 1] + 1,
        tmp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return tmp[a.length][b.length];
}

// Find anagrams of a word in the BIP39 wordlist
export function findAnagrams(word: string): string[] {
  const sortedTarget = word.toLowerCase().split('').sort().join('');
  return BIP39_WORDLIST.filter((w: string) => w.split('').sort().join('') === sortedTarget);
}

// Find typo corrections (edit distance <= 2)
export function findCloseMatches(word: string, maxDistance = 2): string[] {
  return BIP39_WORDLIST.filter((w: string) => levenshteinDistance(word.toLowerCase(), w) <= maxDistance);
}

// Derive Address based on Coin Type and Path
export async function deriveAddressFromMnemonic(
  mnemonic: string,
  coinType: string,
  path: string,
  password = ''
): Promise<{ address: string; privateKey: string; publicKey: string }> {
  const mnemonicInstance = ethers.Mnemonic.fromPhrase(mnemonic, password);
  const hdNode = ethers.HDNodeWallet.fromMnemonic(mnemonicInstance, path);

  let address = hdNode.address;
  if (coinType === 'BTC') {
    address = deriveBitcoinAddress(hdNode.publicKey);
  } else if (coinType === 'BAN') {
    address = await deriveBananoAddress(hdNode.privateKey);
  }

  return {
    address,
    privateKey: hdNode.privateKey,
    publicKey: hdNode.publicKey
  };
}

// Advanced BIP39/BIP44 Derivation Details (inspired by Ian Coleman's tool)
export async function deriveBIP39Details(
  phrase: string,
  password = '',
  customPath = "m/44'/60'/0'/0/0",
  coinType = 'ETH'
) {
  const mnemonicObj = ethers.Mnemonic.fromPhrase(phrase, password);
  const seed = mnemonicObj.computeSeed();
  const hdNode = ethers.HDNodeWallet.fromMnemonic(mnemonicObj);

  // Derive multiple accounts for the table (e.g., first 10 accounts)
  const derivedAccounts = [];
  const basePath = customPath.substring(0, customPath.lastIndexOf('/'));
  
  for (let i = 0; i < 10; i++) {
    const derivationPath = `${basePath}/${i}`;
    const childNode = hdNode.derivePath(derivationPath);
    let derivedAddress = childNode.address;
    
    if (coinType === 'BTC') {
      derivedAddress = deriveBitcoinAddress(childNode.publicKey);
    } else if (coinType === 'BAN') {
      derivedAddress = await deriveBananoAddress(childNode.privateKey);
    }

    derivedAccounts.push({
      index: i,
      path: derivationPath,
      address: derivedAddress,
      publicKey: childNode.publicKey,
      privateKey: childNode.privateKey
    });
  }

  return {
    mnemonic: phrase,
    passphrase: password,
    seedHex: seed,
    bip32RootKey: hdNode.extendedKey,
    bip32RootPubKey: hdNode.neuter().extendedKey,
    derivedAccounts
  };
}

// Brute Force Missing Words with Option to Match Address
export async function recoverMissingWords(
  partialMnemonic: string,
  maxWords = 2,
  targetAddress = '',
  coinType = 'ETH',
  path = "m/44'/60'/0'/0/0",
  onProgress?: (attempts: number) => void
): Promise<{ mnemonic: string; address: string }[]> {
  const words = partialMnemonic.trim().split(/\s+/);
  const missingIndices = words.map((w, i) => w === '?' ? i : -1).filter(i => i !== -1);

  if (missingIndices.length === 0) {
    if (validateMnemonic(partialMnemonic)) {
      const derived = await deriveAddressFromMnemonic(partialMnemonic, coinType, path);
      if (!targetAddress || derived.address.toLowerCase() === targetAddress.toLowerCase()) {
        return [{ mnemonic: partialMnemonic, address: derived.address }];
      }
    }
    return [];
  }

  if (missingIndices.length > maxWords) {
    throw new Error(`Too many missing words. Maximum ${maxWords} allowed for browser recovery.`);
  }

  const results: { mnemonic: string; address: string }[] = [];
  const wordlist = BIP39_WORDLIST;
  let attempts = 0;

  async function bruteForce(currentIndex: number, currentWords: string[]) {
    if (currentIndex === missingIndices.length) {
      attempts++;
      if (attempts % 100 === 0 && onProgress) {
        onProgress(attempts);
        await new Promise(resolve => setTimeout(resolve, 0));
      }
      const phrase = currentWords.join(' ');
      if (bip39.validateMnemonic(phrase)) {
        const derived = await deriveAddressFromMnemonic(phrase, coinType, path);
        if (!targetAddress || derived.address.toLowerCase().includes(targetAddress.toLowerCase())) {
          results.push({ mnemonic: phrase, address: derived.address });
        }
      }
      return;
    }

    const wordIdx = missingIndices[currentIndex];
    for (let i = 0; i < wordlist.length; i++) {
      currentWords[wordIdx] = wordlist[i];
      await bruteForce(currentIndex + 1, [...currentWords]);
      if (results.length > 20) break;
    }
  }

  await bruteForce(0, [...words]);
  return results;
}

// Exhaustive Recovery using Anagrams/Typos and Address Matcher
export async function recoverWithAnagramsAndTypos(
  mnemonic: string,
  targetAddress = '',
  coinType = 'ETH',
  path = "m/44'/60'/0'/0/0",
  onProgress?: (currentWordIndex: number, totalWords: number, attempts: number) => void
): Promise<{ fixedMnemonic: string; address: string; replacedWords: { index: number; original: string; replacedWith: string }[] }[]> {
  const words = mnemonic.trim().split(/\s+/);
  const invalidIndices: number[] = [];

  words.forEach((w, idx) => {
    if (!BIP39_WORDLIST.includes(w.toLowerCase())) {
      invalidIndices.push(idx);
    }
  });

  const results: any[] = [];
  let attempts = 0;

  if (invalidIndices.length === 0) {
    // If all words are valid but checksum is invalid, or if we have a target address to match
    if (bip39.validateMnemonic(mnemonic)) {
      const derived = await deriveAddressFromMnemonic(mnemonic, coinType, path);
      if (!targetAddress || derived.address.toLowerCase().includes(targetAddress.toLowerCase())) {
        return [{ fixedMnemonic: mnemonic, address: derived.address, replacedWords: [] }];
      }
    }
    
    // Scan all words one-by-one to fix single silent typos/anagrams
    for (let i = 0; i < words.length; i++) {
      const originalWord = words[i];
      const candidates = Array.from(new Set([
        ...findAnagrams(originalWord),
        ...findCloseMatches(originalWord, 1)
      ])).filter(c => c !== originalWord);

      for (const candidate of candidates) {
        attempts++;
        if (onProgress) onProgress(i, words.length, attempts);
        const testWords = [...words];
        testWords[i] = candidate;
        const testPhrase = testWords.join(' ');
        if (bip39.validateMnemonic(testPhrase)) {
          const derived = await deriveAddressFromMnemonic(testPhrase, coinType, path);
          if (!targetAddress || derived.address.toLowerCase().includes(targetAddress.toLowerCase())) {
            results.push({
              fixedMnemonic: testPhrase,
              address: derived.address,
              replacedWords: [{ index: i, original: originalWord, replacedWith: candidate }]
            });
          }
        }
      }
    }
    return results;
  }

  // Find candidate replacements for invalid words
  const candidatesMap: { [index: number]: string[] } = {};
  for (const idx of invalidIndices) {
    const originalWord = words[idx];
    const anagrams = findAnagrams(originalWord);
    const closeMatches = findCloseMatches(originalWord, 2);
    const candidates = Array.from(new Set([...anagrams, ...closeMatches]));
    candidatesMap[idx] = candidates.length > 0 ? candidates : BIP39_WORDLIST;
  }

  async function searchReplacements(depth: number, currentWords: string[], replaced: { index: number; original: string; replacedWith: string }[]) {
    if (depth === invalidIndices.length) {
      attempts++;
      if (attempts % 50 === 0 && onProgress) {
        onProgress(depth, invalidIndices.length, attempts);
        await new Promise(resolve => setTimeout(resolve, 0));
      }
      const testPhrase = currentWords.join(' ');
      if (bip39.validateMnemonic(testPhrase)) {
        const derived = await deriveAddressFromMnemonic(testPhrase, coinType, path);
        if (!targetAddress || derived.address.toLowerCase().includes(targetAddress.toLowerCase())) {
          results.push({
            fixedMnemonic: testPhrase,
            address: derived.address,
            replacedWords: [...replaced]
          });
        }
      }
      return;
    }

    const targetIdx = invalidIndices[depth];
    const candidates = candidatesMap[targetIdx];

    for (const cand of candidates) {
      const nextWords = [...currentWords];
      nextWords[targetIdx] = cand;
      await searchReplacements(
        depth + 1, 
        nextWords, 
        [...replaced, { index: targetIdx, original: words[targetIdx], replacedWith: cand }]
      );
      if (results.length > 10) break;
    }
  }

  await searchReplacements(0, [...words], []);
  return results;
}

// Vanity Mines
export async function mineBip39Vanity(
  prefix: string, 
  onProgress: (attempts: number) => void
): Promise<{mnemonic: string, address: string, attempts: number}> {
  let attempts = 0;
  while (true) {
    attempts++;
    const mnemonic = bip39.generateMnemonic();
    const wallet = ethers.Wallet.fromPhrase(mnemonic);
    if (wallet.address.toLowerCase().startsWith(prefix.toLowerCase())) {
      return { mnemonic, address: wallet.address, attempts };
    }
    if (attempts % 100 === 0) {
      onProgress(attempts);
      await new Promise(resolve => setTimeout(resolve, 0));
    }
  }
}

export async function mineBananoVanity(
  prefix: string, 
  onProgress: (attempts: number) => void
): Promise<{seed: string, address: string, attempts: number}> {
  let attempts = 0;
  const bjs = bananojs as any;
  while (true) {
    attempts++;
    const seed = Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const privateKey = bjs.getPrivateKey(seed, 0);
    const publicKey = await bjs.getPublicKey(privateKey);
    const address = bjs.getBananoAccount(publicKey);
    
    if (address.toLowerCase().startsWith(prefix.toLowerCase())) {
      return { seed, address, attempts };
    }
    if (attempts % 100 === 0) {
      onProgress(attempts);
      await new Promise(resolve => setTimeout(resolve, 0));
    }
  }
}
