import React, { useState } from 'react';
import StatCard from './components/StatCard';
import InstallBar from './components/InstallBar';
import { 
  recoverMissingWords, 
  recoverWithAnagramsAndTypos,
  mineBip39Vanity, 
  mineBananoVanity, 
  deriveBIP39Details,
  BIP39_WORDLIST
} from './utils/cryptoUtils';
import * as bip39 from 'bip39';

// Polyfills for Node.js globals
import { Buffer } from 'buffer';
(window as any).global = window;
(window as any).Buffer = Buffer;

type Tool = 'exhaustive' | 'brute' | 'explorer' | 'vanity';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tool>('exhaustive');
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressText, setProgressText] = useState('');
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Common Mnemonic & Derivation Inputs
  const [mnemonicInput, setMnemonicInput] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [coinType, setCoinType] = useState('ETH');
  const [derivationPath, setDerivationPath] = useState("m/44'/60'/0'/0/0");
  const [targetAddress, setTargetAddress] = useState('');

  // Vanity inputs
  const [vanityCoin, setVanityCoin] = useState<'ETH' | 'BAN'>('ETH');
  const [vanityPrefix, setVanityPrefix] = useState('');

  // Explorer Details State
  const [explorerDetails, setExplorerDetails] = useState<any>(null);

  // Real-time word validation helper
  const getWordValidation = (phrase: string) => {
    if (!phrase.trim()) return [];
    return phrase.trim().split(/\s+/).map(word => {
      const lower = word.toLowerCase();
      const isValid = BIP39_WORDLIST.includes(lower) || word === '?';
      return { word, isValid };
    });
  };

  const wordStatuses = getWordValidation(mnemonicInput);

  const handleExhaustiveRecovery = async () => {
    if (!mnemonicInput.trim()) {
      setError('Please enter a mnemonic phrase to recover.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);
    setProgress(0);
    setProgressText('Analyzing phrase for anagrams and typos...');

    try {
      const candidates = await recoverWithAnagramsAndTypos(
        mnemonicInput,
        targetAddress,
        coinType,
        derivationPath,
        (current, total, attempts) => {
          setProgress(attempts);
          setProgressText(`Testing candidates... Attempt ${attempts} (Word ${current}/${total})`);
        }
      );

      if (candidates.length === 0) {
        setError('No valid mnemonic phrases found. Try refining your words or target address.');
      } else {
        const firstMatch = candidates[0];
        
        let fixDetails = '';
        if (firstMatch.replacedWords.length > 0) {
          fixDetails = firstMatch.replacedWords.map(
            (r: any) => `Fixed "${r.original}" ➔ "${r.replacedWith}"`
          ).join(', ');
        } else {
          fixDetails = 'Valid checksum achieved with original words.';
        }

        setResult({
          title: 'Exhausted Archetype',
          type: `${coinType} (BIP44)`,
          address: firstMatch.address,
          mnemonic: firstMatch.fixedMnemonic,
          seed: fixDetails,
          rarity: firstMatch.replacedWords.length > 1 ? 'Legendary' : 'Epic',
          attempts: progress || 1,
          power: 2400,
        });
      }
    } catch (e: any) {
      setError(e.message || 'An error occurred during recovery.');
    }
    setIsLoading(false);
  };

  const handleBruteForce = async () => {
    if (!mnemonicInput.trim()) {
      setError('Please enter a mnemonic phrase with ? placeholders.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);
    setProgress(0);
    setProgressText('Scanning for missing words...');

    try {
      const found = await recoverMissingWords(
        mnemonicInput,
        2,
        targetAddress,
        coinType,
        derivationPath,
        (attempts) => {
          setProgress(attempts);
          setProgressText(`Scanning... Attempt ${attempts}`);
        }
      );

      if (found.length === 0) {
        setError('No valid mnemonics found. Check your "?" placements or target address.');
      } else {
        const match = found[0];
        setResult({
          title: 'Brute Entity',
          type: `${coinType} (BIP44)`,
          address: match.address,
          mnemonic: match.mnemonic,
          rarity: 'Epic',
          attempts: progress || 2048,
          power: 3100,
        });
      }
    } catch (e: any) {
      setError(e.message);
    }
    setIsLoading(false);
  };

  const handleExploreBIP39 = async () => {
    let phrase = mnemonicInput.trim();
    if (!phrase) {
      // Generate a random mnemonic if empty
      phrase = bip39.generateMnemonic();
      setMnemonicInput(phrase);
    }

    setIsLoading(true);
    setError(null);
    try {
      const details = await deriveBIP39Details(phrase, passphrase, derivationPath, coinType);
      setExplorerDetails(details);
    } catch (e: any) {
      setError(e.message || 'Failed to derive BIP39 details.');
    }
    setIsLoading(false);
  };

  const handleMineBip39 = async () => {
    if (!vanityPrefix) {
      setError('Please enter a target address prefix.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);
    setProgress(0);
    setProgressText('Mining vanity BIP39 address...');
    try {
      const res = await mineBip39Vanity(vanityPrefix, (attempts) => {
        setProgress(attempts);
        setProgressText(`Mining... Attempt ${attempts}`);
      });
      setResult({
        title: 'BIP39 Oracle',
        type: 'Ethereum (BIP44)',
        address: res.address,
        mnemonic: res.mnemonic,
        rarity: vanityPrefix.length > 4 ? 'Legendary' : 'Epic',
        attempts: res.attempts,
        power: 4500,
      });
    } catch (e: any) {
      setError(e.message);
    }
    setIsLoading(false);
  };

  const handleMineBanano = async () => {
    if (!vanityPrefix) {
      setError('Please enter a target address prefix.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);
    setProgress(0);
    setProgressText('Mining Banano address...');
    try {
      const res = await mineBananoVanity(vanityPrefix, (attempts) => {
        setProgress(attempts);
        setProgressText(`Mining... Attempt ${attempts}`);
      });
      setResult({
        title: 'Banano Chieftain',
        type: 'Banano',
        address: res.address,
        seed: res.seed,
        rarity: vanityPrefix.length > 4 ? 'Legendary' : 'Epic',
        attempts: res.attempts,
        power: 8900,
      });
    } catch (e: any) {
      setError(e.message);
    }
    setIsLoading(false);
  };

  // Helper to pre-populate typical path when coin selection changes
  const handleCoinChange = (coin: string) => {
    setCoinType(coin);
    if (coin === 'BTC') {
      setDerivationPath("m/44'/0'/0'/0/0");
    } else if (coin === 'BAN') {
      setDerivationPath("m/44'/198'/0'/0/0");
    } else {
      setDerivationPath("m/44'/60'/0'/0/0");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 p-4 md:p-8 font-mono relative overflow-hidden">
      {/* Scanline Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:100%_4px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Terminal Header */}
        <header className="text-center mb-8 border-b-2 border-slate-800 pb-6">
          <div className="inline-block bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs px-3 py-1 rounded-full uppercase tracking-widest mb-3">
            🔐 Advanced Cryptographic Recovery & Derivation Console
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-600 mb-2 tracking-wider">
            BIP39 EXHAUSTIVE RECOVERY ENGINE
          </h1>
          <p className="text-slate-400 max-w-3xl mx-auto text-xs md:text-sm leading-relaxed">
            Inspired by Ian Coleman's standalone BIP39 tool. Perform deep anagram/typo scanning, 
            checksum validation, brute force matching by specific addresses/derivation paths, 
            and generate beautiful soulbound character cards for discovered wallets.
          </p>
        </header>

        {/* Self-Download & Browser Install Toolbar */}
        <InstallBar />

        {/* System Tabs */}
        <div className="flex flex-wrap gap-2 mb-6 p-1 bg-slate-900 border border-slate-800 rounded-xl max-w-4xl mx-auto">
          {(['exhaustive', 'brute', 'explorer', 'vanity'] as Tool[]).map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                setResult(null);
                setError(null);
                setProgress(0);
                setProgressText('');
              }}
              className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs font-bold transition-all uppercase text-center ${
                activeTab === tab 
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/15' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {tab === 'exhaustive' ? '🔍 Anagram/Typo Fixer' :
               tab === 'brute' ? '⚡ Address Brute Force' :
               tab === 'explorer' ? '🧭 BIP39 Explorer' : '💎 Vanity Miner'}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Controls Panel */}
          <div className="lg:col-span-8 bg-slate-900/90 border border-slate-850 p-6 rounded-2xl shadow-2xl space-y-6">
            
            {/* Common Fields for Derivation & Recovery */}
            {activeTab !== 'vanity' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-slate-950 rounded-xl border border-slate-850">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Coin Type</label>
                  <select
                    className="w-full p-2.5 bg-slate-900 border border-slate-750 rounded text-xs text-indigo-300 focus:ring-1 focus:ring-indigo-500 outline-none"
                    value={coinType}
                    onChange={(e) => handleCoinChange(e.target.value)}
                  >
                    <option value="ETH">Ethereum (ETH)</option>
                    <option value="BTC">Bitcoin Legacy (BTC)</option>
                    <option value="BAN">Banano (BAN)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Derivation Path</label>
                  <input
                    type="text"
                    className="w-full p-2 bg-slate-900 border border-slate-750 rounded text-xs font-mono text-indigo-300 focus:ring-1 focus:ring-indigo-500 outline-none"
                    value={derivationPath}
                    onChange={(e) => setDerivationPath(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">BIP39 Passphrase (Optional)</label>
                  <input
                    type="password"
                    placeholder="None"
                    className="w-full p-2 bg-slate-900 border border-slate-750 rounded text-xs text-indigo-300 focus:ring-1 focus:ring-indigo-500 outline-none"
                    value={passphrase}
                    onChange={(e) => setPassphrase(e.target.value)}
                  />
                </div>
              </div>
            )}

            {/* TAB 1: Exhaustive Anagram / Typo Fixer */}
            {activeTab === 'exhaustive' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs uppercase text-slate-400 mb-2">Scrambled Mnemonic Phrase</label>
                  <textarea
                    className="w-full h-28 p-3.5 bg-slate-950 border border-slate-800 rounded-lg text-indigo-300 font-mono text-xs focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                    placeholder="Paste recovery phrase here. Any spelling mistakes or scrambled words will be automatically scanned and corrected."
                    value={mnemonicInput}
                    onChange={(e) => setMnemonicInput(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase text-slate-400 mb-2">Target Address Matcher (Optional)</label>
                  <input
                    type="text"
                    className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg text-indigo-300 text-xs font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="Enter the address or partial address to verify against during search"
                    value={targetAddress}
                    onChange={(e) => setTargetAddress(e.target.value)}
                  />
                  <p className="text-[10px] text-slate-500 mt-1">If provided, the solver will only accept candidates that derive to this exact address at your chosen path.</p>
                </div>

                {/* Real-time word badges */}
                {wordStatuses.length > 0 && (
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-850">
                    <span className="text-[10px] uppercase text-slate-500 block mb-1">Live Mnemonic Analysis:</span>
                    <div className="flex flex-wrap gap-1">
                      {wordStatuses.map((item, idx) => (
                        <span 
                          key={idx} 
                          className={`text-[10px] px-2 py-0.5 rounded border ${
                            item.isValid 
                            ? 'bg-emerald-950/20 border-emerald-850 text-emerald-400' 
                            : 'bg-red-950/20 border-red-850 text-red-400 animate-pulse'
                          }`}
                        >
                          {item.word} {!item.isValid && '(Scrambled)'}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <button
                  onClick={handleExhaustiveRecovery}
                  disabled={isLoading}
                  className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold rounded-lg hover:opacity-90 disabled:opacity-50 transition-all uppercase tracking-widest text-xs"
                >
                  {isLoading ? 'Processing Recovery Sequence...' : 'Scan & Validate Checksum'}
                </button>
              </div>
            )}

            {/* TAB 2: Brute Force (Missing Words) */}
            {activeTab === 'brute' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs uppercase text-slate-400 mb-2">Mnemonic Phrase with Placeholders (?)</label>
                  <textarea
                    className="w-full h-28 p-3.5 bg-slate-950 border border-slate-800 rounded-lg text-indigo-300 font-mono text-xs focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                    placeholder="Enter mnemonic phrase with '?' for missing words. E.g. 'abandon abandon ? abandon ...'"
                    value={mnemonicInput}
                    onChange={(e) => setMnemonicInput(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs uppercase text-slate-400 mb-2">Target Address to Match (Highly Recommended)</label>
                  <input
                    type="text"
                    className="w-full p-3 bg-slate-950 border border-slate-800 rounded-lg text-indigo-300 text-xs font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="e.g. 0x... or 1... or ban_..."
                    value={targetAddress}
                    onChange={(e) => setTargetAddress(e.target.value)}
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Providing the target address allows the brute-forcer to find the exact missing words instantly by matching derived addresses.</p>
                </div>

                <button
                  onClick={handleBruteForce}
                  disabled={isLoading}
                  className="w-full py-3 bg-gradient-to-r from-cyan-600 to-indigo-600 text-white font-bold rounded-lg hover:opacity-90 disabled:opacity-50 transition-all uppercase tracking-widest text-xs"
                >
                  {isLoading ? 'Engaging Brute Force Algorithms...' : 'Brute Force by Target Address'}
                </button>
              </div>
            )}

            {/* TAB 3: BIP39 Explorer (Ian Coleman Mode) */}
            {activeTab === 'explorer' && (
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <label className="block text-xs uppercase text-slate-400 mb-2">Mnemonic Phrase</label>
                    <textarea
                      className="w-full h-20 p-3 bg-slate-950 border border-slate-800 rounded-lg text-indigo-300 font-mono text-xs focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                      placeholder="Enter a mnemonic phrase or leave empty to generate a random one"
                      value={mnemonicInput}
                      onChange={(e) => setMnemonicInput(e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={handleExploreBIP39}
                    disabled={isLoading}
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition-all uppercase tracking-widest text-xs"
                  >
                    {isLoading ? 'Calculating Key Derivations...' : 'Derive Wallet Details'}
                  </button>
                  <button
                    onClick={() => {
                      setMnemonicInput(bip39.generateMnemonic());
                      setExplorerDetails(null);
                    }}
                    className="py-3 px-6 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold rounded-lg transition-all text-xs"
                  >
                    Generate Random Phrase
                  </button>
                </div>

                {explorerDetails && (
                  <div className="space-y-6 pt-4 border-t border-slate-800">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-400">BIP39 Derivation Details</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="p-3 bg-slate-950 rounded border border-slate-850">
                        <span className="block text-slate-500 uppercase text-[9px] mb-1">BIP39 Seed (Hex)</span>
                        <div className="flex justify-between items-center">
                          <span className="font-mono break-all text-indigo-300">{explorerDetails.seedHex}</span>
                          <button onClick={() => copyToClipboard(explorerDetails.seedHex)} className="ml-2 text-indigo-500 hover:text-indigo-400">📋</button>
                        </div>
                      </div>
                      <div className="p-3 bg-slate-950 rounded border border-slate-850">
                        <span className="block text-slate-500 uppercase text-[9px] mb-1">BIP32 Root Key (xprv)</span>
                        <div className="flex justify-between items-center">
                          <span className="font-mono break-all text-indigo-300">{explorerDetails.bip32RootKey}</span>
                          <button onClick={() => copyToClipboard(explorerDetails.bip32RootKey)} className="ml-2 text-indigo-500 hover:text-indigo-400">📋</button>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-950 rounded border border-slate-850 text-xs">
                      <span className="block text-slate-500 uppercase text-[9px] mb-1">BIP32 Extended Public Key (xpub)</span>
                      <div className="flex justify-between items-center">
                        <span className="font-mono break-all text-indigo-300">{explorerDetails.bip32RootPubKey}</span>
                        <button onClick={() => copyToClipboard(explorerDetails.bip32RootPubKey)} className="ml-2 text-indigo-500 hover:text-indigo-400">📋</button>
                      </div>
                    </div>

                    {/* Derived Addresses Table */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Derived Addresses Table (BIP44 Accounts 0-9)</h4>
                      <div className="overflow-x-auto border border-slate-850 rounded-lg">
                        <table className="w-full text-left border-collapse text-[11px] font-mono">
                          <thead>
                            <tr className="bg-slate-950 border-b border-slate-850 text-slate-400">
                              <th className="p-3">Index</th>
                              <th className="p-3">Derivation Path</th>
                              <th className="p-3">Address</th>
                              <th className="p-3">Public Key (Compressed)</th>
                              <th className="p-3">Private Key</th>
                            </tr>
                          </thead>
                          <tbody>
                            {explorerDetails.derivedAccounts.map((acc: any) => (
                              <tr key={acc.index} className="border-b border-slate-850/50 hover:bg-slate-950/40 transition-all">
                                <td className="p-3 text-slate-500">{acc.index}</td>
                                <td className="p-3 text-slate-400">{acc.path}</td>
                                <td className="p-3 text-emerald-400 font-bold max-w-[150px] truncate">{acc.address}</td>
                                <td className="p-3 text-indigo-300 max-w-[150px] truncate">{acc.publicKey}</td>
                                <td className="p-3 text-purple-400 max-w-[150px] truncate">{acc.privateKey}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: Vanity Miner */}
            {activeTab === 'vanity' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-950 rounded-xl border border-slate-850">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Coin System</label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => { setVanityCoin('ETH'); setVanityPrefix(''); }}
                        className={`flex-1 py-2 px-3 rounded text-xs font-bold transition-all ${
                          vanityCoin === 'ETH' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        Ethereum (BIP39)
                      </button>
                      <button
                        onClick={() => { setVanityCoin('BAN'); setVanityPrefix('ban_'); }}
                        className={`flex-1 py-2 px-3 rounded text-xs font-bold transition-all ${
                          vanityCoin === 'BAN' ? 'bg-yellow-600 text-white' : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        Banano (Address)
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Vanity Target Prefix</label>
                    <input
                      type="text"
                      className="w-full p-2.5 bg-slate-900 border border-slate-750 rounded text-xs font-mono text-indigo-300 focus:ring-1 focus:ring-indigo-500 outline-none"
                      placeholder={vanityCoin === 'ETH' ? "0x777" : "ban_monkey"}
                      value={vanityPrefix}
                      onChange={(e) => setVanityPrefix(e.target.value)}
                    />
                  </div>
                </div>

                <div className="p-4 bg-purple-950/20 border border-purple-900/30 rounded-lg text-xs text-slate-400 leading-relaxed">
                  <strong>Prefix Complexity Warning:</strong> Generating longer prefixes requires exponential calculations. A prefix of 3 characters is derived almost instantly, while 5+ characters may take several minutes in the browser sandbox.
                </div>

                <button
                  onClick={vanityCoin === 'ETH' ? handleMineBip39 : handleMineBanano}
                  disabled={isLoading}
                  className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-lg hover:opacity-90 disabled:opacity-50 transition-all uppercase tracking-widest text-xs"
                >
                  {isLoading ? 'Running Miner Engines...' : 'Start Mining'}
                </button>
              </div>
            )}

            {/* Mining/Recovery Live Feedback Progress Bar */}
            {isLoading && (
              <div className="p-4 bg-slate-950 rounded-lg border border-slate-850 space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-indigo-400 animate-pulse font-bold">{progressText}</span>
                  <span className="text-slate-500">{progress.toLocaleString()} operations</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-500 transition-all duration-300" 
                    style={{ width: `${Math.min(100, (progress / 1500) * 100)}%` }}
                  ></div>
                </div>
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-950/30 border border-red-900/50 text-red-400 text-xs rounded-lg flex items-start gap-2">
                <span className="text-lg">⚠️</span>
                <div>
                  <strong className="block uppercase text-[10px] mb-1">Process Exception</strong>
                  {error}
                </div>
              </div>
            )}
          </div>

          {/* Character Stat Card & Results (right side, span 4) */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center min-h-[400px]">
            {result ? (
              <div className="w-full flex flex-col items-center space-y-4 animate-fadeIn">
                <div className="text-xs uppercase tracking-widest text-emerald-400 font-bold flex items-center gap-1.5">
                  <span className="inline-block w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span> Key Signature Verified
                </div>
                <StatCard {...result} />
              </div>
            ) : (
              <div className="w-full max-w-md p-8 border-2 border-dashed border-slate-800 rounded-2xl text-center text-slate-600 bg-slate-900/20 backdrop-blur-sm flex flex-col items-center justify-center space-y-4 min-h-[400px]">
                <div className="w-16 h-16 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center text-2xl text-slate-500 shadow-inner">
                  🛡️
                </div>
                <div>
                  <p className="text-sm font-bold uppercase tracking-widest text-slate-400">Cryptographic Identity Void</p>
                  <p className="text-xs mt-2 text-slate-500 leading-relaxed max-w-xs mx-auto">
                    Initiate a recovery sequence or complete a BIP39 derivation to generate a unique character stat card.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
