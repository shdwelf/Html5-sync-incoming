import React, { useEffect, useState } from 'react';
import {
  downloadSelf,
  registerInstallPrompt,
  installToBrowser,
  isStandalone,
  registerServiceWorker,
  injectManifest,
} from '../utils/appInstall';

const InstallBar: React.FC = () => {
  const [canInstall, setCanInstall] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    injectManifest();
    registerServiceWorker();
    setInstalled(isStandalone());

    const cleanup = registerInstallPrompt((available) => {
      setCanInstall(available);
    });
    return cleanup;
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3500);
  };

  const handleDownload = () => {
    try {
      downloadSelf();
      showToast('✅ Standalone HTML saved! Open it anywhere — fully offline & self-contained.');
    } catch (e) {
      showToast('⚠️ Download failed in this environment.');
    }
  };

  const handleInstall = async () => {
    const result = await installToBrowser();
    if (result === 'accepted') {
      showToast('🎉 App installed to your browser!');
      setInstalled(true);
    } else if (result === 'dismissed') {
      showToast('Installation dismissed.');
    } else {
      showToast(
        'ℹ️ Native install not offered here. Use your browser menu → "Install App", or use Download Self for an offline copy.'
      );
    }
  };

  return (
    <>
      <div className="flex flex-wrap items-center justify-center gap-3 mb-6">
        <button
          onClick={handleDownload}
          className="group flex items-center gap-2 px-4 py-2 bg-slate-900 border border-emerald-700/50 hover:border-emerald-500 text-emerald-400 text-xs font-bold rounded-lg transition-all uppercase tracking-wider shadow-lg shadow-emerald-500/5"
        >
          <span className="text-base group-hover:animate-bounce">⬇️</span>
          Download Self (Offline HTML)
        </button>

        <button
          onClick={handleInstall}
          disabled={installed}
          className={`group flex items-center gap-2 px-4 py-2 border text-xs font-bold rounded-lg transition-all uppercase tracking-wider shadow-lg ${
            installed
              ? 'bg-slate-900 border-slate-700 text-slate-500 cursor-default'
              : canInstall
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 border-indigo-500 text-white shadow-indigo-500/20 hover:opacity-90 animate-pulse'
              : 'bg-slate-900 border-indigo-700/50 hover:border-indigo-500 text-indigo-400 shadow-indigo-500/5'
          }`}
        >
          <span className="text-base">{installed ? '✅' : '📲'}</span>
          {installed ? 'Installed to Browser' : 'Install to Browser (PWA)'}
        </button>

        <div className="text-[10px] text-slate-500 max-w-xs text-center md:text-left leading-snug">
          100% client-side. No keys leave your device. Save a copy and run it air-gapped.
        </div>
      </div>

      {/* Toast notification */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 bg-slate-900 border border-indigo-500/40 text-slate-200 text-xs rounded-xl shadow-2xl shadow-indigo-500/20 backdrop-blur-md max-w-md text-center animate-fadeIn">
          {toast}
        </div>
      )}
    </>
  );
};

export default InstallBar;
