import React from 'react';

interface StatCardProps {
  title: string;
  type: string;
  address: string;
  mnemonic?: string;
  seed?: string;
  rarity: string;
  attempts: number;
  power: number;
}

const StatCard: React.FC<StatCardProps> = ({ title, type, address, mnemonic, seed, rarity, attempts, power }) => {
  return (
    <div className="relative w-full max-w-md p-6 bg-slate-900 border-4 border-indigo-500 rounded-xl shadow-[0_0_20px_rgba(99,102,241,0.6)] text-white font-mono overflow-hidden">
      {/* Decorative background element */}
      <div className="absolute -top-10 -right-10 w-32 h-32 bg-indigo-600 rounded-full blur-3xl opacity-30 animate-pulse"></div>
      <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-purple-600 rounded-full blur-3xl opacity-30 animate-pulse"></div>

      <div className="relative z-10">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-2xl font-bold text-indigo-400 uppercase tracking-wider">{title}</h2>
            <p className="text-xs text-slate-400">{type} Asset</p>
          </div>
          <div className="text-right">
            <span className={`text-xs px-2 py-1 rounded border ${
              rarity === 'Legendary' ? 'border-yellow-400 text-yellow-400 animate-bounce' : 
              rarity === 'Epic' ? 'border-purple-400 text-purple-400' : 
              'border-blue-400 text-blue-400'
            }`}>
              {rarity}
            </span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-3 bg-slate-800 rounded border border-slate-700">
            <p className="text-xs text-slate-500 mb-1">Public Identifier</p>
            <p className="text-sm break-all font-bold text-indigo-300">{address}</p>
          </div>

          {mnemonic && (
            <div className="p-3 bg-slate-800 rounded border border-slate-700">
              <p className="text-xs text-slate-500 mb-1">Soulbound Mnemonic</p>
              <p className="text-xs break-words italic text-slate-300">{mnemonic}</p>
            </div>
          )}

          {seed && (
            <div className="p-3 bg-slate-800 rounded border border-slate-700">
              <p className="text-xs text-slate-500 mb-1">Origin Seed</p>
              <p className="text-xs break-all font-mono text-slate-300">{seed}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase">Calculation Effort</span>
              <span className="text-lg font-bold text-white">{attempts.toLocaleString()} <span className="text-xs font-normal text-slate-400">tries</span></span>
            </div>
            <div className="flex flex-col text-right">
              <span className="text-[10px] text-slate-500 uppercase">Hash Power</span>
              <span className="text-lg font-bold text-white">{power} <span className="text-xs font-normal text-slate-400">h/s</span></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatCard;
