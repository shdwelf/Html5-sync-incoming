// Minimal but robust GEDCOM 5.5/7 parser.
// Streams text line-by-line so it can handle very large files.

export interface GedNode {
  level: number;
  xref?: string;     // @I1@
  tag: string;       // INDI, NAME, BIRT, FAMC...
  value?: string;
  children: GedNode[];
}

export interface Individual {
  id: string;
  name: string;
  given?: string;
  surname?: string;
  sex?: "M" | "F" | "U";
  birth?: { date?: string; place?: string };
  death?: { date?: string; place?: string };
  famc: string[];   // families where this person is a child
  fams: string[];   // families where this person is a spouse
  notes: string[];
}

export interface Family {
  id: string;
  husband?: string;
  wife?: string;
  children: string[];
  marriage?: { date?: string; place?: string };
}

export interface Gedcom {
  individuals: Map<string, Individual>;
  families: Map<string, Family>;
  source?: string;
  header: Record<string, string>;
}

const LINE_RE = /^\s*(\d+)\s+(?:(@[^@]+@)\s+)?(\S+)(?:\s(.*))?$/;

/** Parse raw GEDCOM text into a flat node tree. */
export function parseGedcomText(text: string): GedNode[] {
  // Normalize line endings; GEDCOM can use CRLF or CR.
  const lines = text.replace(/\r\n?/g, "\n").split("\n");
  const roots: GedNode[] = [];
  const stack: GedNode[] = [];

  for (const raw of lines) {
    if (!raw.trim()) continue;
    const m = LINE_RE.exec(raw);
    if (!m) continue;
    const node: GedNode = {
      level: parseInt(m[1], 10),
      xref: m[2],
      tag: m[3],
      value: m[4],
      children: [],
    };
    // CONT/CONC: append text to parent value
    if ((node.tag === "CONT" || node.tag === "CONC") && stack.length) {
      const parent = stack[stack.length - 1];
      const sep = node.tag === "CONT" ? "\n" : "";
      parent.value = (parent.value ?? "") + sep + (node.value ?? "");
      continue;
    }
    while (stack.length && stack[stack.length - 1].level >= node.level) {
      stack.pop();
    }
    if (stack.length === 0) roots.push(node);
    else stack[stack.length - 1].children.push(node);
    stack.push(node);
  }
  return roots;
}

const findChild = (n: GedNode, tag: string) =>
  n.children.find((c) => c.tag === tag);
const findChildren = (n: GedNode, tag: string) =>
  n.children.filter((c) => c.tag === tag);

function readEvent(n: GedNode | undefined) {
  if (!n) return undefined;
  return {
    date: findChild(n, "DATE")?.value,
    place: findChild(n, "PLAC")?.value,
  };
}

/** Build a structured Gedcom from raw text. */
export function buildGedcom(text: string): Gedcom {
  const roots = parseGedcomText(text);
  const individuals = new Map<string, Individual>();
  const families = new Map<string, Family>();
  const header: Record<string, string> = {};

  for (const r of roots) {
    if (r.tag === "HEAD") {
      const src = findChild(r, "SOUR");
      if (src?.value) header.SOUR = src.value;
      const dest = findChild(r, "DEST");
      if (dest?.value) header.DEST = dest.value;
      const date = findChild(r, "DATE");
      if (date?.value) header.DATE = date.value;
      continue;
    }
    if (r.tag === "INDI" && r.xref) {
      const nameNode = findChild(r, "NAME");
      const rawName = nameNode?.value ?? "";
      // Format: Given /Surname/
      let given = findChild(nameNode!, "GIVN")?.value;
      let surname = findChild(nameNode!, "SURN")?.value;
      if (!given || !surname) {
        const m = /^(.*?)\s*\/([^/]*)\/\s*(.*)$/.exec(rawName);
        if (m) {
          given = given ?? m[1].trim();
          surname = surname ?? m[2].trim();
        } else {
          given = given ?? rawName.trim();
        }
      }
      const sex = (findChild(r, "SEX")?.value as Individual["sex"]) ?? "U";
      individuals.set(r.xref, {
        id: r.xref,
        name: [given, surname].filter(Boolean).join(" ").trim() || rawName || r.xref,
        given,
        surname,
        sex,
        birth: readEvent(findChild(r, "BIRT")),
        death: readEvent(findChild(r, "DEAT")),
        famc: findChildren(r, "FAMC").map((c) => c.value!).filter(Boolean),
        fams: findChildren(r, "FAMS").map((c) => c.value!).filter(Boolean),
        notes: findChildren(r, "NOTE").map((c) => c.value ?? ""),
      });
    } else if (r.tag === "FAM" && r.xref) {
      families.set(r.xref, {
        id: r.xref,
        husband: findChild(r, "HUSB")?.value,
        wife: findChild(r, "WIFE")?.value,
        children: findChildren(r, "CHIL").map((c) => c.value!).filter(Boolean),
        marriage: readEvent(findChild(r, "MARR")),
      });
    }
  }
  return { individuals, families, header };
}

/**
 * Recombine multipart GEDCOM fragments.
 * Strategies:
 *   - strip duplicate HEAD/TRLR (keep first HEAD, drop intermediate TRLRs except final)
 *   - concatenate
 *   - de-duplicate INDI / FAM records by xref (later parts can override)
 */
export function recombineMultipart(parts: string[]): string {
  if (parts.length === 0) return "";
  if (parts.length === 1) return parts[0];

  // Parse each, merge by xref.
  const seen = new Set<string>();
  const out: string[] = [];

  // Keep first HEAD.
  let headerEmitted = false;

  for (let i = 0; i < parts.length; i++) {
    const text = parts[i].replace(/\r\n?/g, "\n");
    const lines = text.split("\n");
    let buf: string[] = [];
    let inRecord = false;
    let currentXref: string | null = null;
    let currentTag: string | null = null;

    const flush = () => {
      if (buf.length === 0) return;
      const key = currentXref ? `${currentTag}:${currentXref}` : `__top_${currentTag}_${i}_${Math.random()}`;
      if (currentTag === "HEAD") {
        if (!headerEmitted) {
          out.push(buf.join("\n"));
          headerEmitted = true;
        }
      } else if (currentTag === "TRLR") {
        // skip; we add one TRLR at the end
      } else if (!seen.has(key)) {
        seen.add(key);
        out.push(buf.join("\n"));
      }
      buf = [];
    };

    for (const line of lines) {
      const m = LINE_RE.exec(line);
      if (!m) continue;
      const level = parseInt(m[1], 10);
      if (level === 0) {
        flush();
        inRecord = true;
        currentXref = m[2] ?? null;
        currentTag = m[3];
      }
      if (inRecord) buf.push(line);
    }
    flush();
  }
  out.push("0 TRLR");
  return out.join("\n");
}
