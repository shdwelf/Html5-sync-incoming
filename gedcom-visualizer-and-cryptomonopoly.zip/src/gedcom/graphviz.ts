import type { Gedcom, Individual } from "./parser";

export interface DotOptions {
  rankdir?: "TB" | "LR" | "BT" | "RL";
  rootId?: string;
  maxDepth?: number; // ancestor + descendant generations from root
  showDates?: boolean;
  showPlaces?: boolean;
  theme?: "light" | "dark";
}

const esc = (s: string) =>
  s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n");

function personLabel(p: Individual, opts: DotOptions) {
  const lines: string[] = [];
  lines.push(p.name || p.id);
  if (opts.showDates) {
    const b = p.birth?.date ? `★ ${p.birth.date}` : "";
    const d = p.death?.date ? `† ${p.death.date}` : "";
    if (b || d) lines.push([b, d].filter(Boolean).join("   "));
  }
  if (opts.showPlaces) {
    const bp = p.birth?.place;
    if (bp) lines.push(bp);
  }
  return esc(lines.join("\n"));
}

function colorFor(p: Individual, theme: "light" | "dark") {
  if (theme === "dark") {
    if (p.sex === "M") return { fill: "#1e3a5f", border: "#7cc4ff", text: "#e6f1ff" };
    if (p.sex === "F") return { fill: "#5a1e3f", border: "#ff9ec9", text: "#ffe6f0" };
    return { fill: "#2d2d33", border: "#a3a3a3", text: "#eeeeee" };
  }
  if (p.sex === "M") return { fill: "#dbeafe", border: "#2563eb", text: "#0c1a36" };
  if (p.sex === "F") return { fill: "#fce7f3", border: "#db2777", text: "#3b0a25" };
  return { fill: "#f3f4f6", border: "#6b7280", text: "#111827" };
}

/** Compute which individuals to include given a root + depth. */
function selectSubgraph(g: Gedcom, rootId: string, maxDepth: number) {
  const indis = new Set<string>();
  const fams = new Set<string>();
  if (!g.individuals.has(rootId)) return { indis, fams };

  // Ancestors (up): from FAMC chains
  const visitAncestors = (id: string, depth: number) => {
    if (depth < 0 || indis.has(id + "_a")) return;
    const p = g.individuals.get(id);
    if (!p) return;
    indis.add(id);
    for (const famId of p.famc) {
      const f = g.families.get(famId);
      if (!f) continue;
      fams.add(famId);
      if (f.husband) visitAncestors(f.husband, depth - 1);
      if (f.wife) visitAncestors(f.wife, depth - 1);
    }
  };
  // Descendants (down): from FAMS
  const visitDescendants = (id: string, depth: number) => {
    if (depth < 0) return;
    const p = g.individuals.get(id);
    if (!p) return;
    indis.add(id);
    for (const famId of p.fams) {
      const f = g.families.get(famId);
      if (!f) continue;
      fams.add(famId);
      // include spouse
      if (f.husband && f.husband !== id) indis.add(f.husband);
      if (f.wife && f.wife !== id) indis.add(f.wife);
      for (const c of f.children) visitDescendants(c, depth - 1);
    }
  };
  visitAncestors(rootId, maxDepth);
  visitDescendants(rootId, maxDepth);
  return { indis, fams };
}

export function gedcomToDot(g: Gedcom, opts: DotOptions = {}): string {
  const {
    rankdir = "TB",
    rootId,
    maxDepth = 4,
    showDates = true,
    showPlaces = false,
    theme = "light",
  } = opts;

  let indisToShow: Set<string>;
  let famsToShow: Set<string>;
  if (rootId) {
    const sub = selectSubgraph(g, rootId, maxDepth);
    indisToShow = sub.indis;
    famsToShow = sub.fams;
  } else {
    indisToShow = new Set(g.individuals.keys());
    famsToShow = new Set(g.families.keys());
  }

  const bg = theme === "dark" ? "#0b1020" : "#ffffff";
  const edge = theme === "dark" ? "#94a3b8" : "#475569";
  const famFill = theme === "dark" ? "#facc15" : "#fde68a";
  const famBorder = theme === "dark" ? "#fde047" : "#b45309";

  const out: string[] = [];
  out.push(`digraph FamilyTree {`);
  out.push(`  bgcolor="${bg}";`);
  out.push(`  rankdir=${rankdir};`);
  out.push(`  nodesep=0.25;`);
  out.push(`  ranksep=0.55;`);
  out.push(`  splines=ortho;`);
  out.push(`  node [fontname="Inter, Helvetica, Arial", fontsize=11, style="filled,rounded"];`);
  out.push(`  edge [color="${edge}", arrowhead=none, penwidth=1.2];`);

  // INDI nodes
  for (const id of indisToShow) {
    const p = g.individuals.get(id);
    if (!p) continue;
    const c = colorFor(p, theme);
    out.push(
      `  "${id}" [shape=box, label="${personLabel(p, { showDates, showPlaces })}", fillcolor="${c.fill}", color="${c.border}", fontcolor="${c.text}"];`,
    );
  }

  // FAM nodes (diamond marriage nodes)
  for (const id of famsToShow) {
    const f = g.families.get(id);
    if (!f) continue;
    const label = f.marriage?.date ? `⚭\\n${esc(f.marriage.date)}` : "⚭";
    out.push(
      `  "${id}" [shape=diamond, width=0.35, height=0.35, fixedsize=true, label="${label}", fillcolor="${famFill}", color="${famBorder}", fontsize=9];`,
    );
    if (f.husband && indisToShow.has(f.husband))
      out.push(`  "${f.husband}" -> "${id}";`);
    if (f.wife && indisToShow.has(f.wife))
      out.push(`  "${f.wife}" -> "${id}";`);
    for (const c of f.children) {
      if (indisToShow.has(c)) out.push(`  "${id}" -> "${c}" [arrowhead=normal, arrowsize=0.6];`);
    }
  }

  out.push(`}`);
  return out.join("\n");
}
