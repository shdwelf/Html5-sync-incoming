// Streaming utilities for very large GEDCOM files.

export type ProgressFn = (loaded: number, total: number) => void;

/** Read a (possibly huge) text file in chunks so the UI stays responsive. */
export async function readFileChunked(
  file: File,
  onProgress?: ProgressFn,
  chunkSize = 4 * 1024 * 1024, // 4 MiB
): Promise<string> {
  const decoder = new TextDecoder("utf-8");
  let result = "";
  let offset = 0;
  while (offset < file.size) {
    const slice = file.slice(offset, Math.min(offset + chunkSize, file.size));
    const buf = await slice.arrayBuffer();
    // stream:true so multi-byte characters aren't split between chunks
    result += decoder.decode(buf, { stream: offset + chunkSize < file.size });
    offset += chunkSize;
    onProgress?.(Math.min(offset, file.size), file.size);
    // yield to event loop so UI updates
    await new Promise((r) => setTimeout(r, 0));
  }
  return result;
}

/** Fetch a remote URL, falling back to a CORS proxy when direct fetch fails. */
export async function fetchRemoteText(url: string): Promise<string> {
  const tryFetch = async (u: string) => {
    const r = await fetch(u);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  };
  try {
    return await tryFetch(url);
  } catch (e) {
    // Fall back to public CORS proxy.
    const proxied = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
    return await tryFetch(proxied);
  }
}

/**
 * Scrape GEDCOM data from an HTML page. Looks for:
 *   - `<pre>` / `<code>` blocks containing GEDCOM ("0 HEAD" pattern)
 *   - linked .ged files
 * Returns the raw GEDCOM text if found, else throws.
 */
export async function scrapeGedcomFromHtml(
  url: string,
  html: string,
): Promise<string> {
  // 1. inline blocks
  const blockRe = /<(?:pre|code|textarea)[^>]*>([\s\S]*?)<\/(?:pre|code|textarea)>/gi;
  let m: RegExpExecArray | null;
  while ((m = blockRe.exec(html))) {
    const text = decodeEntities(m[1]);
    if (/^\s*0\s+HEAD/m.test(text) && /\bINDI\b|\bFAM\b/.test(text)) {
      return text;
    }
  }
  // 2. linked .ged files
  const linkRe = /href\s*=\s*["']([^"']+\.ged(?:com)?)(?:\?[^"']*)?["']/gi;
  const links: string[] = [];
  while ((m = linkRe.exec(html))) {
    try {
      links.push(new URL(m[1], url).toString());
    } catch {}
  }
  if (links.length > 0) {
    const parts = await Promise.all(links.map((u) => fetchRemoteText(u)));
    return parts.join("\n");
  }
  throw new Error("No GEDCOM data found on the page.");
}

function decodeEntities(s: string): string {
  return s
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ");
}

/** Smart loader: if text looks like HTML, scrape it; else treat as GEDCOM. */
export async function loadFromUrl(url: string): Promise<string> {
  const text = await fetchRemoteText(url);
  if (/^\s*0\s+HEAD/m.test(text)) return text;
  if (/<html|<!doctype html/i.test(text)) return await scrapeGedcomFromHtml(url, text);
  // Could still be a GEDCOM (some files lack a HEAD line oddly) — return as-is.
  return text;
}

/** Sample tiny family for demo / empty state. */
export const SAMPLE_GEDCOM = `0 HEAD
1 SOUR GedViz
1 GEDC
2 VERS 5.5.1
2 FORM LINEAGE-LINKED
1 CHAR UTF-8
0 @I1@ INDI
1 NAME Ada /Lovelace/
1 SEX F
1 BIRT
2 DATE 10 DEC 1815
2 PLAC London, England
1 DEAT
2 DATE 27 NOV 1852
1 FAMS @F1@
1 FAMC @F2@
0 @I2@ INDI
1 NAME William /King-Noel/
1 SEX M
1 BIRT
2 DATE 21 FEB 1805
1 FAMS @F1@
0 @I3@ INDI
1 NAME Byron /King-Noel/
1 SEX M
1 BIRT
2 DATE 12 MAY 1836
1 FAMC @F1@
0 @I4@ INDI
1 NAME Anne Isabella /King-Noel/
1 SEX F
1 BIRT
2 DATE 22 SEP 1837
1 FAMC @F1@
0 @I5@ INDI
1 NAME Ralph /King-Milbanke/
1 SEX M
1 BIRT
2 DATE 02 JUL 1839
1 FAMC @F1@
0 @I6@ INDI
1 NAME George Gordon /Byron/
1 SEX M
1 BIRT
2 DATE 22 JAN 1788
1 DEAT
2 DATE 19 APR 1824
1 FAMS @F2@
0 @I7@ INDI
1 NAME Anne Isabella /Milbanke/
1 SEX F
1 BIRT
2 DATE 17 MAY 1792
1 FAMS @F2@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I1@
1 MARR
2 DATE 08 JUL 1835
1 CHIL @I3@
1 CHIL @I4@
1 CHIL @I5@
0 @F2@ FAM
1 HUSB @I6@
1 WIFE @I7@
1 MARR
2 DATE 02 JAN 1815
1 CHIL @I1@
0 TRLR
`;
