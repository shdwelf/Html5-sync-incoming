import { useCallback, useEffect, useMemo, useRef, useState } from "react";
// @ts-ignore — viz-js has no bundled types
import { instance as vizInstance } from "@viz-js/viz";
import { buildGedcom, recombineMultipart, type Gedcom } from "./parser";
import { gedcomToDot, type DotOptions } from "./graphviz";
import {
  loadFromUrl,
  readFileChunked,
  SAMPLE_GEDCOM,
} from "./io";

type Part = { id: string; name: string; size: number; text: string };

export default function GedVizApp() {
  const [parts, setParts] = useState<Part[]>([]);
  const [gedcom, setGedcom] = useState<Gedcom | null>(null);
  const [status, setStatus] = useState<string>("Ready.");
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<{ loaded: number; total: number } | null>(null);
  const [url, setUrl] = useState("");
  const [search, setSearch] = useState("");
  const [rootId, setRootId] = useState<string | undefined>(undefined);
  const [maxDepth, setMaxDepth] = useState(4);
  const [rankdir, setRankdir] = useState<DotOptions["rankdir"]>("TB");
  const [showDates, setShowDates] = useState(true);
  const [showPlaces, setShowPlaces] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [svg, setSvg] = useState<string>("");
  const [rendering, setRendering] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const dragRef = useRef<{ x: number; y: number; sx: number; sy: number } | null>(null);
  const svgWrapRef = useRef<HTMLDivElement>(null);
  const vizRef = useRef<any>(null);

  // Initialise viz once
  useEffect(() => {
    vizInstance().then((v: any) => (vizRef.current = v));
  }, []);

  // Combined GEDCOM text
  const combined = useMemo(() => {
    if (parts.length === 0) return "";
    return recombineMultipart(parts.map((p) => p.text));
  }, [parts]);

  // Parse whenever combined changes
  useEffect(() => {
    if (!combined) {
      setGedcom(null);
      return;
    }
    try {
      setStatus("Parsing GEDCOM…");
      const g = buildGedcom(combined);
      setGedcom(g);
      setStatus(
        `Parsed ${g.individuals.size.toLocaleString()} individuals and ${g.families.size.toLocaleString()} families.`,
      );
      if (!rootId || !g.individuals.has(rootId)) {
        // pick a sensible default root (someone with descendants)
        const candidate =
          [...g.individuals.values()].find((i) => i.fams.length > 0) ??
          g.individuals.values().next().value;
        setRootId(candidate?.id);
      }
    } catch (e: any) {
      setError(e.message ?? String(e));
    }
  }, [combined]);

  // Render with GraphViz
  const renderGraph = useCallback(async () => {
    if (!gedcom || !vizRef.current) return;
    setRendering(true);
    try {
      const dot = gedcomToDot(gedcom, {
        rootId,
        maxDepth,
        rankdir,
        showDates,
        showPlaces,
        theme,
      });
      const svgEl: SVGSVGElement = vizRef.current.renderSVGElement(dot);
      // remove fixed width/height to allow zoom/pan
      svgEl.removeAttribute("width");
      svgEl.removeAttribute("height");
      svgEl.setAttribute("style", "width:100%;height:100%;");
      // wire click → set as root
      svgEl.querySelectorAll("g.node").forEach((g) => {
        const title = g.querySelector("title")?.textContent ?? "";
        if (title.startsWith("@I")) {
          (g as any).style.cursor = "pointer";
          g.addEventListener("click", (ev) => {
            ev.stopPropagation();
            setRootId(title);
          });
        }
      });
      setSvg(svgEl.outerHTML);
    } catch (e: any) {
      setError("GraphViz error: " + (e?.message ?? String(e)));
    } finally {
      setRendering(false);
    }
  }, [gedcom, rootId, maxDepth, rankdir, showDates, showPlaces, theme]);

  useEffect(() => {
    renderGraph();
  }, [renderGraph]);

  // === Input handlers ============================================
  const addPart = (name: string, text: string) => {
    setError(null);
    setParts((prev) => [
      ...prev,
      { id: crypto.randomUUID(), name, size: text.length, text },
    ]);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        setError("Clipboard is empty.");
        return;
      }
      addPart(`Clipboard ${new Date().toLocaleTimeString()}`, text);
      setStatus("Pasted from clipboard.");
    } catch (e: any) {
      setError("Cannot read clipboard: " + (e?.message ?? e));
    }
  };

  const handleFiles = async (files: FileList | null) => {
    if (!files) return;
    setError(null);
    for (const f of Array.from(files)) {
      setStatus(`Loading ${f.name} (${(f.size / 1024 / 1024).toFixed(2)} MB)…`);
      setProgress({ loaded: 0, total: f.size });
      try {
        const text = await readFileChunked(f, (loaded, total) =>
          setProgress({ loaded, total }),
        );
        addPart(f.name, text);
      } catch (e: any) {
        setError(`Failed to load ${f.name}: ${e?.message ?? e}`);
      }
    }
    setProgress(null);
    setStatus("File(s) loaded.");
  };

  const handleUrl = async () => {
    if (!url.trim()) return;
    setError(null);
    setStatus(`Fetching ${url}…`);
    try {
      const text = await loadFromUrl(url.trim());
      addPart(url.trim(), text);
      setStatus("Remote GEDCOM loaded.");
    } catch (e: any) {
      setError("URL load failed: " + (e?.message ?? e));
      setStatus("Ready.");
    }
  };

  const removePart = (id: string) =>
    setParts((p) => p.filter((x) => x.id !== id));
  const clearAll = () => {
    setParts([]);
    setSvg("");
    setRootId(undefined);
    setStatus("Cleared.");
  };
  const loadSample = () => {
    clearAll();
    addPart("Sample (Lovelace/Byron)", SAMPLE_GEDCOM);
  };

  // === Pan / zoom ================================================
  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom((z) => Math.min(8, Math.max(0.1, z * factor)));
  };
  const onMouseDown = (e: React.MouseEvent) => {
    dragRef.current = { x: e.clientX, y: e.clientY, sx: pan.x, sy: pan.y };
  };
  const onMouseMove = (e: React.MouseEvent) => {
    if (!dragRef.current) return;
    setPan({
      x: dragRef.current.sx + (e.clientX - dragRef.current.x),
      y: dragRef.current.sy + (e.clientY - dragRef.current.y),
    });
  };
  const endDrag = () => (dragRef.current = null);
  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // === Search ====================================================
  const matchingPeople = useMemo(() => {
    if (!gedcom) return [];
    const q = search.trim().toLowerCase();
    const all = [...gedcom.individuals.values()];
    if (!q) return all.slice(0, 50);
    return all
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.id.toLowerCase().includes(q) ||
          p.surname?.toLowerCase().includes(q),
      )
      .slice(0, 50);
  }, [gedcom, search]);

  // === Download SVG ==============================================
  const downloadSvg = () => {
    if (!svg) return;
    const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "family-tree.svg";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="grid h-full grid-cols-[340px_1fr] grid-rows-[auto_1fr] gap-0">
      {/* Sidebar */}
      <aside className="row-span-2 flex flex-col gap-4 overflow-y-auto border-r border-slate-700/60 bg-slate-900/60 p-4 text-slate-200">
        <div>
          <h2 className="mb-2 text-sm font-bold uppercase tracking-wider text-slate-400">
            Input
          </h2>
          <div className="flex flex-col gap-2">
            <button
              onClick={handlePaste}
              className="rounded-md bg-emerald-600 px-3 py-2 text-sm font-medium hover:bg-emerald-500 active:scale-[0.98]"
            >
              📋 Paste from clipboard
            </button>
            <label className="cursor-pointer rounded-md bg-sky-600 px-3 py-2 text-center text-sm font-medium hover:bg-sky-500">
              📁 Open file(s) — large OK
              <input
                type="file"
                multiple
                accept=".ged,.gedcom,.txt,text/plain"
                hidden
                onChange={(e) => handleFiles(e.target.files)}
              />
            </label>
            <div className="flex gap-1">
              <input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/tree.ged"
                className="min-w-0 flex-1 rounded-md bg-slate-800 px-2 py-2 text-xs outline-none ring-1 ring-slate-700 focus:ring-sky-500"
              />
              <button
                onClick={handleUrl}
                className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-medium hover:bg-indigo-500"
              >
                Fetch
              </button>
            </div>
            <div className="flex gap-2">
              <button
                onClick={loadSample}
                className="flex-1 rounded-md bg-slate-700 px-3 py-1.5 text-xs hover:bg-slate-600"
              >
                Load sample
              </button>
              <button
                onClick={clearAll}
                className="flex-1 rounded-md bg-rose-700/80 px-3 py-1.5 text-xs hover:bg-rose-600"
              >
                Clear all
              </button>
            </div>
          </div>
        </div>

        {progress && (
          <div>
            <div className="mb-1 text-xs text-slate-400">
              {(progress.loaded / 1024 / 1024).toFixed(2)} /{" "}
              {(progress.total / 1024 / 1024).toFixed(2)} MB
            </div>
            <div className="h-2 overflow-hidden rounded bg-slate-800">
              <div
                className="h-full bg-sky-500 transition-all"
                style={{
                  width: `${(progress.loaded / progress.total) * 100}%`,
                }}
              />
            </div>
          </div>
        )}

        {parts.length > 0 && (
          <div>
            <h2 className="mb-2 text-sm font-bold uppercase tracking-wider text-slate-400">
              Parts ({parts.length}) — auto-recombined
            </h2>
            <ul className="flex flex-col gap-1">
              {parts.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between gap-2 rounded bg-slate-800/70 px-2 py-1 text-xs"
                >
                  <span className="truncate" title={p.name}>
                    {p.name}
                  </span>
                  <span className="shrink-0 text-slate-500">
                    {(p.size / 1024).toFixed(1)} KB
                  </span>
                  <button
                    onClick={() => removePart(p.id)}
                    className="shrink-0 rounded bg-slate-700 px-1.5 text-slate-300 hover:bg-rose-600"
                  >
                    ×
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {gedcom && (
          <>
            <div>
              <h2 className="mb-2 text-sm font-bold uppercase tracking-wider text-slate-400">
                View
              </h2>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <label className="flex flex-col gap-1">
                  Direction
                  <select
                    value={rankdir}
                    onChange={(e) => setRankdir(e.target.value as any)}
                    className="rounded bg-slate-800 px-1 py-1 ring-1 ring-slate-700"
                  >
                    <option value="TB">Top → Bottom</option>
                    <option value="BT">Bottom → Top</option>
                    <option value="LR">Left → Right</option>
                    <option value="RL">Right → Left</option>
                  </select>
                </label>
                <label className="flex flex-col gap-1">
                  Generations
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={maxDepth}
                    onChange={(e) => setMaxDepth(parseInt(e.target.value) || 1)}
                    className="rounded bg-slate-800 px-1 py-1 ring-1 ring-slate-700"
                  />
                </label>
                <label className="flex items-center gap-1">
                  <input
                    type="checkbox"
                    checked={showDates}
                    onChange={(e) => setShowDates(e.target.checked)}
                  />
                  Dates
                </label>
                <label className="flex items-center gap-1">
                  <input
                    type="checkbox"
                    checked={showPlaces}
                    onChange={(e) => setShowPlaces(e.target.checked)}
                  />
                  Places
                </label>
                <label className="col-span-2 flex items-center gap-1">
                  <input
                    type="checkbox"
                    checked={theme === "dark"}
                    onChange={(e) => setTheme(e.target.checked ? "dark" : "light")}
                  />
                  Dark theme
                </label>
              </div>
            </div>

            <div>
              <h2 className="mb-2 text-sm font-bold uppercase tracking-wider text-slate-400">
                People — click to focus
              </h2>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name…"
                className="mb-2 w-full rounded bg-slate-800 px-2 py-1.5 text-xs ring-1 ring-slate-700 focus:ring-sky-500 focus:outline-none"
              />
              <ul className="max-h-72 overflow-y-auto rounded border border-slate-800 text-xs">
                {matchingPeople.map((p) => (
                  <li key={p.id}>
                    <button
                      onClick={() => setRootId(p.id)}
                      className={`flex w-full items-center justify-between px-2 py-1 text-left hover:bg-slate-800 ${
                        rootId === p.id ? "bg-sky-700/40" : ""
                      }`}
                    >
                      <span className="truncate">
                        {p.sex === "F" ? "♀" : p.sex === "M" ? "♂" : "·"}{" "}
                        {p.name}
                      </span>
                      {p.birth?.date && (
                        <span className="ml-2 shrink-0 text-slate-500">
                          {p.birth.date.split(" ").pop()}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
                {matchingPeople.length === 0 && (
                  <li className="px-2 py-2 text-slate-500">No matches</li>
                )}
              </ul>
            </div>
          </>
        )}

        <div className="mt-auto text-[10px] leading-relaxed text-slate-500">
          GedViz parses GEDCOM 5.5/7. Click anyone in the graph to re-root.
          Scroll to zoom, drag to pan. Multipart files recombine automatically.
        </div>
      </aside>

      {/* Toolbar */}
      <header className="flex items-center gap-2 border-b border-slate-700/60 bg-slate-900/60 px-4 py-2 text-sm text-slate-200">
        <span className="font-semibold">🌳 GedViz</span>
        <span className="mx-2 h-4 w-px bg-slate-700" />
        <span className="text-slate-400">{status}</span>
        {error && (
          <span className="ml-2 rounded bg-rose-700/40 px-2 py-0.5 text-xs text-rose-200">
            {error}
          </span>
        )}
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => setZoom((z) => Math.min(8, z * 1.2))}
            className="rounded bg-slate-800 px-2 py-1 text-xs hover:bg-slate-700"
          >
            ＋
          </button>
          <button
            onClick={() => setZoom((z) => Math.max(0.1, z / 1.2))}
            className="rounded bg-slate-800 px-2 py-1 text-xs hover:bg-slate-700"
          >
            －
          </button>
          <button
            onClick={resetView}
            className="rounded bg-slate-800 px-2 py-1 text-xs hover:bg-slate-700"
          >
            Reset
          </button>
          <span className="text-xs text-slate-500">
            {(zoom * 100).toFixed(0)}%
          </span>
          <button
            onClick={downloadSvg}
            disabled={!svg}
            className="rounded bg-emerald-700 px-2 py-1 text-xs hover:bg-emerald-600 disabled:opacity-40"
          >
            ⬇ SVG
          </button>
        </div>
      </header>

      {/* Canvas */}
      <main
        ref={svgWrapRef}
        onWheel={onWheel}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={endDrag}
        onMouseLeave={endDrag}
        className="relative overflow-hidden bg-slate-950 select-none"
        style={{ cursor: dragRef.current ? "grabbing" : "grab" }}
      >
        {!gedcom && (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center text-slate-400">
            <div className="text-6xl">🌳</div>
            <p className="text-lg">Paste, upload, or fetch a GEDCOM file</p>
            <p className="max-w-md text-sm text-slate-500">
              Multiple files / clipboard pastes / URLs are merged automatically.
              Try the sample to see a quick demo.
            </p>
          </div>
        )}
        {rendering && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 rounded-full bg-slate-800/80 px-3 py-1 text-xs text-slate-300 backdrop-blur">
            Rendering…
          </div>
        )}
        <div
          className="absolute inset-0 origin-center"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: "50% 50%",
          }}
          dangerouslySetInnerHTML={{ __html: svg }}
        />
      </main>
    </div>
  );
}
