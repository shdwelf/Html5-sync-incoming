import { useState } from "react";
import GedVizApp from "./gedcom/GedVizApp";
import CryptoMonopoly from "./crypto/CryptoMonopoly";

type Tab = "gedviz" | "crypto";

export default function App() {
  const [tab, setTab] = useState<Tab>("gedviz");

  return (
    <div className="flex h-full flex-col">
      <nav className="flex items-center gap-1 border-b border-slate-700/60 bg-slate-950 px-3 py-1.5 text-sm">
        <TabBtn active={tab === "gedviz"} onClick={() => setTab("gedviz")}>
          🌳 GedViz — Family Tree
        </TabBtn>
        <TabBtn active={tab === "crypto"} onClick={() => setTab("crypto")}>
          🪙 CryptoMonopoly (webxdc)
        </TabBtn>
        <span className="ml-auto text-[10px] text-slate-500">
          self-contained HTML5 app • GraphViz • webxdc
        </span>
      </nav>
      <div className="min-h-0 flex-1">
        {tab === "gedviz" ? <GedVizApp /> : <CryptoMonopoly />}
      </div>
    </div>
  );
}

function TabBtn({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-md px-3 py-1.5 transition ${
        active
          ? "bg-slate-800 text-white ring-1 ring-slate-700"
          : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
      }`}
    >
      {children}
    </button>
  );
}
