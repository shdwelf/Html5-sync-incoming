// A 24-tile crypto-themed Monopoly board.

export type TileType = "GO" | "COIN" | "EXCHANGE" | "EVENT" | "JAIL" | "FREE" | "AIRDROP" | "TAX";

export interface Tile {
  index: number;
  name: string;
  type: TileType;
  symbol?: string;     // e.g. BTC
  color?: string;      // tailwind-compatible color
  price?: number;
  rent?: number[];     // by # houses (0..4)
  houseCost?: number;
}

export const BOARD: Tile[] = [
  { index: 0,  name: "GO",            type: "GO" },
  { index: 1,  name: "Bitcoin",       type: "COIN", symbol: "BTC", color: "#f7931a", price: 240, rent: [20, 50, 140, 380, 620], houseCost: 120 },
  { index: 2,  name: "Block Reward",  type: "AIRDROP" },
  { index: 3,  name: "Ethereum",      type: "COIN", symbol: "ETH", color: "#627eea", price: 220, rent: [18, 45, 130, 360, 600], houseCost: 110 },
  { index: 4,  name: "Gas Fees",      type: "TAX" },
  { index: 5,  name: "Binance",       type: "EXCHANGE", symbol: "BNB-CEX", color: "#f0b90b", price: 200 },
  { index: 6,  name: "Solana",        type: "COIN", symbol: "SOL", color: "#14f195", price: 180, rent: [14, 35, 100, 300, 500], houseCost: 90 },
  { index: 7,  name: "Smart Contract",type: "EVENT" },
  { index: 8,  name: "Cardano",       type: "COIN", symbol: "ADA", color: "#0033ad", price: 180, rent: [14, 35, 100, 300, 500], houseCost: 90 },
  { index: 9,  name: "Polkadot",      type: "COIN", symbol: "DOT", color: "#e6007a", price: 160, rent: [12, 30, 90, 270, 450], houseCost: 80 },
  { index: 10, name: "Jail / Rug",    type: "JAIL" },
  { index: 11, name: "Chainlink",     type: "COIN", symbol: "LINK", color: "#2a5ada", price: 160, rent: [12, 30, 90, 270, 450], houseCost: 80 },
  { index: 12, name: "Avalanche",     type: "COIN", symbol: "AVAX", color: "#e84142", price: 200, rent: [16, 40, 120, 340, 560], houseCost: 100 },
  { index: 13, name: "Uniswap",       type: "EXCHANGE", symbol: "UNI-DEX", color: "#ff007a", price: 200 },
  { index: 14, name: "Polygon",       type: "COIN", symbol: "MATIC", color: "#8247e5", price: 180, rent: [14, 35, 100, 300, 500], houseCost: 90 },
  { index: 15, name: "Block Reward",  type: "AIRDROP" },
  { index: 16, name: "Cosmos",        type: "COIN", symbol: "ATOM", color: "#2e3148", price: 180, rent: [14, 35, 100, 300, 500], houseCost: 90 },
  { index: 17, name: "Free Mint",     type: "FREE" },
  { index: 18, name: "Litecoin",      type: "COIN", symbol: "LTC", color: "#a6a9aa", price: 200, rent: [16, 40, 120, 340, 560], houseCost: 100 },
  { index: 19, name: "Dogecoin",      type: "COIN", symbol: "DOGE", color: "#c2a633", price: 160, rent: [12, 30, 90, 270, 450], houseCost: 80 },
  { index: 20, name: "Coinbase",      type: "EXCHANGE", symbol: "COIN-CEX", color: "#0052ff", price: 200 },
  { index: 21, name: "Network Hack",  type: "EVENT" },
  { index: 22, name: "Monero",        type: "COIN", symbol: "XMR", color: "#ff6600", price: 220, rent: [18, 45, 130, 360, 600], houseCost: 110 },
  { index: 23, name: "Validator Tax", type: "TAX" },
];

export const BOARD_SIZE = BOARD.length;
export const GO_BONUS = 200;
export const JAIL_INDEX = 10;
export const STARTING_CASH = 1500;

export const EVENT_DECK: { text: string; effect: { kind: "cash" | "move" | "jail" | "airdrop"; value?: number; target?: number } }[] = [
  { text: "🚀 Bull market! Earn 200 from every other player.", effect: { kind: "cash", value: 200 } },
  { text: "🩸 Bear market. Pay 100 to the bank.", effect: { kind: "cash", value: -100 } },
  { text: "🪂 Surprise airdrop: +150.", effect: { kind: "cash", value: 150 } },
  { text: "🛠 Network upgrade. Pay 50 gas.", effect: { kind: "cash", value: -50 } },
  { text: "👮 Rug pulled! Go to jail.", effect: { kind: "jail" } },
  { text: "🎁 NFT mint. Receive 80.", effect: { kind: "cash", value: 80 } },
  { text: "📉 Liquidation. Pay 120.", effect: { kind: "cash", value: -120 } },
  { text: "🌕 To the moon. Advance to GO.", effect: { kind: "move", target: 0 } },
];
