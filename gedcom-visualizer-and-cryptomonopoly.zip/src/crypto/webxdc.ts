// Minimal webxdc shim so the game also runs as a normal web page.
// When packaged as a real .xdc inside Delta Chat, window.webxdc is provided
// by the host. Here we polyfill with localStorage so it still works.
//
// Reference: https://docs.webxdc.org/

export interface WebxdcUpdate<T = any> {
  payload: T;
  info?: string;
  summary?: string;
  serial: number;
  max_serial: number;
}

export interface Webxdc<T = any> {
  selfAddr: string;
  selfName: string;
  sendUpdate(update: { payload: T; info?: string; summary?: string }, descr: string): void;
  setUpdateListener(
    listener: (u: WebxdcUpdate<T>) => void,
    serial?: number,
  ): Promise<number>;
}

declare global {
  interface Window {
    webxdc?: Webxdc<any>;
  }
}

interface StoredUpdate<T> {
  payload: T;
  info?: string;
  summary?: string;
  serial: number;
}

const STORAGE_KEY = "cryptomonopoly_xdc_updates";

function loadUpdates<T>(): StoredUpdate<T>[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]");
  } catch {
    return [];
  }
}
function saveUpdates<T>(arr: StoredUpdate<T>[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

class WebxdcShim<T> implements Webxdc<T> {
  selfAddr: string;
  selfName: string;
  private listeners: ((u: WebxdcUpdate<T>) => void)[] = [];

  constructor() {
    let addr = localStorage.getItem("cryptomonopoly_self_addr");
    if (!addr) {
      addr = "player-" + Math.random().toString(36).slice(2, 8) + "@local";
      localStorage.setItem("cryptomonopoly_self_addr", addr);
    }
    this.selfAddr = addr;
    this.selfName = localStorage.getItem("cryptomonopoly_self_name") ?? addr;

    // Listen for cross-tab updates so two browser tabs can "play" together.
    window.addEventListener("storage", (e) => {
      if (e.key === STORAGE_KEY) this.deliverAll();
    });
  }

  sendUpdate(update: { payload: T; info?: string; summary?: string }) {
    const all = loadUpdates<T>();
    const serial = all.length + 1;
    all.push({ ...update, serial });
    saveUpdates(all);
    this.deliverAll();
  }

  async setUpdateListener(listener: (u: WebxdcUpdate<T>) => void, serial = 0) {
    this.listeners.push(listener);
    const all = loadUpdates<T>();
    const max = all.length;
    for (const u of all) {
      if (u.serial > serial)
        listener({ ...u, max_serial: max });
    }
    return max;
  }

  private deliverAll() {
    const all = loadUpdates<T>();
    const max = all.length;
    for (const l of this.listeners) {
      for (const u of all) l({ ...u, max_serial: max });
    }
  }
}

/** Get the webxdc API, polyfilling with localStorage when not in a real xdc host. */
export function getWebxdc<T = any>(): Webxdc<T> {
  if (!window.webxdc) {
    (window as any).webxdc = new WebxdcShim<T>();
  }
  return window.webxdc as Webxdc<T>;
}

/** Clear local shim state (only affects the polyfill, not real xdc hosts). */
export function resetWebxdcShim() {
  localStorage.removeItem(STORAGE_KEY);
  location.reload();
}
