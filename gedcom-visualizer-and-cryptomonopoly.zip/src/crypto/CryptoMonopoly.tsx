import { useEffect, useMemo, useRef, useState } from "react";
import { getWebxdc, resetWebxdcShim, type Webxdc } from "./webxdc";
import {
  BOARD,
  BOARD_SIZE,
  EVENT_DECK,
  GO_BONUS,
  JAIL_INDEX,
  STARTING_CASH,
  type Tile,
} from "./board";

// ---------- Game state types -----------------------------------
interface Player {
  addr: string;
  name: string;
  color: string;
  cash: number;
  position: number;
  jailTurns: number;
  bankrupt: boolean;
  joinedAt: number;
}
interface Ownership {
  [tileIndex: number]: { owner: string; houses: number };
}
interface GameState {
  players: Record<string, Player>;
  order: string[];                       // turn order
  currentTurn: number;                   // index into order
  ownership: Ownership;
  log: { ts: number; text: string }[];
  started: boolean;
  lastDice?: [number, number];
  pendingPurchase?: { tile: number; player: string };
  pendingEvent?: { player: string; cardIdx: number };
}

type Action =
  | { type: "JOIN"; addr: string; name: string; color: string }
  | { type: "START" }
  | { type: "ROLL"; addr: string; dice: [number, number]; cardIdx?: number }
  | { type: "BUY"; addr: string; tile: number }
  | { type: "SKIP_BUY"; addr: string }
  | { type: "BUILD"; addr: string; tile: number }
  | { type: "END_TURN"; addr: string }
  | { type: "RESET" };

const COLORS = ["#ef4444", "#3b82f6", "#10b981", "#f59e0b", "#a855f7", "#ec4899"];

const initialState: GameState = {
  players: {},
  order: [],
  currentTurn: 0,
  ownership: {},
  log: [{ ts: Date.now(), text: "🪙 CryptoMonopoly lobby created." }],
  started: false,
};

// ---------- Pure reducer (deterministic on all peers) -----------
function reduce(state: GameState, a: Action): GameState {
  const s = structuredClone(state) as GameState;
  const append = (t: string) => s.log.push({ ts: Date.now(), text: t });

  switch (a.type) {
    case "JOIN": {
      if (s.started || s.players[a.addr]) return s;
      s.players[a.addr] = {
        addr: a.addr,
        name: a.name,
        color: a.color,
        cash: STARTING_CASH,
        position: 0,
        jailTurns: 0,
        bankrupt: false,
        joinedAt: Date.now(),
      };
      s.order.push(a.addr);
      append(`👤 ${a.name} joined.`);
      return s;
    }
    case "START": {
      if (s.started || s.order.length < 2) return s;
      s.started = true;
      append(`🚀 Game started with ${s.order.length} players.`);
      return s;
    }
    case "ROLL": {
      const p = s.players[a.addr];
      if (!p || s.order[s.currentTurn] !== a.addr) return s;
      if (s.pendingPurchase || s.pendingEvent) return s;
      s.lastDice = a.dice;
      const total = a.dice[0] + a.dice[1];

      // Jail handling
      if (p.jailTurns > 0) {
        if (a.dice[0] === a.dice[1]) {
          p.jailTurns = 0;
          append(`🎲 ${p.name} rolled doubles and escaped jail!`);
        } else {
          p.jailTurns--;
          append(`⛓ ${p.name} stays in jail (${p.jailTurns} turns left).`);
          return s;
        }
      }

      const newPos = (p.position + total) % BOARD_SIZE;
      if (newPos < p.position) {
        p.cash += GO_BONUS;
        append(`💰 ${p.name} passed GO (+${GO_BONUS}).`);
      }
      p.position = newPos;
      const tile = BOARD[newPos];
      append(`🎲 ${p.name} rolled ${a.dice[0]}+${a.dice[1]} → ${tile.name}.`);

      // Land effect
      switch (tile.type) {
        case "COIN":
        case "EXCHANGE": {
          const own = s.ownership[newPos];
          if (!own) {
            s.pendingPurchase = { tile: newPos, player: a.addr };
          } else if (own.owner !== a.addr) {
            const rent = tile.type === "EXCHANGE"
              ? 25 * countExchanges(s, own.owner)
              : (tile.rent?.[own.houses] ?? 0);
            const payer = p;
            const owner = s.players[own.owner];
            const pay = Math.min(payer.cash, rent);
            payer.cash -= pay;
            owner.cash += pay;
            append(`💸 ${payer.name} pays ${rent} rent to ${owner.name}.`);
            if (payer.cash < 0 || (rent > 0 && pay < rent)) {
              payer.bankrupt = true;
              append(`🪦 ${payer.name} is bankrupt!`);
            }
          }
          break;
        }
        case "TAX": {
          const t = 100;
          p.cash -= t;
          append(`🧾 ${p.name} pays ${t} gas/tax.`);
          break;
        }
        case "AIRDROP": {
          const g = 75 + Math.floor(Math.random() * 75);
          p.cash += g;
          append(`🪂 ${p.name} airdrop +${g}.`);
          break;
        }
        case "FREE": append(`✨ Free mint — nothing happens.`); break;
        case "GO":   p.cash += GO_BONUS; append(`💰 ${p.name} landed on GO (+${GO_BONUS}).`); break;
        case "JAIL": append(`🛑 ${p.name} just visiting.`); break;
        case "EVENT": {
          const idx = a.cardIdx ?? 0;
          s.pendingEvent = { player: a.addr, cardIdx: idx };
          const card = EVENT_DECK[idx % EVENT_DECK.length];
          append(`🎴 ${p.name} draws: ${card.text}`);
          applyEvent(s, a.addr, idx);
          break;
        }
      }
      return s;
    }
    case "BUY": {
      if (!s.pendingPurchase || s.pendingPurchase.player !== a.addr || s.pendingPurchase.tile !== a.tile) return s;
      const tile = BOARD[a.tile];
      const p = s.players[a.addr];
      if (!tile.price || p.cash < tile.price) {
        append(`❌ ${p.name} cannot afford ${tile.name}.`);
      } else {
        p.cash -= tile.price;
        s.ownership[a.tile] = { owner: a.addr, houses: 0 };
        append(`🛒 ${p.name} bought ${tile.name} for ${tile.price}.`);
      }
      s.pendingPurchase = undefined;
      return s;
    }
    case "SKIP_BUY": {
      if (s.pendingPurchase?.player !== a.addr) return s;
      s.pendingPurchase = undefined;
      append(`🤷 ${s.players[a.addr].name} skipped the purchase.`);
      return s;
    }
    case "BUILD": {
      const own = s.ownership[a.tile];
      const tile = BOARD[a.tile];
      const p = s.players[a.addr];
      if (!own || own.owner !== a.addr || tile.type !== "COIN" || own.houses >= 4) return s;
      if (!tile.houseCost || p.cash < tile.houseCost) return s;
      p.cash -= tile.houseCost;
      own.houses++;
      append(`🏗 ${p.name} built on ${tile.name} (now ${own.houses} validators).`);
      return s;
    }
    case "END_TURN": {
      if (s.order[s.currentTurn] !== a.addr) return s;
      if (s.pendingPurchase) s.pendingPurchase = undefined;
      let next = s.currentTurn;
      for (let i = 0; i < s.order.length; i++) {
        next = (next + 1) % s.order.length;
        if (!s.players[s.order[next]].bankrupt) break;
      }
      s.currentTurn = next;
      s.pendingEvent = undefined;
      append(`➡ Turn passes to ${s.players[s.order[next]].name}.`);
      return s;
    }
    case "RESET": return { ...initialState, log: [{ ts: Date.now(), text: "🔄 Game reset." }] };
  }
  return s;
}

function countExchanges(s: GameState, owner: string) {
  let n = 0;
  for (const [idx, o] of Object.entries(s.ownership)) {
    if (o.owner === owner && BOARD[+idx].type === "EXCHANGE") n++;
  }
  return n;
}

function applyEvent(s: GameState, playerAddr: string, cardIdx: number) {
  const card = EVENT_DECK[cardIdx % EVENT_DECK.length];
  const p = s.players[playerAddr];
  const e = card.effect;
  if (e.kind === "cash" && e.value) {
    p.cash += e.value;
  } else if (e.kind === "move" && e.target !== undefined) {
    if (e.target < p.position) p.cash += GO_BONUS;
    p.position = e.target;
  } else if (e.kind === "jail") {
    p.position = JAIL_INDEX;
    p.jailTurns = 3;
  }
}

// ---------- React component -------------------------------------
export default function CryptoMonopoly() {
  const xdcRef = useRef<Webxdc<Action> | null>(null);
  const [state, setState] = useState<GameState>(initialState);
  const [name, setName] = useState(() => localStorage.getItem("cryptomonopoly_self_name") ?? "");
  const [joined, setJoined] = useState(false);

  // Subscribe to webxdc updates → rebuild state
  useEffect(() => {
    const xdc = getWebxdc<Action>();
    xdcRef.current = xdc;
    let s: GameState = initialState;
    xdc.setUpdateListener((u) => {
      s = reduce(s, u.payload);
      setState({ ...s });
      if (u.serial === u.max_serial) {
        // sync UI
        setJoined(Object.prototype.hasOwnProperty.call(s.players, xdc.selfAddr));
      }
    }, 0);
  }, []);

  const send = (a: Action, summary?: string) =>
    xdcRef.current?.sendUpdate({ payload: a, summary, info: summary }, summary ?? a.type);

  const selfAddr = xdcRef.current?.selfAddr ?? "";
  const me = state.players[selfAddr];
  const isMyTurn = state.started && state.order[state.currentTurn] === selfAddr;

  const join = () => {
    if (!name.trim()) return;
    localStorage.setItem("cryptomonopoly_self_name", name);
    const color = COLORS[state.order.length % COLORS.length];
    send({ type: "JOIN", addr: selfAddr, name: name.trim(), color }, `${name} joined`);
  };

  const roll = () => {
    const dice: [number, number] = [
      1 + Math.floor(Math.random() * 6),
      1 + Math.floor(Math.random() * 6),
    ];
    const cardIdx = Math.floor(Math.random() * EVENT_DECK.length);
    send({ type: "ROLL", addr: selfAddr, dice, cardIdx }, `🎲 ${dice[0]}+${dice[1]}`);
  };

  // ---------- Render ----------
  return (
    <div className="grid h-full grid-cols-[1fr_360px] grid-rows-[auto_1fr] gap-0 bg-gradient-to-br from-indigo-950 via-slate-950 to-slate-900 text-slate-100">
      <header className="col-span-2 flex items-center gap-3 border-b border-indigo-800/50 bg-slate-900/70 px-4 py-2">
        <span className="text-xl">🪙</span>
        <h2 className="text-lg font-bold tracking-tight">CryptoMonopoly</h2>
        <span className="rounded bg-indigo-700/40 px-2 py-0.5 text-[10px] uppercase tracking-wider text-indigo-200">
          webxdc
        </span>
        <div className="ml-auto flex items-center gap-3 text-xs">
          <span className="text-slate-400">you:</span>
          <span className="font-mono text-slate-200">{selfAddr}</span>
          <button
            onClick={resetWebxdcShim}
            className="rounded bg-rose-700/60 px-2 py-1 text-[10px] hover:bg-rose-600"
            title="Clear local shim state (does nothing in a real Delta Chat webxdc host)"
          >
            Reset shim
          </button>
        </div>
      </header>

      {/* Board */}
      <main className="overflow-auto p-4">
        {!state.started ? (
          <Lobby
            state={state}
            name={name}
            setName={setName}
            joined={joined}
            onJoin={join}
            onStart={() => send({ type: "START" }, "🚀 Game start")}
          />
        ) : (
          <Board state={state} />
        )}
      </main>

      {/* Side panel */}
      <aside className="row-span-1 flex h-full flex-col gap-3 overflow-hidden border-l border-indigo-800/50 bg-slate-900/70 p-3">
        <PlayerPanel state={state} selfAddr={selfAddr} />
        {state.started && (
          <Controls
            state={state}
            me={me}
            isMyTurn={isMyTurn}
            onRoll={roll}
            onBuy={(t) => send({ type: "BUY", addr: selfAddr, tile: t }, "🛒 Buy")}
            onSkipBuy={() => send({ type: "SKIP_BUY", addr: selfAddr }, "Skip")}
            onBuild={(t) => send({ type: "BUILD", addr: selfAddr, tile: t }, "🏗 Build")}
            onEnd={() => send({ type: "END_TURN", addr: selfAddr }, "End turn")}
          />
        )}
        <Log state={state} />
      </aside>
    </div>
  );
}

// ===== Sub-components ============================================

function Lobby(props: {
  state: GameState;
  name: string;
  setName: (s: string) => void;
  joined: boolean;
  onJoin: () => void;
  onStart: () => void;
}) {
  return (
    <div className="mx-auto max-w-xl rounded-2xl border border-indigo-800/40 bg-slate-900/60 p-6 shadow-xl">
      <h3 className="mb-1 text-2xl font-bold">🪙 Lobby</h3>
      <p className="mb-4 text-sm text-slate-400">
        Share this webxdc into a Delta Chat group, or open this page in another browser
        tab — moves sync over the realtime channel.
      </p>
      {!props.joined ? (
        <div className="flex gap-2">
          <input
            value={props.name}
            onChange={(e) => props.setName(e.target.value)}
            placeholder="Your handle"
            className="flex-1 rounded bg-slate-800 px-3 py-2 ring-1 ring-slate-700 focus:ring-indigo-500 outline-none"
          />
          <button
            onClick={props.onJoin}
            disabled={!props.name.trim()}
            className="rounded bg-emerald-600 px-4 py-2 font-medium hover:bg-emerald-500 disabled:opacity-40"
          >
            Join
          </button>
        </div>
      ) : (
        <p className="rounded bg-emerald-900/40 px-3 py-2 text-sm text-emerald-200">
          ✓ You are in the lobby. Waiting for more players…
        </p>
      )}

      <h4 className="mt-6 mb-2 text-sm font-bold uppercase tracking-wider text-slate-400">
        Players ({props.state.order.length})
      </h4>
      <ul className="space-y-1">
        {props.state.order.map((addr) => {
          const p = props.state.players[addr];
          return (
            <li key={addr} className="flex items-center gap-2 rounded bg-slate-800/60 px-3 py-2">
              <span className="h-3 w-3 rounded-full" style={{ background: p.color }} />
              <span className="font-medium">{p.name}</span>
              <span className="ml-auto text-xs text-slate-500">{addr}</span>
            </li>
          );
        })}
        {props.state.order.length === 0 && (
          <li className="text-sm text-slate-500">No players yet.</li>
        )}
      </ul>

      <button
        onClick={props.onStart}
        disabled={props.state.order.length < 2}
        className="mt-4 w-full rounded bg-indigo-600 px-4 py-3 font-bold hover:bg-indigo-500 disabled:opacity-40"
      >
        {props.state.order.length < 2 ? "Need ≥ 2 players to start" : "🚀 Start Game"}
      </button>
    </div>
  );
}

function Board({ state }: { state: GameState }) {
  // Lay out the 24-tile board around a 7×7 grid (perimeter only).
  // Tiles 0–6 across the top, 6–12 down the right, 12–18 across the bottom (reversed), 18–24/0 up the left.
  const cells: ({ tile: Tile; players: string[] } | null)[][] = Array.from({ length: 7 }, () => Array(7).fill(null));
  const place = (r: number, c: number, idx: number) => {
    cells[r][c] = { tile: BOARD[idx], players: state.order.filter((a) => state.players[a].position === idx) };
  };
  // top row: 0..6
  for (let i = 0; i < 7; i++) place(0, i, i);
  // right col: 7..11 (rows 1..5)
  for (let i = 0; i < 5; i++) place(1 + i, 6, 7 + i);
  // bottom row: 12..18 (reverse so movement reads clockwise)
  for (let i = 0; i < 7; i++) place(6, 6 - i, 12 + i);
  // left col bottom→top: 19..23 (rows 5..1)
  for (let i = 0; i < 5; i++) place(5 - i, 0, 19 + i);

  return (
    <div className="mx-auto aspect-square w-full max-w-[820px]">
      <div className="grid h-full w-full grid-cols-7 grid-rows-7 gap-1">
        {cells.flatMap((row, r) =>
          row.map((cell, c) => {
            if (!cell) {
              // Center area
              if (r === 1 && c === 1) {
                return (
                  <div
                    key={`${r}-${c}`}
                    className="col-span-5 row-span-5 flex flex-col items-center justify-center rounded-xl bg-gradient-to-br from-indigo-900/40 to-slate-900/60 ring-1 ring-indigo-700/40"
                  >
                    <div className="text-6xl">🪙</div>
                    <div className="mt-2 text-2xl font-extrabold tracking-tight">CryptoMonopoly</div>
                    {state.lastDice && (
                      <div className="mt-4 flex gap-3 text-4xl">
                        <Die n={state.lastDice[0]} />
                        <Die n={state.lastDice[1]} />
                      </div>
                    )}
                    <div className="mt-3 text-sm text-slate-400">
                      Turn: <span className="font-bold text-indigo-200">{state.players[state.order[state.currentTurn]]?.name}</span>
                    </div>
                  </div>
                );
              }
              return null;
            }
            return <TileCell key={`${r}-${c}`} tile={cell.tile} players={cell.players} state={state} />;
          }),
        )}
      </div>
    </div>
  );
}

function Die({ n }: { n: number }) {
  return (
    <div className="grid h-12 w-12 place-items-center rounded-lg bg-white text-slate-900 shadow ring-1 ring-slate-300 font-bold">
      {n}
    </div>
  );
}

function TileCell({ tile, players, state }: { tile: Tile; players: string[]; state: GameState }) {
  const own = state.ownership[tile.index];
  const ownerColor = own ? state.players[own.owner]?.color : undefined;
  const bg = tile.color ?? (tile.type === "GO" ? "#10b981" : tile.type === "JAIL" ? "#94a3b8" : "#334155");
  return (
    <div className="relative flex min-w-0 flex-col overflow-hidden rounded-md bg-slate-800/80 text-[10px] ring-1 ring-slate-700">
      <div className="h-2 w-full" style={{ background: bg }} />
      {ownerColor && (
        <div className="absolute right-1 top-1 h-2.5 w-2.5 rounded-full ring-1 ring-white/40" style={{ background: ownerColor }} />
      )}
      <div className="flex-1 p-1">
        <div className="truncate font-bold leading-tight">{tile.name}</div>
        {tile.symbol && <div className="text-[9px] text-slate-400">{tile.symbol}</div>}
        {tile.price && <div className="text-[9px] text-amber-300">${tile.price}</div>}
        {own && own.houses > 0 && (
          <div className="text-[10px] text-emerald-300">{"🏗".repeat(own.houses)}</div>
        )}
      </div>
      {players.length > 0 && (
        <div className="absolute bottom-1 left-1 flex gap-0.5">
          {players.map((a) => (
            <div
              key={a}
              title={state.players[a].name}
              className="h-2.5 w-2.5 rounded-full ring-1 ring-white/60"
              style={{ background: state.players[a].color }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function PlayerPanel({ state, selfAddr }: { state: GameState; selfAddr: string }) {
  return (
    <div className="rounded-lg bg-slate-800/50 p-2 ring-1 ring-slate-700/50">
      <h4 className="mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Players</h4>
      <ul className="space-y-1">
        {state.order.map((addr, i) => {
          const p = state.players[addr];
          const turn = i === state.currentTurn && state.started;
          return (
            <li
              key={addr}
              className={`flex items-center gap-2 rounded px-2 py-1 text-xs ${turn ? "bg-indigo-700/40 ring-1 ring-indigo-500" : ""}`}
            >
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />
              <span className={p.bankrupt ? "line-through text-slate-500" : ""}>{p.name}</span>
              {addr === selfAddr && <span className="text-[9px] text-emerald-300">(you)</span>}
              <span className="ml-auto font-mono">${p.cash}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Controls(props: {
  state: GameState;
  me: Player | undefined;
  isMyTurn: boolean;
  onRoll: () => void;
  onBuy: (t: number) => void;
  onSkipBuy: () => void;
  onBuild: (t: number) => void;
  onEnd: () => void;
}) {
  const { state, me, isMyTurn } = props;
  if (!me) return <div className="rounded bg-slate-800/50 p-2 text-xs text-slate-400">Spectating…</div>;

  const myProps = useMemo(() => {
    return Object.entries(state.ownership)
      .filter(([_, o]) => o.owner === me.addr)
      .map(([i]) => BOARD[+i])
      .filter((t) => t.type === "COIN");
  }, [state, me]);

  const purchaseTile = state.pendingPurchase && state.pendingPurchase.player === me.addr
    ? BOARD[state.pendingPurchase.tile] : null;

  return (
    <div className="space-y-2 rounded-lg bg-slate-800/50 p-2 ring-1 ring-slate-700/50">
      <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
        {isMyTurn ? "🎯 Your turn" : "Waiting…"}
      </h4>

      {purchaseTile ? (
        <div className="rounded bg-amber-900/40 p-2 text-xs ring-1 ring-amber-700/50">
          <div className="font-bold">Buy {purchaseTile.name} for ${purchaseTile.price}?</div>
          <div className="mt-2 flex gap-2">
            <button onClick={() => props.onBuy(purchaseTile.index)} className="flex-1 rounded bg-emerald-600 py-1 hover:bg-emerald-500">Buy</button>
            <button onClick={props.onSkipBuy} className="flex-1 rounded bg-slate-700 py-1 hover:bg-slate-600">Skip</button>
          </div>
        </div>
      ) : (
        <button
          onClick={props.onRoll}
          disabled={!isMyTurn}
          className="w-full rounded bg-indigo-600 py-2 text-sm font-bold hover:bg-indigo-500 disabled:opacity-40"
        >
          🎲 Roll dice
        </button>
      )}

      {isMyTurn && myProps.length > 0 && (
        <div>
          <div className="mb-1 text-[10px] uppercase tracking-wider text-slate-400">Build validator</div>
          <div className="flex flex-wrap gap-1">
            {myProps.map((t) => (
              <button
                key={t.index}
                onClick={() => props.onBuild(t.index)}
                title={`Cost: $${t.houseCost}`}
                className="rounded bg-slate-700 px-2 py-1 text-[10px] hover:bg-slate-600"
              >
                + {t.symbol} ({state.ownership[t.index]?.houses ?? 0}/4)
              </button>
            ))}
          </div>
        </div>
      )}

      <button
        onClick={props.onEnd}
        disabled={!isMyTurn || !!state.pendingPurchase}
        className="w-full rounded bg-slate-700 py-1.5 text-xs hover:bg-slate-600 disabled:opacity-40"
      >
        End turn ➡
      </button>
    </div>
  );
}

function Log({ state }: { state: GameState }) {
  const ref = useRef<HTMLUListElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [state.log.length]);
  return (
    <div className="flex min-h-0 flex-1 flex-col rounded-lg bg-slate-800/50 p-2 ring-1 ring-slate-700/50">
      <h4 className="mb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">Game log</h4>
      <ul ref={ref} className="flex-1 space-y-0.5 overflow-y-auto pr-1 text-[11px] text-slate-300">
        {state.log.slice(-200).map((l, i) => (
          <li key={i} className="border-b border-slate-700/30 pb-0.5">{l.text}</li>
        ))}
      </ul>
    </div>
  );
}
