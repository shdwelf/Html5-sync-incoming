import { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import type { Family, GedcomData, Individual } from '../utils/gedcom';

interface SimNode extends d3.SimulationNodeDatum {
  id: string;
  type: 'person' | 'family';
  label: string;
  sex?: Individual['sex'];
  radius: number;
  data: Individual | Family;
}

interface SimLink extends d3.SimulationLinkDatum<SimNode> {
  id: string;
  source: string;
  target: string;
  kind: 'spouse' | 'child';
}

interface TreeGraphProps {
  data: GedcomData;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onClearSelection: () => void;
}

export default function TreeGraph({ data, selectedId, onSelect, onClearSelection }: TreeGraphProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const simRef = useRef<d3.Simulation<SimNode, SimLink> | null>(null);
  const [size, setSize] = useState({ width: 800, height: 600 });

  // Measure container
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const update = () => {
      const rect = el.getBoundingClientRect();
      setSize({ width: Math.max(400, rect.width), height: Math.max(300, rect.height) });
    };

    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    window.addEventListener('resize', update);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', update);
    };
  }, []);

  // Build graph and simulation
  useEffect(() => {
    if (!svgRef.current || !data) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const { individuals, families } = data;
    const nodes: SimNode[] = [];

    individuals.forEach((ind) => {
      nodes.push({
        id: ind.id,
        type: 'person',
        label: ind.name,
        sex: ind.sex,
        radius: 20,
        data: ind,
      });
    });

    families.forEach((fam) => {
      nodes.push({
        id: fam.id,
        type: 'family',
        label: fam.marriageDate ? `m. ${fam.marriageDate}` : '',
        radius: 8,
        data: fam,
      });
    });

    const links: SimLink[] = [];
    families.forEach((fam) => {
      if (fam.husbandId) {
        links.push({ id: `${fam.husbandId}-${fam.id}`, source: fam.husbandId, target: fam.id, kind: 'spouse' });
      }
      if (fam.wifeId) {
        links.push({ id: `${fam.wifeId}-${fam.id}`, source: fam.wifeId, target: fam.id, kind: 'spouse' });
      }
      fam.childrenIds.forEach((childId) => {
        links.push({ id: `${fam.id}-${childId}`, source: fam.id, target: childId, kind: 'child' });
      });
    });

    const g = svg.append('g');

    const zoom = d3
      .zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.05, 4])
      .on('zoom', (event) => {
        g.attr('transform', event.transform.toString());
      });

    svg.call(zoom as any);
    zoomRef.current = zoom;

    // Background click clears selection
    svg.on('click', (event) => {
      if (event.target === svgRef.current) {
        onClearSelection();
      }
    });

    // Links
    const linkSel = g
      .append('g')
      .attr('stroke', '#94a3b8')
      .attr('stroke-opacity', 0.7)
      .selectAll('line')
      .data(links)
      .join('line')
      .attr('stroke-width', (d) => (d.kind === 'spouse' ? 2 : 1.5))
      .attr('stroke-dasharray', (d) => (d.kind === 'spouse' ? '4,3' : '0'));

    // Invisible wider links for easier hover
    const linkHit = g
      .append('g')
      .attr('stroke', 'transparent')
      .attr('stroke-width', 12)
      .selectAll('line')
      .data(links)
      .join('line');

    // Drag behavior
    const drag = d3
      .drag<SVGGElement, SimNode>()
      .on('start', (event, d) => {
        if (!event.active && simRef.current) simRef.current.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
      })
      .on('drag', (event, d) => {
        d.fx = event.x;
        d.fy = event.y;
      })
      .on('end', (event, d) => {
        if (!event.active && simRef.current) simRef.current.alphaTarget(0);
        d.fx = null;
        d.fy = null;
      });

    // Nodes
    const nodeGroup = g
      .append('g')
      .selectAll<SVGGElement, SimNode>('g')
      .data(nodes)
      .join('g')
      .attr('cursor', 'pointer')
      .call(drag);

    nodeGroup
      .append((d) => document.createElementNS('http://www.w3.org/2000/svg', d.type === 'family' ? 'polygon' : 'circle'))
      .attr('class', 'node-shape')
      .attr('fill', (d) => {
        if (d.type === 'family') return '#6366f1';
        if (d.sex === 'M') return '#3b82f6';
        if (d.sex === 'F') return '#ec4899';
        return '#94a3b8';
      })
      .attr('stroke', '#fff')
      .attr('stroke-width', 2)
      .each(function (d) {
        const shape = d3.select(this);
        if (d.type === 'family') {
          const s = d.radius;
          shape.attr('points', `0,-${s} ${s},0 0,${s} -${s},0`);
        } else {
          shape.attr('r', d.radius);
        }
      });

    // Labels
    nodeGroup
      .append('text')
      .attr('dy', (d) => (d.type === 'family' ? 24 : 32))
      .attr('text-anchor', 'middle')
      .attr('font-size', (d) => (d.type === 'family' ? 9 : 10))
      .attr('font-weight', 600)
      .attr('fill', (d) => (d.type === 'family' ? '#475569' : '#334155'))
      .attr('paint-order', 'stroke')
      .attr('stroke', '#ffffff')
      .attr('stroke-width', 3)
      .attr('stroke-opacity', 0.8)
      .text((d) => d.label);

    // Native tooltip
    nodeGroup.append('title').text((d) => {
      if (d.type === 'person') {
        const ind = d.data as Individual;
        return `${ind.name}\nSex: ${ind.sex === 'M' ? 'Male' : ind.sex === 'F' ? 'Female' : 'Unknown'}\nBorn: ${ind.birthDate || '-'}${
          ind.birthPlace ? `, ${ind.birthPlace}` : ''
        }\nDied: ${ind.deathDate || '-'}${ind.deathPlace ? `, ${ind.deathPlace}` : ''}`;
      }
      const fam = d.data as Family;
      return `Family ${fam.id}\nMarried: ${fam.marriageDate || '-'}${fam.marriagePlace ? `, ${fam.marriagePlace}` : ''}`;
    });

    nodeGroup.on('click', (_event, d) => {
      onSelect(d.id);
    });

    const sim = d3
      .forceSimulation<SimNode>(nodes)
      .force(
        'link',
        d3
          .forceLink<SimNode, SimLink>(links)
          .id((d) => d.id)
          .distance((d) => (d.kind === 'spouse' ? 28 : 55))
      )
      .force('charge', d3.forceManyBody().strength(-350).distanceMax(350))
      .force('center', d3.forceCenter(size.width / 2, size.height / 2))
      .force('collide', d3.forceCollide<SimNode>().radius((d) => d.radius + 10));

    sim.on('tick', () => {
      linkSel
        .attr('x1', (d) => nodeX(d.source))
        .attr('y1', (d) => nodeY(d.source))
        .attr('x2', (d) => nodeX(d.target))
        .attr('y2', (d) => nodeY(d.target));

      linkHit
        .attr('x1', (d) => nodeX(d.source))
        .attr('y1', (d) => nodeY(d.source))
        .attr('x2', (d) => nodeX(d.target))
        .attr('y2', (d) => nodeY(d.target));

      nodeGroup.attr('transform', (d) => `translate(${d.x ?? 0},${d.y ?? 0})`);
    });

    simRef.current = sim;

    // Stop simulation on unmount
    return () => {
      sim.stop();
      svg.selectAll('*').remove();
    };
  }, [data, size.width, size.height, onSelect, onClearSelection]);

  // Update selection highlight
  useEffect(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg
      .selectAll<SVGCircleElement | SVGPolygonElement, SimNode>('.node-shape')
      .attr('stroke', (d) => (d.id === selectedId ? '#f59e0b' : '#fff'))
      .attr('stroke-width', (d) => (d.id === selectedId ? 4 : 2));
  }, [selectedId]);

  const resetZoom = () => {
    if (!svgRef.current || !zoomRef.current) return;
    d3.select(svgRef.current)
      .transition()
      .duration(500)
      .call(zoomRef.current.transform as any, d3.zoomIdentity);
  };

  return (
    <div ref={containerRef} className="relative h-full w-full overflow-hidden rounded-xl bg-slate-50">
      <svg ref={svgRef} width={size.width} height={size.height} className="block h-full w-full" />
      <div className="pointer-events-none absolute right-3 top-3 flex flex-col gap-2">
        <div className="pointer-events-auto rounded-lg border bg-white/90 px-3 py-2 text-xs font-medium text-slate-600 shadow-sm backdrop-blur">
          {data.individuals.size} people · {data.families.size} families
        </div>
      </div>
      <div className="pointer-events-none absolute bottom-3 right-3 flex gap-2">
        <button
          type="button"
          onClick={resetZoom}
          className="pointer-events-auto rounded-lg border bg-white/90 px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm backdrop-blur hover:bg-white"
        >
          Reset view
        </button>
      </div>
    </div>
  );
}

function nodeX(source: SimLink['source']): number {
  const s = source as unknown as SimNode;
  return s.x ?? 0;
}

function nodeY(source: SimLink['source']): number {
  const s = source as unknown as SimNode;
  return s.y ?? 0;
}
