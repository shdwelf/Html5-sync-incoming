export interface Individual {
  id: string;
  name: string;
  sex: 'M' | 'F' | 'U';
  birthDate?: string;
  birthPlace?: string;
  deathDate?: string;
  deathPlace?: string;
  famc?: string; // family id where this person is a child
  fams: string[]; // family ids where this person is a spouse
}

export interface Family {
  id: string;
  husbandId?: string;
  wifeId?: string;
  childrenIds: string[];
  marriageDate?: string;
  marriagePlace?: string;
}

export interface GedcomData {
  individuals: Map<string, Individual>;
  families: Map<string, Family>;
}

function normalizeSex(value: string): Individual['sex'] {
  const v = value.trim().toUpperCase();
  if (v === 'M') return 'M';
  if (v === 'F') return 'F';
  return 'U';
}

function normalizeName(value: string): string {
  // GEDCOM: Given /Surname/
  return value
    .replace(/\//g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function parseGedcom(text: string): GedcomData {
  const individuals = new Map<string, Individual>();
  const families = new Map<string, Family>();

  const lines = text.split(/\r?\n/);
  let i = 0;

  const lineRegex = /^(\d+)\s+(@[^@]+@|\w+)\s?(.*)$/;

  while (i < lines.length) {
    const line = lines[i];
    if (!line.startsWith('0 ')) {
      i++;
      continue;
    }

    const recordMatch = line.match(/^0 @(.*?)@\s+(\w+)(?:\s+(.*))?$/);
    if (!recordMatch) {
      i++;
      continue;
    }

    const xref = recordMatch[1];
    const tag = recordMatch[2];

    let end = i + 1;
    while (end < lines.length && !lines[end].startsWith('0 ')) {
      end++;
    }
    const block = lines.slice(i, end);

    if (tag === 'INDI') {
      parseIndividual(xref, block);
    } else if (tag === 'FAM') {
      parseFamily(xref, block);
    }

    i = end;
  }

  return { individuals, families };

  function parseIndividual(id: string, block: string[]) {
    const ind: Individual = {
      id,
      name: '',
      sex: 'U',
      fams: [],
    };

    let currentEvent: 'birth' | 'death' | null = null;
    let lastField: { obj: Individual; key: keyof Individual } | null = null;

    for (let j = 1; j < block.length; j++) {
      const parsed = block[j].match(lineRegex);
      if (!parsed) continue;
      const [, levelStr, key, value] = parsed;
      const level = Number(levelStr);

      if (level === 1) {
        currentEvent = null;
        if (key === 'NAME') {
          ind.name = normalizeName(value);
          lastField = { obj: ind, key: 'name' };
        } else if (key === 'SEX') {
          ind.sex = normalizeSex(value);
        } else if (key === 'FAMC') {
          ind.famc = stripAt(value);
        } else if (key === 'FAMS') {
          const famId = stripAt(value);
          if (famId && !ind.fams.includes(famId)) {
            ind.fams.push(famId);
          }
        } else if (key === 'BIRT') {
          currentEvent = 'birth';
        } else if (key === 'DEAT') {
          currentEvent = 'death';
        }
      } else if (level === 2 && currentEvent) {
        if (key === 'DATE') {
          if (currentEvent === 'birth') ind.birthDate = value;
          else if (currentEvent === 'death') ind.deathDate = value;
        } else if (key === 'PLAC') {
          if (currentEvent === 'birth') ind.birthPlace = value;
          else if (currentEvent === 'death') ind.deathPlace = value;
        }
      } else if (key === 'CONC' && lastField) {
        (lastField.obj[lastField.key] as string) += normalizeName(value);
      } else if (key === 'CONT' && lastField) {
        (lastField.obj[lastField.key] as string) += ' ' + normalizeName(value);
      }
    }

    if (!ind.name) ind.name = 'Unknown';
    individuals.set(id, ind);
  }

  function parseFamily(id: string, block: string[]) {
    const fam: Family = {
      id,
      childrenIds: [],
    };

    let currentEvent: 'marriage' | null = null;

    for (let j = 1; j < block.length; j++) {
      const parsed = block[j].match(lineRegex);
      if (!parsed) continue;
      const [, levelStr, key, value] = parsed;
      const level = Number(levelStr);

      if (level === 1) {
        currentEvent = null;
        if (key === 'HUSB') {
          fam.husbandId = stripAt(value);
        } else if (key === 'WIFE') {
          fam.wifeId = stripAt(value);
        } else if (key === 'CHIL') {
          const childId = stripAt(value);
          if (childId && !fam.childrenIds.includes(childId)) {
            fam.childrenIds.push(childId);
          }
        } else if (key === 'MARR') {
          currentEvent = 'marriage';
        }
      } else if (level === 2 && currentEvent === 'marriage') {
        if (key === 'DATE') fam.marriageDate = value;
        else if (key === 'PLAC') fam.marriagePlace = value;
      }
    }

    families.set(id, fam);
  }

  function stripAt(v: string): string {
    return v.replace(/^@|@$/g, '');
  }
}
