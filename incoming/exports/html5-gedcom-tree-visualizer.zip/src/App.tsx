import { useCallback, useMemo, useState } from 'react';
import { parseGedcom, type GedcomData, type Individual, type Family } from './utils/gedcom';
import TreeGraph from './components/TreeGraph';

const SAMPLE_GEDCOM = `0 HEAD
1 SOUR Family Tree App
1 GEDC
2 VERS 5.5.1
0 @I1@ INDI
1 NAME John /Doe/
1 SEX M
1 BIRT
2 DATE 1 JAN 1940
2 PLAC New York, USA
1 FAMS @F1@
0 @I2@ INDI
1 NAME Jane /Smith/
1 SEX F
1 BIRT
2 DATE 15 MAR 1942
2 PLAC Boston, USA
1 FAMS @F1@
0 @I3@ INDI
1 NAME Robert /Doe/
1 SEX M
1 BIRT
2 DATE 10 JUL 1965
2 PLAC New York, USA
1 FAMC @F1@
1 FAMS @F2@
0 @I4@ INDI
1 NAME Alice /Doe/
1 SEX F
1 BIRT
2 DATE 5 MAY 1968
2 PLAC New York, USA
1 FAMC @F1@
0 @I5@ INDI
1 NAME Mary /Johnson/
1 SEX F
1 BIRT
2 DATE 22 SEP 1967
2 PLAC Chicago, USA
1 FAMS @F2@
0 @I6@ INDI
1 NAME Charlie /Doe/
1 SEX M
1 BIRT
2 DATE 3 APR 1995
2 PLAC Austin, USA
1 FAMC @F2@
0 @I7@ INDI
1 NAME Daisy /Doe/
1 SEX F
1 BIRT
2 DATE 18 NOV 1998
2 PLAC Austin, USA
1 FAMC @F2@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
1 CHIL @I3@
1 CHIL @I4@
1 MARR
2 DATE 12 JUN 1963
2 PLAC New York, USA
0 @F2@ FAM
1 HUSB @I3@
1 WIFE @I5@
1 CHIL @I6@
1 CHIL @I7@
1 MARR
2 DATE 8 AUG 1990
2 PLAC Chicago, USA
0 TRLR`;

function formatLifeDates(ind: Individual): string {
  const b = ind.birthDate ? `b. ${ind.birthDate}` : '';
  const d = ind.deathDate ? `d. ${ind.deathDate}` : '';
  if (b && d) return `${b} · ${d}`;
  return b || d || '';
}

export default function App() {
  const [text, setText] = useState(SAMPLE_GEDCOM);
  const [data, setData] = useState<GedcomData | null>(() => parseGedcom(SAMPLE_GEDCOM));
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [query, setQuery] = useState('');

  const handleSelect = useCallback((id: string) => setSelectedId(id), []);
  const handleClearSelection = useCallback(() => setSelectedId(null), []);

  const handleParse = () => {
    try {
      const parsed = parseGedcom(text);
      if (parsed.individuals.size === 0) {
        setError('No INDI records found. Paste a valid GEDCOM file.');
        setData(null);
      } else {
        setData(parsed);
        setError(null);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to parse GEDCOM');
      setData(null);
    }
  };

  const handleClear = () => {
    setText('');
    setData(null);
    setError(null);
    setSelectedId(null);
  };

  const handleLoadExample = () => {
    setText(SAMPLE_GEDCOM);
    const parsed = parseGedcom(SAMPLE_GEDCOM);
    setData(parsed);
    setError(null);
  };

  const selected = useMemo(() => {
    if (!data || !selectedId) return null;
    return data.individuals.get(selectedId) || data.families.get(selectedId) || null;
  }, [data, selectedId]);

  const filteredPeople = useMemo(() => {
    if (!data) return [];
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return Array.from(data.individuals.values())
      .filter((p) => p.name.toLowerCase().includes(q))
      .slice(0, 20);
  }, [data, query]);

  const getParents = (ind: Individual): Individual[] => {
    if (!ind.famc || !data) return [];
    const fam = data.families.get(ind.famc);
    if (!fam) return [];
    const out: Individual[] = [];
    if (fam.husbandId) {
      const p = data.individuals.get(fam.husbandId);
      if (p) out.push(p);
    }
    if (fam.wifeId) {
      const p = data.individuals.get(fam.wifeId);
      if (p) out.push(p);
    }
    return out;
  };

  const getSpouses = (ind: Individual): Individual[] => {
    if (!data) return [];
    const out: Individual[] = [];
    ind.fams.forEach((famId) => {
      const fam = data.families.get(famId);
      if (!fam) return;
      const otherId = fam.husbandId === ind.id ? fam.wifeId : fam.husbandId;
      if (otherId) {
        const other = data.individuals.get(otherId);
        if (other) out.push(other);
      }
    });
    return out;
  };

  const getChildren = (ind: Individual): Individual[] => {
    if (!data) return [];
    const out: Individual[] = [];
    ind.fams.forEach((famId) => {
      const fam = data.families.get(famId);
      if (!fam) return;
      fam.childrenIds.forEach((childId) => {
        const child = data.individuals.get(childId);
        if (child) out.push(child);
      });
    });
    return out;
  };

  const getSiblings = (ind: Individual): Individual[] => {
    if (!ind.famc || !data) return [];
    const fam = data.families.get(ind.famc);
    if (!fam) return [];
    return fam.childrenIds
      .filter((id) => id !== ind.id)
      .map((id) => data.individuals.get(id))
      .filter((p): p is Individual => Boolean(p));
  };

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 text-slate-900">
      <header className="border-b bg-white px-4 py-3 shadow-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 text-white">
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <circle cx="12" cy="5" r="3" />
                <path d="M6 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2" />
                <circle cx="18" cy="5" r="2" />
                <path d="M20 12h-3" />
              </svg>
            </div>
            <h1 className="text-lg font-semibold tracking-tight">GEDCOM Family Tree Viewer</h1>
          </div>
          <div className="text-sm text-slate-500">Paste GEDCOM · Drag & zoom · Click for details</div>
        </div>
      </header>

      <main className="flex flex-1 flex-col gap-4 overflow-hidden p-4 md:flex-row">
        <aside className="flex w-full flex-col gap-4 md:w-96">
          <div className="rounded-xl border bg-white p-4 shadow-sm">
            <label htmlFor="gedcom" className="mb-2 block text-sm font-medium text-slate-700">
              GEDCOM input
            </label>
            <textarea
              id="gedcom"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste your GEDCOM text here..."
              className="h-48 w-full resize-none rounded-lg border border-slate-300 p-3 font-mono text-xs text-slate-700 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleParse}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
              >
                Render tree
              </button>
              <button
                type="button"
                onClick={handleLoadExample}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              >
                Load example
              </button>
              <button
                type="button"
                onClick={handleClear}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              >
                Clear
              </button>
            </div>
            {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
          </div>

          <div className="flex flex-1 flex-col overflow-hidden rounded-xl border bg-white shadow-sm">
            <div className="border-b p-3">
              <label htmlFor="search" className="sr-only">
                Search people
              </label>
              <div className="relative">
                <input
                  id="search"
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search people..."
                  className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                <svg
                  className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <circle cx="11" cy="11" r="8" />
                  <path d="m21 21-4.35-4.35" />
                </svg>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-2">
              {query.trim() ? (
                <ul className="space-y-1">
                  {filteredPeople.map((p) => (
                    <li key={p.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedId(p.id)}
                        className={`w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100 ${
                          selectedId === p.id ? 'bg-indigo-50 text-indigo-700' : 'text-slate-700'
                        }`}
                      >
                        <span className="font-medium">{p.name}</span>
                        <span className="ml-2 text-xs text-slate-400">{formatLifeDates(p)}</span>
                      </button>
                    </li>
                  ))}
                  {filteredPeople.length === 0 && (
                    <li className="px-3 py-4 text-center text-sm text-slate-400">No matches found</li>
                  )}
                </ul>
              ) : (
                <div className="px-3 py-6 text-center text-sm text-slate-400">
                  {data ? (
                    <>
                      <p className="font-medium text-slate-600">{data.individuals.size} people loaded</p>
                      <p className="mt-1">Type above to search, or click a node in the tree.</p>
                    </>
                  ) : (
                    <p>Paste GEDCOM and click Render tree.</p>
                  )}
                </div>
              )}
            </div>

            {selected && (
              <div className="border-t bg-slate-50 p-4">
                {'sex' in selected ? (
                  (() => {
                    const ind = selected as Individual;
                    const parents = getParents(ind);
                    const spouses = getSpouses(ind);
                    const children = getChildren(ind);
                    const siblings = getSiblings(ind);
                    return (
                      <div className="space-y-3 text-sm">
                        <div>
                          <div className="flex items-center gap-2">
                            <span
                              className={`inline-block h-2.5 w-2.5 rounded-full ${
                                ind.sex === 'M' ? 'bg-blue-500' : ind.sex === 'F' ? 'bg-pink-500' : 'bg-slate-400'
                              }`}
                            />
                            <h3 className="font-semibold text-slate-900">{ind.name}</h3>
                            <span className="text-xs text-slate-500">({ind.id})</span>
                          </div>
                          {formatLifeDates(ind) && (
                            <p className="mt-0.5 text-slate-500">{formatLifeDates(ind)}</p>
                          )}
                        </div>

                        {(ind.birthPlace || ind.deathPlace) && (
                          <div className="space-y-1 text-slate-600">
                            {ind.birthPlace && <p>Born in {ind.birthPlace}</p>}
                            {ind.deathPlace && <p>Died in {ind.deathPlace}</p>}
                          </div>
                        )}

                        {parents.length > 0 && (
                          <RelationList title="Parents" people={parents} onSelect={setSelectedId} />
                        )}
                        {spouses.length > 0 && (
                          <RelationList title="Spouses" people={spouses} onSelect={setSelectedId} />
                        )}
                        {children.length > 0 && (
                          <RelationList title="Children" people={children} onSelect={setSelectedId} />
                        )}
                        {siblings.length > 0 && (
                          <RelationList title="Siblings" people={siblings} onSelect={setSelectedId} />
                        )}
                      </div>
                    );
                  })()
                ) : (
                  (() => {
                    const fam = selected as Family;
                    const husband = fam.husbandId ? data?.individuals.get(fam.husbandId) : undefined;
                    const wife = fam.wifeId ? data?.individuals.get(fam.wifeId) : undefined;
                    const children =
                      data?.families
                        .get(fam.id)
                        ?.childrenIds.map((id) => data.individuals.get(id))
                        .filter((p): p is Individual => Boolean(p)) || [];
                    return (
                      <div className="space-y-3 text-sm">
                        <div>
                          <h3 className="font-semibold text-slate-900">Family {fam.id}</h3>
                          {fam.marriageDate && (
                            <p className="text-slate-500">
                              Married {fam.marriageDate}
                              {fam.marriagePlace ? ` · ${fam.marriagePlace}` : ''}
                            </p>
                          )}
                        </div>
                        {husband && <RelationList title="Husband" people={[husband]} onSelect={setSelectedId} />}
                        {wife && <RelationList title="Wife" people={[wife]} onSelect={setSelectedId} />}
                        {children.length > 0 && (
                          <RelationList title="Children" people={children} onSelect={setSelectedId} />
                        )}
                      </div>
                    );
                  })()
                )}
              </div>
            )}
          </div>
        </aside>

        <section className="relative flex min-h-[24rem] flex-1 flex-col overflow-hidden rounded-xl border bg-white shadow-sm">
          {data ? (
            <TreeGraph
              data={data}
              selectedId={selectedId}
              onSelect={handleSelect}
              onClearSelection={handleClearSelection}
            />
          ) : (
            <div className="flex h-full flex-col items-center justify-center gap-3 p-8 text-center text-slate-400">
              <div className="rounded-full bg-slate-100 p-4">
                <svg className="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
                  <circle cx="12" cy="5" r="3" />
                  <path d="M6 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2" />
                </svg>
              </div>
              <p>Paste GEDCOM on the left and click Render tree to see the entire family tree.</p>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function RelationList({
  title,
  people,
  onSelect,
}: {
  title: string;
  people: Individual[];
  onSelect: (id: string) => void;
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{title}</p>
      <ul className="mt-1 space-y-1">
        {people.map((p) => (
          <li key={p.id}>
            <button
              type="button"
              onClick={() => onSelect(p.id)}
              className="text-left text-indigo-600 hover:text-indigo-800 hover:underline"
            >
              {p.name}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
