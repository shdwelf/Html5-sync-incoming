import { useEffect, useMemo, useRef, useState } from "react";

type GedcomEvent = {
  date?: string;
  place?: string;
  year?: number;
  coords?: { lat: number; lon: number };
};

type Individual = {
  id: string;
  name: string;
  sex?: string;
  birth?: GedcomEvent;
  death?: GedcomEvent;
  familiesAsSpouse: string[];
  familiesAsChild: string[];
};

type Family = {
  id: string;
  husband?: string;
  wife?: string;
  children: string[];
};

type ParsedTree = {
  people: Individual[];
  families: Family[];
  byId: Record<string, Individual>;
};

type RemoteUpdate = {
  payload?: {
    text?: string;
    source?: string;
  };
};

declare global {
  interface Window {
    webxdc?: {
      sendUpdate?: (update: RemoteUpdate, description?: string) => void;
      setUpdateListener?: (listener: (update: RemoteUpdate) => void) => void;
    };
  }
}

const sampleGedcom = `0 HEAD
1 SOUR CryptoMonopoly
1 GEDC
2 VERS 5.5.1
0 @I1@ INDI
1 NAME Ada /Lovelace/
1 SEX F
1 BIRT
2 DATE 10 DEC 1815
2 PLAC London, England
1 DEAT
2 DATE 27 NOV 1852
2 PLAC London, England
1 FAMS @F1@
0 @I2@ INDI
1 NAME William /King-Noel/
1 SEX M
1 BIRT
2 DATE 21 FEB 1805
2 PLAC London, England
1 DEAT
2 DATE 29 DEC 1893
2 PLAC Surrey, England
1 FAMS @F1@
0 @I3@ INDI
1 NAME Byron /King-Noel/
1 SEX M
1 BIRT
2 DATE 12 MAY 1836
2 PLAC London, England
1 DEAT
2 DATE 1 SEP 1862
2 PLAC London, England
1 FAMC @F1@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I1@
1 CHIL @I3@
0 TRLR`;

const gazetteer: Record<string, { lat: number; lon: number }> = {
  london: { lat: 51.5072, lon: -0.1276 },
  "london, england": { lat: 51.5072, lon: -0.1276 },
  "surrey, england": { lat: 51.3148, lon: -0.56 },
  paris: { lat: 48.8566, lon: 2.3522 },
  "paris, france": { lat: 48.8566, lon: 2.3522 },
  berlin: { lat: 52.52, lon: 13.405 },
  "new york": { lat: 40.7128, lon: -74.006 },
  "new york, usa": { lat: 40.7128, lon: -74.006 },
  boston: { lat: 42.3601, lon: -71.0589 },
  chicago: { lat: 41.8781, lon: -87.6298 },
  philadelphia: { lat: 39.9526, lon: -75.1652 },
  rome: { lat: 41.9028, lon: 12.4964 },
  dublin: { lat: 53.3498, lon: -6.2603 },
  edinburgh: { lat: 55.9533, lon: -3.1883 },
  madrid: { lat: 40.4168, lon: -3.7038 },
  vienna: { lat: 48.2082, lon: 16.3738 },
};

const tabs = ["Import", "Graph", "Map", "Biorhythms", "Natal", "Statistics"] as const;

const cleanRef = (value = "") => value.replace(/@/g, "").trim();

const normalizeName = (name = "Unknown") => name.replace(/\//g, "").replace(/\s+/g, " ").trim() || "Unknown";

const parseYear = (date?: string) => {
  const match = date?.match(/(\d{3,4})/);
  return match ? Number(match[1]) : undefined;
};

const parseMonthDay = (date?: string) => {
  if (!date) return undefined;
  const monthMap: Record<string, number> = {
    JAN: 1,
    FEB: 2,
    MAR: 3,
    APR: 4,
    MAY: 5,
    JUN: 6,
    JUL: 7,
    AUG: 8,
    SEP: 9,
    OCT: 10,
    NOV: 11,
    DEC: 12,
  };
  const parts = date.toUpperCase().match(/(?:(\d{1,2})\s+)?([A-Z]{3,9})?\s*(\d{3,4})/);
  if (!parts) return undefined;
  const year = Number(parts[3]);
  const month = parts[2] ? monthMap[parts[2].slice(0, 3)] || 1 : 1;
  const day = parts[1] ? Number(parts[1]) : 1;
  return { year, month, day };
};

const coordinatesFor = (place?: string) => {
  if (!place) return undefined;
  const normalized = place.toLowerCase().replace(/\s+/g, " ").trim();
  if (gazetteer[normalized]) return gazetteer[normalized];
  const hit = Object.entries(gazetteer).find(([key]) => normalized.includes(key) || key.includes(normalized));
  if (hit) return hit[1];
  const hash = [...normalized].reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return { lat: ((hash % 120) - 60) * 0.8, lon: ((hash * 7) % 320) - 160 };
};

function recombineGedcom(raw: string) {
  const partMatches = [...raw.matchAll(/(?:CRYPTOMONOPOLY|GEDCOM)\s+PART\s+(\d+)\s*\/\s*(\d+)\s*\n([\s\S]*?)(?=(?:CRYPTOMONOPOLY|GEDCOM)\s+PART\s+\d+\s*\/\s*\d+|$)/gi)];
  if (!partMatches.length) return raw;
  return partMatches
    .sort((a, b) => Number(a[1]) - Number(b[1]))
    .map((match) => match[3].trim())
    .join("\n");
}

function parseGedcom(input: string): ParsedTree {
  const text = recombineGedcom(input);
  const lines = text
    .replace(/^\uFEFF/, "") // Remove BOM if present
    .replace(/\r/g, "")
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  const people: Individual[] = [];
  const families: Family[] = [];
  let currentPerson: Individual | undefined;
  let currentFamily: Family | undefined;
  let currentEvent: "birth" | "death" | undefined;

  const finishEvent = (event?: GedcomEvent) => {
    if (!event) return undefined;
    return { ...event, year: parseYear(event.date), coords: coordinatesFor(event.place) };
  };

  for (const line of lines) {
    const match = line.match(/^(\d+)\s+(?:(@[^@]+@)\s+)?([A-Za-z0-9_:-]+)(?:\s+(.*))?$/);
    if (!match) continue;
    const level = Number(match[1]);
    const pointer = match[2];
    const tag = match[3].toUpperCase();
    const value = match[4] || "";

    if (level === 0) {
      if (currentPerson) people.push({ ...currentPerson, birth: finishEvent(currentPerson.birth), death: finishEvent(currentPerson.death) });
      if (currentFamily) families.push(currentFamily);
      currentPerson = undefined;
      currentFamily = undefined;
      currentEvent = undefined;

      if (tag === "INDI") {
        const id = cleanRef(pointer) || cleanRef(value) || `UNKNOWN_${people.length}`;
        currentPerson = { id, name: "Unknown", familiesAsSpouse: [], familiesAsChild: [] };
      }
      if (tag === "FAM") {
        const id = cleanRef(pointer) || cleanRef(value) || `UNKNOWN_FAM_${families.length}`;
        currentFamily = { id, children: [] };
      }
      continue;
    }

    if (currentPerson) {
      if (level === 1) currentEvent = undefined;
      if (tag === "NAME") currentPerson.name = normalizeName(value);
      if (tag === "SEX") currentPerson.sex = value;
      if (tag === "BIRT") {
        currentPerson.birth = currentPerson.birth || {};
        currentEvent = "birth";
      }
      if (tag === "DEAT") {
        currentPerson.death = currentPerson.death || {};
        currentEvent = "death";
      }
      if (tag === "FAMS") currentPerson.familiesAsSpouse.push(cleanRef(value));
      if (tag === "FAMC") currentPerson.familiesAsChild.push(cleanRef(value));
      if (currentEvent && tag === "DATE") currentPerson[currentEvent] = { ...currentPerson[currentEvent], date: value };
      if (currentEvent && tag === "PLAC") currentPerson[currentEvent] = { ...currentPerson[currentEvent], place: value };
    }

    if (currentFamily) {
      if (tag === "HUSB") currentFamily.husband = cleanRef(value);
      if (tag === "WIFE") currentFamily.wife = cleanRef(value);
      if (tag === "CHIL") currentFamily.children.push(cleanRef(value));
    }
  }

  if (currentPerson) people.push({ ...currentPerson, birth: finishEvent(currentPerson.birth), death: finishEvent(currentPerson.death) });
  if (currentFamily) families.push(currentFamily);

  const byId = Object.fromEntries(people.map((person) => [person.id, person]));
  return { people, families, byId };
}

function toDot(tree: ParsedTree) {
  const personLines = tree.people.map((person) => `  ${person.id} [label="${person.name.replace(/"/g, "'")}"];`);
  const familyLines = tree.families.flatMap((family) => {
    const parents = [family.husband, family.wife].filter(Boolean) as string[];
    return family.children.flatMap((child) => parents.map((parent) => `  ${parent} -> ${child} [label="parent"];`));
  });
  return ["digraph family {", "  rankdir=TB;", "  node [shape=box];", ...personLines, ...familyLines, "}"].join("\n");
}

function lifeSpan(person: Individual) {
  if (!person.birth?.year) return undefined;
  const end = person.death?.year || new Date().getFullYear();
  return Math.max(0, end - person.birth.year);
}

function zodiac(month: number, day: number) {
  const signs = [
    ["Capricorn", 20],
    ["Aquarius", 19],
    ["Pisces", 20],
    ["Aries", 20],
    ["Taurus", 21],
    ["Gemini", 21],
    ["Cancer", 23],
    ["Leo", 23],
    ["Virgo", 23],
    ["Libra", 23],
    ["Scorpio", 22],
    ["Sagittarius", 22],
  ] as const;
  return day < signs[month - 1][1] ? signs[(month + 10) % 12][0] : signs[month - 1][0];
}

function moonPhase(year: number, month: number, day: number) {
  const lp = 2551443;
  const now = Date.UTC(year, month - 1, day) / 1000;
  const newMoon = Date.UTC(2000, 0, 6, 18, 14) / 1000;
  const phase = ((now - newMoon) % lp) / lp;
  const names = ["New", "Waxing crescent", "First quarter", "Waxing gibbous", "Full", "Waning gibbous", "Last quarter", "Waning crescent"];
  return names[Math.floor((((phase + 1) % 1) * 8)) % 8];
}

function useWebxdcSync(onGedcom: (text: string, source: string) => void) {
  useEffect(() => {
    window.webxdc?.setUpdateListener?.((update) => {
      if (update.payload?.text) onGedcom(update.payload.text, update.payload.source || "Delta Chat");
    });
  }, [onGedcom]);
}

function App() {
  const [rawGedcom, setRawGedcom] = useState(sampleGedcom);
  const [url, setUrl] = useState("");
  const [status, setStatus] = useState("Sample GEDCOM loaded. Paste data, fetch a URL, or receive a webxdc update.");
  const [activeTab, setActiveTab] = useState<(typeof tabs)[number]>("Import");
  const [selectedId, setSelectedId] = useState("I1");
  const [mapYear, setMapYear] = useState(1852);
  const [playing, setPlaying] = useState(false);
  const textRef = useRef<HTMLTextAreaElement>(null);

  const tree = useMemo(() => {
    try {
      return parseGedcom(rawGedcom);
    } catch (e) {
      console.error("Parse error:", e);
      return { people: [], families: [], byId: {} };
    }
  }, [rawGedcom]);
  const selectedPerson = tree.byId[selectedId] || tree.people[0];
  const years = useMemo(() => {
    const values = tree.people.flatMap((person) => [person.birth?.year, person.death?.year]).filter(Boolean) as number[];
    return values.length ? { min: Math.min(...values), max: Math.max(...values) } : { min: 1800, max: new Date().getFullYear() };
  }, [tree]);

  useWebxdcSync((text, source) => {
    setRawGedcom(text);
    setStatus(`Loaded GEDCOM from ${source}.`);
  });

  useEffect(() => {
    if (!tree.people.find((person) => person.id === selectedId) && tree.people[0]) setSelectedId(tree.people[0].id);
  }, [selectedId, tree.people]);

  useEffect(() => {
    setMapYear((year) => Math.min(Math.max(year, years.min), years.max));
  }, [years.max, years.min]);

  useEffect(() => {
    if (!playing) return;
    const id = window.setInterval(() => {
      setMapYear((year) => (year >= years.max ? years.min : year + 1));
    }, 320);
    return () => window.clearInterval(id);
  }, [playing, years.max, years.min]);

  const applyGedcom = (text: string, source: string, share = true) => {
    const combined = recombineGedcom(text);
    setRawGedcom(combined);
    setStatus(`Loaded ${combined.split("\n").length} GEDCOM lines from ${source}.`);
    if (share) window.webxdc?.sendUpdate?.({ payload: { text: combined, source } }, `GEDCOM imported from ${source}`);
    setActiveTab("Graph");
  };

  const readClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text) {
        setStatus("Clipboard is empty. Copy some GEDCOM data first.");
        return;
      }
      applyGedcom(text, "clipboard");
    } catch (error) {
      textRef.current?.focus();
      setStatus("Could not read clipboard automatically. Please paste into the text box and press Load pasted GEDCOM.");
    }
  };

  const fetchRemoteGedcom = async () => {
    if (!url.trim()) return;
    try {
      const target = normalizeRemoteUrl(url.trim());
      const response = await fetch(target);
      if (!response.ok) throw new Error(response.statusText);
      const text = await response.text();
      applyGedcom(text, target);
    } catch (error) {
      setStatus(`Could not fetch URL. This can happen when the remote site blocks CORS. ${String(error)}`);
    }
  };

  return (
    <main className="min-h-screen bg-[#f6f0e4] text-[#27190f]">
      <section className="relative isolate flex min-h-[54vh] overflow-hidden border-b border-[#27190f]/15">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_10%_20%,rgba(140,85,39,.35),transparent_30%),linear-gradient(125deg,rgba(39,25,15,.94),rgba(78,46,22,.72)),url('https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=1800&q=80')] bg-cover bg-center" />
        <div className="absolute inset-0 opacity-25 [background-image:linear-gradient(90deg,rgba(255,255,255,.18)_1px,transparent_1px),linear-gradient(rgba(255,255,255,.18)_1px,transparent_1px)] [background-size:72px_72px]" />
        <div className="relative mx-auto flex w-full max-w-6xl flex-col justify-end px-5 py-10 sm:px-8 lg:px-10">
          <div className="max-w-3xl text-[#fff8ed]">
            <p className="mb-5 font-mono text-sm uppercase tracking-[0.36em] text-[#f4cc79]">webxdc genealogy table</p>
            <h1 className="text-5xl font-black tracking-tight sm:text-7xl">CryptoMonopoly</h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-[#fff0d2]">
              Import GEDCOM from clipboard, URLs, multipart drops, or Pastebin, then turn the family record into a graph, animated map, natal notes, and statistical story for Delta Chat.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button onClick={readClipboard} className="bg-[#f4cc79] px-5 py-3 font-bold text-[#27190f] transition hover:-translate-y-0.5 hover:bg-white">
                Read clipboard
              </button>
              <button onClick={() => setActiveTab("Graph")} className="border border-[#fff8ed]/70 px-5 py-3 font-bold text-[#fff8ed] transition hover:-translate-y-0.5 hover:bg-[#fff8ed] hover:text-[#27190f]">
                View family graph
              </button>
            </div>
          </div>
        </div>
      </section>

      <nav className="sticky top-0 z-20 border-b border-[#27190f]/15 bg-[#f6f0e4]/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`whitespace-nowrap px-4 py-2 text-sm font-bold transition ${activeTab === tab ? "bg-[#27190f] text-[#fff8ed]" : "hover:bg-[#e8d8bd]"}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </nav>

      <section className="mx-auto max-w-6xl px-5 py-8 sm:px-8 lg:px-10">
        <div className="mb-6 flex flex-col gap-3 border-b border-[#27190f]/15 pb-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.24em] text-[#875628]">{status}</p>
            <h2 className="mt-2 text-3xl font-black">{activeTab}</h2>
          </div>
          <select value={selectedPerson?.id || ""} onChange={(event) => setSelectedId(event.target.value)} className="max-w-xs border border-[#27190f]/25 bg-transparent px-3 py-2">
            {tree.people.map((person) => (
              <option key={person.id} value={person.id}>{person.name}</option>
            ))}
          </select>
        </div>

        {activeTab === "Import" && (
          <ImportPanel
            rawGedcom={rawGedcom}
            setRawGedcom={setRawGedcom}
            url={url}
            setUrl={setUrl}
            textRef={textRef}
            tree={tree}
            onLoad={() => applyGedcom(rawGedcom, "paste area")}
            onClipboard={readClipboard}
            onFetch={fetchRemoteGedcom}
          />
        )}
        {activeTab === "Graph" && <GraphPanel tree={tree} selectedId={selectedPerson?.id} onSelect={setSelectedId} />}
        {activeTab === "Map" && <MapPanel tree={tree} mapYear={mapYear} setMapYear={setMapYear} playing={playing} setPlaying={setPlaying} years={years} />}
        {activeTab === "Biorhythms" && <BiorhythmPanel person={selectedPerson} />}
        {activeTab === "Natal" && <NatalPanel person={selectedPerson} />}
        {activeTab === "Statistics" && <StatisticsPanel tree={tree} />}
      </section>
    </main>
  );
}

function normalizeRemoteUrl(value: string) {
  try {
    const parsed = new URL(value);
    if (parsed.hostname === "pastebin.com" && !parsed.pathname.startsWith("/raw/")) {
      const id = parsed.pathname.split("/").filter(Boolean).pop();
      return `https://pastebin.com/raw/${id}`;
    }
    if (parsed.hostname === "gist.github.com") {
      return value.replace("gist.github.com", "gist.githubusercontent.com") + "/raw";
    }
    return value;
  } catch {
    return value;
  }
}

function ImportPanel(props: {
  rawGedcom: string;
  setRawGedcom: (value: string) => void;
  url: string;
  setUrl: (value: string) => void;
  textRef: React.RefObject<HTMLTextAreaElement | null>;
  tree: ParsedTree;
  onLoad: () => void;
  onClipboard: () => void;
  onFetch: () => void;
}) {
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <div>
        <textarea
          ref={props.textRef}
          value={props.rawGedcom}
          onChange={(event) => props.setRawGedcom(event.target.value)}
          spellCheck={false}
          className="min-h-[520px] w-full border border-[#27190f]/25 bg-[#fff8ed] p-4 font-mono text-sm leading-6 outline-none focus:border-[#875628]"
        />
        <div className="mt-3 flex flex-wrap items-center gap-4">
          <button onClick={props.onLoad} className="bg-[#27190f] px-4 py-2 font-bold text-white">Load pasted GEDCOM</button>
          <button onClick={props.onClipboard} className="border border-[#27190f]/30 px-4 py-2 font-bold">Read clipboard</button>
          <span className="text-sm font-bold text-[#6d5139]">
            Currently parsing: {props.tree.people.length} individuals, {props.tree.families.length} families
          </span>
        </div>
      </div>
      <aside className="space-y-5">
        <div>
          <h3 className="text-xl font-black">Remote import</h3>
          <p className="mt-2 text-sm leading-6 text-[#6d5139]">Fetch .ged files, text snippets, Pastebin links, and raw Gists. Browser CORS rules still apply in webxdc.</p>
          <input value={props.url} onChange={(event) => props.setUrl(event.target.value)} placeholder="https://pastebin.com/abc123" className="mt-4 w-full border border-[#27190f]/25 bg-transparent px-3 py-2" />
          <button onClick={props.onFetch} className="mt-3 w-full bg-[#875628] px-4 py-2 font-bold text-white">Fetch URL</button>
        </div>
        <div className="border-t border-[#27190f]/15 pt-5">
          <h3 className="text-xl font-black">Multipart format</h3>
          <p className="mt-2 text-sm leading-6 text-[#6d5139]">Paste several chunks labeled like <span className="font-mono">GEDCOM PART 1/3</span>. The app sorts and recombines them before parsing.</p>
        </div>
        <div className="border-t border-[#27190f]/15 pt-5">
          <h3 className="text-xl font-black">Delta Chat sharing</h3>
          <p className="mt-2 text-sm leading-6 text-[#6d5139]">When opened as a webxdc, imports are broadcast with the shared update API so everyone in the chat can view the same tree.</p>
        </div>
      </aside>
    </div>
  );
}

function GraphPanel({ tree, selectedId, onSelect }: { tree: ParsedTree; selectedId?: string; onSelect: (id: string) => void }) {
  const levels = useMemo(() => layoutLevels(tree), [tree]);
  const width = 1120;
  const height = Math.max(460, levels.length * 150 + 80);
  const positions = Object.fromEntries(
    levels.flatMap((level, rowIndex) =>
      level.map((id, index) => [
        id,
        { x: ((index + 1) * width) / (level.length + 1), y: 70 + rowIndex * 150 },
      ]),
    ),
  ) as Record<string, { x: number; y: number }>;

  const edges = tree.families.flatMap((family) => {
    const parents = [family.husband, family.wife].filter(Boolean) as string[];
    return family.children.flatMap((child) => parents.map((parent) => ({ parent, child })));
  });

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_330px]">
      <div className="overflow-auto border border-[#27190f]/20 bg-[#fff8ed]">
        <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="min-w-[900px]">
          <defs>
            <marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#875628" /></marker>
          </defs>
          {edges.map((edge, index) => {
            const a = positions[edge.parent];
            const b = positions[edge.child];
            if (!a || !b) return null;
            return <path key={index} d={`M${a.x} ${a.y + 30} C${a.x} ${a.y + 90}, ${b.x} ${b.y - 90}, ${b.x} ${b.y - 34}`} fill="none" stroke="#875628" strokeWidth="2" markerEnd="url(#arrow)" />;
          })}
          {tree.people.map((person) => {
            const position = positions[person.id];
            if (!position) return null;
            const active = selectedId === person.id;
            return (
              <g key={person.id} transform={`translate(${position.x - 86} ${position.y - 32})`} onClick={() => onSelect(person.id)} className="cursor-pointer transition hover:opacity-80">
                <rect width="172" height="64" fill={active ? "#27190f" : "#f6f0e4"} stroke="#27190f" strokeWidth={active ? 3 : 1} />
                <text x="86" y="27" textAnchor="middle" fontSize="14" fontWeight="800" fill={active ? "#fff8ed" : "#27190f"}>{person.name.slice(0, 22)}</text>
                <text x="86" y="47" textAnchor="middle" fontSize="12" fill={active ? "#f4cc79" : "#6d5139"}>{person.birth?.year || "?"} to {person.death?.year || "present"}</text>
              </g>
            );
          })}
        </svg>
      </div>
      <div>
        <h3 className="text-xl font-black">GraphViz DOT</h3>
        <p className="mt-2 text-sm leading-6 text-[#6d5139]">The visualization uses a GraphViz-style directed family graph. Copy the DOT below into GraphViz if you want server-side rendering.</p>
        <pre className="mt-4 max-h-[520px] overflow-auto border border-[#27190f]/20 bg-[#fff8ed] p-4 text-xs leading-5">{toDot(tree)}</pre>
      </div>
    </div>
  );
}

function layoutLevels(tree: ParsedTree) {
  const childIds = new Set(tree.families.flatMap((family) => family.children));
  const roots = tree.people.filter((person) => !childIds.has(person.id)).map((person) => person.id);
  const levels: string[][] = [];
  const seen = new Set<string>();
  let current = roots.length ? roots : tree.people.slice(0, 4).map((person) => person.id);
  while (current.length) {
    const level = [...new Set(current)].filter((id) => !seen.has(id));
    if (!level.length) break;
    level.forEach((id) => seen.add(id));
    levels.push(level);
    current = tree.families.flatMap((family) => {
      const parents = [family.husband, family.wife];
      return parents.some((id) => id && level.includes(id)) ? family.children : [];
    });
  }
  const remaining = tree.people.map((person) => person.id).filter((id) => !seen.has(id));
  if (remaining.length) levels.push(remaining);
  return levels;
}

function MapPanel(props: { tree: ParsedTree; mapYear: number; setMapYear: (year: number) => void; playing: boolean; setPlaying: (value: boolean) => void; years: { min: number; max: number } }) {
  const events = props.tree.people.flatMap((person) => [
    person.birth?.coords && person.birth.year ? { person, type: "Born", event: person.birth } : undefined,
    person.death?.coords && person.death.year ? { person, type: "Died", event: person.death } : undefined,
  ]).filter(Boolean) as { person: Individual; type: string; event: GedcomEvent }[];
  const visible = events.filter((item) => (item.event.year || 0) <= props.mapYear);
  const current = events.filter((item) => item.event.year === props.mapYear);

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
      <div className="relative h-[560px] overflow-hidden border border-[#27190f]/20 bg-[#d6e3d1]">
        <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(39,25,15,.08)_1px,transparent_1px),linear-gradient(90deg,rgba(39,25,15,.08)_1px,transparent_1px)] bg-[size:56px_56px]" />
        <svg viewBox="0 0 1000 560" className="absolute inset-0 h-full w-full">
          <path d="M85 178 C165 95 248 111 302 183 C359 258 318 333 229 337 C134 340 55 266 85 178Z" fill="#b88a54" opacity=".42" />
          <path d="M450 144 C540 73 671 98 704 191 C748 315 634 414 510 380 C406 351 366 211 450 144Z" fill="#b88a54" opacity=".42" />
          <path d="M730 257 C825 213 916 260 925 358 C931 426 861 468 784 441 C714 416 672 306 730 257Z" fill="#b88a54" opacity=".42" />
          {visible.map((item, index) => {
            const x = ((item.event.coords!.lon + 180) / 360) * 1000;
            const y = ((90 - item.event.coords!.lat) / 180) * 560;
            const isCurrent = item.event.year === props.mapYear;
            return <circle key={`${item.person.id}-${item.type}-${index}`} cx={x} cy={y} r={isCurrent ? 9 : 5} fill={item.type === "Born" ? "#1f6b44" : "#7b2323"} opacity={isCurrent ? 1 : 0.55} />;
          })}
        </svg>
        <div className="absolute left-5 top-5 bg-[#fff8ed]/90 px-4 py-3 backdrop-blur">
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-[#875628]">Family story year</p>
          <p className="text-4xl font-black">{props.mapYear}</p>
        </div>
      </div>
      <div>
        <button onClick={() => props.setPlaying(!props.playing)} className="w-full bg-[#27190f] px-4 py-3 font-bold text-white">{props.playing ? "Pause animation" : "Play animation"}</button>
        <input type="range" min={props.years.min} max={props.years.max} value={props.mapYear} onChange={(event) => props.setMapYear(Number(event.target.value))} className="mt-5 w-full accent-[#875628]" />
        <div className="mt-6 border-t border-[#27190f]/15 pt-5">
          <h3 className="text-xl font-black">Events in {props.mapYear}</h3>
          <div className="mt-3 space-y-3">
            {(current.length ? current : visible.slice(-6)).map((item, index) => (
              <p key={index} className="text-sm leading-6"><strong>{item.type}</strong> {item.person.name} in {item.event.place || "unknown place"} ({item.event.year})</p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function BiorhythmPanel({ person }: { person?: Individual }) {
  const birth = parseMonthDay(person?.birth?.date);
  const rows = useMemo(() => {
    if (!birth) return [];
    const start = new Date();
    const born = new Date(birth.year, birth.month - 1, birth.day);
    return Array.from({ length: 30 }, (_, index) => {
      const date = new Date(start);
      date.setDate(start.getDate() + index);
      const days = Math.floor((date.getTime() - born.getTime()) / 86400000);
      return {
        date: date.toLocaleDateString(),
        physical: Math.sin((2 * Math.PI * days) / 23),
        emotional: Math.sin((2 * Math.PI * days) / 28),
        intellectual: Math.sin((2 * Math.PI * days) / 33),
      };
    });
  }, [birth]);
  return (
    <div>
      <p className="max-w-3xl leading-7 text-[#6d5139]">Biorhythms are an exploratory statistical folklore view, not a scientific prediction. This tab calculates 23, 28, and 33 day cycles from the selected birth date.</p>
      <div className="mt-6 overflow-auto border border-[#27190f]/20 bg-[#fff8ed]">
        <table className="w-full min-w-[680px] text-left text-sm">
          <thead className="bg-[#27190f] text-white"><tr><th className="p-3">Date</th><th>Physical</th><th>Emotional</th><th>Intellectual</th></tr></thead>
          <tbody>{rows.map((row) => <tr key={row.date} className="border-t border-[#27190f]/10"><td className="p-3 font-bold">{row.date}</td><td>{percent(row.physical)}</td><td>{percent(row.emotional)}</td><td>{percent(row.intellectual)}</td></tr>)}</tbody>
        </table>
      </div>
    </div>
  );
}

function NatalPanel({ person }: { person?: Individual }) {
  const birth = parseMonthDay(person?.birth?.date);
  if (!person || !birth) return <p>No complete birth date is available for the selected person.</p>;
  const sign = zodiac(birth.month, birth.day);
  const phase = moonPhase(birth.year, birth.month, birth.day);
  const pseudoAscendant = zodiac(((birth.month + 5) % 12) + 1, birth.day);
  return (
    <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
      <div className="relative aspect-square border border-[#27190f]/25 bg-[#fff8ed]">
        <div className="absolute inset-8 rounded-full border-2 border-[#875628]" />
        <div className="absolute inset-20 rounded-full border border-[#27190f]/25" />
        {Array.from({ length: 12 }, (_, index) => <div key={index} className="absolute left-1/2 top-1/2 h-px w-[42%] origin-left bg-[#27190f]/25" style={{ transform: `rotate(${index * 30}deg)` }} />)}
        <div className="absolute inset-0 grid place-items-center text-center"><div><p className="text-sm uppercase tracking-[0.22em] text-[#875628]">{person.name}</p><p className="text-3xl font-black">{sign}</p></div></div>
      </div>
      <div>
        <h3 className="text-2xl font-black">Natal snapshot</h3>
        <p className="mt-3 leading-7 text-[#6d5139]">A lightweight chart derived from GEDCOM birth date. Exact astrology needs time zone, birth time, and ephemeris data, so this webxdc view uses date-based solar and lunar approximations.</p>
        <dl className="mt-6 grid gap-4 sm:grid-cols-2">
          <Metric label="Sun sign" value={sign} />
          <Metric label="Moon phase" value={phase} />
          <Metric label="Approx ascendant" value={pseudoAscendant} />
          <Metric label="Birth place" value={person.birth?.place || "Unknown"} />
        </dl>
      </div>
    </div>
  );
}

function StatisticsPanel({ tree }: { tree: ParsedTree }) {
  const lifespans = tree.people.map(lifeSpan).filter((value): value is number => typeof value === "number");
  const birthsByCentury = bucketByCentury(tree.people.map((person) => person.birth?.year).filter(Boolean) as number[]);
  const deathsByCentury = bucketByCentury(tree.people.map((person) => person.death?.year).filter(Boolean) as number[]);
  const avgLife = lifespans.length ? Math.round(lifespans.reduce((sum, value) => sum + value, 0) / lifespans.length) : 0;
  const places = topPlaces(tree.people.flatMap((person) => [person.birth?.place, person.death?.place]).filter(Boolean) as string[]);
  return (
    <div>
      <dl className="grid gap-4 sm:grid-cols-4">
        <Metric label="People" value={String(tree.people.length)} />
        <Metric label="Families" value={String(tree.families.length)} />
        <Metric label="Average lifespan" value={`${avgLife} years`} />
        <Metric label="Mapped events" value={String(tree.people.filter((person) => person.birth?.coords || person.death?.coords).length)} />
      </dl>
      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <BarChart title="Births by century" data={birthsByCentury} />
        <BarChart title="Deaths by century" data={deathsByCentury} />
      </div>
      <div className="mt-8 border-t border-[#27190f]/15 pt-6">
        <h3 className="text-xl font-black">Most common places</h3>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{places.map(([place, count]) => <Metric key={place} label={place} value={`${count} event${count === 1 ? "" : "s"}`} />)}</div>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="border-l-4 border-[#875628] bg-[#fff8ed] p-4"><dt className="text-xs font-bold uppercase tracking-[0.18em] text-[#875628]">{label}</dt><dd className="mt-2 text-2xl font-black">{value}</dd></div>;
}

function BarChart({ title, data }: { title: string; data: [string, number][] }) {
  const max = Math.max(1, ...data.map((item) => item[1]));
  return <div><h3 className="text-xl font-black">{title}</h3><div className="mt-4 space-y-3">{data.map(([label, value]) => <div key={label} className="grid grid-cols-[80px_1fr_40px] items-center gap-3 text-sm"><span className="font-bold">{label}</span><span className="h-4 bg-[#e8d8bd]"><span className="block h-full bg-[#875628]" style={{ width: `${(value / max) * 100}%` }} /></span><span>{value}</span></div>)}</div></div>;
}

function bucketByCentury(years: number[]) {
  const buckets = years.reduce<Record<string, number>>((acc, year) => {
    const label = `${Math.floor((year - 1) / 100) + 1}th`;
    acc[label] = (acc[label] || 0) + 1;
    return acc;
  }, {});
  return Object.entries(buckets).sort(([a], [b]) => Number(a.replace("th", "")) - Number(b.replace("th", "")));
}

function topPlaces(places: string[]) {
  const counts = places.reduce<Record<string, number>>((acc, place) => {
    acc[place] = (acc[place] || 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 6);
}

function percent(value: number) {
  return `${Math.round(value * 100)}%`;
}

export default App;