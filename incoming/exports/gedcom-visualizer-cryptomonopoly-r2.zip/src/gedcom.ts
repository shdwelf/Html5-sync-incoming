import type { GedcomEvent, Individual, Family, ParsedTree } from "./types";

/* ── gazetteer ─────────────────────────────────────────────── */

const gazetteer: Record<string, { lat: number; lon: number }> = {
  london: { lat: 51.5072, lon: -0.1276 },
  "london, england": { lat: 51.5072, lon: -0.1276 },
  "surrey, england": { lat: 51.3148, lon: -0.56 },
  paris: { lat: 48.8566, lon: 2.3522 },
  "paris, france": { lat: 48.8566, lon: 2.3522 },
  berlin: { lat: 52.52, lon: 13.405 },
  "berlin, germany": { lat: 52.52, lon: 13.405 },
  "new york": { lat: 40.7128, lon: -74.006 },
  "new york, usa": { lat: 40.7128, lon: -74.006 },
  "new york, new york": { lat: 40.7128, lon: -74.006 },
  boston: { lat: 42.3601, lon: -71.0589 },
  "boston, massachusetts": { lat: 42.3601, lon: -71.0589 },
  chicago: { lat: 41.8781, lon: -87.6298 },
  philadelphia: { lat: 39.9526, lon: -75.1652 },
  rome: { lat: 41.9028, lon: 12.4964 },
  dublin: { lat: 53.3498, lon: -6.2603 },
  edinburgh: { lat: 55.9533, lon: -3.1883 },
  madrid: { lat: 40.4168, lon: -3.7038 },
  vienna: { lat: 48.2082, lon: 16.3738 },
  amsterdam: { lat: 52.3676, lon: 4.9041 },
  stockholm: { lat: 59.3293, lon: 18.0686 },
  oslo: { lat: 59.9139, lon: 10.7522 },
  copenhagen: { lat: 55.6761, lon: 12.5683 },
  lisbon: { lat: 38.7223, lon: -9.1393 },
  warsaw: { lat: 52.2297, lon: 21.0122 },
  moscow: { lat: 55.7558, lon: 37.6173 },
  tokyo: { lat: 35.6762, lon: 139.6503 },
  beijing: { lat: 39.9042, lon: 116.4074 },
  sydney: { lat: -33.8688, lon: 151.2093 },
  melbourne: { lat: -37.8136, lon: 144.9631 },
  "los angeles": { lat: 34.0522, lon: -118.2437 },
  "san francisco": { lat: 37.7749, lon: -122.4194 },
  "washington": { lat: 38.9072, lon: -77.0369 },
  "washington, dc": { lat: 38.9072, lon: -77.0369 },
  "salt lake city": { lat: 40.7608, lon: -111.891 },
  "salt lake city, utah": { lat: 40.7608, lon: -111.891 },
};

/* ── helpers ───────────────────────────────────────────────── */

const cleanRef = (v = "") => v.replace(/@/g, "").trim();

const normalizeName = (n = "Unknown") =>
  n.replace(/\//g, "").replace(/\s+/g, " ").trim() || "Unknown";

export const parseYear = (date?: string) => {
  const m = date?.match(/(\d{3,4})/);
  return m ? Number(m[1]) : undefined;
};

export const parseMonthDay = (date?: string) => {
  if (!date) return undefined;
  const monthMap: Record<string, number> = {
    JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
    JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
    JANUARY: 1, FEBRUARY: 2, MARCH: 3, APRIL: 4, JUNE: 6,
    JULY: 7, AUGUST: 8, SEPTEMBER: 9, OCTOBER: 10,
    NOVEMBER: 11, DECEMBER: 12,
  };
  const parts = date
    .toUpperCase()
    .match(/(?:(\d{1,2})\s+)?([A-Z]{3,9})?\s*(\d{3,4})/);
  if (!parts) return undefined;
  const year = Number(parts[3]);
  const monthKey = parts[2]?.slice(0, 3);
  const month = monthKey ? monthMap[monthKey] || 1 : 1;
  const day = parts[1] ? Number(parts[1]) : 1;
  return { year, month, day };
};

const coordinatesFor = (place?: string) => {
  if (!place) return undefined;
  const norm = place.toLowerCase().replace(/\s+/g, " ").trim();
  if (gazetteer[norm]) return gazetteer[norm];
  // partial match
  for (const [key, val] of Object.entries(gazetteer)) {
    if (norm.includes(key) || key.includes(norm)) return val;
  }
  // deterministic fallback from string hash
  const hash = [...norm].reduce((s, c) => s + c.charCodeAt(0), 0);
  return { lat: ((hash % 120) - 60) * 0.8, lon: ((hash * 7) % 320) - 160 };
};

/* ── detect whether a string looks like GEDCOM ─────────────── */

export function looksLikeGedcom(text: string): boolean {
  const lines = text.trim().split("\n").slice(0, 30);
  let score = 0;
  for (const line of lines) {
    const trimmed = line.trim();
    if (/^\d+\s+(@[^@]+@\s+)?(HEAD|INDI|FAM|SOUR|GEDC|TRLR|NAME|SEX|BIRT|DEAT|DATE|PLAC|HUSB|WIFE|CHIL|FAMS|FAMC|NOTE|EVEN)\b/i.test(trimmed)) {
      score++;
    }
  }
  return score >= 2;
}

/* ── recombine multipart ───────────────────────────────────── */

export function recombineGedcom(raw: string) {
  const partRegex =
    /(?:CRYPTOMONOPOLY|GEDCOM)\s+PART\s+(\d+)\s*\/\s*(\d+)\s*\n([\s\S]*?)(?=(?:CRYPTOMONOPOLY|GEDCOM)\s+PART\s+\d+\s*\/\s*\d+|$)/gi;
  const matches = [...raw.matchAll(partRegex)];
  if (!matches.length) return raw;
  return matches
    .sort((a, b) => Number(a[1]) - Number(b[1]))
    .map((m) => m[3].trim())
    .join("\n");
}

/* ── main parser ───────────────────────────────────────────── */

export function parseGedcom(input: string): ParsedTree {
  const text = recombineGedcom(input);
  const lines = text
    .replace(/\r/g, "")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  const people: Individual[] = [];
  const families: Family[] = [];
  let curPerson: Individual | undefined;
  let curFamily: Family | undefined;
  let curEvent: "birth" | "death" | undefined;

  const finishEvent = (ev?: GedcomEvent) => {
    if (!ev) return undefined;
    return { ...ev, year: parseYear(ev.date), coords: coordinatesFor(ev.place) };
  };

  const flush = () => {
    if (curPerson)
      people.push({
        ...curPerson,
        birth: finishEvent(curPerson.birth),
        death: finishEvent(curPerson.death),
      });
    if (curFamily) families.push(curFamily);
    curPerson = undefined;
    curFamily = undefined;
    curEvent = undefined;
  };

  for (const line of lines) {
    // more lenient regex: allow optional leading whitespace, tabs
    const m = line.match(
      /^(\d+)\s+(?:(@[^@]+@)\s+)?([A-Za-z_]\w*)(?:\s+(.*))?$/
    );
    if (!m) continue;
    const level = Number(m[1]);
    const pointer = m[2];
    const tag = m[3].toUpperCase();
    const value = m[4] || "";

    if (level === 0) {
      flush();
      if (tag === "INDI") {
        curPerson = {
          id: cleanRef(pointer),
          name: "Unknown",
          familiesAsSpouse: [],
          familiesAsChild: [],
        };
      } else if (tag === "FAM") {
        curFamily = { id: cleanRef(pointer), children: [] };
      }
      continue;
    }

    if (curPerson) {
      if (level === 1) curEvent = undefined;
      if (tag === "NAME") curPerson.name = normalizeName(value);
      if (tag === "SEX") curPerson.sex = value.trim();
      if (tag === "BIRT") {
        curPerson.birth = curPerson.birth || {};
        curEvent = "birth";
      }
      if (tag === "DEAT") {
        curPerson.death = curPerson.death || {};
        curEvent = "death";
      }
      if (tag === "FAMS") curPerson.familiesAsSpouse.push(cleanRef(value));
      if (tag === "FAMC") curPerson.familiesAsChild.push(cleanRef(value));
      if (curEvent && tag === "DATE")
        curPerson[curEvent] = { ...curPerson[curEvent], date: value };
      if (curEvent && tag === "PLAC")
        curPerson[curEvent] = { ...curPerson[curEvent], place: value };
    }

    if (curFamily) {
      if (tag === "HUSB") curFamily.husband = cleanRef(value);
      if (tag === "WIFE") curFamily.wife = cleanRef(value);
      if (tag === "CHIL") curFamily.children.push(cleanRef(value));
    }
  }
  flush();

  const byId = Object.fromEntries(people.map((p) => [p.id, p]));
  return { people, families, byId };
}

/* ── DOT export ────────────────────────────────────────────── */

export function toDot(tree: ParsedTree) {
  const nodes = tree.people.map(
    (p) => `  "${p.id}" [label="${p.name.replace(/"/g, "'")}"];`
  );
  const edges = tree.families.flatMap((f) => {
    const parents = [f.husband, f.wife].filter(Boolean) as string[];
    return f.children.flatMap((c) =>
      parents.map((p) => `  "${p}" -> "${c}";`)
    );
  });
  return [
    "digraph FamilyTree {",
    "  rankdir=TB;",
    '  node [shape=box, style=filled, fillcolor="#fff8ed"];',
    ...nodes,
    ...edges,
    "}",
  ].join("\n");
}

/* ── layout for SVG graph ──────────────────────────────────── */

export function layoutLevels(tree: ParsedTree) {
  const childIds = new Set(tree.families.flatMap((f) => f.children));
  const roots = tree.people
    .filter((p) => !childIds.has(p.id))
    .map((p) => p.id);
  const levels: string[][] = [];
  const seen = new Set<string>();
  let current = roots.length
    ? roots
    : tree.people.slice(0, 4).map((p) => p.id);
  while (current.length) {
    const level = [...new Set(current)].filter((id) => !seen.has(id));
    if (!level.length) break;
    level.forEach((id) => seen.add(id));
    levels.push(level);
    current = tree.families.flatMap((f) => {
      const parents = [f.husband, f.wife];
      return parents.some((id) => id && level.includes(id))
        ? f.children
        : [];
    });
  }
  const remaining = tree.people
    .map((p) => p.id)
    .filter((id) => !seen.has(id));
  if (remaining.length) levels.push(remaining);
  return levels;
}

/* ── utils ─────────────────────────────────────────────────── */

export function lifeSpan(person: Individual) {
  if (!person.birth?.year) return undefined;
  const end = person.death?.year || new Date().getFullYear();
  return Math.max(0, end - person.birth.year);
}

export function zodiac(month: number, day: number) {
  const signs = [
    ["Capricorn", 20], ["Aquarius", 19], ["Pisces", 20],
    ["Aries", 20], ["Taurus", 21], ["Gemini", 21],
    ["Cancer", 23], ["Leo", 23], ["Virgo", 23],
    ["Libra", 23], ["Scorpio", 22], ["Sagittarius", 22],
  ] as const;
  return day < signs[month - 1][1]
    ? signs[(month + 10) % 12][0]
    : signs[month - 1][0];
}

export function moonPhase(year: number, month: number, day: number) {
  const lp = 2551443;
  const now = Date.UTC(year, month - 1, day) / 1000;
  const newMoon = Date.UTC(2000, 0, 6, 18, 14) / 1000;
  const phase = ((now - newMoon) % lp) / lp;
  const names = [
    "New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous",
    "Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent",
  ];
  return names[Math.floor(((phase + 1) % 1) * 8) % 8];
}

export function normalizeRemoteUrl(value: string) {
  try {
    const parsed = new URL(value);
    if (
      parsed.hostname === "pastebin.com" &&
      !parsed.pathname.startsWith("/raw/")
    ) {
      const id = parsed.pathname.split("/").filter(Boolean).pop();
      return `https://pastebin.com/raw/${id}`;
    }
    if (parsed.hostname === "gist.github.com") {
      return (
        value.replace("gist.github.com", "gist.githubusercontent.com") + "/raw"
      );
    }
    return value;
  } catch {
    return value;
  }
}
