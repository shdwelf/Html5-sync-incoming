import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Individual, ParsedTree, GedcomEvent } from "./types";
import {
  parseGedcom, toDot, layoutLevels, lifeSpan,
  zodiac, moonPhase, parseMonthDay, looksLikeGedcom,
  recombineGedcom, normalizeRemoteUrl,
} from "./gedcom";
import { sampleGedcom } from "./sample";

/* ── tabs ──────────────────────────────────────────────────── */

const tabs = ["Import", "Graph", "Map", "Biorhythms", "Natal", "Statistics"] as const;
type Tab = (typeof tabs)[number];

/* ── empty tree ────────────────────────────────────────────── */

const EMPTY_TREE: ParsedTree = { people: [], families: [], byId: {} };

/* ══════════════════════════════════════════════════════════════
   APP
   ══════════════════════════════════════════════════════════════ */

export default function App() {
  const [gedcomText, setGedcomText] = useState("");
  const [tree, setTree] = useState<ParsedTree>(EMPTY_TREE);
  const [parseError, setParseError] = useState("");
  const [status, setStatus] = useState("No GEDCOM loaded yet. Paste, drop a file, or load the sample.");
  const [tab, setTab] = useState<Tab>("Import");
  const [selectedId, setSelectedId] = useState("");
  const [mapYear, setMapYear] = useState(1850);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [url, setUrl] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  /* ── parse whenever gedcomText changes ── */
  const doParse = useCallback((text: string, source: string) => {
    try {
      const combined = recombineGedcom(text);
      const parsed = parseGedcom(combined);
      if (parsed.people.length === 0) {
        setParseError("No individuals found — is this valid GEDCOM?");
        setTree(EMPTY_TREE);
        setStatus(`⚠ Parsed 0 people from ${source}.`);
        return;
      }
      setTree(parsed);
      setGedcomText(combined);
      setParseError("");
      setSelectedId(parsed.people[0].id);
      setStatus(`✓ Loaded ${parsed.people.length} people, ${parsed.families.length} families from ${source}.`);
      // broadcast to webxdc peers
      try {
        window.webxdc?.sendUpdate?.(
          { payload: { text: combined, source } },
          `GEDCOM from ${source}`
        );
      } catch { /* ignore */ }
    } catch (err) {
      setParseError(`Parse error: ${String(err)}`);
      setStatus(`✗ Failed to parse GEDCOM from ${source}.`);
    }
  }, []);

  /* ── load sample ── */
  const loadSample = useCallback(() => {
    setGedcomText(sampleGedcom);
    doParse(sampleGedcom, "built-in sample");
  }, [doParse]);

  /* ── start with sample ── */
  useEffect(() => {
    loadSample();
  }, [loadSample]);

  /* ── webxdc sync ── */
  useEffect(() => {
    try {
      window.webxdc?.setUpdateListener?.((update) => {
        if (update.payload?.text) {
          doParse(update.payload.text, update.payload.source || "Delta Chat");
        }
      });
    } catch { /* no webxdc */ }
  }, [doParse]);

  /* ── global paste handler ── */
  useEffect(() => {
    const handler = (e: ClipboardEvent) => {
      // only intercept if not typing in the textarea
      if (document.activeElement === textareaRef.current) return;
      const text = e.clipboardData?.getData("text/plain");
      if (text && looksLikeGedcom(text)) {
        e.preventDefault();
        setGedcomText(text);
        doParse(text, "clipboard paste");
        setTab("Graph");
      }
    };
    document.addEventListener("paste", handler);
    return () => document.removeEventListener("paste", handler);
  }, [doParse]);

  /* ── drag & drop ── */
  useEffect(() => {
    const onDragOver = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
    };
    const onDrop = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const file = e.dataTransfer?.files?.[0];
      if (file) {
        readFileContent(file);
        return;
      }
      const text = e.dataTransfer?.getData("text/plain");
      if (text && looksLikeGedcom(text)) {
        setGedcomText(text);
        doParse(text, "dropped text");
        setTab("Graph");
      }
    };
    document.addEventListener("dragover", onDragOver);
    document.addEventListener("drop", onDrop);
    return () => {
      document.removeEventListener("dragover", onDragOver);
      document.removeEventListener("drop", onDrop);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doParse]);

  /* ── file reader helper ── */
  const readFileContent = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result as string;
      setGedcomText(text);
      doParse(text, file.name);
      setTab("Graph");
    };
    reader.onerror = () => {
      setStatus(`✗ Could not read file: ${file.name}`);
    };
    reader.readAsText(file);
  }, [doParse]);

  /* ── file input change ── */
  const onFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) readFileContent(file);
  }, [readFileContent]);

  /* ── read clipboard button ── */
  const readClipboard = useCallback(async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        setStatus("⚠ Clipboard is empty.");
        return;
      }
      setGedcomText(text);
      doParse(text, "clipboard");
      setTab("Graph");
    } catch {
      setStatus("⚠ Clipboard permission denied. Paste directly with Ctrl+V / Cmd+V, or use the text area.");
    }
  }, [doParse]);

  /* ── load from textarea button ── */
  const loadFromTextarea = useCallback(() => {
    if (!gedcomText.trim()) {
      setStatus("⚠ Text area is empty — paste GEDCOM data first.");
      return;
    }
    doParse(gedcomText, "text area");
    setTab("Graph");
  }, [doParse, gedcomText]);

  /* ── fetch remote URL ── */
  const fetchRemote = useCallback(async () => {
    const raw = url.trim();
    if (!raw) {
      setStatus("⚠ Enter a URL first.");
      return;
    }
    setLoading(true);
    setStatus(`Fetching ${raw}…`);
    try {
      const target = normalizeRemoteUrl(raw);
      const resp = await fetch(target);
      if (!resp.ok) throw new Error(`HTTP ${resp.status} ${resp.statusText}`);
      const text = await resp.text();
      setGedcomText(text);
      doParse(text, target);
      setTab("Graph");
    } catch (err) {
      setStatus(`✗ Fetch failed: ${String(err)}. CORS restrictions may block direct downloads.`);
    } finally {
      setLoading(false);
    }
  }, [doParse, url]);

  /* ── selected person & years ── */
  const selectedPerson = tree.byId[selectedId] || tree.people[0];

  const years = useMemo(() => {
    const vals = tree.people
      .flatMap((p) => [p.birth?.year, p.death?.year])
      .filter(Boolean) as number[];
    return vals.length
      ? { min: Math.min(...vals), max: Math.max(...vals) }
      : { min: 1800, max: new Date().getFullYear() };
  }, [tree]);

  useEffect(() => {
    setMapYear((y) => Math.min(Math.max(y, years.min), years.max));
  }, [years]);

  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setMapYear((y) => (y >= years.max ? years.min : y + 1));
    }, 300);
    return () => clearInterval(id);
  }, [playing, years]);

  /* ── hidden file input ── */
  const fileInput = (
    <input
      ref={fileRef}
      type="file"
      accept=".ged,.gedcom,.txt,.json"
      className="hidden"
      onChange={onFileChange}
    />
  );

  /* ──────────────────────────────────────────────────────────── */
  return (
    <main className="min-h-screen bg-[#f6f0e4] text-[#27190f]">
      {fileInput}

      {/* ── HERO ── */}
      <header className="relative isolate flex min-h-[46vh] overflow-hidden border-b-2 border-[#27190f]/20">
        <div className="absolute inset-0 bg-gradient-to-br from-[#27190f] via-[#4e2e16] to-[#6d3e1a]" />
        <div className="absolute inset-0 opacity-20 [background-image:repeating-linear-gradient(45deg,transparent,transparent_35px,rgba(255,255,255,.06)_35px,rgba(255,255,255,.06)_70px)]" />
        <div className="relative mx-auto flex w-full max-w-6xl flex-col justify-end px-5 pb-10 pt-14 sm:px-8">
          <p className="mb-4 font-mono text-xs uppercase tracking-[0.4em] text-[#f4cc79]">
            webxdc · gedcom · family tree
          </p>
          <h1 className="text-5xl font-black tracking-tight text-[#fff8ed] sm:text-7xl">
            CryptoMonopoly
          </h1>
          <p className="mt-4 max-w-2xl text-lg leading-8 text-[#fff0d2]/90">
            Paste GEDCOM anywhere on this page, drop a <code>.ged</code> file,
            fetch from a URL / Pastebin, or use the text area. Visualize your
            family tree as a graph, animated map, natal chart &amp; statistics.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <button
              onClick={readClipboard}
              className="bg-[#f4cc79] px-5 py-3 font-bold text-[#27190f] transition hover:bg-white"
            >
              📋 Read Clipboard
            </button>
            <button
              onClick={() => fileRef.current?.click()}
              className="bg-[#f4cc79] px-5 py-3 font-bold text-[#27190f] transition hover:bg-white"
            >
              📁 Open .ged File
            </button>
            <button
              onClick={() => { setTab("Graph"); }}
              className="border border-[#fff8ed]/60 px-5 py-3 font-bold text-[#fff8ed] transition hover:bg-[#fff8ed] hover:text-[#27190f]"
            >
              View Graph →
            </button>
          </div>
        </div>
      </header>

      {/* ── TAB BAR ── */}
      <nav className="sticky top-0 z-30 border-b border-[#27190f]/15 bg-[#f6f0e4]/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 py-2">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`whitespace-nowrap rounded px-4 py-2 text-sm font-bold transition ${
                tab === t
                  ? "bg-[#27190f] text-[#fff8ed]"
                  : "hover:bg-[#e8d8bd]"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </nav>

      {/* ── STATUS BAR ── */}
      <div className="mx-auto max-w-6xl px-5 pt-6 sm:px-8">
        <div className="flex flex-col gap-3 border-b border-[#27190f]/15 pb-4 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0 flex-1">
            <p className={`font-mono text-xs uppercase tracking-wide ${
              parseError ? "text-red-700" : "text-[#875628]"
            }`}>
              {parseError || status}
            </p>
            <h2 className="mt-1 text-3xl font-black">{tab}</h2>
          </div>
          {tree.people.length > 0 && (
            <select
              value={selectedPerson?.id || ""}
              onChange={(e) => setSelectedId(e.target.value)}
              className="max-w-xs shrink-0 border border-[#27190f]/25 bg-transparent px-3 py-2 text-sm"
            >
              {tree.people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.birth?.year || "?"} – {p.death?.year || "…"})
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* ── TAB CONTENT ── */}
      <section className="mx-auto max-w-6xl px-5 py-8 sm:px-8">
        {tab === "Import" && (
          <ImportTab
            gedcomText={gedcomText}
            setGedcomText={setGedcomText}
            url={url}
            setUrl={setUrl}
            textareaRef={textareaRef}
            onLoad={loadFromTextarea}
            onClipboard={readClipboard}
            onFetch={fetchRemote}
            onSample={loadSample}
            onFile={() => fileRef.current?.click()}
            loading={loading}
            tree={tree}
          />
        )}
        {tab === "Graph" && (
          <GraphTab
            tree={tree}
            selectedId={selectedPerson?.id}
            onSelect={setSelectedId}
          />
        )}
        {tab === "Map" && (
          <MapTab
            tree={tree}
            mapYear={mapYear}
            setMapYear={setMapYear}
            playing={playing}
            setPlaying={setPlaying}
            years={years}
          />
        )}
        {tab === "Biorhythms" && <BiorhythmTab person={selectedPerson} />}
        {tab === "Natal" && <NatalTab person={selectedPerson} />}
        {tab === "Statistics" && <StatisticsTab tree={tree} />}
      </section>
    </main>
  );
}

/* ══════════════════════════════════════════════════════════════
   IMPORT TAB
   ══════════════════════════════════════════════════════════════ */

function ImportTab(props: {
  gedcomText: string;
  setGedcomText: (v: string) => void;
  url: string;
  setUrl: (v: string) => void;
  textareaRef: React.RefObject<HTMLTextAreaElement | null>;
  onLoad: () => void;
  onClipboard: () => void;
  onFetch: () => void;
  onSample: () => void;
  onFile: () => void;
  loading: boolean;
  tree: ParsedTree;
}) {
  const handlePasteInTextarea = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const text = e.clipboardData.getData("text/plain");
    if (text) {
      e.preventDefault();
      props.setGedcomText(text);
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
      <div>
        {/* instructions */}
        <div className="mb-4 rounded border border-[#875628]/30 bg-[#fff8ed] p-4">
          <h3 className="text-lg font-black">How to import GEDCOM data</h3>
          <ul className="mt-2 list-inside list-disc space-y-1 text-sm leading-6 text-[#6d5139]">
            <li><strong>Paste anywhere</strong> on this page (Ctrl+V / Cmd+V) — auto-detected &amp; loaded</li>
            <li><strong>Paste into the text box</strong> below — replaces content, then click "Load GEDCOM"</li>
            <li><strong>Drop a <code>.ged</code> file</strong> anywhere on this page</li>
            <li>Click <strong>"Open .ged File"</strong> to browse your computer</li>
            <li>Enter a <strong>URL</strong> (Pastebin, Gist, raw .ged) in the sidebar</li>
          </ul>
        </div>

        {/* textarea */}
        <textarea
          ref={props.textareaRef}
          value={props.gedcomText}
          onChange={(e) => props.setGedcomText(e.target.value)}
          onPaste={handlePasteInTextarea}
          spellCheck={false}
          placeholder="Paste GEDCOM data here…"
          className="min-h-[440px] w-full border-2 border-dashed border-[#27190f]/25 bg-[#fff8ed] p-4 font-mono text-sm leading-6 outline-none transition focus:border-[#875628] focus:border-solid"
        />

        {/* buttons */}
        <div className="mt-3 flex flex-wrap gap-3">
          <button
            onClick={props.onLoad}
            className="bg-[#27190f] px-5 py-2.5 font-bold text-white transition hover:bg-[#4e2e16]"
          >
            ▶ Load GEDCOM
          </button>
          <button
            onClick={props.onClipboard}
            className="border border-[#27190f]/30 px-5 py-2.5 font-bold transition hover:bg-[#e8d8bd]"
          >
            📋 Read Clipboard
          </button>
          <button
            onClick={props.onFile}
            className="border border-[#27190f]/30 px-5 py-2.5 font-bold transition hover:bg-[#e8d8bd]"
          >
            📁 Open File
          </button>
          <button
            onClick={props.onSample}
            className="border border-[#27190f]/30 px-5 py-2.5 font-bold transition hover:bg-[#e8d8bd]"
          >
            🧪 Load Sample
          </button>
          <button
            onClick={() => props.setGedcomText("")}
            className="border border-red-300 px-5 py-2.5 font-bold text-red-700 transition hover:bg-red-50"
          >
            ✕ Clear
          </button>
        </div>

        {/* live parse preview */}
        {props.tree.people.length > 0 && (
          <div className="mt-5 rounded border border-green-300 bg-green-50 p-4">
            <p className="text-sm font-bold text-green-800">
              ✓ Currently parsed: {props.tree.people.length} people, {props.tree.families.length} families
            </p>
            <p className="mt-1 text-xs text-green-700">
              {props.tree.people.slice(0, 5).map((p) => p.name).join(" · ")}
              {props.tree.people.length > 5 ? ` … and ${props.tree.people.length - 5} more` : ""}
            </p>
          </div>
        )}
      </div>

      {/* sidebar */}
      <aside className="space-y-6">
        {/* URL fetch */}
        <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-5">
          <h3 className="text-lg font-black">Fetch from URL</h3>
          <p className="mt-2 text-sm leading-6 text-[#6d5139]">
            Supports Pastebin links, GitHub Gists, and direct <code>.ged</code> file URLs.
          </p>
          <input
            value={props.url}
            onChange={(e) => props.setUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && props.onFetch()}
            placeholder="https://pastebin.com/abc123"
            className="mt-3 w-full border border-[#27190f]/25 bg-white px-3 py-2 text-sm outline-none focus:border-[#875628]"
          />
          <button
            onClick={props.onFetch}
            disabled={props.loading}
            className="mt-3 w-full bg-[#875628] px-4 py-2.5 font-bold text-white transition hover:bg-[#6d4520] disabled:opacity-50"
          >
            {props.loading ? "Fetching…" : "Fetch URL"}
          </button>
        </div>

        {/* multipart */}
        <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-5">
          <h3 className="text-lg font-black">Multipart support</h3>
          <p className="mt-2 text-sm leading-6 text-[#6d5139]">
            If your GEDCOM is split, label chunks as{" "}
            <code className="rounded bg-[#e8d8bd] px-1 py-0.5 text-xs font-bold">
              GEDCOM PART 1/3
            </code>
            . They'll be auto-sorted and recombined.
          </p>
        </div>

        {/* webxdc */}
        <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-5">
          <h3 className="text-lg font-black">Delta Chat / webxdc</h3>
          <p className="mt-2 text-sm leading-6 text-[#6d5139]">
            When running as a webxdc app, imports are broadcast to all chat
            participants so everyone sees the same family tree.
          </p>
        </div>
      </aside>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   GRAPH TAB
   ══════════════════════════════════════════════════════════════ */

function GraphTab({
  tree,
  selectedId,
  onSelect,
}: {
  tree: ParsedTree;
  selectedId?: string;
  onSelect: (id: string) => void;
}) {
  const levels = useMemo(() => layoutLevels(tree), [tree]);
  const width = 1120;
  const height = Math.max(460, levels.length * 160 + 100);
  const positions = useMemo(() => {
    const map: Record<string, { x: number; y: number }> = {};
    levels.forEach((level, row) => {
      level.forEach((id, col) => {
        map[id] = {
          x: ((col + 1) * width) / (level.length + 1),
          y: 80 + row * 160,
        };
      });
    });
    return map;
  }, [levels]);

  const edges = tree.families.flatMap((f) => {
    const parents = [f.husband, f.wife].filter(Boolean) as string[];
    return f.children.flatMap((c) =>
      parents.map((p) => ({ from: p, to: c }))
    );
  });

  if (tree.people.length === 0) {
    return (
      <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-12 text-center">
        <p className="text-lg font-bold text-[#875628]">No data to graph</p>
        <p className="mt-2 text-sm text-[#6d5139]">Import GEDCOM data first using the Import tab.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_330px]">
      <div className="overflow-auto rounded border border-[#27190f]/20 bg-[#fff8ed]">
        <svg
          width={width}
          height={height}
          viewBox={`0 0 ${width} ${height}`}
          className="min-w-[900px]"
        >
          <defs>
            <marker
              id="arrowhead"
              markerWidth="8"
              markerHeight="8"
              refX="7"
              refY="4"
              orient="auto"
            >
              <path d="M0,0 L8,4 L0,8 z" fill="#875628" />
            </marker>
          </defs>
          {edges.map((e, i) => {
            const a = positions[e.from];
            const b = positions[e.to];
            if (!a || !b) return null;
            return (
              <path
                key={i}
                d={`M${a.x} ${a.y + 32} C${a.x} ${a.y + 96},${b.x} ${b.y - 96},${b.x} ${b.y - 36}`}
                fill="none"
                stroke="#875628"
                strokeWidth="2"
                markerEnd="url(#arrowhead)"
              />
            );
          })}
          {tree.people.map((p) => {
            const pos = positions[p.id];
            if (!pos) return null;
            const active = selectedId === p.id;
            const fill = active ? "#27190f" : p.sex === "F" ? "#f5e6d8" : "#e8ddd0";
            const textFill = active ? "#fff8ed" : "#27190f";
            const subFill = active ? "#f4cc79" : "#6d5139";
            return (
              <g
                key={p.id}
                transform={`translate(${pos.x - 90} ${pos.y - 32})`}
                onClick={() => onSelect(p.id)}
                className="cursor-pointer"
              >
                <rect
                  width="180"
                  height="64"
                  rx="4"
                  fill={fill}
                  stroke={active ? "#f4cc79" : "#27190f"}
                  strokeWidth={active ? 3 : 1}
                />
                <text
                  x="90"
                  y="28"
                  textAnchor="middle"
                  fontSize="13"
                  fontWeight="800"
                  fill={textFill}
                >
                  {p.name.length > 24 ? p.name.slice(0, 22) + "…" : p.name}
                </text>
                <text
                  x="90"
                  y="48"
                  textAnchor="middle"
                  fontSize="11"
                  fill={subFill}
                >
                  {p.birth?.year || "?"} – {p.death?.year || "present"}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* DOT sidebar */}
      <div>
        <h3 className="text-xl font-black">GraphViz DOT</h3>
        <p className="mt-2 text-sm leading-6 text-[#6d5139]">
          Copy the DOT source below into{" "}
          <a
            href="https://dreampuf.github.io/GraphvizOnline/"
            target="_blank"
            rel="noopener"
            className="underline"
          >
            GraphViz Online
          </a>{" "}
          for a high-quality rendered graph.
        </p>
        <pre className="mt-4 max-h-[500px] overflow-auto rounded border border-[#27190f]/20 bg-[#fff8ed] p-4 text-xs leading-5">
          {toDot(tree)}
        </pre>
        <button
          onClick={() => navigator.clipboard?.writeText(toDot(tree))}
          className="mt-3 w-full border border-[#27190f]/25 px-4 py-2 text-sm font-bold transition hover:bg-[#e8d8bd]"
        >
          Copy DOT to clipboard
        </button>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   MAP TAB
   ══════════════════════════════════════════════════════════════ */

function MapTab(props: {
  tree: ParsedTree;
  mapYear: number;
  setMapYear: (y: number) => void;
  playing: boolean;
  setPlaying: (v: boolean) => void;
  years: { min: number; max: number };
}) {
  const events = useMemo(
    () =>
      props.tree.people.flatMap((p) => {
        const out: { person: Individual; type: string; event: GedcomEvent }[] = [];
        if (p.birth?.coords && p.birth.year)
          out.push({ person: p, type: "Born", event: p.birth });
        if (p.death?.coords && p.death.year)
          out.push({ person: p, type: "Died", event: p.death });
        return out;
      }),
    [props.tree]
  );

  const visible = events.filter((e) => (e.event.year || 0) <= props.mapYear);
  const current = events.filter((e) => e.event.year === props.mapYear);

  if (events.length === 0) {
    return (
      <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-12 text-center">
        <p className="text-lg font-bold text-[#875628]">No map events</p>
        <p className="mt-2 text-sm text-[#6d5139]">Import GEDCOM data with PLAC (place) fields to see map events.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
      <div className="relative h-[560px] overflow-hidden rounded border border-[#27190f]/20 bg-[#d6e3d1]">
        {/* grid bg */}
        <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(39,25,15,.06)_1px,transparent_1px),linear-gradient(90deg,rgba(39,25,15,.06)_1px,transparent_1px)] [background-size:50px_50px]" />
        <svg
          viewBox="0 0 1000 560"
          className="absolute inset-0 h-full w-full"
        >
          {/* very simplified continent shapes */}
          <ellipse cx="280" cy="240" rx="170" ry="120" fill="#b88a54" opacity=".32" />
          <ellipse cx="580" cy="210" rx="200" ry="140" fill="#b88a54" opacity=".32" />
          <ellipse cx="830" cy="320" rx="110" ry="90" fill="#b88a54" opacity=".32" />
          <ellipse cx="220" cy="400" rx="90" ry="70" fill="#b88a54" opacity=".22" />
          <ellipse cx="750" cy="180" rx="120" ry="80" fill="#b88a54" opacity=".22" />

          {visible.map((item, i) => {
            const x = ((item.event.coords!.lon + 180) / 360) * 1000;
            const y = ((90 - item.event.coords!.lat) / 180) * 560;
            const isCurrent = item.event.year === props.mapYear;
            return (
              <g key={`${item.person.id}-${item.type}-${i}`}>
                {isCurrent && (
                  <circle cx={x} cy={y} r="18" fill="none" stroke={item.type === "Born" ? "#1f6b44" : "#7b2323"} strokeWidth="2" opacity=".5">
                    <animate attributeName="r" from="10" to="22" dur="1s" repeatCount="indefinite" />
                    <animate attributeName="opacity" from=".6" to="0" dur="1s" repeatCount="indefinite" />
                  </circle>
                )}
                <circle
                  cx={x}
                  cy={y}
                  r={isCurrent ? 8 : 5}
                  fill={item.type === "Born" ? "#1f6b44" : "#7b2323"}
                  opacity={isCurrent ? 1 : 0.5}
                />
                {isCurrent && (
                  <text x={x} y={y - 14} textAnchor="middle" fontSize="10" fontWeight="700" fill="#27190f">
                    {item.person.name.split(" ")[0]}
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* year overlay */}
        <div className="absolute left-4 top-4 rounded bg-[#fff8ed]/90 px-4 py-3 backdrop-blur">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#875628]">
            Family story
          </p>
          <p className="text-4xl font-black">{props.mapYear}</p>
        </div>

        {/* legend */}
        <div className="absolute bottom-4 right-4 flex gap-4 rounded bg-[#fff8ed]/90 px-4 py-2 text-xs font-bold backdrop-blur">
          <span className="flex items-center gap-1"><span className="inline-block h-3 w-3 rounded-full bg-[#1f6b44]" /> Birth</span>
          <span className="flex items-center gap-1"><span className="inline-block h-3 w-3 rounded-full bg-[#7b2323]" /> Death</span>
        </div>
      </div>

      {/* controls */}
      <div>
        <button
          onClick={() => props.setPlaying(!props.playing)}
          className="w-full bg-[#27190f] px-4 py-3 font-bold text-white transition hover:bg-[#4e2e16]"
        >
          {props.playing ? "⏸ Pause" : "▶ Play Animation"}
        </button>
        <div className="mt-4 flex items-center gap-3 text-sm">
          <span className="font-bold">{props.years.min}</span>
          <input
            type="range"
            min={props.years.min}
            max={props.years.max}
            value={props.mapYear}
            onChange={(e) => props.setMapYear(Number(e.target.value))}
            className="flex-1 accent-[#875628]"
          />
          <span className="font-bold">{props.years.max}</span>
        </div>

        <div className="mt-6 border-t border-[#27190f]/15 pt-5">
          <h3 className="text-lg font-black">Events in {props.mapYear}</h3>
          <div className="mt-3 space-y-2">
            {current.length > 0 ? (
              current.map((item, i) => (
                <div key={i} className="rounded bg-[#fff8ed] p-3 text-sm">
                  <span className={`inline-block rounded px-2 py-0.5 text-xs font-bold text-white ${item.type === "Born" ? "bg-[#1f6b44]" : "bg-[#7b2323]"}`}>
                    {item.type}
                  </span>{" "}
                  <strong>{item.person.name}</strong> in{" "}
                  {item.event.place || "unknown"}
                </div>
              ))
            ) : (
              <p className="text-sm text-[#6d5139]">No events this year. Use the slider or play button.</p>
            )}
          </div>
        </div>

        {/* all events summary */}
        <div className="mt-6 border-t border-[#27190f]/15 pt-5">
          <h3 className="text-lg font-black">All Events ({events.length})</h3>
          <div className="mt-3 max-h-48 space-y-1 overflow-y-auto text-xs">
            {events
              .sort((a, b) => (a.event.year || 0) - (b.event.year || 0))
              .map((item, i) => (
                <p key={i}>
                  <strong>{item.event.year}</strong> — {item.type}: {item.person.name}
                </p>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   BIORHYTHM TAB
   ══════════════════════════════════════════════════════════════ */

function BiorhythmTab({ person }: { person?: Individual }) {
  const birth = parseMonthDay(person?.birth?.date);

  const { rows, chartData } = useMemo(() => {
    if (!birth) return { rows: [], chartData: [] };
    const start = new Date();
    const born = new Date(birth.year, birth.month - 1, birth.day);
    const data = Array.from({ length: 60 }, (_, i) => {
      const date = new Date(start);
      date.setDate(start.getDate() + i - 15);
      const days = Math.floor(
        (date.getTime() - born.getTime()) / 86_400_000
      );
      return {
        label: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        physical: Math.sin((2 * Math.PI * days) / 23),
        emotional: Math.sin((2 * Math.PI * days) / 28),
        intellectual: Math.sin((2 * Math.PI * days) / 33),
        isToday: i === 15,
      };
    });
    return { rows: data.slice(15, 45), chartData: data };
  }, [birth]);

  if (!person || !birth) {
    return (
      <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-12 text-center">
        <p className="text-lg font-bold text-[#875628]">No birth date available</p>
        <p className="mt-2 text-sm text-[#6d5139]">Select a person with a complete birth date to view biorhythms.</p>
      </div>
    );
  }

  const h = 200;
  const w = 900;

  return (
    <div>
      <p className="max-w-3xl text-sm leading-7 text-[#6d5139]">
        Biorhythm cycles (23-day physical, 28-day emotional, 33-day
        intellectual) computed from <strong>{person.name}</strong>'s birth date:{" "}
        <strong>{person.birth?.date}</strong>. This is an exploratory
        statistical view, not a scientific prediction.
      </p>

      {/* chart */}
      <div className="mt-6 overflow-auto rounded border border-[#27190f]/20 bg-[#fff8ed] p-4">
        <svg viewBox={`0 0 ${w} ${h}`} className="min-w-[700px]">
          <line x1="0" y1={h / 2} x2={w} y2={h / 2} stroke="#27190f" strokeWidth=".5" strokeDasharray="4" />
          {["#d97706", "#2563eb", "#16a34a"].map((color, ci) => {
            const key = (["physical", "emotional", "intellectual"] as const)[ci];
            const pts = chartData
              .map((d, i) => `${(i / (chartData.length - 1)) * w},${h / 2 - d[key] * (h / 2 - 10)}`)
              .join(" ");
            return <polyline key={ci} points={pts} fill="none" stroke={color} strokeWidth="2" />;
          })}
          {/* today line */}
          <line x1={(15 / (chartData.length - 1)) * w} y1="0" x2={(15 / (chartData.length - 1)) * w} y2={h} stroke="#ef4444" strokeWidth="1" strokeDasharray="4" />
          <text x={(15 / (chartData.length - 1)) * w + 4} y="12" fontSize="10" fill="#ef4444">Today</text>
        </svg>
        <div className="mt-2 flex justify-center gap-6 text-xs font-bold">
          <span className="text-[#d97706]">● Physical (23d)</span>
          <span className="text-[#2563eb]">● Emotional (28d)</span>
          <span className="text-[#16a34a]">● Intellectual (33d)</span>
        </div>
      </div>

      {/* table */}
      <div className="mt-6 overflow-auto rounded border border-[#27190f]/20 bg-[#fff8ed]">
        <table className="w-full min-w-[600px] text-left text-sm">
          <thead className="bg-[#27190f] text-white">
            <tr>
              <th className="p-3">Date</th>
              <th className="p-3">Physical</th>
              <th className="p-3">Emotional</th>
              <th className="p-3">Intellectual</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr
                key={row.label}
                className={`border-t border-[#27190f]/10 ${row.isToday ? "bg-[#f4cc79]/30 font-bold" : ""}`}
              >
                <td className="p-3">{row.label} {row.isToday && "← today"}</td>
                <td className="p-3"><Bar value={row.physical} color="#d97706" /></td>
                <td className="p-3"><Bar value={row.emotional} color="#2563eb" /></td>
                <td className="p-3"><Bar value={row.intellectual} color="#16a34a" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Bar({ value, color }: { value: number; color: string }) {
  const pct = Math.round(value * 100);
  const width = Math.abs(pct);
  return (
    <div className="flex items-center gap-2">
      <div className="relative h-4 w-24 bg-[#e8d8bd]">
        <div
          className="absolute top-0 h-full"
          style={{
            backgroundColor: color,
            width: `${width}%`,
            left: pct >= 0 ? "50%" : `${50 - width}%`,
            opacity: 0.7,
          }}
        />
        <div className="absolute left-1/2 top-0 h-full w-px bg-[#27190f]/30" />
      </div>
      <span className="w-10 text-right text-xs font-bold" style={{ color }}>
        {pct > 0 ? "+" : ""}{pct}%
      </span>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   NATAL TAB
   ══════════════════════════════════════════════════════════════ */

function NatalTab({ person }: { person?: Individual }) {
  const birth = parseMonthDay(person?.birth?.date);
  if (!person || !birth) {
    return (
      <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-12 text-center">
        <p className="text-lg font-bold text-[#875628]">No birth date available</p>
        <p className="mt-2 text-sm text-[#6d5139]">Select a person with a complete birth date to view natal chart.</p>
      </div>
    );
  }

  const sign = zodiac(birth.month, birth.day);
  const phase = moonPhase(birth.year, birth.month, birth.day);
  const ascendant = zodiac(((birth.month + 5) % 12) + 1, birth.day);
  const signSymbols: Record<string, string> = {
    Aries: "♈", Taurus: "♉", Gemini: "♊", Cancer: "♋",
    Leo: "♌", Virgo: "♍", Libra: "♎", Scorpio: "♏",
    Sagittarius: "♐", Capricorn: "♑", Aquarius: "♒", Pisces: "♓",
  };
  const allSigns = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"];
  const sunIndex = allSigns.indexOf(sign);

  return (
    <div className="grid gap-8 lg:grid-cols-[380px_1fr]">
      {/* chart wheel */}
      <div className="relative aspect-square rounded border border-[#27190f]/20 bg-[#fff8ed] p-4">
        <svg viewBox="0 0 400 400" className="h-full w-full">
          {/* outer ring */}
          <circle cx="200" cy="200" r="180" fill="none" stroke="#875628" strokeWidth="2" />
          <circle cx="200" cy="200" r="140" fill="none" stroke="#27190f" strokeWidth=".5" opacity=".3" />
          <circle cx="200" cy="200" r="80" fill="none" stroke="#27190f" strokeWidth=".5" opacity=".2" />

          {/* 12 house lines */}
          {allSigns.map((_, i) => {
            const angle = (i * 30 - 90) * (Math.PI / 180);
            const x1 = 200 + 140 * Math.cos(angle);
            const y1 = 200 + 140 * Math.sin(angle);
            const x2 = 200 + 180 * Math.cos(angle);
            const y2 = 200 + 180 * Math.sin(angle);
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#27190f" strokeWidth=".5" opacity=".4" />;
          })}

          {/* sign labels around wheel */}
          {allSigns.map((s, i) => {
            const angle = ((i * 30 + 15) - 90) * (Math.PI / 180);
            const x = 200 + 160 * Math.cos(angle);
            const y = 200 + 160 * Math.sin(angle);
            const isActive = s === sign;
            return (
              <text
                key={s}
                x={x}
                y={y}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize={isActive ? "18" : "14"}
                fontWeight={isActive ? "800" : "400"}
                fill={isActive ? "#875628" : "#27190f"}
                opacity={isActive ? 1 : 0.5}
              >
                {signSymbols[s]}
              </text>
            );
          })}

          {/* sun marker */}
          {(() => {
            const angle = ((sunIndex * 30 + 15) - 90) * (Math.PI / 180);
            const x = 200 + 110 * Math.cos(angle);
            const y = 200 + 110 * Math.sin(angle);
            return (
              <>
                <circle cx={x} cy={y} r="12" fill="#f4cc79" stroke="#875628" strokeWidth="2" />
                <text x={x} y={y + 1} textAnchor="middle" dominantBaseline="middle" fontSize="14">☉</text>
              </>
            );
          })()}

          {/* center text */}
          <text x="200" y="190" textAnchor="middle" fontSize="12" fill="#875628" fontWeight="700">
            {person.name.split(" ")[0]}
          </text>
          <text x="200" y="210" textAnchor="middle" fontSize="22" fontWeight="900" fill="#27190f">
            {signSymbols[sign]} {sign}
          </text>
        </svg>
      </div>

      {/* details */}
      <div>
        <h3 className="text-2xl font-black">Natal Snapshot</h3>
        <p className="mt-3 text-sm leading-7 text-[#6d5139]">
          Computed from <strong>{person.name}</strong>'s GEDCOM birth date ({person.birth?.date}).
          Full natal charts require exact birth time, timezone, and an ephemeris.
          This is a date-based approximation using solar and lunar positions.
        </p>

        <dl className="mt-6 grid gap-4 sm:grid-cols-2">
          <Metric label="Sun sign" value={`${signSymbols[sign]} ${sign}`} />
          <Metric label="Lunar phase" value={phase} />
          <Metric label="Approx. ascendant" value={`${signSymbols[ascendant]} ${ascendant}`} />
          <Metric label="Birth place" value={person.birth?.place || "Unknown"} />
          <Metric label="Birth date" value={person.birth?.date || "Unknown"} />
          <Metric label="Day of week" value={
            new Date(birth.year, birth.month - 1, birth.day).toLocaleDateString("en-US", { weekday: "long" })
          } />
        </dl>

        {/* element */}
        <div className="mt-6 border-t border-[#27190f]/15 pt-5">
          <h4 className="text-lg font-black">Element &amp; Quality</h4>
          <div className="mt-3 flex gap-4 text-sm">
            <span className="rounded bg-[#fff8ed] border border-[#27190f]/15 px-4 py-2 font-bold">
              {elementOf(sign)}
            </span>
            <span className="rounded bg-[#fff8ed] border border-[#27190f]/15 px-4 py-2 font-bold">
              {qualityOf(sign)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function elementOf(sign: string) {
  const map: Record<string, string> = {
    Aries: "🔥 Fire", Leo: "🔥 Fire", Sagittarius: "🔥 Fire",
    Taurus: "🌍 Earth", Virgo: "🌍 Earth", Capricorn: "🌍 Earth",
    Gemini: "💨 Air", Libra: "💨 Air", Aquarius: "💨 Air",
    Cancer: "💧 Water", Scorpio: "💧 Water", Pisces: "💧 Water",
  };
  return map[sign] || "Unknown";
}

function qualityOf(sign: string) {
  const map: Record<string, string> = {
    Aries: "Cardinal", Cancer: "Cardinal", Libra: "Cardinal", Capricorn: "Cardinal",
    Taurus: "Fixed", Leo: "Fixed", Scorpio: "Fixed", Aquarius: "Fixed",
    Gemini: "Mutable", Virgo: "Mutable", Sagittarius: "Mutable", Pisces: "Mutable",
  };
  return map[sign] || "Unknown";
}

/* ══════════════════════════════════════════════════════════════
   STATISTICS TAB
   ══════════════════════════════════════════════════════════════ */

function StatisticsTab({ tree }: { tree: ParsedTree }) {
  const lifespans = tree.people
    .map(lifeSpan)
    .filter((v): v is number => typeof v === "number");
  const avgLife = lifespans.length
    ? Math.round(lifespans.reduce((s, v) => s + v, 0) / lifespans.length)
    : 0;
  const medianLife = lifespans.length
    ? lifespans.sort((a, b) => a - b)[Math.floor(lifespans.length / 2)]
    : 0;
  const maxLife = lifespans.length ? Math.max(...lifespans) : 0;
  const minLife = lifespans.length ? Math.min(...lifespans) : 0;

  const maleCount = tree.people.filter((p) => p.sex === "M").length;
  const femaleCount = tree.people.filter((p) => p.sex === "F").length;

  const birthsByCentury = bucketByCentury(
    tree.people.map((p) => p.birth?.year).filter(Boolean) as number[]
  );
  const deathsByCentury = bucketByCentury(
    tree.people.map((p) => p.death?.year).filter(Boolean) as number[]
  );

  const birthsByMonth = bucketByMonth(
    tree.people.map((p) => parseMonthDay(p.birth?.date)).filter(Boolean) as { month: number }[]
  );
  const deathsByMonth = bucketByMonth(
    tree.people.map((p) => parseMonthDay(p.death?.date)).filter(Boolean) as { month: number }[]
  );

  const places = topPlaces(
    tree.people
      .flatMap((p) => [p.birth?.place, p.death?.place])
      .filter(Boolean) as string[]
  );

  if (tree.people.length === 0) {
    return (
      <div className="rounded border border-[#27190f]/15 bg-[#fff8ed] p-12 text-center">
        <p className="text-lg font-bold text-[#875628]">No data</p>
        <p className="mt-2 text-sm text-[#6d5139]">Import GEDCOM data first.</p>
      </div>
    );
  }

  return (
    <div>
      {/* top metrics */}
      <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label="People" value={String(tree.people.length)} />
        <Metric label="Families" value={String(tree.families.length)} />
        <Metric label="Average lifespan" value={avgLife ? `${avgLife} years` : "N/A"} />
        <Metric label="Median lifespan" value={medianLife ? `${medianLife} years` : "N/A"} />
      </dl>

      <dl className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label="Longest life" value={maxLife ? `${maxLife} years` : "N/A"} />
        <Metric label="Shortest life" value={minLife ? `${minLife} years` : "N/A"} />
        <Metric label="Male" value={String(maleCount)} />
        <Metric label="Female" value={String(femaleCount)} />
      </dl>

      {/* charts */}
      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <HBarChart title="Births by century" data={birthsByCentury} color="#1f6b44" />
        <HBarChart title="Deaths by century" data={deathsByCentury} color="#7b2323" />
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <HBarChart title="Births by month" data={birthsByMonth} color="#2563eb" />
        <HBarChart title="Deaths by month" data={deathsByMonth} color="#d97706" />
      </div>

      {/* places */}
      <div className="mt-8 border-t border-[#27190f]/15 pt-6">
        <h3 className="text-xl font-black">Most Common Places</h3>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {places.map(([place, count]) => (
            <Metric
              key={place}
              label={place}
              value={`${count} event${count === 1 ? "" : "s"}`}
            />
          ))}
        </div>
      </div>

      {/* lifespan distribution */}
      {lifespans.length > 0 && (
        <div className="mt-8 border-t border-[#27190f]/15 pt-6">
          <h3 className="text-xl font-black">Lifespan Distribution</h3>
          <div className="mt-4 overflow-auto rounded border border-[#27190f]/20 bg-[#fff8ed] p-4">
            <svg viewBox={`0 0 800 200`} className="min-w-[600px]">
              {(() => {
                const buckets: Record<string, number> = {};
                for (const l of lifespans) {
                  const key = `${Math.floor(l / 10) * 10}s`;
                  buckets[key] = (buckets[key] || 0) + 1;
                }
                const entries = Object.entries(buckets).sort(
                  (a, b) =>
                    Number(a[0].replace("s", "")) -
                    Number(b[0].replace("s", ""))
                );
                const max = Math.max(1, ...entries.map((e) => e[1]));
                const barW = Math.min(60, 780 / entries.length - 4);
                return entries.map(([label, count], i) => (
                  <g key={label}>
                    <rect
                      x={i * (barW + 4) + 10}
                      y={180 - (count / max) * 160}
                      width={barW}
                      height={(count / max) * 160}
                      fill="#875628"
                      rx="2"
                    />
                    <text
                      x={i * (barW + 4) + 10 + barW / 2}
                      y={196}
                      textAnchor="middle"
                      fontSize="10"
                      fill="#27190f"
                    >
                      {label}
                    </text>
                    <text
                      x={i * (barW + 4) + 10 + barW / 2}
                      y={176 - (count / max) * 160}
                      textAnchor="middle"
                      fontSize="10"
                      fontWeight="700"
                      fill="#27190f"
                    >
                      {count}
                    </text>
                  </g>
                ));
              })()}
            </svg>
          </div>
        </div>
      )}
    </div>
  );
}

/* ── shared components ─────────────────────────────────────── */

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-l-4 border-[#875628] bg-[#fff8ed] p-4">
      <dt className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#875628]">
        {label}
      </dt>
      <dd className="mt-1.5 text-2xl font-black">{value}</dd>
    </div>
  );
}

function HBarChart({
  title,
  data,
  color = "#875628",
}: {
  title: string;
  data: [string, number][];
  color?: string;
}) {
  const max = Math.max(1, ...data.map((d) => d[1]));
  return (
    <div>
      <h3 className="text-lg font-black">{title}</h3>
      <div className="mt-3 space-y-2">
        {data.map(([label, value]) => (
          <div
            key={label}
            className="grid grid-cols-[90px_1fr_36px] items-center gap-3 text-sm"
          >
            <span className="truncate font-bold">{label}</span>
            <span className="h-5 rounded bg-[#e8d8bd]">
              <span
                className="block h-full rounded"
                style={{
                  width: `${(value / max) * 100}%`,
                  backgroundColor: color,
                }}
              />
            </span>
            <span className="text-right font-bold">{value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── stat helpers ──────────────────────────────────────────── */

function bucketByCentury(years: number[]) {
  const b = years.reduce<Record<string, number>>((a, y) => {
    const c = Math.floor((y - 1) / 100) + 1;
    const label = `${c}00s`;
    a[label] = (a[label] || 0) + 1;
    return a;
  }, {});
  return Object.entries(b).sort(
    (a, b) => Number(a[0].replace("s", "")) - Number(b[0].replace("s", ""))
  );
}

function bucketByMonth(dates: { month: number }[]) {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const b: Record<string, number> = {};
  for (const m of months) b[m] = 0;
  for (const d of dates) b[months[d.month - 1]] = (b[months[d.month - 1]] || 0) + 1;
  return Object.entries(b);
}

function topPlaces(places: string[]) {
  const c = places.reduce<Record<string, number>>((a, p) => {
    a[p] = (a[p] || 0) + 1;
    return a;
  }, {});
  return Object.entries(c)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);
}
