export type GedcomEvent = {
  date?: string;
  place?: string;
  year?: number;
  coords?: { lat: number; lon: number };
};

export type Individual = {
  id: string;
  name: string;
  sex?: string;
  birth?: GedcomEvent;
  death?: GedcomEvent;
  familiesAsSpouse: string[];
  familiesAsChild: string[];
};

export type Family = {
  id: string;
  husband?: string;
  wife?: string;
  children: string[];
};

export type ParsedTree = {
  people: Individual[];
  families: Family[];
  byId: Record<string, Individual>;
};

export type RemoteUpdate = {
  payload?: {
    text?: string;
    source?: string;
  };
};

declare global {
  interface Window {
    webxdc?: {
      sendUpdate?: (update: RemoteUpdate, description?: string) => void;
      setUpdateListener?: (listener: (update: RemoteUpdate) => void) => void;
    };
  }
}
