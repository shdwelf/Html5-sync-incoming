export const sampleGedcom = `0 HEAD
1 SOUR CryptoMonopoly
1 GEDC
2 VERS 5.5.1
0 @I1@ INDI
1 NAME Ada /Lovelace/
1 SEX F
1 BIRT
2 DATE 10 DEC 1815
2 PLAC London, England
1 DEAT
2 DATE 27 NOV 1852
2 PLAC London, England
1 FAMS @F1@
0 @I2@ INDI
1 NAME William /King-Noel/
1 SEX M
1 BIRT
2 DATE 21 FEB 1805
2 PLAC London, England
1 DEAT
2 DATE 29 DEC 1893
2 PLAC Surrey, England
1 FAMS @F1@
0 @I3@ INDI
1 NAME Byron /King-Noel/
1 SEX M
1 BIRT
2 DATE 12 MAY 1836
2 PLAC London, England
1 DEAT
2 DATE 1 SEP 1862
2 PLAC London, England
1 FAMC @F1@
0 @I4@ INDI
1 NAME Anne Isabella /Milbanke/
1 SEX F
1 BIRT
2 DATE 17 MAY 1792
2 PLAC Durham, England
1 DEAT
2 DATE 16 MAY 1860
2 PLAC London, England
1 FAMS @F2@
0 @I5@ INDI
1 NAME Lord George /Byron/
1 SEX M
1 BIRT
2 DATE 22 JAN 1788
2 PLAC London, England
1 DEAT
2 DATE 19 APR 1824
2 PLAC Missolonghi, Greece
1 FAMS @F2@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I1@
1 CHIL @I3@
0 @F2@ FAM
1 HUSB @I5@
1 WIFE @I4@
1 CHIL @I1@
0 TRLR`;
