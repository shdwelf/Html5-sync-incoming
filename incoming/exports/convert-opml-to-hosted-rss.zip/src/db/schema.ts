import {
  pgTable,
  serial,
  text,
  timestamp,
  boolean,
  integer,
  uniqueIndex,
  index,
  real,
} from "drizzle-orm/pg-core";

export const feeds = pgTable(
  "feeds",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    xmlUrl: text("xml_url").notNull(),
    htmlUrl: text("html_url"),
    folder: text("folder"),
    lastFetchedAt: timestamp("last_fetched_at"),
    lastError: text("last_error"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    xmlUrlIdx: uniqueIndex("feeds_xml_url_idx").on(t.xmlUrl),
  }),
);

export const items = pgTable(
  "items",
  {
    id: serial("id").primaryKey(),
    feedId: integer("feed_id")
      .notNull()
      .references(() => feeds.id, { onDelete: "cascade" }),
    guid: text("guid").notNull(),
    title: text("title").notNull(),
    link: text("link"),
    author: text("author"),
    summary: text("summary"),
    publishedAt: timestamp("published_at"),
    read: boolean("read").notNull().default(false),
    starred: boolean("starred").notNull().default(false),
    lat: real("lat"),
    lon: real("lon"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    guidIdx: uniqueIndex("items_feed_guid_idx").on(t.feedId, t.guid),
    pubIdx: index("items_published_idx").on(t.publishedAt),
  }),
);

export const pastes = pgTable("pastes", {
  id: text("id").primaryKey(),
  format: text("format").notNull(),
  title: text("title").notNull(),
  contentType: text("content_type").notNull(),
  body: text("body").notNull(),
  remoteUrl: text("remote_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const shortlinks = pgTable(
  "shortlinks",
  {
    slug: text("slug").primaryKey(),
    target: text("target").notNull(),
    label: text("label"),
    kind: text("kind").notNull().default("url"),
    clicks: integer("clicks").notNull().default(0),
    lastVisitedAt: timestamp("last_visited_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    targetIdx: index("shortlinks_target_idx").on(t.target),
  }),
);

export type Feed = typeof feeds.$inferSelect;
export type Item = typeof items.$inferSelect;
export type Paste = typeof pastes.$inferSelect;
