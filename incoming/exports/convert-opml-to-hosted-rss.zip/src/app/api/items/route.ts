import { NextResponse } from "next/server";
import { db } from "@/db";
import { feeds, items } from "@/db/schema";
import { and, desc, eq, ilike, or, inArray, type SQL } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const feedId = url.searchParams.get("feedId");
  const folder = url.searchParams.get("folder");
  const filter = url.searchParams.get("filter") ?? "all";
  const q = url.searchParams.get("q")?.trim();
  const limit = Math.min(Number(url.searchParams.get("limit") ?? 60), 200);
  const offset = Number(url.searchParams.get("offset") ?? 0);

  const where: SQL[] = [];
  if (feedId) where.push(eq(items.feedId, Number(feedId)));
  if (folder) where.push(eq(feeds.folder, folder));
  if (filter === "unread") where.push(eq(items.read, false));
  if (filter === "starred") where.push(eq(items.starred, true));
  if (q) {
    const cond = or(ilike(items.title, `%${q}%`), ilike(items.summary, `%${q}%`));
    if (cond) where.push(cond);
  }

  const rows = await db
    .select({
      id: items.id,
      title: items.title,
      link: items.link,
      author: items.author,
      summary: items.summary,
      publishedAt: items.publishedAt,
      read: items.read,
      starred: items.starred,
      feedId: items.feedId,
      feedTitle: feeds.title,
      folder: feeds.folder,
      lat: items.lat,
      lon: items.lon,
    })
    .from(items)
    .innerJoin(feeds, eq(feeds.id, items.feedId))
    .where(where.length ? and(...where) : undefined)
    .orderBy(desc(items.publishedAt))
    .limit(limit)
    .offset(offset);

  return NextResponse.json({ items: rows });
}

export async function PATCH(req: Request) {
  const body = (await req.json()) as {
    ids?: number[];
    read?: boolean;
    starred?: boolean;
  };
  if (!body.ids?.length) return NextResponse.json({ error: "ids required" }, { status: 400 });
  const set: { read?: boolean; starred?: boolean } = {};
  if (typeof body.read === "boolean") set.read = body.read;
  if (typeof body.starred === "boolean") set.starred = body.starred;
  if (Object.keys(set).length === 0)
    return NextResponse.json({ error: "nothing to update" }, { status: 400 });
  await db.update(items).set(set).where(inArray(items.id, body.ids));
  return NextResponse.json({ ok: true });
}
