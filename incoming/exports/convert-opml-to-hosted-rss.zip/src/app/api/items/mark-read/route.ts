import { NextResponse } from "next/server";
import { db } from "@/db";
import { feeds, items } from "@/db/schema";
import { and, eq, inArray, type SQL } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    feedId?: number;
    folder?: string;
  };
  const where: SQL[] = [eq(items.read, false)];
  if (body.feedId) where.push(eq(items.feedId, body.feedId));
  if (body.folder) {
    const ids = await db
      .select({ id: feeds.id })
      .from(feeds)
      .where(eq(feeds.folder, body.folder));
    if (ids.length === 0) return NextResponse.json({ ok: true });
    where.push(
      inArray(
        items.feedId,
        ids.map((r) => r.id),
      ),
    );
  }
  await db
    .update(items)
    .set({ read: true })
    .where(and(...where));
  return NextResponse.json({ ok: true });
}
