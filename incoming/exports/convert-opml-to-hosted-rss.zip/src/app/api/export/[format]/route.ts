import { NextResponse } from "next/server";
import { isFormat, renderExport } from "@/lib/export-service";
import { requestOrigin } from "@/lib/origin";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ format: string }> }) {
  const { format } = await ctx.params;
  if (!isFormat(format)) {
    return NextResponse.json({ error: `Unknown format "${format}"` }, { status: 404 });
  }
  const url = new URL(req.url);
  const origin = requestOrigin(req);
  const { body, contentType, filename } = await renderExport(format, origin);

  const headers: Record<string, string> = { "content-type": contentType };
  if (url.searchParams.get("download") === "1") {
    headers["content-disposition"] = `attachment; filename="${filename}"`;
  }
  return new NextResponse(body, { headers });
}
