import { NextResponse } from "next/server";
import { db } from "@/db";
import { shortlinks } from "@/db/schema";
import { desc } from "drizzle-orm";
import { createShortlink } from "@/lib/shortener";
import { requestOrigin } from "@/lib/origin";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const origin = requestOrigin(req);
  const rows = await db
    .select()
    .from(shortlinks)
    .orderBy(desc(shortlinks.createdAt))
    .limit(100);

  return NextResponse.json({
    shortlinks: rows.map((r) => ({
      slug: r.slug,
      target: r.target,
      label: r.label,
      kind: r.kind,
      clicks: r.clicks,
      lastVisitedAt: r.lastVisitedAt,
      createdAt: r.createdAt,
      shortUrl: `${origin}/s/${r.slug}`,
      qrUrl: `${origin}/qr/${r.slug}`,
    })),
  });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    target?: string;
    slug?: string;
    label?: string;
    kind?: string;
    reuse?: boolean;
  };
  if (!body.target) return NextResponse.json({ error: "target required" }, { status: 400 });

  const result = await createShortlink({
    target: body.target,
    slug: body.slug ?? null,
    label: body.label ?? null,
    kind: body.kind ?? "url",
    reuse: body.reuse,
  });
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: 400 });

  const origin = requestOrigin(req);
  return NextResponse.json({
    slug: result.slug,
    created: result.created,
    shortUrl: `${origin}/s/${result.slug}`,
    qrUrl: `${origin}/qr/${result.slug}`,
  });
}
