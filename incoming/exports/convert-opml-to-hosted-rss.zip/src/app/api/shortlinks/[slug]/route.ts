import { NextResponse } from "next/server";
import { db } from "@/db";
import { shortlinks } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function DELETE(_req: Request, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  await db.delete(shortlinks).where(eq(shortlinks.slug, slug));
  return NextResponse.json({ ok: true });
}
