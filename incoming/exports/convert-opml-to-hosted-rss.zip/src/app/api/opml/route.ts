import { NextResponse } from "next/server";
import { db } from "@/db";
import { feeds } from "@/db/schema";
import { parseOpml, buildOpml } from "@/lib/opml";
import { DEFAULT_OPML } from "@/lib/default-opml";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(feeds).orderBy(feeds.title);
  const xml = buildOpml(rows);
  return new NextResponse(xml, {
    headers: {
      "content-type": "text/x-opml; charset=utf-8",
      "content-disposition": 'attachment; filename="subscriptions.opml"',
    },
  });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    opml?: string;
    useDefault?: boolean;
  };
  const xml = body.useDefault ? DEFAULT_OPML : body.opml;
  if (!xml?.trim()) return NextResponse.json({ error: "opml required" }, { status: 400 });

  let parsed;
  try {
    parsed = parseOpml(xml);
  } catch {
    return NextResponse.json({ error: "Invalid OPML" }, { status: 400 });
  }
  if (parsed.length === 0)
    return NextResponse.json({ error: "No feeds found in OPML" }, { status: 400 });

  const inserted = await db
    .insert(feeds)
    .values(parsed)
    .onConflictDoNothing({ target: feeds.xmlUrl })
    .returning({ id: feeds.id });

  return NextResponse.json({ found: parsed.length, imported: inserted.length });
}
