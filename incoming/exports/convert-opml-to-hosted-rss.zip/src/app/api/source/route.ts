import { NextResponse } from "next/server";
import { collectSource, renderSourceText } from "@/lib/selfsource";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const format = url.searchParams.get("format") ?? "txt";
  const files = await collectSource();

  if (format === "json") {
    return NextResponse.json({
      files: files.length,
      bytes: files.reduce((s, f) => s + f.content.length, 0),
      source: files,
    });
  }

  const body = renderSourceText(files);
  return new NextResponse(body, {
    headers: {
      "content-type": "text/plain; charset=utf-8",
      "content-disposition": 'attachment; filename="pulse-reader-quine.txt"',
    },
  });
}
