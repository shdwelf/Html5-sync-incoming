import { NextResponse } from "next/server";
import { db } from "@/db";
import { pastes } from "@/db/schema";
import { desc } from "drizzle-orm";
import { FORMATS } from "@/lib/exporters";
import { isFormat, renderExport } from "@/lib/export-service";
import { requestOrigin } from "@/lib/origin";
import { createShortlink } from "@/lib/shortener";

export const dynamic = "force-dynamic";

const PASTE_FORMAT: Record<string, string> = {
  opml: "xml",
  rss: "xml",
  atom: "xml",
  xml: "xml",
  xdc: "xml",
  json: "json",
};

function id(): string {
  const alphabet = "abcdefghijkmnpqrstuvwxyz23456789";
  let s = "";
  const bytes = crypto.getRandomValues(new Uint8Array(10));
  for (const b of bytes) s += alphabet[b % alphabet.length];
  return s;
}

async function publishToPastebin(
  title: string,
  body: string,
  format: string,
): Promise<string | null> {
  const key = process.env.PASTEBIN_API_KEY;
  if (!key) return null;
  try {
    const res = await fetch("https://pastebin.com/api/api_post.php", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        api_dev_key: key,
        api_option: "paste",
        api_paste_code: body,
        api_paste_name: title,
        api_paste_format: PASTE_FORMAT[format] ?? "xml",
        api_paste_private: "1",
        api_paste_expire_date: "1M",
      }),
      signal: AbortSignal.timeout(15000),
    });
    const text = (await res.text()).trim();
    if (!res.ok || !text.startsWith("http")) return null;
    // convert to a raw URL so feed readers can import it directly
    return text.replace("pastebin.com/", "pastebin.com/raw/");
  } catch {
    return null;
  }
}

export async function GET() {
  const rows = await db
    .select({
      id: pastes.id,
      format: pastes.format,
      title: pastes.title,
      remoteUrl: pastes.remoteUrl,
      createdAt: pastes.createdAt,
      bytes: pastes.body,
    })
    .from(pastes)
    .orderBy(desc(pastes.createdAt))
    .limit(20);

  return NextResponse.json({
    pastes: rows.map((r) => ({
      id: r.id,
      format: r.format,
      title: r.title,
      remoteUrl: r.remoteUrl,
      createdAt: r.createdAt,
      size: r.bytes.length,
    })),
  });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { format?: string };
  const format = body.format ?? "opml";
  if (!isFormat(format)) return NextResponse.json({ error: "bad format" }, { status: 400 });

  const origin = requestOrigin(req);
  const rendered = await renderExport(format, origin);
  const pasteId = id();
  const title = `Pulse Reader ${format.toUpperCase()} — ${new Date().toISOString().slice(0, 10)}`;
  const remoteUrl = await publishToPastebin(title, rendered.body, format);

  await db.insert(pastes).values({
    id: pasteId,
    format,
    title,
    contentType: FORMATS[format].contentType,
    body: rendered.body,
    remoteUrl,
  });

  // mint short aliases for both the local paste and (if present) the pastebin.com mirror
  const localShort = await createShortlink({
    target: `/p/${pasteId}`,
    kind: "paste",
    label: title,
  });
  const remoteShort = remoteUrl
    ? await createShortlink({ target: remoteUrl, kind: "pastebin", label: title })
    : null;

  return NextResponse.json({
    id: pasteId,
    title,
    format,
    size: rendered.body.length,
    rawUrl: `${origin}/p/${pasteId}`,
    remoteUrl,
    hosted: remoteUrl ? "pastebin.com" : "self-hosted",
    shortUrl: "slug" in localShort ? `${origin}/s/${localShort.slug}` : null,
    remoteShortUrl:
      remoteShort && "slug" in remoteShort ? `${origin}/s/${remoteShort.slug}` : null,
    qrUrl: "slug" in localShort ? `${origin}/qr/${localShort.slug}` : null,
    note: remoteUrl
      ? "Published to pastebin.com (raw URL is importable in any reader)."
      : "Set PASTEBIN_API_KEY to mirror to pastebin.com. This raw URL is public and importable right now.",
  });
}
