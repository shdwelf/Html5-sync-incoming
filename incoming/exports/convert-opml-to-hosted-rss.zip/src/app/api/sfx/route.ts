import { NextResponse } from "next/server";
import { collectSource, renderSfxInstaller } from "@/lib/selfsource";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const files = await collectSource();
  const script = renderSfxInstaller(files);
  return new NextResponse(script, {
    headers: {
      "content-type": "application/x-shellscript; charset=utf-8",
      "content-disposition": 'attachment; filename="pulse-reader-sfx.sh"',
    },
  });
}
