import { NextResponse } from "next/server";
import { refreshFeeds } from "@/lib/sync";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST() {
  const result = await refreshFeeds();
  return NextResponse.json(result);
}
