import { NextResponse } from "next/server";
import { db } from "@/db";
import { feeds } from "@/db/schema";
import { eq } from "drizzle-orm";
import { refreshFeeds } from "@/lib/sync";

export const dynamic = "force-dynamic";

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(feeds).where(eq(feeds.id, Number(id)));
  return NextResponse.json({ ok: true });
}

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const result = await refreshFeeds([Number(id)]);
  return NextResponse.json(result);
}
