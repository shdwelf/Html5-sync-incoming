import { NextResponse } from "next/server";
import { db } from "@/db";
import { feeds, items } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { fetchFeed } from "@/lib/rss";
import { saveItems } from "@/lib/sync";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select({
      id: feeds.id,
      title: feeds.title,
      xmlUrl: feeds.xmlUrl,
      htmlUrl: feeds.htmlUrl,
      folder: feeds.folder,
      lastFetchedAt: feeds.lastFetchedAt,
      lastError: feeds.lastError,
      unread: sql<number>`count(${items.id}) filter (where ${items.read} = false)`.mapWith(
        Number,
      ),
      total: sql<number>`count(${items.id})`.mapWith(Number),
    })
    .from(feeds)
    .leftJoin(items, eq(items.feedId, feeds.id))
    .groupBy(feeds.id)
    .orderBy(feeds.title);

  return NextResponse.json({ feeds: rows });
}

export async function POST(req: Request) {
  const body = (await req.json()) as { xmlUrl?: string; folder?: string | null };
  let xmlUrl = body.xmlUrl?.trim();
  if (!xmlUrl) return NextResponse.json({ error: "xmlUrl required" }, { status: 400 });
  if (!/^https?:\/\//i.test(xmlUrl)) xmlUrl = `https://${xmlUrl}`;
  xmlUrl = xmlUrl.replace(/\/+$/, "");

  const existing = await db.select().from(feeds).where(eq(feeds.xmlUrl, xmlUrl)).limit(1);

  let title = xmlUrl;
  try {
    const parsed = await fetchFeed(xmlUrl);
    if (parsed.title) title = parsed.title;
    const [feed] = await db
      .insert(feeds)
      .values({ title, xmlUrl, folder: body.folder || null })
      .onConflictDoUpdate({
        target: feeds.xmlUrl,
        set: { title, lastFetchedAt: new Date(), lastError: null },
      })
      .returning();
    const newItems = await saveItems(feed.id, parsed.items);
    return NextResponse.json({
      feed,
      newItems,
      alreadyExisted: existing.length > 0,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Failed to fetch feed" },
      { status: 400 },
    );
  }
}
