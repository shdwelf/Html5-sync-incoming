"use client";

import { useEffect, useRef } from "react";
import Globe from "react-globe.gl";
import type { ItemRow } from "./types";

export default function GlobeView({ items }: { items: ItemRow[] }) {
  const globeRef = useRef<any>(null);

  useEffect(() => {
    if (globeRef.current) {
      globeRef.current.controls().autoRotate = true;
      globeRef.current.controls().autoRotateSpeed = 1.0;
    }
  }, []);

  const data = items
    .filter((it) => it.lat !== null && it.lon !== null)
    .map((it) => ({
      lat: it.lat,
      lng: it.lon,
      size: 0.2,
      color: "orange",
      title: it.title,
    }));

  return (
    <div style={{ width: "100%", height: "100vh" }}>
      <Globe
        ref={globeRef}
        globeImageUrl="//unpkg.com/three-globe/example/img/earth-dark.jpg"
        pointsData={data}
        pointAltitude="size"
        pointColor="color"
        pointLabel="title"
        backgroundColor="rgba(0,0,0,0)"
      />
    </div>
  );
}
