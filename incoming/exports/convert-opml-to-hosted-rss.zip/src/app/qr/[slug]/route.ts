import { NextResponse } from "next/server";
import { db } from "@/db";
import { shortlinks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { encodeQrToSvg } from "@/lib/qr";
import { requestOrigin } from "@/lib/origin";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const [row] = await db.select().from(shortlinks).where(eq(shortlinks.slug, slug)).limit(1);
  if (!row) return new NextResponse("Not found", { status: 404 });

  // encode the short URL itself so scans hit our redirector (and click tracking)
  const origin = requestOrigin(req);
  const shortUrl = `${origin}/s/${row.slug}`;
  const svg = encodeQrToSvg(shortUrl, { scale: 8, margin: 2 });

  return new NextResponse(svg, {
    headers: {
      "content-type": "image/svg+xml; charset=utf-8",
      "cache-control": "public, max-age=3600",
    },
  });
}
