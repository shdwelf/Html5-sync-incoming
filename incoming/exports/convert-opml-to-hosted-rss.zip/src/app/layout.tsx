import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pulse Reader — RSS / OPML / XDC",
  description: "Self-hosting RSS reader with OPML, RSS, Atom, XML, XDC export and SFX installer.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="alternate" type="application/rss+xml" title="Pulse Reader river" href="/api/export/rss" />
        <link rel="alternate" type="application/atom+xml" title="Pulse Reader Atom" href="/api/export/atom" />
      </head>
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
