import { NextResponse } from "next/server";
import { db } from "@/db";
import { shortlinks } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const [row] = await db.select().from(shortlinks).where(eq(shortlinks.slug, slug)).limit(1);
  if (!row) return new NextResponse("Short link not found", { status: 404 });

  // async click tracking — never blocks the redirect on failure
  void db
    .update(shortlinks)
    .set({ clicks: sql`${shortlinks.clicks} + 1`, lastVisitedAt: new Date() })
    .where(eq(shortlinks.slug, slug))
    .catch(() => {});

  const preview = new URL(req.url).searchParams.get("preview") === "1";
  if (preview) {
    return NextResponse.json({ slug: row.slug, target: row.target, clicks: row.clicks + 1 });
  }

  const target = row.target.startsWith("/")
    ? new URL(row.target, req.url).toString()
    : row.target;
  return NextResponse.redirect(target, 302);
}
