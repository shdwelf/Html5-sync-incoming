"use client";

import { useCallback, useEffect, useState } from "react";

const FORMATS = [
  { id: "opml", label: "OPML", hint: "Subscription list for any RSS reader" },
  { id: "rss", label: "RSS 2.0", hint: "Merged river of every article" },
  { id: "atom", label: "Atom", hint: "Same river, Atom flavoured" },
  { id: "xml", label: "XML", hint: "Full catalog: feeds + articles" },
  { id: "xdc", label: "XDC", hint: "Exchange data catalog w/ checksums" },
  { id: "json", label: "JSON Feed", hint: "JSON Feed 1.1" },
] as const;

type FormatId = (typeof FORMATS)[number]["id"];

type PublishResult = {
  id: string;
  rawUrl: string;
  remoteUrl: string | null;
  shortUrl: string | null;
  remoteShortUrl: string | null;
  qrUrl: string | null;
  hosted: string;
  size: number;
  note: string;
  format: string;
};

type Shortlink = {
  slug: string;
  target: string;
  label: string | null;
  kind: string;
  clicks: number;
  lastVisitedAt: string | null;
  createdAt: string;
  shortUrl: string;
  qrUrl: string;
};

type Tab = "export" | "publish" | "shortlinks" | "quine";

export default function Studio({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>("export");
  const [format, setFormat] = useState<FormatId>("opml");
  const [preview, setPreview] = useState("");
  const [loading, setLoading] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [result, setResult] = useState<PublishResult | null>(null);
  const [shortlinks, setShortlinks] = useState<Shortlink[]>([]);
  const [copied, setCopied] = useState<string | null>(null);

  // shortener form
  const [target, setTarget] = useState("");
  const [customSlug, setCustomSlug] = useState("");
  const [label, setLabel] = useState("");
  const [minting, setMinting] = useState(false);
  const [mintError, setMintError] = useState<string | null>(null);

  // export shortlink
  const [exportShort, setExportShort] = useState<string | null>(null);
  const [exportShorting, setExportShorting] = useState(false);
  const [qrOpen, setQrOpen] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setExportShort(null);
    fetch(`/api/export/${format}`)
      .then((r) => r.text())
      .then((t) => {
        if (!cancelled) {
          setPreview(t.length > 4000 ? `${t.slice(0, 4000)}\n… truncated preview …` : t);
          setLoading(false);
        }
      })
      .catch(() => setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [format]);

  const loadShortlinks = useCallback(async () => {
    const r = await fetch("/api/shortlinks");
    const j = (await r.json()) as { shortlinks: Shortlink[] };
    setShortlinks(j.shortlinks);
  }, []);

  useEffect(() => {
    void loadShortlinks();
  }, [loadShortlinks]);

  async function copy(text: string, key: string) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      /* ignore */
    }
    setCopied(key);
    setTimeout(() => setCopied(null), 1600);
  }

  async function publish() {
    setPublishing(true);
    const r = await fetch("/api/paste", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ format }),
    });
    const j = (await r.json()) as PublishResult;
    setResult(j);
    setPublishing(false);
    void loadShortlinks();
    setTab("publish");
  }

  async function shortenExport() {
    setExportShorting(true);
    const r = await fetch("/api/shortlinks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        target: `${window.location.origin}/api/export/${format}`,
        kind: "export",
        label: `${format.toUpperCase()} export`,
      }),
    });
    const j = (await r.json()) as { shortUrl?: string; error?: string };
    setExportShorting(false);
    if (j.shortUrl) {
      setExportShort(j.shortUrl);
      void loadShortlinks();
    }
  }

  async function mint() {
    if (!target.trim()) return;
    setMinting(true);
    setMintError(null);
    const r = await fetch("/api/shortlinks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        target,
        slug: customSlug.trim() || undefined,
        label: label.trim() || undefined,
        kind: "url",
      }),
    });
    const j = (await r.json()) as { shortUrl?: string; error?: string };
    setMinting(false);
    if (j.error) return setMintError(j.error);
    setTarget("");
    setCustomSlug("");
    setLabel("");
    await loadShortlinks();
  }

  async function removeShortlink(slug: string) {
    await fetch(`/api/shortlinks/${slug}`, { method: "DELETE" });
    await loadShortlinks();
  }

  const btn =
    "rounded-md border border-white/15 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-white/10 transition disabled:opacity-50";
  const btnPrimary =
    "rounded-md bg-orange-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-orange-400 transition disabled:opacity-50";

  const TabBtn = ({ id, children }: { id: Tab; children: React.ReactNode }) => (
    <button
      onClick={() => setTab(id)}
      className={`rounded-md px-3 py-1.5 text-xs font-medium transition ${
        tab === id
          ? "bg-orange-500 text-white"
          : "border border-white/10 text-slate-300 hover:bg-white/5"
      }`}
    >
      {children}
    </button>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm">
      <div className="my-6 w-full max-w-3xl rounded-2xl border border-white/10 bg-slate-900 shadow-2xl">
        <header className="flex items-center gap-3 border-b border-white/10 px-5 py-3">
          <span className="text-lg">🛰️</span>
          <h2 className="mr-auto text-sm font-semibold">Studio</h2>
          <button onClick={onClose} className={btn}>
            Close ✕
          </button>
        </header>

        <nav className="flex flex-wrap gap-2 border-b border-white/10 px-5 py-2.5">
          <TabBtn id="export">Export</TabBtn>
          <TabBtn id="publish">Publish</TabBtn>
          <TabBtn id="shortlinks">Short links · {shortlinks.length}</TabBtn>
          <TabBtn id="quine">Self-replicate</TabBtn>
        </nav>

        <div className="space-y-5 p-5">
          {tab === "export" && (
            <>
              <section>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Choose a format
                </h3>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {FORMATS.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setFormat(f.id)}
                      className={`rounded-lg border p-2.5 text-left transition ${
                        format === f.id
                          ? "border-orange-500 bg-orange-500/10"
                          : "border-white/10 hover:border-white/25 hover:bg-white/5"
                      }`}
                    >
                      <div className="text-sm font-semibold">{f.label}</div>
                      <div className="text-[11px] leading-tight text-slate-400">{f.hint}</div>
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Preview
                </h3>
                <pre className="max-h-52 overflow-auto rounded-lg border border-white/10 bg-black/40 p-3 text-[11px] leading-relaxed text-slate-300">
                  {loading ? "Rendering…" : preview}
                </pre>
                <div className="mt-2 flex flex-wrap gap-2">
                  <a className={btnPrimary} href={`/api/export/${format}?download=1`}>
                    ⬇ Download .{format}
                  </a>
                  <a
                    className={btn}
                    href={`/api/export/${format}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open raw ↗
                  </a>
                  <button
                    className={btn}
                    onClick={() => void shortenExport()}
                    disabled={exportShorting}
                  >
                    🔗 {exportShorting ? "Shortening…" : `Shorten /api/export/${format}`}
                  </button>
                  <button className={btn} onClick={() => void copy(preview, "preview")}>
                    {copied === "preview" ? "Copied ✓" : "Copy body"}
                  </button>
                </div>
                {exportShort && (
                  <div className="mt-2 flex items-center gap-2 rounded-lg border border-orange-500/30 bg-orange-500/5 p-2 text-xs">
                    <input
                      readOnly
                      value={exportShort}
                      className="min-w-0 flex-1 rounded border border-white/10 bg-black/40 px-2 py-1 font-mono text-[11px]"
                    />
                    <button className={btn} onClick={() => void copy(exportShort, "exp")}>
                      {copied === "exp" ? "Copied ✓" : "Copy"}
                    </button>
                    <a className={btn} href={exportShort} target="_blank" rel="noreferrer">
                      Open ↗
                    </a>
                  </div>
                )}
              </section>
            </>
          )}

          {tab === "publish" && (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Publish a shareable paste
              </h3>
              <p className="mb-2 text-[11px] text-slate-400">
                Creates an immutable raw URL any reader can import — plus a short link and QR
                automatically. Mirrors to <b>pastebin.com</b> when{" "}
                <code className="text-orange-300">PASTEBIN_API_KEY</code> is set.
              </p>
              <div className="flex flex-wrap gap-2">
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value as FormatId)}
                  className="rounded-md border border-white/15 bg-slate-950 px-2 py-1.5 text-xs"
                >
                  {FORMATS.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                    </option>
                  ))}
                </select>
                <button className={btnPrimary} onClick={() => void publish()} disabled={publishing}>
                  {publishing ? "Publishing…" : `📋 Publish ${format.toUpperCase()}`}
                </button>
              </div>

              {result && (
                <div className="mt-3 space-y-3 rounded-lg border border-orange-500/30 bg-orange-500/5 p-3 text-xs">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] uppercase">
                      {result.hosted}
                    </span>
                    <span className="text-slate-400">{result.size} bytes</span>
                  </div>

                  {[
                    { label: "Short URL", url: result.shortUrl, key: "s1" },
                    { label: "Raw", url: result.rawUrl, key: "s2" },
                    { label: "Pastebin", url: result.remoteUrl, key: "s3" },
                    { label: "Pastebin short", url: result.remoteShortUrl, key: "s4" },
                  ]
                    .filter((r) => r.url)
                    .map((r) => (
                      <div key={r.key} className="flex items-center gap-2">
                        <span className="w-24 shrink-0 text-[10px] uppercase text-slate-400">
                          {r.label}
                        </span>
                        <input
                          readOnly
                          value={r.url!}
                          className="min-w-0 flex-1 rounded border border-white/10 bg-black/40 px-2 py-1 font-mono text-[11px]"
                        />
                        <button className={btn} onClick={() => void copy(r.url!, r.key)}>
                          {copied === r.key ? "✓" : "Copy"}
                        </button>
                        <a className={btn} href={r.url!} target="_blank" rel="noreferrer">
                          ↗
                        </a>
                      </div>
                    ))}

                  {result.qrUrl && (
                    <div className="flex items-start gap-3 pt-1">
                      <img
                        src={result.qrUrl}
                        alt="QR code"
                        width={110}
                        height={110}
                        className="rounded bg-white p-1"
                      />
                      <div className="text-[11px] text-slate-400">
                        <div className="mb-1 font-semibold text-slate-200">Scan to import</div>
                        <div>Points at the short URL → paste → your reader.</div>
                        <a
                          className="mt-1 inline-block underline hover:text-orange-300"
                          href={result.qrUrl}
                          download={`${result.id}.svg`}
                        >
                          Download SVG
                        </a>
                      </div>
                    </div>
                  )}
                  <p className="text-[11px] text-slate-400">{result.note}</p>
                </div>
              )}
            </section>
          )}

          {tab === "shortlinks" && (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Shorten any URL
              </h3>
              <div className="space-y-2 rounded-lg border border-white/10 bg-black/20 p-3">
                <input
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                  placeholder="https://long.example.com/path?with=params"
                  className="w-full rounded border border-white/10 bg-slate-950 px-2 py-1.5 text-xs outline-none focus:border-orange-500"
                />
                <div className="flex flex-wrap gap-2">
                  <input
                    value={customSlug}
                    onChange={(e) => setCustomSlug(e.target.value)}
                    placeholder="custom-slug (optional)"
                    className="min-w-0 flex-1 rounded border border-white/10 bg-slate-950 px-2 py-1.5 text-xs outline-none focus:border-orange-500"
                  />
                  <input
                    value={label}
                    onChange={(e) => setLabel(e.target.value)}
                    placeholder="label (optional)"
                    className="min-w-0 flex-1 rounded border border-white/10 bg-slate-950 px-2 py-1.5 text-xs outline-none focus:border-orange-500"
                  />
                  <button className={btnPrimary} onClick={() => void mint()} disabled={minting}>
                    {minting ? "…" : "Shorten"}
                  </button>
                </div>
                {mintError && <div className="text-[11px] text-red-400">{mintError}</div>}
              </div>

              <h3 className="mt-4 mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Existing short links
              </h3>
              {shortlinks.length === 0 ? (
                <p className="text-[11px] text-slate-400">
                  None yet. Publish a paste or shorten an export above.
                </p>
              ) : (
                <ul className="divide-y divide-white/5 rounded-lg border border-white/10">
                  {shortlinks.map((s) => (
                    <li key={s.slug} className="px-3 py-2 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] uppercase">
                          {s.kind}
                        </span>
                        <a
                          href={s.shortUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="font-mono text-orange-300 hover:underline"
                        >
                          /s/{s.slug}
                        </a>
                        <span className="text-slate-500">· {s.clicks} clicks</span>
                        <button
                          className="ml-auto text-[11px] text-slate-400 hover:text-orange-300"
                          onClick={() => void copy(s.shortUrl, `sl-${s.slug}`)}
                        >
                          {copied === `sl-${s.slug}` ? "Copied ✓" : "Copy"}
                        </button>
                        <button
                          className="text-[11px] text-slate-400 hover:text-orange-300"
                          onClick={() => setQrOpen(qrOpen === s.slug ? null : s.slug)}
                        >
                          QR
                        </button>
                        <button
                          className="text-[11px] text-slate-500 hover:text-red-400"
                          onClick={() => void removeShortlink(s.slug)}
                        >
                          ✕
                        </button>
                      </div>
                      <div className="mt-1 truncate text-[11px] text-slate-500" title={s.target}>
                        → {s.target}
                      </div>
                      {qrOpen === s.slug && (
                        <div className="mt-2 flex items-center gap-3">
                          <img
                            src={s.qrUrl}
                            alt=""
                            width={110}
                            height={110}
                            className="rounded bg-white p-1"
                          />
                          <a
                            href={s.qrUrl}
                            download={`${s.slug}.svg`}
                            className="text-[11px] underline hover:text-orange-300"
                          >
                            Download QR
                          </a>
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          )}

          {tab === "quine" && (
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Self-replication
              </h3>
              <div className="grid gap-2 sm:grid-cols-2">
                <a
                  href="/api/source?format=txt"
                  className="rounded-lg border border-white/10 p-3 transition hover:border-orange-500/60 hover:bg-white/5"
                >
                  <div className="text-sm font-semibold">🧬 Download self (quine)</div>
                  <p className="mt-0.5 text-[11px] text-slate-400">
                    One text file containing every source file of this running app.
                  </p>
                </a>
                <a
                  href="/api/sfx"
                  className="rounded-lg border border-white/10 p-3 transition hover:border-orange-500/60 hover:bg-white/5"
                >
                  <div className="text-sm font-semibold">📦 SFX installer (.sh)</div>
                  <p className="mt-0.5 text-[11px] text-slate-400">
                    <code>bash pulse-reader-sfx.sh app --install</code>
                  </p>
                </a>
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
