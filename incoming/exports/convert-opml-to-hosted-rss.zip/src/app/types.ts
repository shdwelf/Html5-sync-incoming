export type FeedRow = {
  id: number;
  title: string;
  xmlUrl: string;
  htmlUrl: string | null;
  folder: string | null;
  lastFetchedAt: string | null;
  lastError: string | null;
  unread: number;
  total: number;
};

export type ItemRow = {
  id: number;
  title: string;
  link: string | null;
  author: string | null;
  summary: string | null;
  publishedAt: string | null;
  read: boolean;
  starred: boolean;
  feedId: number;
  feedTitle: string;
  folder: string | null;
  lat: number | null;
  lon: number | null;
};
