import { NextResponse } from "next/server";
import { db } from "@/db";
import { pastes } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [row] = await db.select().from(pastes).where(eq(pastes.id, id)).limit(1);
  if (!row) return new NextResponse("Paste not found", { status: 404 });

  const download = new URL(req.url).searchParams.get("download") === "1";
  const headers: Record<string, string> = {
    "content-type": row.contentType,
    "cache-control": "public, max-age=60",
    "access-control-allow-origin": "*",
  };
  if (download) headers["content-disposition"] = `attachment; filename="${row.id}.${row.format}"`;
  return new NextResponse(row.body, { headers });
}
