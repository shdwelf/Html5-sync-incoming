"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { FeedRow, ItemRow } from "./types";
import Studio from "./studio";
import dynamic from "next/dynamic";
const GlobeView = dynamic(() => import("./globe"), { ssr: false });

type Selection =
  | { kind: "all" }
  | { kind: "starred" }
  | { kind: "folder"; folder: string }
  | { kind: "feed"; feedId: number; title: string };

function timeAgo(iso: string | null) {
  if (!iso) return "";
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.round(diff / 60000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h`;
  const days = Math.round(h / 24);
  if (days < 30) return `${days}d`;
  return new Date(iso).toLocaleDateString();
}

export default function Reader() {
  const [feeds, setFeeds] = useState<FeedRow[]>([]);
  const [items, setItems] = useState<ItemRow[]>([]);
  const [selection, setSelection] = useState<Selection>({ kind: "all" });
  const [filter, setFilter] = useState<"all" | "unread" | "starred">("all");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [cursor, setCursor] = useState(0);
  const [showAdd, setShowAdd] = useState(false);
  const [showStudio, setShowStudio] = useState(false);
  const [newUrl, setNewUrl] = useState("");
  const [opmlText, setOpmlText] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [pinned, setPinned] = useState(true);
  const searchRef = useRef<HTMLInputElement>(null);

  const [pipWindow, setPipWindow] = useState<Window | null>(null);

  const flash = (m: string) => {
    setToast(m);
    setTimeout(() => setToast(null), 3500);
  };

  const loadFeeds = useCallback(async () => {
    const r = await fetch("/api/feeds");
    const j = (await r.json()) as { feeds: FeedRow[] };
    setFeeds(j.feeds);
  }, []);

  const loadItems = useCallback(async () => {
    setLoading(true);
    const p = new URLSearchParams();
    if (selection.kind === "feed") p.set("feedId", String(selection.feedId));
    if (selection.kind === "folder") p.set("folder", selection.folder);
    const eff = selection.kind === "starred" ? "starred" : filter;
    if (eff !== "all") p.set("filter", eff);
    if (q.trim()) p.set("q", q.trim());
    const r = await fetch(`/api/items?${p.toString()}`);
    const j = (await r.json()) as { items: ItemRow[] };
    setItems(j.items);
    setCursor(0);
    setLoading(false);
  }, [selection, filter, q]);

  useEffect(() => {
    void loadFeeds();
  }, [loadFeeds]);

  useEffect(() => {
    const t = setTimeout(() => void loadItems(), 200);
    return () => clearTimeout(t);
  }, [loadItems]);

  const grouped = useMemo(() => {
    const root = feeds.filter((f) => !f.folder);
    const folders = new Map<string, FeedRow[]>();
    for (const f of feeds) {
      if (!f.folder) continue;
      const arr = folders.get(f.folder) ?? [];
      arr.push(f);
      folders.set(f.folder, arr);
    }
    return { root, folders: [...folders.entries()].sort((a, b) => a[0].localeCompare(b[0])) };
  }, [feeds]);

  const totalUnread = feeds.reduce((s, f) => s + f.unread, 0);

  const patchItems = useCallback(
    async (ids: number[], patch: { read?: boolean; starred?: boolean }) => {
      setItems((prev) => prev.map((i) => (ids.includes(i.id) ? { ...i, ...patch } : i)));
      await fetch("/api/items", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ids, ...patch }),
      });
      void loadFeeds();
    },
    [loadFeeds],
  );

  const refreshAll = useCallback(async () => {
    setBusy("Refreshing all feeds…");
    const r = await fetch("/api/refresh", { method: "POST" });
    const j = (await r.json()) as { feeds: number; newItems: number; failed: number };
    setBusy(null);
    flash(`Refreshed ${j.feeds} feeds · ${j.newItems} new · ${j.failed} failed`);
    await Promise.all([loadFeeds(), loadItems()]);
  }, [loadFeeds, loadItems]);

  // keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") {
        if (e.key === "Escape") (e.target as HTMLElement).blur();
        return;
      }
      if (e.key === "/") {
        e.preventDefault();
        searchRef.current?.focus();
        return;
      }
      if (showStudio) return;
      const cur = items[cursor];
      if (e.key === "j" || e.key === "ArrowDown") {
        e.preventDefault();
        setCursor((c) => Math.min(c + 1, Math.max(items.length - 1, 0)));
      } else if (e.key === "k" || e.key === "ArrowUp") {
        e.preventDefault();
        setCursor((c) => Math.max(c - 1, 0));
      } else if (e.key === "Enter" && cur) {
        setOpen((o) => (o === cur.id ? null : cur.id));
        if (!cur.read) void patchItems([cur.id], { read: true });
      } else if (e.key === "o" && cur?.link) {
        window.open(cur.link, "_blank", "noreferrer");
      } else if (e.key === "m" && cur) {
        void patchItems([cur.id], { read: !cur.read });
      } else if (e.key === "s" && cur) {
        void patchItems([cur.id], { starred: !cur.starred });
      } else if (e.key === "r") {
        void refreshAll();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [items, cursor, patchItems, refreshAll, showStudio]);

  useEffect(() => {
    document.getElementById(`item-${items[cursor]?.id}`)?.scrollIntoView({
      block: "nearest",
      behavior: "smooth",
    });
  }, [cursor, items]);

  async function importOpml(useDefault: boolean) {
    setBusy(useDefault ? "Importing sample OPML…" : "Importing OPML…");
    const r = await fetch("/api/opml", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(useDefault ? { useDefault: true } : { opml: opmlText }),
    });
    const j = (await r.json()) as { imported?: number; found?: number; error?: string };
    setBusy(null);
    if (j.error) return flash(j.error);
    setOpmlText("");
    flash(`Imported ${j.imported} of ${j.found} feeds. Refreshing…`);
    await loadFeeds();
    await refreshAll();
  }

  async function addFeed() {
    if (!newUrl.trim()) return;
    setBusy("Adding feed…");
    const r = await fetch("/api/feeds", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ xmlUrl: newUrl.trim() }),
    });
    const j = (await r.json()) as {
      error?: string;
      newItems?: number;
      alreadyExisted?: boolean;
      feed?: FeedRow;
    };
    setBusy(null);
    if (j.error || !j.feed) return flash(j.error ?? "Could not add feed");
    setNewUrl("");
    flash(
      `${j.alreadyExisted ? "Already subscribed to" : "Subscribed to"} “${j.feed.title}” · ${
        j.newItems ?? 0
      } new items`,
    );
    select({ kind: "feed", feedId: j.feed.id, title: j.feed.title });
    setFilter("all");
    await loadFeeds();
  }

  async function removeFeed(id: number) {
    await fetch(`/api/feeds/${id}`, { method: "DELETE" });
    if (selection.kind === "feed" && selection.feedId === id) setSelection({ kind: "all" });
    await Promise.all([loadFeeds(), loadItems()]);
  }

  async function markAllRead() {
    const body: { feedId?: number; folder?: string } = {};
    if (selection.kind === "feed") body.feedId = selection.feedId;
    if (selection.kind === "folder") body.folder = selection.folder;
    await fetch("/api/items/mark-read", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    await Promise.all([loadFeeds(), loadItems()]);
  }

  function select(s: Selection) {
    setSelection(s);
    setDrawerOpen(false);
  }

  async function openGlobePip() {
    if (!("documentPictureInPicture" in window)) {
      return flash("Document Picture-in-Picture API not supported in this browser.");
    }
    try {
      const pip = await (window as any).documentPictureInPicture.requestWindow({
        width: 400,
        height: 400,
      });
      
      pip.document.body.style.margin = "0";
      pip.document.body.style.padding = "0";
      pip.document.body.style.overflow = "hidden";
      pip.document.body.style.backgroundColor = "#000";
      
      // We will render the globe into this window via React Portal
      setPipWindow(pip);
      
      pip.addEventListener("pagehide", () => {
        setPipWindow(null);
      });
    } catch (e) {
      flash("Failed to open PiP: " + e);
    }
  }

  const title =
    selection.kind === "all"
      ? "All articles"
      : selection.kind === "starred"
        ? "Starred"
        : selection.kind === "folder"
          ? selection.folder
          : selection.title;

  const NavBtn = ({
    active,
    onClick,
    children,
    count,
  }: {
    active: boolean;
    onClick: () => void;
    children: React.ReactNode;
    count?: number;
  }) => (
    <button
      onClick={onClick}
      className={`flex w-full items-center justify-between gap-2 rounded-md px-2.5 py-1.5 text-left text-sm transition ${
        active ? "bg-orange-500/15 text-orange-300" : "text-slate-300 hover:bg-white/5"
      }`}
    >
      <span className="truncate">{children}</span>
      {count ? (
        <span className="shrink-0 rounded-full bg-white/10 px-1.5 text-[11px] text-slate-300">
          {count}
        </span>
      ) : null}
    </button>
  );

  return (
    <div className="min-h-dvh bg-slate-950 text-slate-100">
      {/* mobile backdrop */}
      {drawerOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setDrawerOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 max-w-[85vw] flex-col border-r border-white/10 bg-slate-900 transition-transform duration-200 ease-out ${
          drawerOpen ? "translate-x-0" : "-translate-x-full"
        } ${pinned ? "lg:translate-x-0" : "lg:-translate-x-full"}`}
      >
        <div className="flex items-center gap-2 border-b border-white/10 px-3 py-3">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-orange-500 text-base">
            📡
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-semibold">Pulse Reader</div>
            <div className="text-[11px] text-slate-400">
              {feeds.length} feeds · {totalUnread} unread
            </div>
          </div>
          <button
            onClick={() => (window.innerWidth < 1024 ? setDrawerOpen(false) : setPinned(false))}
            className="rounded border border-white/15 px-1.5 py-0.5 text-xs text-slate-400 hover:bg-white/10"
            title="Hide sidebar"
          >
            «
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3">
          <div className="mb-3 space-y-1">
            <NavBtn
              active={selection.kind === "all"}
              onClick={() => select({ kind: "all" })}
              count={totalUnread}
            >
              📰 All articles
            </NavBtn>
            <NavBtn
              active={selection.kind === "starred"}
              onClick={() => select({ kind: "starred" })}
            >
              ⭐ Starred
            </NavBtn>
          </div>

          <div className="mb-2 grid grid-cols-2 gap-2">
            <button
              onClick={() => void refreshAll()}
              className="rounded-md bg-orange-500 px-2 py-1.5 text-xs font-medium text-white hover:bg-orange-400"
            >
              Refresh all
            </button>
            <button
              onClick={() => setShowAdd((v) => !v)}
              className="rounded-md border border-white/15 px-2 py-1.5 text-xs hover:bg-white/5"
            >
              + Feeds
            </button>
            <button
              onClick={() => void openGlobePip()}
              className="rounded-md border border-white/15 px-2 py-1.5 text-xs hover:bg-white/5"
            >
              🌎 Globe (PiP)
            </button>
            <button
              onClick={() => setShowStudio(true)}
              className="rounded-md border border-white/15 px-2 py-1.5 text-xs hover:bg-white/5"
            >
              🛰️ Studio
            </button>
          </div>

          {showAdd && (
            <div className="mb-3 space-y-2 rounded-lg border border-white/10 bg-black/20 p-2">
              <div className="flex gap-1">
                <input
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && void addFeed()}
                  placeholder="https://site.com/feed"
                  className="min-w-0 flex-1 rounded border border-white/10 bg-slate-950 px-2 py-1 text-xs outline-none focus:border-orange-500"
                />
                <button
                  onClick={() => void addFeed()}
                  className="rounded bg-white/10 px-2 text-xs hover:bg-white/20"
                >
                  Add
                </button>
              </div>
              <textarea
                value={opmlText}
                onChange={(e) => setOpmlText(e.target.value)}
                placeholder="Paste OPML XML here…"
                rows={4}
                className="w-full rounded border border-white/10 bg-slate-950 px-2 py-1 font-mono text-[11px] outline-none focus:border-orange-500"
              />
              <div className="flex flex-wrap gap-1">
                <button
                  onClick={() => void importOpml(false)}
                  className="rounded bg-white/10 px-2 py-1 text-xs hover:bg-white/20"
                >
                  Import OPML
                </button>
                <button
                  onClick={() => void importOpml(true)}
                  className="rounded bg-white/10 px-2 py-1 text-xs hover:bg-white/20"
                >
                  Load sample set
                </button>
              </div>
            </div>
          )}

          {grouped.folders.map(([folder, list]) => {
            const unread = list.reduce((s, f) => s + f.unread, 0);
            return (
              <div key={folder} className="mb-2">
                <NavBtn
                  active={selection.kind === "folder" && selection.folder === folder}
                  onClick={() => select({ kind: "folder", folder })}
                  count={unread}
                >
                  📁 {folder}
                </NavBtn>
                <div className="ml-3 border-l border-white/10 pl-1">
                  {list.map((f) => (
                    <FeedItem
                      key={f.id}
                      f={f}
                      active={selection.kind === "feed" && selection.feedId === f.id}
                      onSelect={() => select({ kind: "feed", feedId: f.id, title: f.title })}
                      onRemove={() => void removeFeed(f.id)}
                    />
                  ))}
                </div>
              </div>
            );
          })}

          <div className="mt-2">
            {grouped.root.map((f) => (
              <FeedItem
                key={f.id}
                f={f}
                active={selection.kind === "feed" && selection.feedId === f.id}
                onSelect={() => select({ kind: "feed", feedId: f.id, title: f.title })}
                onRemove={() => void removeFeed(f.id)}
              />
            ))}
          </div>

          {feeds.length === 0 && (
            <p className="px-2 py-6 text-xs text-slate-400">
              No subscriptions yet. Open <b>+ Feeds</b> → <b>Load sample set</b>.
            </p>
          )}
        </div>

        <div className="border-t border-white/10 px-3 py-2 text-[10px] text-slate-500">
          j/k move · Enter expand · o open · s star · m read · r refresh · / search
        </div>
      </aside>

      {/* Main column — padded so the sidebar never covers it */}
      <div className={`transition-[padding] duration-200 ${pinned ? "lg:pl-72" : "lg:pl-0"}`}>
        <header className="sticky top-0 z-20 border-b border-white/10 bg-slate-950/90 px-3 py-2.5 backdrop-blur sm:px-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setDrawerOpen(true)}
              className="rounded border border-white/15 px-2 py-1.5 text-xs hover:bg-white/10 lg:hidden"
              title="Open sidebar"
            >
              ☰
            </button>
            {!pinned && (
              <button
                onClick={() => setPinned(true)}
                className="hidden rounded border border-white/15 px-2 py-1.5 text-xs hover:bg-white/10 lg:block"
                title="Show sidebar"
              >
                » Feeds
              </button>
            )}
            <h1 className="mr-auto min-w-0 truncate text-base font-semibold sm:text-lg">{title}</h1>
            <input
              ref={searchRef}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search…  (/)"
              className="w-32 rounded-md border border-white/10 bg-slate-900 px-2 py-1.5 text-sm outline-none focus:border-orange-500 sm:w-56"
            />
            <div className="flex overflow-hidden rounded-md border border-white/10">
              {(["all", "unread", "starred"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-2.5 py-1.5 text-xs capitalize ${
                    filter === f ? "bg-orange-500 text-white" : "hover:bg-white/5"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
            <button
              onClick={() => void markAllRead()}
              className="rounded-md border border-white/15 px-2.5 py-1.5 text-xs hover:bg-white/5"
            >
              Mark all read
            </button>
          </div>
          {busy && <div className="mt-2 text-xs text-orange-300">{busy}</div>}
        </header>

        <main className="mx-auto max-w-4xl divide-y divide-white/5 pb-24">
          {loading && <div className="p-6 text-sm text-slate-400">Loading…</div>}
          {!loading && items.length === 0 && (
            <div className="p-10 text-center text-sm text-slate-400">
              Nothing here. Import feeds and hit <b>Refresh all</b>.
            </div>
          )}
          {items.map((it, idx) => (
            <article
              id={`item-${it.id}`}
              key={it.id}
              onMouseEnter={() => setCursor(idx)}
              className={`border-l-2 px-3 py-3 transition sm:px-4 ${
                idx === cursor ? "border-l-orange-500 bg-white/[0.04]" : "border-l-transparent"
              } ${it.read ? "opacity-60" : ""} hover:bg-white/[0.03]`}
            >
              <div className="flex items-start gap-3">
                <button
                  onClick={() => void patchItems([it.id], { starred: !it.starred })}
                  className="mt-0.5 text-lg leading-none"
                  title="Star (s)"
                >
                  {it.starred ? "⭐" : "☆"}
                </button>
                <div className="min-w-0 flex-1">
                  <button
                    className="block w-full text-left"
                    onClick={() => {
                      setCursor(idx);
                      setOpen(open === it.id ? null : it.id);
                      if (!it.read) void patchItems([it.id], { read: true });
                    }}
                  >
                    <h2
                      className={`text-[15px] leading-snug break-words ${
                        it.read ? "" : "font-semibold"
                      }`}
                    >
                      {it.title}
                    </h2>
                  </button>
                  <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-400">
                    <span className="text-orange-300">{it.feedTitle}</span>
                    {it.folder && <span>· {it.folder}</span>}
                    <span>· {timeAgo(it.publishedAt)}</span>
                    {it.author && <span className="truncate">· {it.author}</span>}
                    {it.link && (
                      <a
                        href={it.link}
                        target="_blank"
                        rel="noreferrer"
                        className="underline hover:text-orange-300"
                      >
                        open ↗
                      </a>
                    )}
                    <button
                      onClick={() => void patchItems([it.id], { read: !it.read })}
                      className="underline hover:text-orange-300"
                    >
                      mark {it.read ? "unread" : "read"}
                    </button>
                  </div>
                  {open === it.id && it.summary && (
                    <p className="mt-2 text-sm leading-relaxed text-slate-300">{it.summary}</p>
                  )}
                </div>
              </div>
            </article>
          ))}
        </main>
      </div>

      {showStudio && <Studio onClose={() => setShowStudio(false)} />}

      {pipWindow && createPortal(<GlobeView items={items} />, pipWindow.document.body)}

      {toast && (
        <div className="fixed bottom-4 left-1/2 z-50 max-w-[92vw] -translate-x-1/2 rounded-lg bg-orange-500 px-4 py-2 text-center text-sm text-white shadow-lg">
          {toast}
        </div>
      )}
    </div>
  );
}

function FeedItem({
  f,
  active,
  onSelect,
  onRemove,
}: {
  f: FeedRow;
  active: boolean;
  onSelect: () => void;
  onRemove: () => void;
}) {
  return (
    <div
      className={`group flex items-center gap-1 rounded-md pr-1 ${
        active ? "bg-orange-500/15" : "hover:bg-white/5"
      }`}
    >
      <button
        onClick={onSelect}
        className={`min-w-0 flex-1 truncate px-2.5 py-1.5 text-left text-[13px] ${
          active ? "text-orange-300" : "text-slate-300"
        }`}
        title={f.lastError ? `Error: ${f.lastError}` : f.xmlUrl}
      >
        {f.lastError ? "⚠️ " : ""}
        {f.title}
      </button>
      {f.unread > 0 && (
        <span className="shrink-0 rounded-full bg-white/10 px-1.5 text-[11px] text-slate-300">
          {f.unread}
        </span>
      )}
      <button
        onClick={onRemove}
        className="shrink-0 px-1 text-xs text-slate-500 opacity-0 transition group-hover:opacity-100 hover:text-red-400"
        title="Unsubscribe"
      >
        ✕
      </button>
    </div>
  );
}
