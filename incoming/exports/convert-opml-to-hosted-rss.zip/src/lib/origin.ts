/** Public-facing origin of a request, honouring reverse-proxy headers. */
export function requestOrigin(req: Request): string {
  const h = req.headers;
  const host = (h.get("x-forwarded-host") ?? h.get("host") ?? "").split(",")[0].trim();
  const proto = (h.get("x-forwarded-proto") ?? "").split(",")[0].trim();
  if (host && !/^(0\.0\.0\.0|::)(:|$)/.test(host)) {
    const scheme = proto || (host.startsWith("localhost") || host.startsWith("127.") ? "http" : "https");
    return `${scheme}://${host}`;
  }
  return new URL(req.url).origin;
}
