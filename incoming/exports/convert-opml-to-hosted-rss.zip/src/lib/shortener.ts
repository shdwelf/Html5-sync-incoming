import { db } from "@/db";
import { shortlinks } from "@/db/schema";
import { eq } from "drizzle-orm";

// url-friendly, unambiguous alphabet (no 0/O/1/l/I)
const ALPHABET = "23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ";

export function makeSlug(len = 6): string {
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  let s = "";
  for (const b of bytes) s += ALPHABET[b % ALPHABET.length];
  return s;
}

const RESERVED = new Set([
  "api",
  "p",
  "s",
  "u",
  "qr",
  "_next",
  "favicon.ico",
  "robots.txt",
  "sitemap.xml",
]);

export function isValidSlug(slug: string): boolean {
  if (!slug || slug.length < 2 || slug.length > 40) return false;
  if (!/^[A-Za-z0-9_-]+$/.test(slug)) return false;
  if (RESERVED.has(slug.toLowerCase())) return false;
  return true;
}

export function normaliseTarget(raw: string): string | null {
  const t = raw.trim();
  if (!t) return null;
  // allow absolute paths (internal), otherwise require a scheme
  if (t.startsWith("/")) return t;
  const withScheme = /^https?:\/\//i.test(t) ? t : `https://${t}`;
  try {
    const u = new URL(withScheme);
    if (!/^https?:$/.test(u.protocol)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

export async function createShortlink(opts: {
  target: string;
  slug?: string | null;
  label?: string | null;
  kind?: string;
  reuse?: boolean;
}): Promise<{ slug: string; created: boolean } | { error: string }> {
  const target = normaliseTarget(opts.target);
  if (!target) return { error: "Invalid target URL" };

  if (opts.slug) {
    if (!isValidSlug(opts.slug)) return { error: "Slug must be 2–40 chars, letters/digits/_-" };
    const clash = await db.select().from(shortlinks).where(eq(shortlinks.slug, opts.slug)).limit(1);
    if (clash.length) return { error: "That short code is already taken" };
    await db.insert(shortlinks).values({
      slug: opts.slug,
      target,
      label: opts.label ?? null,
      kind: opts.kind ?? "url",
    });
    return { slug: opts.slug, created: true };
  }

  if (opts.reuse !== false) {
    const existing = await db
      .select()
      .from(shortlinks)
      .where(eq(shortlinks.target, target))
      .limit(1);
    if (existing.length) return { slug: existing[0].slug, created: false };
  }

  for (let attempt = 0; attempt < 6; attempt++) {
    const slug = makeSlug(6 + Math.floor(attempt / 2));
    try {
      await db.insert(shortlinks).values({
        slug,
        target,
        label: opts.label ?? null,
        kind: opts.kind ?? "url",
      });
      return { slug, created: true };
    } catch {
      // slug collision — retry
    }
  }
  return { error: "Could not allocate a slug, try again" };
}
