import { db } from "@/db";
import { feeds, items } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import type { FeedRow, ItemRow } from "@/app/types";
import { buildOpml } from "@/lib/opml";
import {
  FORMATS,
  buildAtom,
  buildJsonFeed,
  buildRss,
  buildXdc,
  buildXmlCatalog,
  type ExportFormat,
} from "@/lib/exporters";

export function isFormat(v: string): v is ExportFormat {
  return v in FORMATS;
}

export async function loadFeedRows(): Promise<FeedRow[]> {
  const rows = await db
    .select({
      id: feeds.id,
      title: feeds.title,
      xmlUrl: feeds.xmlUrl,
      htmlUrl: feeds.htmlUrl,
      folder: feeds.folder,
      lastFetchedAt: feeds.lastFetchedAt,
      lastError: feeds.lastError,
      unread: sql<number>`count(${items.id}) filter (where ${items.read} = false)`.mapWith(Number),
      total: sql<number>`count(${items.id})`.mapWith(Number),
    })
    .from(feeds)
    .leftJoin(items, eq(items.feedId, feeds.id))
    .groupBy(feeds.id)
    .orderBy(feeds.title);

  return rows.map((r) => ({
    ...r,
    lastFetchedAt: r.lastFetchedAt ? r.lastFetchedAt.toISOString() : null,
  }));
}

export async function loadItemRows(limit = 200): Promise<ItemRow[]> {
  const rows = await db
    .select({
      id: items.id,
      title: items.title,
      link: items.link,
      author: items.author,
      summary: items.summary,
      publishedAt: items.publishedAt,
      read: items.read,
      starred: items.starred,
      feedId: items.feedId,
      feedTitle: feeds.title,
      folder: feeds.folder,
      lat: items.lat,
      lon: items.lon,
    })
    .from(items)
    .innerJoin(feeds, eq(feeds.id, items.feedId))
    .orderBy(desc(items.publishedAt))
    .limit(limit);

  return rows.map((r) => ({
    ...r,
    publishedAt: r.publishedAt ? r.publishedAt.toISOString() : null,
  }));
}

export async function renderExport(
  format: ExportFormat,
  origin: string,
): Promise<{ body: string; contentType: string; filename: string }> {
  const meta = FORMATS[format];
  const filename = `pulse-reader-subscriptions.${meta.ext}`;

  if (format === "opml") {
    const rows = await loadFeedRows();
    return { body: buildOpml(rows), contentType: meta.contentType, filename };
  }

  const [feedRows, itemRows] = await Promise.all([loadFeedRows(), loadItemRows()]);

  const body =
    format === "rss"
      ? buildRss(itemRows, origin)
      : format === "atom"
        ? buildAtom(itemRows, origin)
        : format === "xml"
          ? buildXmlCatalog(feedRows, itemRows, origin)
          : format === "xdc"
            ? buildXdc(feedRows, itemRows, origin)
            : buildJsonFeed(itemRows, origin);

  return { body, contentType: meta.contentType, filename };
}
