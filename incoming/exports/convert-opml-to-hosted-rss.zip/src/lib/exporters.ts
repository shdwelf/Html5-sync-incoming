import type { FeedRow, ItemRow } from "@/app/types";

export type ExportFormat = "opml" | "rss" | "atom" | "xml" | "xdc" | "json";

export const FORMATS: Record<
  ExportFormat,
  { label: string; ext: string; contentType: string; hint: string }
> = {
  opml: {
    label: "OPML (subscription list)",
    ext: "opml",
    contentType: "text/x-opml; charset=utf-8",
    hint: "Import into Capy Reader, Feedly, NetNewsWire…",
  },
  rss: {
    label: "RSS 2.0 (river of news)",
    ext: "rss",
    contentType: "application/rss+xml; charset=utf-8",
    hint: "One merged feed of every article in your library.",
  },
  atom: {
    label: "Atom 1.0",
    ext: "atom",
    contentType: "application/atom+xml; charset=utf-8",
    hint: "Same river of news, Atom flavoured.",
  },
  xml: {
    label: "XML catalog",
    ext: "xml",
    contentType: "application/xml; charset=utf-8",
    hint: "Plain XML dump of feeds + articles.",
  },
  xdc: {
    label: "XDC data catalog",
    ext: "xdc",
    contentType: "application/xml; charset=utf-8",
    hint: "Exchange Data Catalog: feeds, folders, stats, checksums.",
  },
  json: {
    label: "JSON Feed 1.1",
    ext: "json",
    contentType: "application/feed+json; charset=utf-8",
    hint: "Machine-readable JSON Feed export.",
  },
};

export function esc(s: string | null | undefined): string {
  return (s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;")
    // strip control chars that break XML parsers
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
}

const rfc822 = (d: string | Date | null) =>
  d ? new Date(d).toUTCString() : new Date().toUTCString();
const iso = (d: string | Date | null) =>
  d ? new Date(d).toISOString() : new Date().toISOString();

export function buildRss(items: ItemRow[], origin: string): string {
  const body = items
    .map(
      (i) => `    <item>
      <title>${esc(i.title)}</title>
      <link>${esc(i.link ?? origin)}</link>
      <guid isPermaLink="false">pulse-${i.id}</guid>
      <source url="${esc(origin)}/api/export/rss">${esc(i.feedTitle)}</source>
      ${i.folder ? `<category>${esc(i.folder)}</category>` : ""}
      ${i.author ? `<dc:creator>${esc(i.author)}</dc:creator>` : ""}
      <pubDate>${rfc822(i.publishedAt)}</pubDate>
      <description>${esc(i.summary ?? i.title)}</description>
    </item>`,
    )
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>Pulse Reader — merged river</title>
    <link>${esc(origin)}</link>
    <atom:link href="${esc(origin)}/api/export/rss" rel="self" type="application/rss+xml"/>
    <description>Every article from every subscription, newest first.</description>
    <language>en</language>
    <generator>Pulse Reader</generator>
    <lastBuildDate>${rfc822(items[0]?.publishedAt ?? null)}</lastBuildDate>
${body}
  </channel>
</rss>
`;
}

export function buildAtom(items: ItemRow[], origin: string): string {
  const body = items
    .map(
      (i) => `  <entry>
    <title type="text">${esc(i.title)}</title>
    <id>urn:pulse:item:${i.id}</id>
    <link rel="alternate" href="${esc(i.link ?? origin)}"/>
    <updated>${iso(i.publishedAt)}</updated>
    <author><name>${esc(i.author ?? i.feedTitle)}</name></author>
    <category term="${esc(i.folder ?? "uncategorised")}"/>
    <summary type="text">${esc(i.summary ?? i.title)}</summary>
  </entry>`,
    )
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>Pulse Reader — merged river</title>
  <id>urn:pulse:river</id>
  <link rel="self" href="${esc(origin)}/api/export/atom"/>
  <link rel="alternate" href="${esc(origin)}"/>
  <updated>${iso(items[0]?.publishedAt ?? null)}</updated>
  <generator uri="${esc(origin)}">Pulse Reader</generator>
${body}
</feed>
`;
}

export function buildXmlCatalog(feeds: FeedRow[], items: ItemRow[], origin: string): string {
  const feedXml = feeds
    .map(
      (f) => `    <feed id="${f.id}" unread="${f.unread}" total="${f.total}">
      <title>${esc(f.title)}</title>
      <folder>${esc(f.folder ?? "")}</folder>
      <xmlUrl>${esc(f.xmlUrl)}</xmlUrl>
      <htmlUrl>${esc(f.htmlUrl ?? "")}</htmlUrl>
      <lastFetchedAt>${f.lastFetchedAt ? iso(f.lastFetchedAt) : ""}</lastFetchedAt>
      <status>${f.lastError ? `error: ${esc(f.lastError)}` : "ok"}</status>
    </feed>`,
    )
    .join("\n");

  const itemXml = items
    .map(
      (i) => `    <article id="${i.id}" feed="${i.feedId}" read="${i.read}" starred="${i.starred}">
      <title>${esc(i.title)}</title>
      <link>${esc(i.link ?? "")}</link>
      <published>${i.publishedAt ? iso(i.publishedAt) : ""}</published>
      <summary>${esc(i.summary ?? "")}</summary>
    </article>`,
    )
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<pulse generator="Pulse Reader" origin="${esc(origin)}" exportedAt="${iso(null)}">
  <feeds count="${feeds.length}">
${feedXml}
  </feeds>
  <articles count="${items.length}">
${itemXml}
  </articles>
</pulse>
`;
}

/** XDC = eXchange Data Catalog: compact, checksummed catalog for machine ingest. */
export function buildXdc(feeds: FeedRow[], items: ItemRow[], origin: string): string {
  const checksum = (s: string) => {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16).padStart(8, "0");
  };
  const folders = [...new Set(feeds.map((f) => f.folder ?? "(root)"))];
  const payload = feeds.map((f) => f.xmlUrl).join("|");

  return `<?xml version="1.0" encoding="UTF-8"?>
<xdc version="1.0" profile="feed-catalog" generated="${iso(null)}" origin="${esc(origin)}">
  <meta>
    <generator>Pulse Reader</generator>
    <records>${feeds.length}</records>
    <articles>${items.length}</articles>
    <unread>${feeds.reduce((s, f) => s + f.unread, 0)}</unread>
    <checksum algorithm="fnv1a32">${checksum(payload)}</checksum>
  </meta>
  <taxonomy>
${folders.map((f) => `    <folder name="${esc(f)}"/>`).join("\n")}
  </taxonomy>
  <records>
${feeds
  .map(
    (f) =>
      `    <record key="${checksum(f.xmlUrl)}" folder="${esc(f.folder ?? "(root)")}" unread="${
        f.unread
      }" total="${f.total}" title="${esc(f.title)}" source="${esc(f.xmlUrl)}" site="${esc(
        f.htmlUrl ?? "",
      )}"/>`,
  )
  .join("\n")}
  </records>
</xdc>
`;
}

export function buildJsonFeed(items: ItemRow[], origin: string): string {
  return JSON.stringify(
    {
      version: "https://jsonfeed.org/version/1.1",
      title: "Pulse Reader — merged river",
      home_page_url: origin,
      feed_url: `${origin}/api/export/json`,
      items: items.map((i) => ({
        id: `pulse-${i.id}`,
        url: i.link ?? undefined,
        title: i.title,
        summary: i.summary ?? undefined,
        date_published: i.publishedAt ? iso(i.publishedAt) : undefined,
        authors: i.author ? [{ name: i.author }] : undefined,
        tags: [i.feedTitle, i.folder].filter(Boolean),
      })),
    },
    null,
    2,
  );
}
