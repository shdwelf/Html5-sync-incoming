import { XMLParser } from "fast-xml-parser";

export type ParsedFeed = {
  title: string;
  xmlUrl: string;
  htmlUrl: string | null;
  folder: string | null;
};

type RawOutline = Record<string, unknown> & { outline?: unknown };

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  processEntities: true,
});

function asArray<T>(v: T | T[] | undefined): T[] {
  if (v === undefined || v === null) return [];
  return Array.isArray(v) ? v : [v];
}

export function parseOpml(xml: string): ParsedFeed[] {
  const doc = parser.parse(xml) as { opml?: { body?: { outline?: unknown } } };
  const roots = asArray(doc.opml?.body?.outline as RawOutline | RawOutline[]);
  const out: ParsedFeed[] = [];

  const walk = (node: RawOutline, folder: string | null) => {
    const xmlUrl = node["@_xmlUrl"] as string | undefined;
    const title =
      (node["@_title"] as string | undefined) ??
      (node["@_text"] as string | undefined) ??
      xmlUrl ??
      "Untitled";
    if (xmlUrl) {
      out.push({
        title: String(title),
        xmlUrl: String(xmlUrl),
        htmlUrl: (node["@_htmlUrl"] as string | undefined) ?? null,
        folder,
      });
      return;
    }
    const children = asArray(node.outline as RawOutline | RawOutline[]);
    for (const child of children) walk(child, String(title));
  };

  for (const r of roots) walk(r, null);

  const seen = new Set<string>();
  return out.filter((f) => {
    if (seen.has(f.xmlUrl)) return false;
    seen.add(f.xmlUrl);
    return true;
  });
}

export function buildOpml(
  feeds: { title: string; xmlUrl: string; htmlUrl: string | null; folder: string | null }[],
): string {
  const esc = (s: string) =>
    s
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  const line = (f: (typeof feeds)[number], indent: string) =>
    `${indent}<outline text="${esc(f.title)}" title="${esc(f.title)}" type="rss" htmlUrl="${esc(
      f.htmlUrl ?? "",
    )}" xmlUrl="${esc(f.xmlUrl)}"/>`;

  const root = feeds.filter((f) => !f.folder);
  const folders = new Map<string, typeof feeds>();
  for (const f of feeds) {
    if (!f.folder) continue;
    const arr = folders.get(f.folder) ?? [];
    arr.push(f);
    folders.set(f.folder, arr);
  }
  const body = [
    ...root.map((f) => line(f, "    ")),
    ...[...folders.entries()].map(
      ([name, list]) =>
        `    <outline text="${esc(name)}" title="${esc(name)}">\n` +
        list.map((f) => line(f, "      ")).join("\n") +
        `\n    </outline>`,
    ),
  ].join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>\n<opml version="1.1">\n  <head><title>Pulse Reader Export</title></head>\n  <body>\n${body}\n  </body>\n</opml>\n`;
}
