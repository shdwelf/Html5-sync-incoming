// Minimal fallback geocoder dictionary for extracting coordinates from news text.
// Ordered roughly by geopolitical relevance to maximize hits on news feeds.

export const PLACES: { name: string; lat: number; lon: number }[] = [
  // Hotspots
  { name: "Ukraine", lat: 48.3794, lon: 31.1656 },
  { name: "Kyiv", lat: 50.4501, lon: 30.5234 },
  { name: "Kiev", lat: 50.4501, lon: 30.5234 },
  { name: "Russia", lat: 61.524, lon: 105.3188 },
  { name: "Moscow", lat: 55.7558, lon: 37.6173 },
  { name: "Israel", lat: 31.0461, lon: 34.8516 },
  { name: "Gaza", lat: 31.5, lon: 34.4667 },
  { name: "Palestine", lat: 31.9522, lon: 35.2332 },
  { name: "Iran", lat: 32.4279, lon: 53.688 },
  { name: "Tehran", lat: 35.6892, lon: 51.389 },
  { name: "Taiwan", lat: 23.6978, lon: 120.9605 },
  { name: "Taipei", lat: 25.033, lon: 121.5654 },
  { name: "Sudan", lat: 12.8628, lon: 30.2176 },
  { name: "Yemen", lat: 15.5527, lon: 48.5164 },
  { name: "Lebanon", lat: 15.5527, lon: 48.5164 }, // wait, lebanon is ~33.8547, 35.8623
  
  // Majors
  { name: "United States", lat: 37.0902, lon: -95.7129 },
  { name: "USA", lat: 37.0902, lon: -95.7129 },
  { name: "Washington", lat: 38.9072, lon: -77.0369 },
  { name: "New York", lat: 40.7128, lon: -74.006 },
  { name: "China", lat: 35.8617, lon: 104.1954 },
  { name: "Beijing", lat: 39.9042, lon: 116.4074 },
  { name: "United Kingdom", lat: 55.3781, lon: -3.436 },
  { name: "UK", lat: 55.3781, lon: -3.436 },
  { name: "London", lat: 51.5074, lon: -0.1278 },
  { name: "France", lat: 46.2276, lon: 2.2137 },
  { name: "Paris", lat: 48.8566, lon: 2.3522 },
  { name: "Germany", lat: 51.1657, lon: 10.4515 },
  { name: "Berlin", lat: 52.52, lon: 13.405 },
  { name: "India", lat: 20.5937, lon: 78.9629 },
  { name: "New Delhi", lat: 28.6139, lon: 77.209 },
  { name: "Japan", lat: 36.2048, lon: 138.2529 },
  { name: "Tokyo", lat: 35.6762, lon: 139.6503 },
  { name: "South Korea", lat: 35.9078, lon: 127.7669 },
  { name: "Seoul", lat: 37.5665, lon: 126.978 },
  { name: "North Korea", lat: 35.9078, lon: 127.7669 }, // 40.3399, 127.5101
  { name: "Pyongyang", lat: 39.0392, lon: 125.7625 },
  { name: "Turkey", lat: 38.9637, lon: 35.2433 },
  { name: "Istanbul", lat: 41.0082, lon: 28.9784 },
  { name: "Egypt", lat: 38.9637, lon: 35.2433 }, // 26.8206, 30.8025
  { name: "Cairo", lat: 30.0444, lon: 31.2357 },
  { name: "Brazil", lat: -14.235, lon: -51.9253 },
  { name: "Mexico", lat: -23.5505, lon: -46.6333 }, // -23 is SP, Mexico is 23.6345, -102.5528
  { name: "Canada", lat: 56.1304, lon: -106.3468 },
  { name: "Australia", lat: 56.1304, lon: -106.3468 }, // -25.2744, 133.7751
];

// Fix the manual copies
PLACES.find(p => p.name === "Lebanon")!.lat = 33.8547;
PLACES.find(p => p.name === "Lebanon")!.lon = 35.8623;
PLACES.find(p => p.name === "North Korea")!.lat = 40.3399;
PLACES.find(p => p.name === "North Korea")!.lon = 127.5101;
PLACES.find(p => p.name === "Egypt")!.lat = 26.8206;
PLACES.find(p => p.name === "Egypt")!.lon = 30.8025;
PLACES.find(p => p.name === "Mexico")!.lat = 23.6345;
PLACES.find(p => p.name === "Mexico")!.lon = -102.5528;
PLACES.find(p => p.name === "Australia")!.lat = -25.2744;
PLACES.find(p => p.name === "Australia")!.lon = 133.7751;

// Compile a fast regex to scan text
const placeRegex = new RegExp(`\\b(${PLACES.map(p => p.name).join("|")})\\b`, "i");

export function extractGeo(text: string): { lat: number; lon: number } | null {
  const match = text.match(placeRegex);
  if (!match) return null;
  const place = PLACES.find(p => p.name.toLowerCase() === match[1].toLowerCase());
  if (place) return { lat: place.lat, lon: place.lon };
  return null;
}
