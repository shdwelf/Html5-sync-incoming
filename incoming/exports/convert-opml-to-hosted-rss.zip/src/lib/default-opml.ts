export const DEFAULT_OPML = `<?xml version="1.0" encoding="UTF-8"?>
<opml version="1.1">
  <head><title>Capy Reader Export</title></head>
  <body>
    <outline text="| NewsWire OSINT Ukraine" title="| NewsWire OSINT Ukraine" type="rss" htmlUrl="https://rss.osintukraine.com" xmlUrl="https://rss.osintukraine.com/i/?a=rss&amp;hours=168"/>
    <outline text="ABC News: Top Stories" title="ABC News: Top Stories" type="rss" htmlUrl="http://abcnews.com/" xmlUrl="https://feeds.abcnews.com/abcnews/topstories"/>
    <outline text="All3DP" title="All3DP" type="rss" htmlUrl="https://all3dp.com" xmlUrl="https://all3dp.com/feed/newsfeed"/>
    <outline text="AllAfrica" title="AllAfrica" type="rss" htmlUrl="https://allafrica.com/africa/" xmlUrl="https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf"/>
    <outline text="Austin Henley" title="Austin Henley" type="rss" htmlUrl="https://austinhenley.com/blog.html" xmlUrl="https://austinhenley.com/blog/feed.rss"/>
    <outline text="BGR" title="BGR" type="rss" htmlUrl="https://www.bgr.com/" xmlUrl="https://bgr.com/feed"/>
    <outline text="Book Riot" title="Book Riot" type="rss" htmlUrl="https://bookriot.com/" xmlUrl="https://bookriot.com/feed"/>
    <outline text="Ars Technica" title="Ars Technica" type="rss" htmlUrl="https://arstechnica.com" xmlUrl="https://feeds.arstechnica.com/arstechnica/index"/>
    <outline text="404 Media" title="404 Media" type="rss" htmlUrl="https://www.404media.co/" xmlUrl="https://www.404media.co/rss"/>
    <outline text="Al Jazeera" title="Al Jazeera" type="rss" htmlUrl="https://www.aljazeera.com" xmlUrl="https://www.aljazeera.com/xml/rss/all.xml"/>
    <outline text="Android Authority" title="Android Authority" type="rss" htmlUrl="https://www.androidauthority.com/" xmlUrl="https://www.androidauthority.com/feed"/>
    <outline text="AI News" title="AI News" type="rss" htmlUrl="https://www.artificialintelligence-news.com/" xmlUrl="https://www.artificialintelligence-news.com/feed"/>
    <outline text="BleepingComputer" title="BleepingComputer" type="rss" htmlUrl="https://www.bleepingcomputer.com/" xmlUrl="https://www.bleepingcomputer.com/feed/"/>
    <outline text="Biometric Update" title="Biometric Update" type="rss" htmlUrl="https://www.biometricupdate.com" xmlUrl="https://www.biometricupdate.com/feed"/>
    <outline text="CBC Top Stories" title="CBC Top Stories" type="rss" htmlUrl="https://www.cbc.ca/news/" xmlUrl="https://www.cbc.ca/webfeed/rss/rss-topstories"/>
    <outline text="Channel News Asia" title="Channel News Asia" type="rss" htmlUrl="https://www.channelnewsasia.com/" xmlUrl="https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml"/>
    <outline text="CNET News" title="CNET News" type="rss" htmlUrl="https://www.cnet.com" xmlUrl="https://www.cnet.com/rss/news"/>
    <outline text="Computerworld" title="Computerworld" type="rss" htmlUrl="https://www.computerworld.com" xmlUrl="https://www.computerworld.com/feed"/>
    <outline text="NBC News" title="NBC News" type="rss" htmlUrl="https://www.nbcnews.com/" xmlUrl="https://www.nbcnews.com/feed"/>
    <outline text="r/3Dprinting" title="r/3Dprinting" type="rss" htmlUrl="https://www.reddit.com/r/3Dprinting/" xmlUrl="https://www.reddit.com/r/3Dprinting/.rss"/>
    <outline text="SCMP" title="SCMP" type="rss" htmlUrl="https://www.scmp.com" xmlUrl="https://www.scmp.com/rss/4/feed"/>
    <outline text="BBC" title="BBC">
      <outline text="BBC News" title="BBC News" type="rss" htmlUrl="https://www.bbc.co.uk/news" xmlUrl="https://feeds.bbci.co.uk/news/rss.xml"/>
      <outline text="BBC Technology" title="BBC Technology" type="rss" htmlUrl="https://www.bbc.co.uk/news/technology" xmlUrl="https://feeds.bbci.co.uk/news/technology/rss.xml"/>
      <outline text="BBC Europe" title="BBC Europe" type="rss" htmlUrl="https://www.bbc.co.uk/news/world/europe" xmlUrl="https://feeds.bbci.co.uk/news/world/europe/rss.xml"/>
      <outline text="BBC Asia" title="BBC Asia" type="rss" htmlUrl="https://www.bbc.co.uk/news/world/asia" xmlUrl="https://feeds.bbci.co.uk/news/world/asia/rss.xml"/>
      <outline text="BBC Africa" title="BBC Africa" type="rss" htmlUrl="https://www.bbc.co.uk/news/world/africa" xmlUrl="https://feeds.bbci.co.uk/news/world/africa/rss.xml"/>
      <outline text="BBC Middle East" title="BBC Middle East" type="rss" htmlUrl="https://www.bbc.co.uk/news/world/middle_east" xmlUrl="https://feeds.bbci.co.uk/news/world/middle_east/rss.xml"/>
      <outline text="BBC US &amp; Canada" title="BBC US &amp; Canada" type="rss" htmlUrl="https://www.bbc.co.uk/news/world/us_and_canada" xmlUrl="https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml"/>
    </outline>
    <outline text="United States" title="United States">
      <outline text="FOX News" title="FOX News" type="rss" htmlUrl="https://www.foxnews.com/" xmlUrl="https://feeds.foxnews.com/foxnews/latest"/>
      <outline text="NYT &gt; Top Stories" title="NYT &gt; Top Stories" type="rss" htmlUrl="https://www.nytimes.com" xmlUrl="https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml"/>
      <outline text="Politico Playbook" title="Politico Playbook" type="rss" htmlUrl="https://rss.politico.com/playbook.xml" xmlUrl="https://rss.politico.com/playbook.xml"/>
      <outline text="CNBC US Top News" title="CNBC US Top News" type="rss" htmlUrl="https://www.cnbc.com/us-top-news-and-analysis/" xmlUrl="https://www.cnbc.com/id/100003114/device/rss/rss.html"/>
      <outline text="Washington Post World" title="Washington Post World" type="rss" htmlUrl="https://www.washingtonpost.com" xmlUrl="https://feeds.washingtonpost.com/rss/world"/>
      <outline text="LA Times World &amp; Nation" title="LA Times World &amp; Nation" type="rss" htmlUrl="https://www.latimes.com" xmlUrl="https://www.latimes.com/world-nation/rss2.0.xml"/>
      <outline text="HuffPost World" title="HuffPost World" type="rss" htmlUrl="https://www.huffpost.com/news/world-news" xmlUrl="https://www.huffpost.com/section/world-news/feed"/>
      <outline text="WSJ World News" title="WSJ World News" type="rss" htmlUrl="http://online.wsj.com" xmlUrl="https://feeds.a.dj.com/rss/RSSWorldNews.xml"/>
      <outline text="Yahoo News" title="Yahoo News" type="rss" htmlUrl="https://www.yahoo.com/news" xmlUrl="https://news.yahoo.com/rss/mostviewed"/>
    </outline>
    <outline text="YouTube" title="YouTube">
      <outline text="Brodie Robertson" title="Brodie Robertson" type="rss" htmlUrl="https://www.youtube.com/channel/UCld68syR8Wi-GY_n4CaoJGA" xmlUrl="https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA"/>
      <outline text="Channel UC2C_jShtL725hvbm1arSV9w" title="Channel UC2C_jShtL725hvbm1arSV9w" type="rss" htmlUrl="https://www.youtube.com/channel/UC2C_jShtL725hvbm1arSV9w" xmlUrl="https://www.youtube.com/feeds/videos.xml?channel_id=UC2C_jShtL725hvbm1arSV9w"/>
      <outline text="Channel UCMlGfpWw-RUdWX_JbLCukXg" title="Channel UCMlGfpWw-RUdWX_JbLCukXg" type="rss" htmlUrl="https://www.youtube.com/channel/UCMlGfpWw-RUdWX_JbLCukXg" xmlUrl="https://www.youtube.com/feeds/videos.xml?channel_id=UCMlGfpWw-RUdWX_JbLCukXg"/>
      <outline text="Channel UCX_t3BvnQtS5IHzto_y7tbw" title="Channel UCX_t3BvnQtS5IHzto_y7tbw" type="rss" htmlUrl="https://www.youtube.com/channel/UCX_t3BvnQtS5IHzto_y7tbw" xmlUrl="https://www.youtube.com/feeds/videos.xml?channel_id=UCX_t3BvnQtS5IHzto_y7tbw"/>
    </outline>
  </body>
</opml>`;
