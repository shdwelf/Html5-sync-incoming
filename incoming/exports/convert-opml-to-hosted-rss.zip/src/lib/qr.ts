/* Minimal QR code encoder (byte mode, ECC-M, versions 1–20).
   Emits an SVG string. Adapted from the public-domain "QR Code generator library"
   algorithm (Project Nayuki), reimplemented in TypeScript. */

type Bit = 0 | 1;

const ECC_CODEWORDS_PER_BLOCK: number[] = [
  10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26,
];
const NUM_ERROR_CORRECTION_BLOCKS: number[] = [
  1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16,
];

function getNumRawDataModules(ver: number): number {
  let result = (16 * ver + 128) * ver + 64;
  if (ver >= 2) {
    const numAlign = Math.floor(ver / 7) + 2;
    result -= (25 * numAlign - 10) * numAlign - 55;
    if (ver >= 7) result -= 36;
  }
  return result;
}

function reedSolomonComputeDivisor(degree: number): number[] {
  const result = new Array<number>(degree).fill(0);
  result[degree - 1] = 1;
  let root = 1;
  for (let i = 0; i < degree; i++) {
    for (let j = 0; j < result.length; j++) {
      result[j] = gfMul(result[j], root);
      if (j + 1 < result.length) result[j] ^= result[j + 1];
    }
    root = gfMul(root, 0x02);
  }
  return result;
}

function reedSolomonComputeRemainder(data: number[], divisor: number[]): number[] {
  const result = new Array<number>(divisor.length).fill(0);
  for (const b of data) {
    const factor = b ^ (result.shift() as number);
    result.push(0);
    for (let i = 0; i < divisor.length; i++) result[i] ^= gfMul(divisor[i], factor);
  }
  return result;
}

function gfMul(x: number, y: number): number {
  let z = 0;
  for (let i = 7; i >= 0; i--) {
    z = (z << 1) ^ ((z >>> 7) * 0x11d);
    z ^= ((y >>> i) & 1) * x;
  }
  return z & 0xff;
}

function chooseVersion(text: string): number {
  const bits = 4 + 16 + text.length * 8;
  for (let ver = 1; ver <= 20; ver++) {
    const dataCapacityBits =
      Math.floor(
        (getNumRawDataModules(ver) / 8 -
          ECC_CODEWORDS_PER_BLOCK[ver - 1] * NUM_ERROR_CORRECTION_BLOCKS[ver - 1]) *
          8,
      );
    // widen the length field for larger versions
    const overhead = ver >= 10 ? 4 + 16 : 4 + 8;
    if (overhead + text.length * 8 <= dataCapacityBits) return ver;
  }
  throw new Error("Text too long for QR shortlink");
}

function buildBitstream(text: string, version: number): number[] {
  const bits: Bit[] = [];
  const push = (val: number, len: number) => {
    for (let i = len - 1; i >= 0; i--) bits.push(((val >>> i) & 1) as Bit);
  };
  push(0b0100, 4); // byte mode
  push(text.length, version < 10 ? 8 : 16);
  const utf8 = new TextEncoder().encode(text);
  for (const b of utf8) push(b, 8);

  const capacityBits =
    (Math.floor(getNumRawDataModules(version) / 8) -
      ECC_CODEWORDS_PER_BLOCK[version - 1] * NUM_ERROR_CORRECTION_BLOCKS[version - 1]) *
    8;
  const terminator = Math.min(4, capacityBits - bits.length);
  for (let i = 0; i < terminator; i++) bits.push(0);
  while (bits.length % 8 !== 0) bits.push(0);

  const bytes: number[] = [];
  for (let i = 0; i < bits.length; i += 8) {
    let b = 0;
    for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j];
    bytes.push(b);
  }
  const totalDataBytes = capacityBits / 8;
  for (let i = 0, pad = 0xec; bytes.length < totalDataBytes; i++, pad ^= 0xec ^ 0x11) {
    bytes.push(pad);
  }
  return bytes;
}

function addEcc(data: number[], version: number): number[] {
  const numBlocks = NUM_ERROR_CORRECTION_BLOCKS[version - 1];
  const eccLen = ECC_CODEWORDS_PER_BLOCK[version - 1];
  const rawCodewords = Math.floor(getNumRawDataModules(version) / 8);
  const numShortBlocks = numBlocks - (rawCodewords % numBlocks);
  const shortBlockLen = Math.floor(rawCodewords / numBlocks);

  const blocks: number[][] = [];
  const rsDiv = reedSolomonComputeDivisor(eccLen);
  let k = 0;
  for (let i = 0; i < numBlocks; i++) {
    const dataLen = shortBlockLen - eccLen + (i < numShortBlocks ? 0 : 1);
    const dat = data.slice(k, k + dataLen);
    k += dataLen;
    const ecc = reedSolomonComputeRemainder(dat, rsDiv);
    if (i < numShortBlocks) dat.push(0);
    blocks.push(dat.concat(ecc));
  }

  const result: number[] = [];
  for (let i = 0; i < blocks[0].length; i++) {
    for (let j = 0; j < blocks.length; j++) {
      if (i !== shortBlockLen - eccLen || j >= numShortBlocks) result.push(blocks[j][i]);
    }
  }
  return result;
}

class Matrix {
  size: number;
  m: number[]; // 0/1 modules
  reserved: boolean[];
  constructor(version: number) {
    this.size = version * 4 + 17;
    this.m = new Array(this.size * this.size).fill(0);
    this.reserved = new Array(this.size * this.size).fill(false);
  }
  get(x: number, y: number): number {
    return this.m[y * this.size + x];
  }
  set(x: number, y: number, v: number, reserved = false) {
    this.m[y * this.size + x] = v;
    if (reserved) this.reserved[y * this.size + x] = true;
  }
  isReserved(x: number, y: number): boolean {
    return this.reserved[y * this.size + x];
  }
}

function drawFinderPattern(mat: Matrix, cx: number, cy: number) {
  for (let dy = -4; dy <= 4; dy++) {
    for (let dx = -4; dx <= 4; dx++) {
      const x = cx + dx;
      const y = cy + dy;
      if (x < 0 || y < 0 || x >= mat.size || y >= mat.size) continue;
      const d = Math.max(Math.abs(dx), Math.abs(dy));
      const on = d !== 2 && d !== 4;
      mat.set(x, y, on ? 1 : 0, true);
    }
  }
}

function drawAlignmentPattern(mat: Matrix, cx: number, cy: number) {
  for (let dy = -2; dy <= 2; dy++) {
    for (let dx = -2; dx <= 2; dx++) {
      const d = Math.max(Math.abs(dx), Math.abs(dy));
      mat.set(cx + dx, cy + dy, d === 1 ? 0 : 1, true);
    }
  }
}

function alignmentPatternPositions(version: number): number[] {
  if (version === 1) return [];
  const numAlign = Math.floor(version / 7) + 2;
  const size = version * 4 + 17;
  const step = version === 32 ? 26 : Math.ceil((size - 13) / (numAlign * 2 - 2)) * 2;
  const pos = [6];
  for (let i = numAlign - 1; i > 0; i--) pos.push(size - 7 - (numAlign - 1 - i) * step);
  return pos;
}

function drawFunctionPatterns(mat: Matrix, version: number) {
  drawFinderPattern(mat, 3, 3);
  drawFinderPattern(mat, mat.size - 4, 3);
  drawFinderPattern(mat, 3, mat.size - 4);
  // timing patterns
  for (let i = 8; i < mat.size - 8; i++) {
    mat.set(6, i, i % 2 === 0 ? 1 : 0, true);
    mat.set(i, 6, i % 2 === 0 ? 1 : 0, true);
  }
  // alignment patterns
  const pos = alignmentPatternPositions(version);
  for (const y of pos) {
    for (const x of pos) {
      if ((x === 6 && y === 6) || (x === 6 && y === mat.size - 7) || (x === mat.size - 7 && y === 6))
        continue;
      drawAlignmentPattern(mat, x, y);
    }
  }
  // dark module + format info reservation
  mat.set(8, mat.size - 8, 1, true);
  for (let i = 0; i <= 8; i++) {
    mat.set(i, 8, 0, true);
    mat.set(8, i, 0, true);
    mat.set(mat.size - 1 - i, 8, 0, true);
    mat.set(8, mat.size - 1 - i, 0, true);
  }
}

function drawData(mat: Matrix, data: number[]) {
  let bitIdx = 0;
  for (let right = mat.size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < mat.size; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? mat.size - 1 - vert : vert;
        if (!mat.isReserved(x, y)) {
          const byteIdx = bitIdx >>> 3;
          const bit = byteIdx < data.length ? (data[byteIdx] >> (7 - (bitIdx & 7))) & 1 : 0;
          mat.set(x, y, bit);
          bitIdx++;
        }
      }
    }
  }
}

function applyMask(mat: Matrix, mask: number) {
  for (let y = 0; y < mat.size; y++) {
    for (let x = 0; x < mat.size; x++) {
      if (mat.isReserved(x, y)) continue;
      let invert = false;
      switch (mask) {
        case 0: invert = (x + y) % 2 === 0; break;
        case 1: invert = y % 2 === 0; break;
        case 2: invert = x % 3 === 0; break;
        case 3: invert = (x + y) % 3 === 0; break;
        case 4: invert = (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0; break;
        case 5: invert = ((x * y) % 2) + ((x * y) % 3) === 0; break;
        case 6: invert = (((x * y) % 2) + ((x * y) % 3)) % 2 === 0; break;
        case 7: invert = (((x + y) % 2) + ((x * y) % 3)) % 2 === 0; break;
      }
      if (invert) mat.set(x, y, mat.get(x, y) ^ 1);
    }
  }
}

function drawFormatBits(mat: Matrix, mask: number) {
  // ECC-M = 0b00
  const data = (0b00 << 3) | mask;
  let rem = data;
  for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >> 9) * 0x537);
  const bits = ((data << 10) | rem) ^ 0x5412;

  for (let i = 0; i <= 5; i++) mat.set(8, i, (bits >> i) & 1);
  mat.set(8, 7, (bits >> 6) & 1);
  mat.set(8, 8, (bits >> 7) & 1);
  mat.set(7, 8, (bits >> 8) & 1);
  for (let i = 9; i < 15; i++) mat.set(14 - i, 8, (bits >> i) & 1);
  for (let i = 0; i < 8; i++) mat.set(mat.size - 1 - i, 8, (bits >> i) & 1);
  for (let i = 8; i < 15; i++) mat.set(8, mat.size - 15 + i, (bits >> i) & 1);
  mat.set(8, mat.size - 8, 1);
}

function penalty(mat: Matrix): number {
  let p = 0;
  const size = mat.size;
  // Rule 1: runs of ≥5
  for (let y = 0; y < size; y++) {
    let runColor = -1, runLen = 0;
    for (let x = 0; x < size; x++) {
      const c = mat.get(x, y);
      if (c === runColor) { runLen++; if (runLen === 5) p += 3; else if (runLen > 5) p++; }
      else { runColor = c; runLen = 1; }
    }
  }
  for (let x = 0; x < size; x++) {
    let runColor = -1, runLen = 0;
    for (let y = 0; y < size; y++) {
      const c = mat.get(x, y);
      if (c === runColor) { runLen++; if (runLen === 5) p += 3; else if (runLen > 5) p++; }
      else { runColor = c; runLen = 1; }
    }
  }
  return p;
}

export function encodeQrToSvg(text: string, opts: { scale?: number; margin?: number } = {}): string {
  const version = chooseVersion(text);
  const bytes = buildBitstream(text, version);
  const codewords = addEcc(bytes, version);

  let best: { mat: Matrix; mask: number; score: number } | null = null;
  for (let mask = 0; mask < 8; mask++) {
    const mat = new Matrix(version);
    drawFunctionPatterns(mat, version);
    drawData(mat, codewords);
    applyMask(mat, mask);
    drawFormatBits(mat, mask);
    const score = penalty(mat);
    if (!best || score < best.score) best = { mat, mask, score };
  }
  const mat = best!.mat;

  const scale = opts.scale ?? 8;
  const margin = opts.margin ?? 2;
  const total = (mat.size + margin * 2) * scale;

  let rects = "";
  for (let y = 0; y < mat.size; y++) {
    let runStart = -1;
    for (let x = 0; x <= mat.size; x++) {
      const on = x < mat.size && mat.get(x, y) === 1;
      if (on && runStart === -1) runStart = x;
      else if (!on && runStart !== -1) {
        const px = (runStart + margin) * scale;
        const py = (y + margin) * scale;
        const pw = (x - runStart) * scale;
        rects += `<rect x="${px}" y="${py}" width="${pw}" height="${scale}"/>`;
        runStart = -1;
      }
    }
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${total} ${total}" width="${total}" height="${total}" shape-rendering="crispEdges">
  <rect width="100%" height="100%" fill="#ffffff"/>
  <g fill="#0f172a">${rects}</g>
</svg>`;
}
