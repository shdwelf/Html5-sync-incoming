import { promises as fs } from "node:fs";
import path from "node:path";

const ROOT_FILES = [
  "package.json",
  "tsconfig.json",
  "next.config.ts",
  "postcss.config.mjs",
  "eslint.config.mjs",
  "drizzle.config.json",
];

const SKIP_DIRS = new Set(["node_modules", ".next", ".git", "dist", "build", ".turbo"]);
const MAX_FILE_BYTES = 256 * 1024;

export type SourceFile = { path: string; content: string };

async function walk(dir: string, root: string, out: SourceFile[]) {
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (SKIP_DIRS.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      await walk(full, root, out);
    } else if (/\.(ts|tsx|js|jsx|mjs|css|json|md|sql)$/.test(e.name)) {
      const stat = await fs.stat(full);
      if (stat.size > MAX_FILE_BYTES) continue;
      out.push({
        path: path.relative(root, full).split(path.sep).join("/"),
        content: await fs.readFile(full, "utf8"),
      });
    }
  }
}

export async function collectSource(): Promise<SourceFile[]> {
  const root = process.cwd();
  const out: SourceFile[] = [];
  await walk(path.join(root, "src"), root, out);
  for (const f of ROOT_FILES) {
    try {
      const content = await fs.readFile(path.join(root, f), "utf8");
      out.push({ path: f, content });
    } catch {
      /* optional file */
    }
  }
  return out.sort((a, b) => a.path.localeCompare(b.path));
}

export function renderSourceText(files: SourceFile[]): string {
  const header = `/* ============================================================
   Pulse Reader — quine bundle
   ${files.length} files · generated ${new Date().toISOString()}

   This file contains the complete source of the running app.
   Recreate it by writing each block below to its "FILE:" path,
   then: npm install && npx drizzle-kit push && npm run build
   ============================================================ */\n\n`;

  return (
    header +
    files
      .map(
        (f) =>
          `/* ---------- FILE: ${f.path} (${f.content.length} bytes) ---------- */\n${f.content}\n`,
      )
      .join("\n")
  );
}

const README = `# Pulse Reader

Self-extracted from a running instance.

## Setup
1. \`npm install\`
2. Set \`DATABASE_URL\` in \`.env\` (PostgreSQL).
3. \`npx drizzle-kit push\`
4. \`npm run build && npm start\`

Then open http://localhost:3000, click **+ Feeds → Load sample set**, and **Refresh all**.
`;

export function renderSfxInstaller(files: SourceFile[]): string {
  const b64 = (s: string) =>
    Buffer.from(s, "utf8")
      .toString("base64")
      .replace(/(.{76})/g, "$1\n");

  const payload = [...files, { path: "README.md", content: README }]
    .map(
      (f) => `emit "${f.path}" <<'PULSE_EOF'
${b64(f.content)}
PULSE_EOF`,
    )
    .join("\n\n");

  const totalBytes = files.reduce((s, f) => s + f.content.length, 0);

  return `#!/usr/bin/env bash
# ==============================================================
#  Pulse Reader — self-extracting installer (SFX)
#  ${files.length + 1} files · ${totalBytes} bytes of source
#  Generated ${new Date().toISOString()}
#
#  Usage:  bash pulse-reader-sfx.sh [target-dir] [--install]
# ==============================================================
set -euo pipefail

TARGET="\${1:-pulse-reader}"
DO_INSTALL="no"
for arg in "\$@"; do [ "\$arg" = "--install" ] && DO_INSTALL="yes"; done
[ "\${TARGET:0:2}" = "--" ] && TARGET="pulse-reader"

if printf 'aGk=' | base64 -d >/dev/null 2>&1; then B64D="base64 -d"; else B64D="base64 -D"; fi

cat <<'BANNER'
  ____        _            ____                _
 |  _ \\ _   _| |___  ___  |  _ \\ ___  __ _  __| | ___ _ __
 | |_) | | | | / __|/ _ \\ | |_) / _ \\/ _\` |/ _\` |/ _ \\ '__|
 |  __/| |_| | \\__ \\  __/ |  _ <  __/ (_| | (_| |  __/ |
 |_|    \\__,_|_|___/\\___| |_| \\_\\___|\\__,_|\\__,_|\\___|_|
   self-extracting installer
BANNER

echo "→ extracting into: \$TARGET"
mkdir -p "\$TARGET"

emit() {
  mkdir -p "\$TARGET/\$(dirname "\$1")"
  \$B64D > "\$TARGET/\$1"
  echo "   + \$1"
}

${payload}

if [ ! -f "\$TARGET/.env" ]; then
  echo 'DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db' > "\$TARGET/.env"
  echo "   + .env (edit DATABASE_URL as needed)"
fi

echo ""
echo "✔ extracted ${files.length + 1} files"

if [ "\$DO_INSTALL" = "yes" ]; then
  echo "→ installing dependencies…"
  (cd "\$TARGET" && npm install && npx drizzle-kit push --force && npm run build)
  echo "✔ ready:  cd \$TARGET && npm start"
else
  echo ""
  echo "Next steps:"
  echo "  cd \$TARGET"
  echo "  npm install"
  echo "  npx drizzle-kit push"
  echo "  npm run build && npm start"
  echo ""
  echo "(re-run with --install to do all of that automatically)"
fi
`;
}
