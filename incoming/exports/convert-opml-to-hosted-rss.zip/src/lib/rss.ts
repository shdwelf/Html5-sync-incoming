import { XMLParser } from "fast-xml-parser";

import { extractGeo } from "./geocode";

export type ParsedItem = {
  guid: string;
  title: string;
  link: string | null;
  author: string | null;
  summary: string | null;
  publishedAt: Date | null;
  lat: number | null;
  lon: number | null;
};

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  processEntities: true,
  trimValues: true,
});

function asArray<T>(v: T | T[] | undefined | null): T[] {
  if (v === undefined || v === null) return [];
  return Array.isArray(v) ? v : [v];
}

function text(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  if (typeof v === "string") return v;
  if (typeof v === "number") return String(v);
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    if (typeof o["#text"] === "string") return o["#text"];
    if (typeof o["@_href"] === "string") return o["@_href"];
  }
  return null;
}

function stripHtml(s: string | null): string | null {
  if (!s) return null;
  const out = s
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return out.length > 600 ? out.slice(0, 600) + "…" : out || null;
}

function toDate(s: string | null): Date | null {
  if (!s) return null;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}

export type FetchedFeed = { title: string | null; items: ParsedItem[] };

export function parseFeedXml(xml: string): FetchedFeed {
  const doc = parser.parse(xml) as Record<string, any>;

  // RSS 2.0
  if (doc.rss?.channel) {
    const ch = Array.isArray(doc.rss.channel) ? doc.rss.channel[0] : doc.rss.channel;
    const items = asArray(ch.item).map((it: any): ParsedItem => {
      const link = text(it.link);
      const guid = text(it.guid) ?? link ?? text(it.title) ?? crypto.randomUUID();
      let lat = Number(text(it["geo:lat"])) || null;
      let lon = Number(text(it["geo:long"])) || null;
      const point = text(it["georss:point"]);
      if (point && !lat && !lon) {
        const [plat, plon] = point.split(" ");
        if (plat && plon) { lat = Number(plat); lon = Number(plon); }
      }
      const titleStr = text(it.title) ?? "(untitled)";
      const summaryStr = stripHtml(text(it.description) ?? text(it["content:encoded"]));
      if (!lat || !lon) {
        const geo = extractGeo(titleStr + " " + (summaryStr ?? ""));
        if (geo) { lat = geo.lat; lon = geo.lon; }
      }
      return {
        guid,
        title: titleStr,
        link,
        author: text(it["dc:creator"]) ?? text(it.author),
        summary: summaryStr,
        publishedAt: toDate(text(it.pubDate) ?? text(it["dc:date"])),
        lat,
        lon,
      };
    });
    return { title: text(ch.title), items };
  }

  // Atom
  if (doc.feed) {
    const f = doc.feed;
    const items = asArray(f.entry).map((e: any): ParsedItem => {
      const links = asArray(e.link);
      const linkObj =
        links.find((l: any) => l?.["@_rel"] === "alternate" || l?.["@_rel"] === undefined) ??
        links[0];
      const link = text(linkObj);
      const guid = text(e.id) ?? link ?? text(e.title) ?? crypto.randomUUID();
      const media = e["media:group"];
      let lat = Number(text(e["geo:lat"])) || null;
      let lon = Number(text(e["geo:long"])) || null;
      const point = text(e["georss:point"]);
      if (point && !lat && !lon) {
        const [plat, plon] = point.split(" ");
        if (plat && plon) { lat = Number(plat); lon = Number(plon); }
      }
      const titleStr = text(e.title) ?? text(media?.["media:title"]) ?? "(untitled)";
      const summaryStr = stripHtml(text(e.summary) ?? text(e.content) ?? text(media?.["media:description"]));
      if (!lat || !lon) {
        const geo = extractGeo(titleStr + " " + (summaryStr ?? ""));
        if (geo) { lat = geo.lat; lon = geo.lon; }
      }
      return {
        guid,
        title: titleStr,
        link,
        author: text(e.author?.name) ?? text(e.author),
        summary: summaryStr,
        publishedAt: toDate(text(e.published) ?? text(e.updated)),
        lat,
        lon,
      };
    });
    return { title: text(f.title), items };
  }

  // RDF / RSS 1.0
  if (doc["rdf:RDF"]) {
    const r = doc["rdf:RDF"];
    const items = asArray(r.item).map((it: any): ParsedItem => {
      const link = text(it.link);
      const titleStr = text(it.title) ?? "(untitled)";
      const summaryStr = stripHtml(text(it.description));
      let lat = null;
      let lon = null;
      const geo = extractGeo(titleStr + " " + (summaryStr ?? ""));
      if (geo) { lat = geo.lat; lon = geo.lon; }
      return {
        guid: link ?? text(it["@_rdf:about"]) ?? crypto.randomUUID(),
        title: titleStr,
        link,
        author: text(it["dc:creator"]),
        summary: summaryStr,
        publishedAt: toDate(text(it["dc:date"])),
        lat,
        lon,
      };
    });
    return { title: text(r.channel?.title), items };
  }

  return { title: null, items: [] };
}

const UAS = [
  "Mozilla/5.0 (compatible; PulseReader/1.0; +https://example.com/bot)",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
];

async function request(url: string, ua: string) {
  return fetch(url, {
    headers: {
      "user-agent": ua,
      accept:
        "application/rss+xml, application/atom+xml, application/xml;q=0.9, text/xml;q=0.9, text/html;q=0.8, */*;q=0.5",
      "accept-language": "en-US,en;q=0.9",
    },
    redirect: "follow",
    signal: AbortSignal.timeout(15000),
    cache: "no-store",
  });
}

/** Find <link rel="alternate" type="application/rss+xml" href="..."> in an HTML page. */
export function discoverFeedUrl(html: string, baseUrl: string): string | null {
  const linkTags = html.match(/<link\b[^>]*>/gi) ?? [];
  for (const tag of linkTags) {
    if (!/rel=["']?alternate/i.test(tag)) continue;
    if (!/type=["']?application\/(rss|atom)\+xml/i.test(tag)) continue;
    const href = tag.match(/href=["']([^"']+)["']/i)?.[1];
    if (href) {
      try {
        return new URL(href, baseUrl).toString();
      } catch {
        return null;
      }
    }
  }
  return null;
}

export async function fetchFeed(url: string, depth = 0): Promise<FetchedFeed> {
  let lastStatus = 0;
  for (const ua of UAS) {
    let res: Response;
    try {
      res = await request(url, ua);
    } catch (e) {
      if (ua === UAS[UAS.length - 1]) throw e;
      continue;
    }
    if (!res.ok) {
      lastStatus = res.status;
      continue;
    }
    const body = await res.text();
    const looksLikeHtml =
      /^\s*<(!doctype html|html)\b/i.test(body) ||
      (res.headers.get("content-type") ?? "").includes("text/html");

    if (looksLikeHtml && depth < 1) {
      const discovered = discoverFeedUrl(body, res.url || url);
      if (discovered && discovered !== url) return fetchFeed(discovered, depth + 1);
    }

    const parsed = parseFeedXml(body);
    if (parsed.items.length > 0 || !looksLikeHtml) return parsed;
    throw new Error("No feed items found at this URL");
  }
  throw new Error(lastStatus ? `HTTP ${lastStatus}` : "Request failed");
}
