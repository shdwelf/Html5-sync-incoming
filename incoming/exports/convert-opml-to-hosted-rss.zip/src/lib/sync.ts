import { db } from "@/db";
import { feeds, items } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { fetchFeed, type ParsedItem } from "@/lib/rss";

export async function saveItems(feedId: number, parsed: ParsedItem[]) {
  if (parsed.length === 0) return 0;
  const seen = new Set<string>();
  const values = parsed
    .filter((p) => {
      if (seen.has(p.guid)) return false;
      seen.add(p.guid);
      return true;
    })
    .slice(0, 100)
    .map((p) => ({
      feedId,
      guid: p.guid.slice(0, 500),
      title: p.title.slice(0, 500),
      link: p.link,
      author: p.author,
      summary: p.summary,
      publishedAt: p.publishedAt ?? new Date(),
      lat: p.lat,
      lon: p.lon,
    }));

  const inserted = await db
    .insert(items)
    .values(values)
    .onConflictDoNothing({ target: [items.feedId, items.guid] })
    .returning({ id: items.id });
  return inserted.length;
}

export async function refreshFeeds(ids?: number[]) {
  const list = ids?.length
    ? await db.select().from(feeds).where(inArray(feeds.id, ids))
    : await db.select().from(feeds);

  let newItems = 0;
  let failed = 0;
  const concurrency = 8;
  let cursor = 0;

  async function worker() {
    while (cursor < list.length) {
      const feed = list[cursor++];
      try {
        const parsed = await fetchFeed(feed.xmlUrl);
        newItems += await saveItems(feed.id, parsed.items);
        await db
          .update(feeds)
          .set({ lastFetchedAt: new Date(), lastError: null })
          .where(eq(feeds.id, feed.id));
      } catch (e) {
        failed++;
        await db
          .update(feeds)
          .set({
            lastFetchedAt: new Date(),
            lastError: e instanceof Error ? e.message : "unknown error",
          })
          .where(eq(feeds.id, feed.id));
      }
    }
  }

  await Promise.all(Array.from({ length: Math.min(concurrency, list.length) }, worker));
  return { feeds: list.length, newItems, failed };
}
