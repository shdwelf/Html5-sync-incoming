import { useEffect, useState } from "react";
import EnsoForge from "./components/EnsoForge";
import Vault from "./components/Vault";
import Terminal from "./components/Terminal";
import Exchange from "./components/Exchange";
import type { GeneratedWallet } from "./lib/wallet";
import { loadVault, saveVault } from "./lib/storage";

type Tab = "forge" | "vault" | "terminal" | "exchange";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "forge", label: "Ensō Forge", icon: "円" },
  { id: "vault", label: "Vault", icon: "🔐" },
  { id: "terminal", label: "Terminal / IRC", icon: "▣" },
  { id: "exchange", label: "Waves Exchange", icon: "≋" },
];

export default function App() {
  const [tab, setTab] = useState<Tab>("forge");
  const [vault, setVault] = useState<GeneratedWallet[]>([]);

  useEffect(() => {
    setVault(loadVault());
  }, []);

  useEffect(() => {
    saveVault(vault);
  }, [vault]);

  const mint = (w: GeneratedWallet) =>
    setVault((v) => [w, ...v].slice(0, 200));
  const del = (id: string) => setVault((v) => v.filter((w) => w.id !== id));
  const clear = () => {
    if (confirm("Delete all wallets from the vault?")) setVault([]);
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 bg-[radial-gradient(ellipse_at_top,rgba(16,185,129,0.08),transparent_60%)]">
      <header className="border-b border-stone-800 sticky top-0 z-10 backdrop-blur bg-stone-950/80">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-2xl text-emerald-400 font-serif">円</span>
            <div>
              <div className="font-semibold leading-tight">Ensō Haiku Wallet</div>
              <div className="text-[11px] text-stone-500 leading-tight">
                BIP-39/44 forge · offline standalone
              </div>
            </div>
          </div>
          <nav className="flex-1 flex justify-end gap-1 flex-wrap">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={
                  "px-3 py-1.5 rounded-lg text-sm transition-colors " +
                  (tab === t.id
                    ? "bg-emerald-600 text-white"
                    : "text-stone-400 hover:text-stone-100 hover:bg-stone-800")
                }
              >
                <span className="mr-1">{t.icon}</span>
                <span className="hidden sm:inline">{t.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        {tab === "forge" && <EnsoForge onMint={mint} />}
        {tab === "vault" && (
          <Vault vault={vault} onDelete={del} onClear={clear} />
        )}
        {tab === "terminal" && <Terminal vault={vault} />}
        {tab === "exchange" && <Exchange />}
      </main>

      <footer className="max-w-6xl mx-auto px-4 py-6 text-center text-[11px] text-stone-600">
        Standalone single-file build · All keys generated & stored locally ·
        Educational demo — not for storing real funds.
      </footer>
    </div>
  );
}
