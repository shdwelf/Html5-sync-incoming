import { wordlist } from "@scure/bip39/wordlists/english.js";
import {
  generateMnemonic,
  mnemonicToSeedSync,
  validateMnemonic,
  entropyToMnemonic,
} from "@scure/bip39";
import { HDKey } from "@scure/bip32";
import { sha256 } from "@noble/hashes/sha2.js";
import { ripemd160 } from "@noble/hashes/legacy.js";
import { mulberry32 } from "./enso";

export { wordlist };

// ---- Syllable counter (heuristic English) for authentic haiku 5-7-5 ----
export function countSyllables(word: string): number {
  word = word.toLowerCase().trim();
  if (!word) return 0;
  if (word.length <= 3) return 1;
  word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, "");
  word = word.replace(/^y/, "");
  const matches = word.match(/[aeiouy]{1,2}/g);
  let count = matches ? matches.length : 1;
  if (count < 1) count = 1;
  return count;
}

export function countLineSyllables(line: string): number {
  return line
    .split(/\s+/)
    .filter(Boolean)
    .reduce((sum, w) => sum + countSyllables(w), 0);
}

// ---- Wallet types & their derivation paths ----
export type WalletType = {
  id: string;
  name: string;
  path: string; // BIP-44 path
  coin: string;
  versionByte: number; // for P2PKH-style address prefix demo
};

export const WALLET_TYPES: WalletType[] = [
  { id: "btc", name: "Bitcoin (BIP-44)", path: "m/44'/0'/0'/0/0", coin: "BTC", versionByte: 0x00 },
  { id: "ltc", name: "Litecoin", path: "m/44'/2'/0'/0/0", coin: "LTC", versionByte: 0x30 },
  { id: "doge", name: "Dogecoin", path: "m/44'/3'/0'/0/0", coin: "DOGE", versionByte: 0x1e },
  { id: "eth", name: "Ethereum (BIP-44)", path: "m/44'/60'/0'/0/0", coin: "ETH", versionByte: 0x00 },
  { id: "dash", name: "Dash", path: "m/44'/5'/0'/0/0", coin: "DASH", versionByte: 0x4c },
];

// Base58 encoding for address display + checksum
const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function base58(bytes: Uint8Array): string {
  let num = BigInt("0x" + Buf2hex(bytes));
  let out = "";
  while (num > 0n) {
    const rem = Number(num % 58n);
    num = num / 58n;
    out = B58[rem] + out;
  }
  for (const b of bytes) {
    if (b === 0) out = "1" + out;
    else break;
  }
  return out;
}
function Buf2hex(b: Uint8Array): string {
  return Array.from(b)
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
}

// Build a checksummed base58check address from a pubkey (P2PKH-style demo)
export function pubkeyToAddress(pubkey: Uint8Array, versionByte: number): string {
  const h160 = ripemd160(sha256(pubkey));
  const payload = new Uint8Array(1 + h160.length);
  payload[0] = versionByte;
  payload.set(h160, 1);
  const checksum = sha256(sha256(payload)).slice(0, 4);
  const full = new Uint8Array(payload.length + 4);
  full.set(payload);
  full.set(checksum, payload.length);
  return base58(full);
}

export type GeneratedWallet = {
  id: string;
  ensoId: string;
  mnemonic: string;
  strength: number; // bits
  haiku: string[]; // 3 lines
  haikuSyllables: number[];
  haikuValid: boolean;
  wallets: { type: string; coin: string; path: string; address: string; xpriv: string }[];
  createdAt: number;
};

// Generate entropy deterministically from a seed integer (offline, reproducible)
function seededEntropy(seed: number, bytes: number): Uint8Array {
  const r = mulberry32(seed);
  const out = new Uint8Array(bytes);
  for (let i = 0; i < bytes; i++) out[i] = Math.floor(r() * 256);
  return out;
}

// Compose a 5-7-5 haiku from the mnemonic words, honoring syllable counts.
export function buildHaiku(mnemonic: string): {
  lines: string[];
  syllables: number[];
  valid: boolean;
} {
  const words = mnemonic.split(/\s+/).filter(Boolean);
  const targets = [5, 7, 5];
  const lines: string[] = [];
  let idx = 0;
  // Greedy: fill each line toward its syllable target, looping words.
  for (const target of targets) {
    let line: string[] = [];
    let count = 0;
    let guard = 0;
    while (count < target && guard < 50) {
      const w = words[idx % words.length];
      const s = countSyllables(w);
      if (count + s <= target || line.length === 0) {
        line.push(w);
        count += s;
        idx++;
      } else {
        idx++;
      }
      guard++;
      if (count >= target) break;
    }
    lines.push(line.join(" "));
  }
  const syllables = lines.map(countLineSyllables);
  const valid =
    syllables[0] === 5 && syllables[1] === 7 && syllables[2] === 5;
  return { lines, syllables, valid };
}

export function generateWallet(opts: {
  ensoId: string;
  seed?: number; // if given, deterministic; else random mnemonic
  strength?: number; // 128 | 256
  requireHaiku?: boolean; // keep regenerating (deterministic seed bump) until 5-7-5 valid
}): GeneratedWallet {
  const strength = opts.strength ?? 128;
  let mnemonic: string;
  let haiku = { lines: ["", "", ""], syllables: [0, 0, 0], valid: false };
  let attempts = 0;
  let seed = opts.seed;

  do {
    if (seed !== undefined) {
      const ent = seededEntropy(seed + attempts * 7919, strength / 8);
      mnemonic = entropyToMnemonic(ent, wordlist);
    } else {
      mnemonic = generateMnemonic(wordlist, strength);
    }
    haiku = buildHaiku(mnemonic);
    attempts++;
  } while (opts.requireHaiku && !haiku.valid && attempts < 200 && seed !== undefined);

  const masterSeed = mnemonicToSeedSync(mnemonic, opts.ensoId);
  const root = HDKey.fromMasterSeed(masterSeed);

  const wallets = WALLET_TYPES.map((wt) => {
    const child = root.derive(wt.path);
    const addr = child.publicKey
      ? pubkeyToAddress(child.publicKey, wt.versionByte)
      : "—";
    return {
      type: wt.name,
      coin: wt.coin,
      path: wt.path,
      address: addr,
      xpriv: child.privateExtendedKey.slice(0, 24) + "…",
    };
  });

  return {
    id: opts.ensoId + "-" + Date.now().toString(36),
    ensoId: opts.ensoId,
    mnemonic,
    strength,
    haiku: haiku.lines,
    haikuSyllables: haiku.syllables,
    haikuValid: haiku.valid,
    wallets,
    createdAt: Date.now(),
  };
}

export function isValidMnemonic(m: string): boolean {
  return validateMnemonic(m, wordlist);
}
