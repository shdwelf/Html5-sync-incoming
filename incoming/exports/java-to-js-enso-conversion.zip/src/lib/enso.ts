// Ensō parameter system — each generated ensō has a deterministic "terrain ID"
// (like the seed-based terrain ID in Worms Armageddon) that doubles as the
// master vault password used to unlock the haiku wallet.

export type EnsoParams = {
  inkLoad: number; // 0-10
  direction: number; // 0 = Clockwise, 1 = Counter-Clockwise
  paperHue: number; // index into PAPER_HUES
  brushSize: number; // 1-12
  inkDensity: number; // 1-6
  stretchUnequal: number; // 0 = Equal, 1 = Unequal
  paperTexture: number; // 1-8
  bristleDensity: number; // 1-9
  signatureDark: number; // 0 = Light, 1 = Dark
  brushstrokeSize: number; // index into STROKE_SIZES
  startRotation: number; // 0-359 degrees
};

export const PAPER_HUES = [
  { name: "Cyan", h: 186 },
  { name: "Indigo", h: 240 },
  { name: "Crimson", h: 350 },
  { name: "Jade", h: 150 },
  { name: "Amber", h: 38 },
  { name: "Violet", h: 280 },
  { name: "Sumi", h: 30 },
  { name: "Sky", h: 205 },
];

export const STROKE_SIZES = ["Fine", "Small", "Medium", "Bold", "Massive"];
export const DIRECTIONS = ["Clockwise", "Counter-Clockwise"];
export const STRETCH = ["Equal", "Unequal"];
export const SIGNATURE = ["Light", "Dark"];

// The canonical "default" preset described in the spec.
export const DEFAULT_PARAMS: EnsoParams = {
  inkLoad: 4,
  direction: 0, // Clockwise
  paperHue: 0, // Cyan
  brushSize: 6,
  inkDensity: 3,
  stretchUnequal: 1, // Unequal
  paperTexture: 4,
  bristleDensity: 5,
  signatureDark: 1, // Dark
  brushstrokeSize: 2, // Medium
  startRotation: 216,
};

// ---- Deterministic PRNG (mulberry32) ----
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashStringToSeed(str: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// Generate random params from a numeric seed.
export function paramsFromSeed(seed: number): EnsoParams {
  const r = mulberry32(seed);
  const pick = (n: number) => Math.floor(r() * n);
  return {
    inkLoad: pick(11),
    direction: pick(2),
    paperHue: pick(PAPER_HUES.length),
    brushSize: 1 + pick(12),
    inkDensity: 1 + pick(6),
    stretchUnequal: pick(2),
    paperTexture: 1 + pick(8),
    bristleDensity: 1 + pick(9),
    signatureDark: pick(2),
    brushstrokeSize: pick(STROKE_SIZES.length),
    startRotation: pick(360),
  };
}

// Pack params into a compact base-36 "Ensō ID" (the terrain master password).
export function encodeEnsoId(p: EnsoParams): string {
  // Pack each field into a big integer with fixed radixes.
  const fields: [number, number][] = [
    [p.inkLoad, 11],
    [p.direction, 2],
    [p.paperHue, PAPER_HUES.length],
    [p.brushSize, 13],
    [p.inkDensity, 7],
    [p.stretchUnequal, 2],
    [p.paperTexture, 9],
    [p.bristleDensity, 10],
    [p.signatureDark, 2],
    [p.brushstrokeSize, STROKE_SIZES.length],
    [p.startRotation, 360],
  ];
  let value = 0n;
  for (const [v, radix] of fields) {
    value = value * BigInt(radix) + BigInt(Math.max(0, Math.min(radix - 1, v)));
  }
  const raw = value.toString(36).toUpperCase().padStart(8, "0");
  // Format like ENSO-XXXX-XXXX for flavor.
  const groups = raw.match(/.{1,4}/g) || [raw];
  return "ENSO-" + groups.join("-");
}

export function decodeEnsoId(id: string): EnsoParams | null {
  try {
    const raw = id.replace(/^ENSO-/i, "").replace(/-/g, "").toLowerCase();
    if (!/^[0-9a-z]+$/.test(raw)) return null;
    let value = BigInt(0);
    for (const ch of raw) {
      const d = parseInt(ch, 36);
      value = value * 36n + BigInt(d);
    }
    const radixes = [
      11,
      2,
      PAPER_HUES.length,
      13,
      7,
      2,
      9,
      10,
      2,
      STROKE_SIZES.length,
      360,
    ];
    const out: number[] = [];
    for (let i = radixes.length - 1; i >= 0; i--) {
      const radix = BigInt(radixes[i]);
      out[i] = Number(value % radix);
      value = value / radix;
    }
    return {
      inkLoad: out[0],
      direction: out[1],
      paperHue: out[2],
      brushSize: out[3],
      inkDensity: out[4],
      stretchUnequal: out[5],
      paperTexture: out[6],
      bristleDensity: out[7],
      signatureDark: out[8],
      brushstrokeSize: out[9],
      startRotation: out[10],
    };
  } catch {
    return null;
  }
}
