import CryptoJS from "crypto-js";
import type { GeneratedWallet } from "./wallet";

const COOKIE_KEY = "enso_haiku_vault";
const COOKIE_DAYS = 365;

// Master key for at-rest cookie encryption (derived from a device-local salt).
function deviceKey(): string {
  let salt = localStorage.getItem("enso_device_salt");
  if (!salt) {
    salt =
      CryptoJS.lib.WordArray.random(16).toString() +
      navigator.userAgent.slice(0, 12);
    localStorage.setItem("enso_device_salt", salt);
  }
  return salt;
}

export function encryptText(plain: string, passphrase: string): string {
  // AES-256 via CryptoJS (PBKDF2-derived key under the hood with salt).
  return CryptoJS.AES.encrypt(plain, passphrase).toString();
}

export function decryptText(cipher: string, passphrase: string): string {
  const bytes = CryptoJS.AES.decrypt(cipher, passphrase);
  return bytes.toString(CryptoJS.enc.Utf8);
}

// ---- Cookie helpers (encrypted at rest with device key) ----
function setCookie(name: string, value: string, days: number) {
  const d = new Date();
  d.setTime(d.getTime() + days * 864e5);
  document.cookie = `${name}=${encodeURIComponent(
    value
  )};expires=${d.toUTCString()};path=/;SameSite=Lax`;
}
function getCookie(name: string): string | null {
  const match = document.cookie.match(
    new RegExp("(?:^|; )" + name + "=([^;]*)")
  );
  return match ? decodeURIComponent(match[1]) : null;
}

export function saveVault(wallets: GeneratedWallet[]) {
  const json = JSON.stringify(wallets);
  const enc = encryptText(json, deviceKey());
  try {
    setCookie(COOKIE_KEY, enc, COOKIE_DAYS);
  } catch {
    /* cookie too large — fall through */
  }
  // Mirror to localStorage for large vaults (cookies have ~4KB limit).
  try {
    localStorage.setItem(COOKIE_KEY, enc);
  } catch {
    /* ignore */
  }
}

export function loadVault(): GeneratedWallet[] {
  let enc = getCookie(COOKIE_KEY);
  if (!enc) enc = localStorage.getItem(COOKIE_KEY);
  if (!enc) return [];
  try {
    const json = decryptText(enc, deviceKey());
    return JSON.parse(json) as GeneratedWallet[];
  } catch {
    return [];
  }
}

export function downloadFile(filename: string, content: string, mime = "text/plain") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportVaultTxt(
  wallets: GeneratedWallet[],
  passphrase: string
): string {
  const lines: string[] = [];
  lines.push("===== ENSŌ HAIKU VAULT EXPORT =====");
  lines.push("Generated: " + new Date().toISOString());
  lines.push("Wallets: " + wallets.length);
  lines.push("");
  for (const w of wallets) {
    lines.push("Ensō ID : " + w.ensoId);
    lines.push("Strength: " + w.strength + " bits");
    lines.push("Haiku   :");
    w.haiku.forEach((l, i) =>
      lines.push("   " + l + "   (" + w.haikuSyllables[i] + ")")
    );
    lines.push("Mnemonic: " + w.mnemonic);
    w.wallets.forEach((c) =>
      lines.push(`   ${c.coin.padEnd(5)} ${c.path}  ${c.address}`)
    );
    lines.push("");
  }
  const plain = lines.join("\n");
  return passphrase ? encryptText(plain, passphrase) : plain;
}
