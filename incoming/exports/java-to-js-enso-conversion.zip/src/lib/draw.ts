import { type EnsoParams, PAPER_HUES, mulberry32, encodeEnsoId } from "./enso";

// Renders an ensō (Zen circle) onto a canvas based on the parameter set.
export function drawEnso(
  canvas: HTMLCanvasElement,
  p: EnsoParams,
  size = 512
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  canvas.width = size;
  canvas.height = size;
  const cx = size / 2;
  const cy = size / 2;
  const baseR = size * 0.32;

  const hue = PAPER_HUES[p.paperHue % PAPER_HUES.length].h;

  // Paper background with texture grain.
  const lightness = p.signatureDark ? 14 : 96;
  ctx.fillStyle = `hsl(${hue} 18% ${p.signatureDark ? 10 : 97}%)`;
  ctx.fillRect(0, 0, size, size);

  // Texture: fibrous paper noise driven by paperTexture.
  const seed = (encodeEnsoIdNum(p) >>> 0) || 1;
  const r = mulberry32(seed);
  const grains = p.paperTexture * 1400;
  for (let i = 0; i < grains; i++) {
    const x = r() * size;
    const y = r() * size;
    const a = r() * 0.05 * (p.paperTexture / 8);
    ctx.fillStyle = p.signatureDark
      ? `rgba(255,255,255,${a})`
      : `rgba(0,0,0,${a})`;
    ctx.fillRect(x, y, 1, 1);
  }

  // Ink color
  const inkL = p.signatureDark ? 88 : 12;
  const inkColor = `hsl(${hue} 30% ${inkL}%)`;

  // Brush stroke: many overlapping arc segments to simulate bristles.
  const dir = p.direction === 0 ? 1 : -1;
  const startAngle = (p.startRotation * Math.PI) / 180;
  // Ensō is an (almost) closed circle with a gap (incompleteness).
  const gap = 0.18 + r() * 0.22;
  const sweep = (Math.PI * 2 - gap) * dir;

  const strokeScale = [0.5, 0.75, 1, 1.4, 1.9][p.brushstrokeSize] ?? 1;
  const baseWidth = p.brushSize * 2 * strokeScale;
  const bristles = p.bristleDensity * 4;
  const stretchX = p.stretchUnequal ? 1.12 : 1;
  const stretchY = p.stretchUnequal ? 0.9 : 1;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.lineCap = "round";

  const steps = 240;
  for (let b = 0; b < bristles; b++) {
    const offset = (b / bristles - 0.5) * baseWidth;
    const jitter = (r() - 0.5) * 4;
    ctx.beginPath();
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const ang = startAngle + sweep * t;
      // Ink load tapers the stroke at start & end (dry brush effect).
      const taper = Math.sin(Math.PI * t);
      const wobble =
        Math.sin(t * Math.PI * (6 + p.inkDensity)) * (3 + p.brushSize * 0.3);
      const rr = baseR + offset + wobble + jitter;
      const x = Math.cos(ang) * rr * stretchX;
      const y = Math.sin(ang) * rr * stretchY;
      if (s === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      // Vary alpha per-bristle to mimic ink density & load.
      if (s % 8 === 0) {
        ctx.strokeStyle = inkColor;
        const alpha =
          0.04 +
          (p.inkDensity / 6) * 0.12 * taper +
          (p.inkLoad / 10) * 0.06 * taper;
        ctx.globalAlpha = Math.min(0.9, alpha + r() * 0.04);
        ctx.lineWidth = 1 + r() * 1.5;
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, y);
      }
    }
    ctx.strokeStyle = inkColor;
    ctx.globalAlpha = Math.min(0.9, 0.05 + (p.inkLoad / 10) * 0.1);
    ctx.lineWidth = 1 + r();
    ctx.stroke();
  }

  // Ink splatter near the brush start (load 4 = moderate).
  ctx.globalAlpha = 1;
  const splats = p.inkLoad * 3;
  const sAng = startAngle;
  for (let i = 0; i < splats; i++) {
    const rr = baseR + (r() - 0.5) * baseWidth * 2.4;
    const a = sAng + (r() - 0.5) * 0.5;
    const x = Math.cos(a) * rr * stretchX;
    const y = Math.sin(a) * rr * stretchY;
    ctx.beginPath();
    ctx.fillStyle = inkColor;
    ctx.globalAlpha = 0.3 * r();
    ctx.arc(x, y, r() * 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();

  // Signature seal (red hanko) — bottom right.
  const sealSize = size * 0.07;
  ctx.globalAlpha = 0.92;
  ctx.fillStyle = "hsl(355 70% 45%)";
  roundRect(ctx, size - sealSize - 24, size - sealSize - 24, sealSize, sealSize, 4);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  ctx.font = `${sealSize * 0.5}px serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("円", size - sealSize / 2 - 24, size - sealSize / 2 - 24);
  ctx.globalAlpha = 1;
  void lightness;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function encodeEnsoIdNum(p: EnsoParams): number {
  // Stable numeric seed from the formatted ID.
  const id = encodeEnsoId(p);
  let h = 2166136261 >>> 0;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function downloadCanvasPng(canvas: HTMLCanvasElement, filename: string) {
  const url = canvas.toDataURL("image/png");
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
}
