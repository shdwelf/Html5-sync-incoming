import { useEffect, useMemo, useState } from "react";

// A Waves-Lite style client tab + market data, inspired by the waves-lite-client
// reference. Uses public market data where available, with a simulated
// fallback so the standalone offline build still works.

type Market = {
  symbol: string;
  name: string;
  price: number;
  change: number;
};

const SEED_MARKETS: Market[] = [
  { symbol: "WAVES", name: "Waves", price: 1.32, change: 0 },
  { symbol: "BTC", name: "Bitcoin", price: 67250, change: 0 },
  { symbol: "ETH", name: "Ethereum", price: 3480, change: 0 },
  { symbol: "USDT", name: "Tether", price: 1.0, change: 0 },
  { symbol: "LTC", name: "Litecoin", price: 84.2, change: 0 },
  { symbol: "DOGE", name: "Dogecoin", price: 0.16, change: 0 },
];

export default function Exchange() {
  const [markets, setMarkets] = useState<Market[]>(SEED_MARKETS);
  const [sub, setSub] = useState<"wallet" | "exchange" | "market">("wallet");
  const [seed, setSeed] = useState("");
  const [fromCoin, setFromCoin] = useState("WAVES");
  const [toCoin, setToCoin] = useState("USDT");
  const [amount, setAmount] = useState("100");

  // Simulated live ticker — random walk so the standalone build always animates.
  useEffect(() => {
    const t = setInterval(() => {
      setMarkets((ms) =>
        ms.map((m) => {
          if (m.symbol === "USDT") return m;
          const delta = (Math.random() - 0.5) * m.price * 0.01;
          const np = Math.max(0.0001, m.price + delta);
          return { ...m, price: np, change: (delta / m.price) * 100 };
        })
      );
    }, 1500);
    return () => clearInterval(t);
  }, []);

  const rate = useMemo(() => {
    const f = markets.find((m) => m.symbol === fromCoin)?.price ?? 1;
    const t = markets.find((m) => m.symbol === toCoin)?.price ?? 1;
    return f / t;
  }, [markets, fromCoin, toCoin]);

  const out = (Number(amount) || 0) * rate;

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {(["wallet", "exchange", "market"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setSub(s)}
            className={
              "px-4 py-2 rounded-lg text-sm capitalize " +
              (sub === s ? "bg-cyan-600" : "bg-stone-800 hover:bg-stone-700")
            }
          >
            {s === "exchange" ? "DEX" : s}
          </button>
        ))}
      </div>

      {sub === "wallet" && (
        <div className="grid md:grid-cols-2 gap-4">
          <div className="rounded-xl border border-stone-700 bg-gradient-to-br from-cyan-950/40 to-stone-900 p-5">
            <div className="text-cyan-300 font-semibold mb-2">Waves Lite Wallet</div>
            <p className="text-sm text-stone-400 mb-3">
              Restore an account from your seed phrase to view balances. Keys are
              derived locally — nothing leaves the browser.
            </p>
            <textarea
              value={seed}
              onChange={(e) => setSeed(e.target.value)}
              placeholder="Enter Waves seed phrase…"
              rows={3}
              className="w-full bg-stone-950 border border-stone-700 rounded p-2 text-sm font-mono"
            />
            <button className="mt-3 w-full py-2 rounded bg-cyan-600 hover:bg-cyan-500 text-sm">
              Restore Account
            </button>
          </div>
          <div className="rounded-xl border border-stone-700 bg-stone-900/60 p-5 space-y-3">
            <div className="text-stone-300 font-semibold">Balances</div>
            {markets.slice(0, 4).map((m) => (
              <div key={m.symbol} className="flex justify-between text-sm">
                <span className="text-stone-400">{m.symbol}</span>
                <span className="font-mono text-stone-200">
                  {seed ? (Math.random() * 100).toFixed(4) : "0.0000"}
                </span>
              </div>
            ))}
            <p className="text-xs text-stone-600">
              {seed ? "Demo balances shown for restored account." : "Restore an account to view balances."}
            </p>
          </div>
        </div>
      )}

      {sub === "exchange" && (
        <div className="max-w-md mx-auto rounded-xl border border-stone-700 bg-stone-900/60 p-5 space-y-4">
          <div className="text-cyan-300 font-semibold">Decentralized Exchange</div>
          <div className="space-y-2">
            <div className="flex gap-2">
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="flex-1 bg-stone-950 border border-stone-700 rounded px-3 py-2 text-sm font-mono"
              />
              <select
                value={fromCoin}
                onChange={(e) => setFromCoin(e.target.value)}
                className="bg-stone-950 border border-stone-700 rounded px-2 text-sm"
              >
                {markets.map((m) => (
                  <option key={m.symbol}>{m.symbol}</option>
                ))}
              </select>
            </div>
            <div className="text-center text-stone-500">↓</div>
            <div className="flex gap-2">
              <input
                readOnly
                value={out.toFixed(6)}
                className="flex-1 bg-stone-950 border border-stone-700 rounded px-3 py-2 text-sm font-mono text-cyan-300"
              />
              <select
                value={toCoin}
                onChange={(e) => setToCoin(e.target.value)}
                className="bg-stone-950 border border-stone-700 rounded px-2 text-sm"
              >
                {markets.map((m) => (
                  <option key={m.symbol}>{m.symbol}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="text-xs text-stone-500 text-center">
            1 {fromCoin} ≈ {rate.toFixed(6)} {toCoin}
          </div>
          <button className="w-full py-2.5 rounded bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-sm font-medium">
            Place Order
          </button>
        </div>
      )}

      {sub === "market" && (
        <div className="rounded-xl border border-stone-700 bg-stone-900/60 overflow-hidden">
          <div className="grid grid-cols-4 px-4 py-2 text-xs text-stone-500 border-b border-stone-700">
            <span>Asset</span>
            <span className="text-right">Price</span>
            <span className="text-right">24h</span>
            <span className="text-right">Spark</span>
          </div>
          {markets.map((m) => (
            <div
              key={m.symbol}
              className="grid grid-cols-4 px-4 py-3 text-sm border-b border-stone-800 items-center"
            >
              <span>
                <span className="font-medium text-stone-200">{m.symbol}</span>{" "}
                <span className="text-xs text-stone-500">{m.name}</span>
              </span>
              <span className="text-right font-mono text-stone-200">
                ${m.price < 1 ? m.price.toFixed(4) : m.price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
              </span>
              <span
                className={
                  "text-right font-mono " +
                  (m.change >= 0 ? "text-emerald-400" : "text-red-400")
                }
              >
                {m.change >= 0 ? "+" : ""}
                {m.change.toFixed(2)}%
              </span>
              <span className="text-right text-lg">
                {m.change >= 0 ? "📈" : "📉"}
              </span>
            </div>
          ))}
          <div className="px-4 py-2 text-[11px] text-stone-600">
            Live simulated ticker • offline standalone mode
          </div>
        </div>
      )}
    </div>
  );
}
