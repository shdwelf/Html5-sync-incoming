import { useEffect, useRef, useState } from "react";
import type { GeneratedWallet } from "../lib/wallet";

type Line = { text: string; cls?: string };

type Props = {
  vault: GeneratedWallet[];
};

// PIM (Personal Information Manager) command-line port — the GUI build is
// commented out; this runs the CLI variant in the browser. Includes an IRC
// chat client that connects over WebSocket.
export default function Terminal({ vault }: Props) {
  const [lines, setLines] = useState<Line[]>([
    { text: "PIM CLI v0.alpha — GUI build disabled, command-line mode active.", cls: "text-emerald-400" },
    { text: "Type 'help' for commands. Use 'irc' to open the chat window.", cls: "text-stone-500" },
  ]);
  const [input, setInput] = useState("");
  const [ircOpen, setIrcOpen] = useState(false);
  const [ircNick, setIrcNick] = useState("enso" + Math.floor(Math.random() * 9999));
  const [ircChan, setIrcChan] = useState("#enso");
  const [ircServer, setIrcServer] = useState("wss://irc.example.org/ws");
  const [ircConnected, setIrcConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [lines]);

  const print = (text: string, cls?: string) =>
    setLines((l) => [...l, { text, cls }]);

  const ircSend = (raw: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(raw + "\r\n");
      print("→ " + raw, "text-sky-400");
    } else {
      print("[irc] not connected", "text-amber-400");
    }
  };

  const connectIrc = () => {
    print(`[irc] connecting to ${ircServer} …`, "text-stone-400");
    try {
      const ws = new WebSocket(ircServer);
      wsRef.current = ws;
      ws.onopen = () => {
        setIrcConnected(true);
        print("[irc] socket open — registering", "text-emerald-400");
        ws.send(`NICK ${ircNick}\r\n`);
        ws.send(`USER ${ircNick} 0 * :Ensō PIM client\r\n`);
        setTimeout(() => ws.send(`JOIN ${ircChan}\r\n`), 600);
      };
      ws.onmessage = (ev) => {
        const data = typeof ev.data === "string" ? ev.data : "";
        data.split(/\r?\n/).filter(Boolean).forEach((msg) => {
          // Respond to server PING to stay connected.
          if (msg.startsWith("PING")) {
            ws.send("PONG" + msg.slice(4) + "\r\n");
            return;
          }
          const m = msg.match(/^:(\S+?)!\S+ PRIVMSG (\S+) :(.*)$/);
          if (m) print(`<${m[1]}> ${m[3]}`, "text-stone-200");
          else print(msg, "text-stone-500");
        });
      };
      ws.onerror = () => print("[irc] websocket error", "text-red-400");
      ws.onclose = () => {
        setIrcConnected(false);
        print("[irc] disconnected", "text-amber-400");
      };
    } catch (e) {
      print("[irc] failed: " + String(e), "text-red-400");
    }
  };

  const disconnectIrc = () => {
    wsRef.current?.close();
    wsRef.current = null;
    setIrcConnected(false);
  };

  const run = (cmd: string) => {
    const [c, ...rest] = cmd.trim().split(/\s+/);
    const arg = rest.join(" ");
    print("$ " + cmd, "text-stone-400");
    switch (c) {
      case "":
        break;
      case "help":
        print("Commands:", "text-emerald-400");
        print("  help            this message");
        print("  ls / list       list vault wallets");
        print("  show <n>        show wallet #n haiku & addresses");
        print("  enso <n>        print ensō id of wallet #n");
        print("  count           number of collectibles");
        print("  irc             open IRC chat window");
        print("  msg <text>      send message to current IRC channel");
        print("  date / whoami / clear / about");
        break;
      case "ls":
      case "list":
        if (!vault.length) print("(vault empty)");
        vault.forEach((w, i) =>
          print(`  [${i}] ${w.ensoId}  ${w.haikuValid ? "5-7-5" : "≈"}  ${w.strength}bit`)
        );
        break;
      case "show": {
        const w = vault[Number(arg)];
        if (!w) { print("no such wallet", "text-red-400"); break; }
        w.haiku.forEach((l) => print("  " + l, "text-emerald-200"));
        w.wallets.forEach((x) => print(`  ${x.coin}: ${x.address}`));
        break;
      }
      case "enso": {
        const w = vault[Number(arg)];
        print(w ? w.ensoId : "no such wallet", w ? "text-emerald-300" : "text-red-400");
        break;
      }
      case "count":
        print(String(vault.length));
        break;
      case "irc":
        setIrcOpen(true);
        print("[irc] chat window opened — configure & connect below.", "text-sky-400");
        break;
      case "msg":
        ircSend(`PRIVMSG ${ircChan} :${arg}`);
        break;
      case "date":
        print(new Date().toString());
        break;
      case "whoami":
        print(ircNick);
        break;
      case "about":
        print("PIM — handcrafted Java→JS port. CLI + IRC over WebSocket.", "text-emerald-400");
        break;
      case "clear":
        setLines([]);
        break;
      default:
        print(`pim: command not found: ${c}`, "text-red-400");
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 rounded-xl border border-stone-700 bg-black/80 font-mono text-sm overflow-hidden flex flex-col h-[28rem]">
        <div className="px-3 py-2 bg-stone-900 border-b border-stone-700 text-xs text-stone-400 flex justify-between">
          <span>pim@browser:~</span>
          <span className={ircConnected ? "text-emerald-400" : "text-stone-600"}>
            irc: {ircConnected ? "connected" : "offline"}
          </span>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {lines.map((l, i) => (
            <div key={i} className={l.cls ?? "text-stone-300"}>
              {l.text}
            </div>
          ))}
          <div ref={endRef} />
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run(input);
            setInput("");
          }}
          className="flex border-t border-stone-700"
        >
          <span className="px-3 py-2 text-emerald-400">$</span>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            autoFocus
            className="flex-1 bg-transparent py-2 pr-3 outline-none text-stone-100"
            placeholder="type a command…"
          />
        </form>
      </div>

      <div className="rounded-xl border border-stone-700 bg-stone-900/60 p-4 space-y-3">
        <div className="text-sm font-medium text-sky-300">IRC Chat Window</div>
        {!ircOpen && (
          <p className="text-xs text-stone-500">
            Run <code className="text-emerald-400">irc</code> in the terminal to
            open the chat panel.
          </p>
        )}
        {ircOpen && (
          <div className="space-y-2 text-sm">
            <label className="block">
              <span className="text-xs text-stone-400">WebSocket server</span>
              <input
                value={ircServer}
                onChange={(e) => setIrcServer(e.target.value)}
                className="w-full mt-1 bg-stone-950 border border-stone-700 rounded px-2 py-1 text-xs"
              />
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label className="block">
                <span className="text-xs text-stone-400">Nick</span>
                <input
                  value={ircNick}
                  onChange={(e) => setIrcNick(e.target.value)}
                  className="w-full mt-1 bg-stone-950 border border-stone-700 rounded px-2 py-1 text-xs"
                />
              </label>
              <label className="block">
                <span className="text-xs text-stone-400">Channel</span>
                <input
                  value={ircChan}
                  onChange={(e) => setIrcChan(e.target.value)}
                  className="w-full mt-1 bg-stone-950 border border-stone-700 rounded px-2 py-1 text-xs"
                />
              </label>
            </div>
            {!ircConnected ? (
              <button
                onClick={connectIrc}
                className="w-full py-2 rounded bg-sky-600 hover:bg-sky-500 text-sm"
              >
                Connect
              </button>
            ) : (
              <>
                <button
                  onClick={() => ircSend(`JOIN ${ircChan}`)}
                  className="w-full py-1.5 rounded bg-stone-700 hover:bg-stone-600 text-xs"
                >
                  Join {ircChan}
                </button>
                <button
                  onClick={disconnectIrc}
                  className="w-full py-2 rounded bg-red-900/60 hover:bg-red-800 text-sm"
                >
                  Disconnect
                </button>
                <p className="text-[11px] text-stone-500">
                  Use <code className="text-emerald-400">msg &lt;text&gt;</code> in
                  the terminal to chat.
                </p>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
