import { useEffect, useRef, useState } from "react";
import {
  type EnsoParams,
  DEFAULT_PARAMS,
  PAPER_HUES,
  STROKE_SIZES,
  DIRECTIONS,
  STRETCH,
  SIGNATURE,
  paramsFromSeed,
  encodeEnsoId,
  decodeEnsoId,
} from "../lib/enso";
import { drawEnso, downloadCanvasPng } from "../lib/draw";
import { generateWallet, isValidMnemonic, type GeneratedWallet } from "../lib/wallet";

type Props = {
  onMint: (w: GeneratedWallet) => void;
};

function Slider({
  label,
  value,
  min,
  max,
  onChange,
  display,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (n: number) => void;
  display?: string;
}) {
  return (
    <label className="block">
      <div className="flex justify-between text-xs text-stone-400 mb-1">
        <span>{label}</span>
        <span className="font-mono text-emerald-300">{display ?? value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-emerald-400"
      />
    </label>
  );
}

export default function EnsoForge({ onMint }: Props) {
  const [params, setParams] = useState<EnsoParams>(DEFAULT_PARAMS);
  const [seed, setSeed] = useState<number>(216);
  const [strength, setStrength] = useState<128 | 256>(128);
  const [requireHaiku, setRequireHaiku] = useState(true);
  const [batch, setBatch] = useState(1);
  const [forging, setForging] = useState(false);
  const [current, setCurrent] = useState<GeneratedWallet | null>(null);
  const [idInput, setIdInput] = useState("");
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const ensoId = encodeEnsoId(params);

  useEffect(() => {
    if (canvasRef.current) drawEnso(canvasRef.current, params);
  }, [params]);

  const set = (patch: Partial<EnsoParams>) =>
    setParams((p) => ({ ...p, ...patch }));

  const randomize = () => {
    const s = Math.floor(Math.random() * 0xffffffff);
    setSeed(s);
    setParams(paramsFromSeed(s));
  };

  const applyId = () => {
    const decoded = decodeEnsoId(idInput.trim());
    if (decoded) {
      setParams(decoded);
    } else {
      alert("Invalid Ensō ID. Format: ENSO-XXXX-XXXX");
    }
  };

  const forge = async () => {
    setForging(true);
    setCurrent(null);
    // brief forging animation delay
    await new Promise((r) => setTimeout(r, 900));
    const wallets: GeneratedWallet[] = [];
    for (let i = 0; i < batch; i++) {
      const w = generateWallet({
        ensoId: i === 0 ? ensoId : ensoId + "-" + i,
        seed: seed + i * 104729,
        strength,
        requireHaiku,
      });
      wallets.push(w);
    }
    setCurrent(wallets[0]);
    wallets.forEach(onMint);
    setForging(false);
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* LEFT — Ensō canvas & ID */}
      <div className="space-y-4">
        <div className="relative rounded-2xl overflow-hidden border border-stone-700 bg-stone-950 shadow-2xl">
          <canvas
            ref={canvasRef}
            className={
              "w-full aspect-square transition-opacity duration-500 " +
              (forging ? "animate-pulse opacity-60" : "opacity-100")
            }
          />
          {forging && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-40 w-40 rounded-full border-4 border-emerald-400/40 border-t-emerald-300 animate-spin" />
              <span className="absolute text-emerald-200 text-sm tracking-widest">
                FORGING 円
              </span>
            </div>
          )}
        </div>

        <div className="rounded-xl border border-stone-700 bg-stone-900/60 p-4">
          <div className="text-xs text-stone-400 mb-1">
            Ensō ID — master vault password (terrain seed)
          </div>
          <div className="flex items-center gap-2">
            <code className="flex-1 font-mono text-emerald-300 text-lg tracking-wide break-all">
              {ensoId}
            </code>
            <button
              onClick={() => navigator.clipboard?.writeText(ensoId)}
              className="px-3 py-1 text-xs rounded bg-stone-700 hover:bg-stone-600"
            >
              Copy
            </button>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={randomize}
            className="flex-1 py-2 rounded-lg bg-stone-700 hover:bg-stone-600 text-sm"
          >
            🎲 Random Seed
          </button>
          <button
            onClick={() =>
              canvasRef.current &&
              downloadCanvasPng(canvasRef.current, ensoId + ".png")
            }
            className="flex-1 py-2 rounded-lg bg-stone-700 hover:bg-stone-600 text-sm"
          >
            ⬇ Download PNG
          </button>
        </div>

        <div className="flex gap-2">
          <input
            value={idInput}
            onChange={(e) => setIdInput(e.target.value)}
            placeholder="Enter Ensō ID to unlock…"
            className="flex-1 px-3 py-2 rounded-lg bg-stone-900 border border-stone-700 text-sm font-mono"
          />
          <button
            onClick={applyId}
            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-sm"
          >
            Unlock
          </button>
        </div>
      </div>

      {/* RIGHT — controls + result */}
      <div className="space-y-4">
        <div className="rounded-xl border border-stone-700 bg-stone-900/60 p-4 grid grid-cols-2 gap-4">
          <Slider label="Ink Load" value={params.inkLoad} min={0} max={10} onChange={(v) => set({ inkLoad: v })} />
          <label className="block">
            <div className="text-xs text-stone-400 mb-1">Direction</div>
            <select
              value={params.direction}
              onChange={(e) => set({ direction: Number(e.target.value) })}
              className="w-full bg-stone-900 border border-stone-700 rounded px-2 py-1.5 text-sm"
            >
              {DIRECTIONS.map((d, i) => (
                <option key={d} value={i}>{d}</option>
              ))}
            </select>
          </label>
          <label className="block">
            <div className="text-xs text-stone-400 mb-1">Paper Hue</div>
            <select
              value={params.paperHue}
              onChange={(e) => set({ paperHue: Number(e.target.value) })}
              className="w-full bg-stone-900 border border-stone-700 rounded px-2 py-1.5 text-sm"
            >
              {PAPER_HUES.map((h, i) => (
                <option key={h.name} value={i}>{h.name}</option>
              ))}
            </select>
          </label>
          <Slider label="Brush Size" value={params.brushSize} min={1} max={12} onChange={(v) => set({ brushSize: v })} />
          <Slider label="Ink Density" value={params.inkDensity} min={1} max={6} onChange={(v) => set({ inkDensity: v })} />
          <label className="block">
            <div className="text-xs text-stone-400 mb-1">X/Y Stretch</div>
            <select
              value={params.stretchUnequal}
              onChange={(e) => set({ stretchUnequal: Number(e.target.value) })}
              className="w-full bg-stone-900 border border-stone-700 rounded px-2 py-1.5 text-sm"
            >
              {STRETCH.map((d, i) => (
                <option key={d} value={i}>{d}</option>
              ))}
            </select>
          </label>
          <Slider label="Paper Texture" value={params.paperTexture} min={1} max={8} onChange={(v) => set({ paperTexture: v })} />
          <Slider label="Bristle Density" value={params.bristleDensity} min={1} max={9} onChange={(v) => set({ bristleDensity: v })} />
          <label className="block">
            <div className="text-xs text-stone-400 mb-1">Signature Style</div>
            <select
              value={params.signatureDark}
              onChange={(e) => set({ signatureDark: Number(e.target.value) })}
              className="w-full bg-stone-900 border border-stone-700 rounded px-2 py-1.5 text-sm"
            >
              {SIGNATURE.map((d, i) => (
                <option key={d} value={i}>{d}</option>
              ))}
            </select>
          </label>
          <label className="block">
            <div className="text-xs text-stone-400 mb-1">Brushstroke Size</div>
            <select
              value={params.brushstrokeSize}
              onChange={(e) => set({ brushstrokeSize: Number(e.target.value) })}
              className="w-full bg-stone-900 border border-stone-700 rounded px-2 py-1.5 text-sm"
            >
              {STROKE_SIZES.map((d, i) => (
                <option key={d} value={i}>{d}</option>
              ))}
            </select>
          </label>
          <Slider
            label="Brushstroke Start"
            value={params.startRotation}
            min={0}
            max={359}
            onChange={(v) => set({ startRotation: v })}
            display={params.startRotation + "°"}
          />
        </div>

        {/* Wallet forge controls */}
        <div className="rounded-xl border border-stone-700 bg-stone-900/60 p-4 space-y-3">
          <div className="flex items-center gap-3 flex-wrap text-sm">
            <span className="text-stone-400">Strength:</span>
            {[128, 256].map((s) => (
              <button
                key={s}
                onClick={() => setStrength(s as 128 | 256)}
                className={
                  "px-3 py-1 rounded " +
                  (strength === s ? "bg-emerald-600" : "bg-stone-700")
                }
              >
                {s}-bit ({s === 128 ? 12 : 24} words)
              </button>
            ))}
          </div>
          <label className="flex items-center gap-2 text-sm text-stone-300">
            <input
              type="checkbox"
              checked={requireHaiku}
              onChange={(e) => setRequireHaiku(e.target.checked)}
              className="accent-emerald-400"
            />
            Spell-check: only accept valid 5-7-5 haiku (skip others)
          </label>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-stone-400">Mine batch:</span>
            <input
              type="number"
              min={1}
              max={20}
              value={batch}
              onChange={(e) => setBatch(Math.max(1, Math.min(20, Number(e.target.value))))}
              className="w-20 bg-stone-900 border border-stone-700 rounded px-2 py-1"
            />
            <span className="text-stone-500 text-xs">parallel wallets</span>
          </div>
          <button
            onClick={forge}
            disabled={forging}
            className="w-full py-3 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 font-medium disabled:opacity-50"
          >
            {forging ? "Forging Ensō…" : "⚒ Forge Haiku Wallet"}
          </button>
        </div>

        {current && (
          <div className="rounded-xl border border-emerald-700/50 bg-emerald-950/30 p-4 space-y-3">
            <div className="text-center font-serif text-lg leading-relaxed text-emerald-100">
              {current.haiku.map((l, i) => (
                <div key={i}>
                  {l}{" "}
                  <span className="text-xs text-emerald-500/70">
                    ({current.haikuSyllables[i]})
                  </span>
                </div>
              ))}
            </div>
            <div
              className={
                "text-center text-xs " +
                (current.haikuValid ? "text-emerald-400" : "text-amber-400")
              }
            >
              {current.haikuValid ? "✓ Authentic 5-7-5 haiku" : "≈ Approximate haiku"}
            </div>
            <div className="font-mono text-xs text-stone-300 bg-stone-950/60 p-2 rounded break-words">
              {current.mnemonic}
            </div>
            <div className="text-xs text-stone-400">
              BIP-39 valid:{" "}
              <span className={isValidMnemonic(current.mnemonic) ? "text-emerald-400" : "text-red-400"}>
                {isValidMnemonic(current.mnemonic) ? "yes (checksum OK)" : "no"}
              </span>
            </div>
            <div className="space-y-1">
              {current.wallets.map((w) => (
                <div key={w.coin} className="flex justify-between text-xs font-mono">
                  <span className="text-stone-400">{w.coin}</span>
                  <span className="text-stone-300 truncate ml-2">{w.address}</span>
                </div>
              ))}
            </div>
            <div className="text-center text-xs text-emerald-400">
              ✦ Collectible minted to vault ✦
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
