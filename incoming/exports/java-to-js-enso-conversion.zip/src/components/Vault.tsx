import { useState } from "react";
import type { GeneratedWallet } from "../lib/wallet";
import { exportVaultTxt, downloadFile } from "../lib/storage";

type Props = {
  vault: GeneratedWallet[];
  onDelete: (id: string) => void;
  onClear: () => void;
};

export default function Vault({ vault, onDelete, onClear }: Props) {
  const [passphrase, setPassphrase] = useState("");
  const [open, setOpen] = useState<string | null>(null);

  const doExport = () => {
    const content = exportVaultTxt(vault, passphrase);
    const name = passphrase
      ? `enso-vault-encrypted-${Date.now()}.txt`
      : `enso-vault-${Date.now()}.txt`;
    downloadFile(name, content);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-stone-700 bg-stone-900/60 p-4 flex flex-wrap items-center gap-3">
        <div className="text-sm text-stone-300">
          <span className="text-emerald-400 font-mono text-lg">{vault.length}</span>{" "}
          collectible{vault.length !== 1 ? "s" : ""} in vault
          <span className="text-stone-500 text-xs ml-2">
            (encrypted cookie + localStorage)
          </span>
        </div>
        <div className="flex-1" />
        <input
          type="password"
          value={passphrase}
          onChange={(e) => setPassphrase(e.target.value)}
          placeholder="AES-256 export passphrase (optional)"
          className="px-3 py-2 rounded-lg bg-stone-900 border border-stone-700 text-sm w-64"
        />
        <button
          onClick={doExport}
          disabled={!vault.length}
          className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-sm disabled:opacity-40"
        >
          Export .txt
        </button>
        <button
          onClick={onClear}
          disabled={!vault.length}
          className="px-4 py-2 rounded-lg bg-red-900/60 hover:bg-red-800 text-sm disabled:opacity-40"
        >
          Clear All
        </button>
      </div>

      {vault.length === 0 && (
        <div className="text-center text-stone-500 py-16 border border-dashed border-stone-700 rounded-xl">
          No wallets yet. Forge an Ensō to begin collecting.
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-3">
        {vault.map((w) => (
          <div
            key={w.id}
            className="rounded-xl border border-stone-700 bg-stone-900/60 p-4 space-y-2"
          >
            <div className="flex items-center justify-between">
              <code className="text-emerald-300 font-mono text-sm">{w.ensoId}</code>
              <button
                onClick={() => onDelete(w.id)}
                className="text-xs text-red-400 hover:text-red-300"
              >
                ✕ delete
              </button>
            </div>
            <div className="font-serif text-sm text-stone-200 leading-snug">
              {w.haiku.map((l, i) => (
                <div key={i}>{l}</div>
              ))}
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className={w.haikuValid ? "text-emerald-400" : "text-amber-400"}>
                {w.haikuValid ? "5-7-5 ✓" : "≈ haiku"}
              </span>
              <span className="text-stone-500">{w.strength}-bit</span>
              <span className="text-stone-500">
                {new Date(w.createdAt).toLocaleDateString()}
              </span>
            </div>
            <button
              onClick={() => setOpen(open === w.id ? null : w.id)}
              className="text-xs text-stone-400 hover:text-stone-200"
            >
              {open === w.id ? "▾ hide secrets" : "▸ reveal secrets"}
            </button>
            {open === w.id && (
              <div className="space-y-2 pt-1">
                <div className="font-mono text-[11px] text-stone-300 bg-stone-950/70 p-2 rounded break-words">
                  {w.mnemonic}
                </div>
                {w.wallets.map((c) => (
                  <div key={c.coin} className="text-[11px] font-mono flex justify-between">
                    <span className="text-stone-500">{c.coin} {c.path}</span>
                    <span className="text-stone-300 truncate ml-2">{c.address}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
