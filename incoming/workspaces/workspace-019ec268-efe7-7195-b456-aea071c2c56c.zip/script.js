// Game Data Configuration
const boardData = [
  {id:0, name:"GO", type:"corner", row:11, col:11},
  {id:1, name:"Dogecoin", symbol:"DOGEUSDT", color:"brown", type:"prop", basePrice:60, baseRent:2, row:11, col:10, side:"row-bottom"},
  {id:2, name:"Community Chest", type:"chest", row:11, col:9, side:"row-bottom"},
  {id:3, name:"Shiba Inu", symbol:"SHIBUSDT", color:"brown", type:"prop", basePrice:60, baseRent:4, row:11, col:8, side:"row-bottom"},
  {id:4, name:"Gas Fee", type:"tax", amount:200, row:11, col:7, side:"row-bottom"},
  {id:5, name:"Binance", type:"rr", basePrice:200, baseRent:25, row:11, col:6, side:"row-bottom"},
  {id:6, name:"Cardano", symbol:"ADAUSDT", color:"lightblue", type:"prop", basePrice:100, baseRent:6, row:11, col:5, side:"row-bottom"},
  {id:7, name:"Chance", type:"chance", row:11, col:4, side:"row-bottom"},
  {id:8, name:"Polygon", symbol:"MATICUSDT", color:"lightblue", type:"prop", basePrice:100, baseRent:6, row:11, col:3, side:"row-bottom"},
  {id:9, name:"Polkadot", symbol:"DOTUSDT", color:"lightblue", type:"prop", basePrice:120, baseRent:8, row:11, col:2, side:"row-bottom"},
  {id:10, name:"Jail", type:"corner", row:11, col:1},
  {id:11, name:"Chainlink", symbol:"LINKUSDT", color:"pink", type:"prop", basePrice:140, baseRent:10, row:10, col:1, side:"col-left"},
  {id:12, name:"ASIC Miner", type:"util", basePrice:150, baseRent:10, row:9, col:1, side:"col-left"},
  {id:13, name:"Litecoin", symbol:"LTCUSDT", color:"pink", type:"prop", basePrice:140, baseRent:10, row:8, col:1, side:"col-left"},
  {id:14, name:"Uniswap", symbol:"UNIUSDT", color:"pink", type:"prop", basePrice:160, baseRent:12, row:7, col:1, side:"col-left"},
  {id:15, name:"Coinbase", type:"rr", basePrice:200, baseRent:25, row:6, col:1, side:"col-left"},
  {id:16, name:"Avalanche", symbol:"AVAXUSDT", color:"orange", type:"prop", basePrice:180, baseRent:14, row:5, col:1, side:"col-left"},
  {id:17, name:"Community Chest", type:"chest", row:4, col:1, side:"col-left"},
  {id:18, name:"Stellar", symbol:"XLMUSDT", color:"orange", type:"prop", basePrice:180, baseRent:14, row:3, col:1, side:"col-left"},
  {id:19, name:"Cosmos", symbol:"ATOMUSDT", color:"orange", type:"prop", basePrice:200, baseRent:16, row:2, col:1, side:"col-left"},
  {id:20, name:"Free Parking", type:"corner", row:1, col:1},
  {id:21, name:"Solana", symbol:"SOLUSDT", color:"red", type:"prop", basePrice:220, baseRent:18, row:1, col:2, side:"row-top"},
  {id:22, name:"Chance", type:"chance", row:1, col:3, side:"row-top"},
  {id:23, name:"Ripple", symbol:"XRPUSDT", color:"red", type:"prop", basePrice:220, baseRent:18, row:1, col:4, side:"row-top"},
  {id:24, name:"Tron", symbol:"TRXUSDT", color:"red", type:"prop", basePrice:240, baseRent:20, row:1, col:5, side:"row-top"},
  {id:25, name:"Kraken", type:"rr", basePrice:200, baseRent:25, row:1, col:6, side:"row-top"},
  {id:26, name:"Near", symbol:"NEARUSDT", color:"yellow", type:"prop", basePrice:260, baseRent:22, row:1, col:7, side:"row-top"},
  {id:27, name:"Cloud Mining", type:"util", basePrice:150, baseRent:10, row:1, col:8, side:"row-top"},
  {id:28, name:"Algorand", symbol:"ALGOUSDT", color:"yellow", type:"prop", basePrice:260, baseRent:22, row:1, col:9, side:"row-top"},
  {id:29, name:"VeChain", symbol:"VETUSDT", color:"yellow", type:"prop", basePrice:280, baseRent:24, row:1, col:10, side:"row-top"},
  {id:30, name:"Go To Jail", type:"corner", row:1, col:11},
  {id:31, name:"EOS", symbol:"EOSUSDT", color:"green", type:"prop", basePrice:300, baseRent:26, row:2, col:11, side:"col-right"},
  {id:32, name:"Bitcoin Cash", symbol:"BCHUSDT", color:"green", type:"prop", basePrice:300, baseRent:26, row:3, col:11, side:"col-right"},
  {id:33, name:"Community Chest", type:"chest", row:4, col:11, side:"col-right"},
  {id:34, name:"BNB", symbol:"BNBUSDT", color:"green", type:"prop", basePrice:320, baseRent:28, row:5, col:11, side:"col-right"},
  {id:35, name:"KuCoin", type:"rr", basePrice:200, baseRent:25, row:6, col:11, side:"col-right"},
  {id:36, name:"Chance", type:"chance", row:7, col:11, side:"col-right"},
  {id:37, name:"Ethereum", symbol:"ETHUSDT", color:"darkblue", type:"prop", basePrice:350, baseRent:35, row:8, col:11, side:"col-right"},
  {id:38, name:"Whale Tax", type:"tax", amount:100, row:9, col:11, side:"col-right"},
  {id:39, name:"Bitcoin", symbol:"BTCUSDT", color:"darkblue", type:"prop", basePrice:400, baseRent:50, row:10, col:11, side:"col-right"}
];

const nftCommunityChest = [
  { text: "Minted a rare Bored Ape. Collect $200", action: "add", amount: 200 },
  { text: "Gas fee spike on failed NFT transaction. Pay $50", action: "sub", amount: 50 },
  { text: "Sold your CryptoPunk at the top! Collect $500", action: "add", amount: 500 },
  { text: "Rug pulled by a shady NFT project. Pay $150", action: "sub", amount: 150 },
  { text: "Airdrop! Received tokens from an NFT collection. Collect $100", action: "add", amount: 100 },
  { text: "Paid OpenSea marketplace royalty fees. Pay $25", action: "sub", amount: 25 },
  { text: "Won a whitelist spot for a blue-chip NFT. Collect $50", action: "add", amount: 50 },
  { text: "Your NFT art won a community contest. Collect $100", action: "add", amount: 100 }
];

const cryptoChance = [
  { text: "Bull Market! Advance to Bitcoin (Space 39).", action: "move", pos: 39 },
  { text: "Market Crash! Go directly to Jail. Do not pass GO.", action: "gotojail" },
  { text: "Advance to GO. Collect $200", action: "move", pos: 0 },
  { text: "Hacked exchange! Lose $100.", action: "sub", amount: 100 },
  { text: "Staking rewards paid out. Collect $150.", action: "add", amount: 150 },
  { text: "Go back 3 spaces.", action: "back3" },
  { text: "Advance to the nearest Exchange.", action: "nearestRR" },
  { text: "Hardware wallet recovered! Collect $50.", action: "add", amount: 50 }
];

const players = [
  { id: 0, name: "Player 1", money: 1500, pos: 0, color: "#ff2a2a", inJail: false, jailTurns: 0, tokenEl: null },
  { id: 1, name: "Player 2", money: 1500, pos: 0, color: "#2a75ff", inJail: false, jailTurns: 0, tokenEl: null }
];

let currentPlayerIndex = 0;
let gameState = "WAITING_ROLL"; // "WAITING_ROLL" | "WAITING_ACTION"
let doublesCount = 0;

// Initialize Board Properties
boardData.forEach(space => {
  if (space.type === "prop" || space.type === "rr" || space.type === "util") {
    space.currentPrice = space.basePrice;
    space.currentRent = space.baseRent;
    space.owner = null;
    space.liveChange = 0;
  }
});

const boardEl = document.getElementById("board");
const actionArea = document.getElementById("action-area");
const rollBtn = document.getElementById("roll-btn");
const endTurnBtn = document.getElementById("end-turn-btn");
const playersInfoEl = document.getElementById("players-info");
const logList = document.getElementById("log-list");
const die1El = document.getElementById("die1");
const die2El = document.getElementById("die2");

// Build Board Elements
function buildBoard() {
  boardData.forEach(space => {
    const el = document.createElement("div");
    el.className = `space ${space.type} ${space.side || ""} ${space.color || ""}`;
    el.id = `space-${space.id}`;
    el.style.gridRow = space.row;
    el.style.gridColumn = space.col;
    
    // Create an inner wrapper to handle rotation for side spaces
    let innerContent = "";
    
    innerContent += `<div class="name">${space.name}</div>`;
    
    if (space.type === "prop" || space.type === "rr" || space.type === "util") {
        if (space.color) {
            innerContent += `<div class="color-bar"></div>`;
        }
        
        if (space.type === "prop" && space.symbol) {
            const coinSymbol = space.symbol.replace("USDT", "").toLowerCase();
            innerContent += `<img class="prop-logo" src="https://assets.coincap.io/assets/icons/${coinSymbol}@2x.png" alt="${coinSymbol}">`;
        }

        innerContent += `<div class="price" id="price-${space.id}">$${space.currentPrice}</div>`;
        if (space.symbol) {
            innerContent += `<div class="live-change" id="change-${space.id}">--%</div>`;
        }
    } else if (space.type === "tax") {
        innerContent += `<div class="price">Pay $${space.amount}</div>`;
    }
    
    el.innerHTML = `<div class="space-inner">${innerContent}</div>`;
    boardEl.appendChild(el);
  });

  // Create token elements
  players.forEach((p, idx) => {
    const token = document.createElement("div");
    token.className = "token";
    token.style.backgroundColor = p.color;
    token.id = `token-${p.id}`;
    document.body.appendChild(token); // Attach to body for absolute positioning
    p.tokenEl = token;
  });

  updatePlayerTokens();
  updatePlayersUI();
  log("Game initialized. Player 1's turn.");
}

function updatePlayerTokens() {
  players.forEach((p, idx) => {
    const spaceEl = document.getElementById(`space-${p.pos}`);
    const rect = spaceEl.getBoundingClientRect();
    
    // Offset slightly so they don't overlap perfectly
    const offsetX = idx === 0 ? -15 : 15;
    const offsetY = idx === 0 ? 15 : -15;

    p.tokenEl.style.left = `${rect.left + rect.width / 2 + offsetX}px`;
    p.tokenEl.style.top = `${rect.top + rect.height / 2 + offsetY}px`;
  });
}

// Window resize handler to reposition tokens correctly
window.addEventListener('resize', updatePlayerTokens);

function updatePlayersUI() {
  playersInfoEl.innerHTML = "";
  players.forEach((p, idx) => {
    const card = document.createElement("div");
    card.className = `player-card ${idx === currentPlayerIndex ? "active" : ""}`;
    
    const propsOwned = boardData.filter(s => s.owner === p.id);
    
    card.innerHTML = `
      <div class="player-header">
        <span><span class="player-token-indicator" style="background:${p.color}"></span> ${p.name}</span>
        <span>$${p.money}</span>
      </div>
      <div class="player-portfolio">
        ${propsOwned.length === 0 ? "<em>No assets</em>" : ""}
        ${propsOwned.map(s => {
            let logoHtml = '';
            if (s.symbol) {
                const coinSymbol = s.symbol.replace("USDT", "").toLowerCase();
                logoHtml = `<img src="https://assets.coincap.io/assets/icons/${coinSymbol}@2x.png" style="width:12px; height:12px; vertical-align:middle; margin-right:5px; border-radius:50%;">`;
            }
            return `<div class="portfolio-item"><span>${logoHtml}${s.name}</span> <span>$${s.currentPrice}</span></div>`;
        }).join("")}
      </div>
    `;
    playersInfoEl.appendChild(card);
  });
}

function log(msg) {
  const li = document.createElement("li");
  const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'});
  li.innerHTML = `<span class="log-time">[${time}]</span> ${msg}`;
  logList.prepend(li);
}

// Market Data Fetching
const activeSymbols = boardData.filter(s => s.symbol).map(s => s.symbol);

async function fetchLiveMarketData() {
  try {
    const query = '%5B' + activeSymbols.map(s => `%22${s}%22`).join(',') + '%5D';
    const res = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbols=${query}`);
    const data = await res.json();
    
    if (!Array.isArray(data)) {
        console.error("Binance API error:", data);
        return;
    }
    
    let tickerHtml = "";
    
    data.forEach(ticker => {
      const space = boardData.find(s => s.symbol === ticker.symbol);
      if (space) {
        const change = parseFloat(ticker.priceChangePercent);
        space.liveChange = change;
        
        // Adjust Monopoly Price and Rent based on live market %
        const multiplier = 1 + (change / 100);
        space.currentPrice = Math.max(10, Math.floor(space.basePrice * multiplier));
        space.currentRent = Math.max(1, Math.floor(space.baseRent * multiplier));
        
        // Update DOM
        const priceEl = document.getElementById(`price-${space.id}`);
        const changeEl = document.getElementById(`change-${space.id}`);
        if(priceEl) priceEl.innerText = `$${space.currentPrice}`;
        if(changeEl) {
            changeEl.innerText = `${change > 0 ? '+' : ''}${change.toFixed(2)}%`;
            changeEl.className = `live-change ${change >= 0 ? 'up' : 'down'}`;
        }
        
        tickerHtml += `<span style="margin-right:20px">${space.name}: ${change > 0 ? '+' : ''}${change.toFixed(2)}%</span>`;
      }
    });
    
    document.getElementById("live-ticker").innerHTML = tickerHtml;
    updatePlayersUI(); // Update net worth / asset values
    
  } catch(e) {
    console.error("Market fetch failed", e);
  }
}

// Game Logic
function rollDice() {
  if (gameState !== "WAITING_ROLL") return;
  
  const d1 = Math.floor(Math.random() * 6) + 1;
  const d2 = Math.floor(Math.random() * 6) + 1;
  
  const diceFaces = ["⚀","⚁","⚂","⚃","⚄","⚅"];
  die1El.innerText = diceFaces[d1-1];
  die2El.innerText = diceFaces[d2-1];
  
  const total = d1 + d2;
  const isDouble = d1 === d2;
  
  const p = players[currentPlayerIndex];
  log(`${p.name} rolled ${d1} and ${d2} (${total}).`);
  
  if (p.inJail) {
      if (isDouble) {
          log(`${p.name} rolled doubles and got out of Jail!`);
          p.inJail = false;
          p.jailTurns = 0;
      } else {
          p.jailTurns++;
          if (p.jailTurns >= 3) {
              log(`${p.name} pays $50 to get out of Jail.`);
              p.money -= 50;
              p.inJail = false;
              p.jailTurns = 0;
          } else {
              log(`${p.name} is still in Jail.`);
              endTurnSetup();
              return;
          }
      }
  } else {
      if (isDouble) {
          doublesCount++;
          if (doublesCount === 3) {
              log(`${p.name} rolled 3 doubles! Speeding fine: Go to Jail!`);
              goToJail(p);
              endTurnSetup();
              return;
          }
      }
  }

  movePlayer(p, total);
}

function movePlayer(player, steps) {
  gameState = "WAITING_ACTION";
  rollBtn.disabled = true;
  
  let newPos = player.pos + steps;
  if (newPos >= 40) {
      newPos = newPos % 40;
      player.money += 200;
      log(`${player.name} passed GO. Collected $200.`);
  }
  
  player.pos = newPos;
  updatePlayerTokens();
  
  setTimeout(() => handleSpace(player, boardData[player.pos]), 500);
}

function handleSpace(player, space) {
  let actionHtml = '';
  if (space.type === "prop" && space.symbol) {
      const coinSymbol = space.symbol.replace("USDT", "").toLowerCase();
      actionHtml += `<img src="https://assets.coincap.io/assets/icons/${coinSymbol}@2x.png" style="width:50px; margin-bottom: 10px; border-radius: 50%;">`;
  }
  actionHtml += `<p>Landed on <strong>${space.name}</strong>.</p>`;
  
  if (space.type === "prop" || space.type === "rr" || space.type === "util") {
      if (space.owner === null) {
          actionHtml += `<p>Unowned. Price: $${space.currentPrice}</p>
                         <button class="btn-primary" id="buy-btn" onclick="buyProperty(${space.id})">Buy</button>`;
      } else if (space.owner !== player.id) {
          const owner = players.find(p => p.id === space.owner);
          actionHtml += `<p>Owned by ${owner.name}. Rent: $${space.currentRent}</p>`;
          payRent(player, owner, space.currentRent);
      } else {
          actionHtml += `<p>You own this property.</p>`;
      }
  } else if (space.type === "tax") {
      actionHtml += `<p>Pay $${space.amount}</p>`;
      player.money -= space.amount;
      log(`${player.name} paid $${space.amount} for ${space.name}.`);
  } else if (space.type === "chest") {
      actionHtml += drawCard(player, nftCommunityChest, "Community Chest");
  } else if (space.type === "chance") {
      actionHtml += drawCard(player, cryptoChance, "Chance");
  } else if (space.name === "Go To Jail") {
      actionHtml += `<p>Busted! Go directly to Jail.</p>`;
      goToJail(player);
  } else {
      actionHtml += `<p>Restting...</p>`;
  }

  actionArea.innerHTML = actionHtml;
  updatePlayersUI();
  endTurnSetup();
}

function buyProperty(spaceId) {
  const p = players[currentPlayerIndex];
  const space = boardData.find(s => s.id === spaceId);
  
  if (p.money >= space.currentPrice) {
      p.money -= space.currentPrice;
      space.owner = p.id;
      log(`${p.name} bought ${space.name} for $${space.currentPrice}.`);
      
      // Update visual indicator
      const spaceEl = document.getElementById(`space-${space.id}`);
      const indicator = document.createElement("div");
      indicator.className = "owner-indicator";
      indicator.style.backgroundColor = p.color;
      spaceEl.appendChild(indicator);
      
      actionArea.innerHTML = `<p>You successfully purchased ${space.name}!</p>`;
      updatePlayersUI();
  } else {
      alert("Not enough funds!");
  }
}

function payRent(payer, payee, amount) {
  payer.money -= amount;
  payee.money += amount;
  log(`${payer.name} paid $${amount} rent to ${payee.name}.`);
}

function drawCard(player, deck, deckName) {
  const card = deck[Math.floor(Math.random() * deck.length)];
  log(`${player.name} drew ${deckName}: "${card.text}"`);
  
  if (card.action === "add") {
      player.money += card.amount;
  } else if (card.action === "sub") {
      player.money -= card.amount;
  } else if (card.action === "move") {
      player.pos = card.pos;
      updatePlayerTokens();
      setTimeout(() => handleSpace(player, boardData[player.pos]), 500);
      return `<p>Drew: <em>${card.text}</em></p><p>Moving...</p>`;
  } else if (card.action === "gotojail") {
      goToJail(player);
  } else if (card.action === "back3") {
      player.pos -= 3;
      if (player.pos < 0) player.pos += 40;
      updatePlayerTokens();
      setTimeout(() => handleSpace(player, boardData[player.pos]), 500);
      return `<p>Drew: <em>${card.text}</em></p><p>Moving back 3 spaces...</p>`;
  } else if (card.action === "nearestRR") {
      let newPos = player.pos;
      while (boardData[newPos].type !== "rr") {
          newPos = (newPos + 1) % 40;
      }
      if (newPos < player.pos) player.money += 200; // Passed Go
      player.pos = newPos;
      updatePlayerTokens();
      setTimeout(() => handleSpace(player, boardData[player.pos]), 500);
      return `<p>Drew: <em>${card.text}</em></p><p>Moving to nearest Exchange...</p>`;
  }
  
  return `<p>Drew: <em>${card.text}</em></p>`;
}

function goToJail(player) {
  player.pos = 10;
  player.inJail = true;
  player.jailTurns = 0;
  updatePlayerTokens();
  log(`${player.name} is sent to Jail!`);
}

function endTurnSetup() {
  if (doublesCount > 0 && !players[currentPlayerIndex].inJail && doublesCount < 3) {
      endTurnBtn.disabled = true;
      rollBtn.disabled = false;
      gameState = "WAITING_ROLL";
      actionArea.innerHTML += `<p><strong>Rolled doubles! Roll again!</strong></p>`;
  } else {
      endTurnBtn.disabled = false;
  }
}

function nextTurn() {
  doublesCount = 0;
  currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
  gameState = "WAITING_ROLL";
  
  rollBtn.disabled = false;
  endTurnBtn.disabled = true;
  
  const p = players[currentPlayerIndex];
  actionArea.innerHTML = `<p>It is now <strong>${p.name}</strong>'s turn. Roll the dice!</p>`;
  updatePlayersUI();
}

rollBtn.addEventListener("click", rollDice);
endTurnBtn.addEventListener("click", nextTurn);

// Boot
buildBoard();
fetchLiveMarketData();
setInterval(fetchLiveMarketData, 15000); // Update market every 15s

// Force first token positioning accurately after rendering is totally finished
setTimeout(updatePlayerTokens, 1000);
