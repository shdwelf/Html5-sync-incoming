/* ============================================
   FLIGHT RADAR HUD - MAIN APPLICATION
   Using OpenSky Network ADS-B API
   ============================================ */

// Configuration
const CONFIG = {
    // OpenSky API endpoints
    API_BASE: 'https://opensky-network.org/api',
    // Refresh intervals (ms)
    DEFAULT_REFRESH: 10000,
    MIN_REFRESH: 5000,
    MAX_REFRESH: 60000,
    // Map settings
    DEFAULT_CENTER: [37.0902, -95.7129], // Center of US
    DEFAULT_ZOOM: 5,
    MAX_TRAIL_AGE: 60000, // 1 minute for trails
};

// Aircraft Classification
function classifyAircraft(aircraft) {
    // Military detection based on hex codes and callsign
    const icao = (aircraft.icao24 || '').toUpperCase();
    const callsign = (aircraft.callsign || '').toUpperCase();
    
    // US Military patterns
    if (/^AE[0-9A-F]{4}$/i.test(icao)) return 'military';  // US Air Force
    if (/^ADF[0-9A-F]{4}$/i.test(icao)) return 'military'; // US Government
    if (/^A[0-2][0-9A-F]{4}$/i.test(icao)) return 'military'; // Other US military
    if (callsign.startsWith('RCH') || callsign.startsWith('REACH')) return 'military'; // Air Mobility
    if (callsign.startsWith('EVAC')) return 'military'; // Medevac
    if (callsign.startsWith('ARMY')) return 'military';
    if (callsign.startsWith('NAVY')) return 'military';
    if (callsign.startsWith('MARINE')) return 'military';
    if (callsign.startsWith('GUARD')) return 'military';
    if (callsign.startsWith('SPAR') || callsign.startsWith('COAST')) return 'military'; // Coast Guard
    if (callsign.startsWith('VIPER')) return 'military';
    if (callsign.startsWith('PAT')) return 'military';
    if (callsign.startsWith('REACH')) return 'military';
    
    // Check aircraft type if available
    if (aircraft.typecode) {
        const type = aircraft.typecode.toUpperCase();
        if (['C130', 'C17', 'KC10', 'KC13', 'E3', 'E4', 'E8', 'V22', 'F15', 'F16', 'F18', 'F22', 'F35', 'B52', 'B2', 'A400', 'C400'].includes(type)) {
            return 'military';
        }
    }
    
    // Commercial airlines (common callsign patterns)
    const commercialPrefixes = ['AAL', 'UAL', 'DAL', 'SWA', 'JBU', 'ASA', 'FFT', 'ENY', 'SKW', 'RPA', 'DAL', 'BAW', 'DLH', 'AFR', 'KLM', 'UAE', 'QTR', 'SIA', 'CPA', 'THY', 'ACA', 'AMX', 'AVA'];
    if (commercialPrefixes.some(p => callsign.startsWith(p))) return 'commercial';
    
    // Private jets (common registrations)
    if (/^N[0-9]{1,5}[A-Z]{1,2}$/i.test(aircraft.registration || '')) return 'private';
    
    // If we have a callsign but can't classify, likely commercial
    if (callsign.length >= 3) return 'commercial';
    
    return 'unknown';
}

// Create SVG aircraft icon
function createAircraftIcon(heading, type, isSelected = false) {
    const colors = {
        commercial: '#00ff88',
        private: '#00ccff',
        military: '#ff3344',
        unknown: '#ffaa00'
    };
    
    const color = colors[type] || colors.unknown;
    const glow = isSelected ? `filter: drop-shadow(0 0 8px ${color});` : '';
    
    return L.divIcon({
        className: 'aircraft-marker',
        html: `<svg class="aircraft-icon" width="24" height="24" viewBox="0 0 24 24" style="${glow}">
            <g transform="translate(12, 12) rotate(${heading})">
                <!-- Aircraft body -->
                <path d="M0,-8 L2,-2 L12,4 L12,6 L2,3 L1,8 L1,10 L0,12 L-1,10 L-1,8 L-2,3 L-12,6 L-12,4 L-2,-2 Z" 
                      fill="${color}" stroke="${color}" stroke-width="0.5" opacity="0.9"/>
                <!-- Center dot -->
                <circle cx="0" cy="0" r="1" fill="#fff"/>
            </g>
        </svg>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
        popupAnchor: [0, -15]
    });
}

// Main Application Class
class FlightRadarHUD {
    constructor() {
        this.map = null;
        this.aircraftMarkers = {};
        this.aircraftTrails = {};
        this.aircraftData = new Map();
        this.trackedHistory = new Map(); // For trails
        this.refreshInterval = CONFIG.DEFAULT_REFRESH;
        this.refreshTimer = null;
        this.countdownTimer = null;
        this.selectedAircraft = null;
        this.showTrails = false;
        this.showLabels = false;
        this.filters = {
            commercial: true,
            private: true,
            military: true,
            unknown: true,
            minAltitude: 0,
            minSpeed: 0
        };
        this.isRefreshing = false;
        
        this.init();
    }
    
    async init() {
        this.initMap();
        this.initEventListeners();
        this.startClock();
        this.updateStatus('CONNECTING');
        await this.fetchAircraft();
        this.startAutoRefresh();
    }
    
    initMap() {
        // Initialize map centered on US
        this.map = L.map('map', {
            center: CONFIG.DEFAULT_CENTER,
            zoom: CONFIG.DEFAULT_ZOOM,
            zoomControl: false,
            attributionControl: false
        });
        
        // Add dark-tinted tile layer
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            maxZoom: 18,
            subdomains: 'abcd'
        }).addTo(this.map);
        
        // Update coordinate display on map move
        this.map.on('moveend', () => this.updateCoords());
        this.map.on('zoomend', () => this.updateCoords());
        
        this.updateCoords();
    }
    
    initEventListeners() {
        // Search button
        document.getElementById('btnSearch').addEventListener('click', () => this.toggleSearch());
        document.getElementById('closeSearch').addEventListener('click', () => this.toggleSearch());
        document.getElementById('searchInput').addEventListener('input', (e) => this.handleSearch(e.target.value));
        
        // Filter button
        document.getElementById('btnFilter').addEventListener('click', () => this.toggleFilters());
        document.getElementById('closeFilter').addEventListener('click', () => this.toggleFilters());
        document.getElementById('applyFilters').addEventListener('click', () => this.applyFilters());
        
        // Filter value displays
        document.getElementById('minAltitude').addEventListener('input', (e) => {
            document.getElementById('minAltValue').textContent = e.target.value;
        });
        document.getElementById('minSpeed').addEventListener('input', (e) => {
            document.getElementById('minSpeedValue').textContent = e.target.value;
        });
        document.getElementById('refreshInterval').addEventListener('input', (e) => {
            document.getElementById('refreshIntervalValue').textContent = e.target.value;
        });
        
        // Trail toggle
        document.getElementById('btnTrails').addEventListener('click', () => this.toggleTrails());
        
        // Label toggle
        document.getElementById('btnLabels').addEventListener('click', () => this.toggleLabels());
        
        // Manual refresh
        document.getElementById('btnRefresh').addEventListener('click', () => {
            this.fetchAircraft();
            this.startCountdown();
        });
        
        // My location
        document.getElementById('btnMyLocation').addEventListener('click', () => this.centerOnMyLocation());
        
        // Click on map to deselect
        this.map.on('click', () => {
            this.selectedAircraft = null;
            this.updateDetailsPanel();
        });
    }
    
    startClock() {
        const updateTime = () => {
            const now = new Date();
            document.getElementById('hudTime').textContent = now.toUTCString().split(' ')[4];
            document.getElementById('hudDate').textContent = now.toLocaleDateString('en-US');
        };
        updateTime();
        setInterval(updateTime, 1000);
    }
    
    updateStatus(status) {
        const indicator = document.getElementById('connectionStatus');
        const text = document.getElementById('connectionText');
        
        indicator.className = 'status-indicator';
        if (status === 'CONNECTED') {
            indicator.classList.add('connected');
            text.textContent = 'LIVE FEED';
        } else if (status === 'ERROR') {
            indicator.classList.add('disconnected');
            text.textContent = 'CONNECTION ERROR';
        } else {
            text.textContent = status;
        }
    }
    
    updateCoords() {
        const center = this.map.getCenter();
        const zoom = this.map.getZoom();
        document.getElementById('centerLat').textContent = center.lat.toFixed(4);
        document.getElementById('centerLon').textContent = center.lng.toFixed(4);
        document.getElementById('zoomLevel').textContent = zoom;
    }
    
    updateStats(aircraft) {
        const total = aircraft.states ? aircraft.states.length : 0;
        let commercial = 0, private_ = 0, military = 0, unknown = 0;
        let groundCount = 0;
        let highestAlt = 0;
        let fastestSpeed = 0;
        
        aircraft.states.forEach(state => {
            const ac = {
                icao24: state[0],
                callsign: state[1]?.trim(),
                country: state[2],
                lastContact: state[4],
                longitude: state[5],
                latitude: state[6],
                baroAltitude: state[7],
                onGround: state[8],
                velocity: state[9],
                heading: state[10],
                verticalRate: state[11],
                sensors: state[12],
                geoAltitude: state[13],
                squawk: state[14],
                spi: state[15],
                typecode: state[16]
            };
            
            const type = classifyAircraft(ac);
            switch (type) {
                case 'commercial': commercial++; break;
                case 'private': private_++; break;
                case 'military': military++; break;
                default: unknown++;
            }
            
            if (ac.onGround) groundCount++;
            if (ac.baroAltitude > highestAlt) highestAlt = ac.baroAltitude || 0;
            if (ac.velocity > fastestSpeed) fastestSpeed = ac.velocity || 0;
        });
        
        document.getElementById('totalAircraft').textContent = total;
        document.getElementById('commercialCount').textContent = commercial;
        document.getElementById('privateCount').textContent = private_;
        document.getElementById('militaryCount').textContent = military;
        document.getElementById('groundCount').textContent = groundCount;
        document.getElementById('highestAlt').textContent = `${Math.round(highestAlt * 3.281).toLocaleString()} ft`;
        document.getElementById('fastestSpeed').textContent = `${Math.round(fastestSpeed * 1.944).toLocaleString()} kts`;
    }
    
    async fetchAircraft() {
        if (this.isRefreshing) return;
        this.isRefreshing = true;
        
        // Show scanning effect
        const scanEffect = document.getElementById('scanEffect');
        scanEffect.classList.add('active');
        setTimeout(() => scanEffect.classList.remove('active'), 2000);
        
        try {
            const bounds = this.map.getBounds();
            const url = `${CONFIG.API_BASE}/states/all?lamin=${bounds.getSouth()}&lomin=${bounds.getWest()}&lamax=${bounds.getNorth()}&lomax=${bounds.getEast()}`;
            
            const response = await fetch(url);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            const data = await response.json();
            
            if (data.states) {
                this.updateAircraftMarkers(data);
                this.updateStats(data);
                this.updateStatus('CONNECTED');
                document.getElementById('lastUpdate').textContent = new Date().toUTCString().split(' ')[4];
                
                // Update detail panel if aircraft is selected
                if (this.selectedAircraft) {
                    const updated = this.aircraftData.get(this.selectedAircraft);
                    if (updated) {
                        this.updateDetailsPanel(updated);
                    }
                }
            }
        } catch (error) {
            console.error('Error fetching aircraft:', error);
            this.updateStatus('ERROR');
            
            // Use demo data if API fails
            this.useDemoData();
        } finally {
            this.isRefreshing = false;
        }
    }
    
    updateAircraftMarkers(data) {
        const currentIcaos = new Set();
        
        data.states.forEach(state => {
            const icao24 = state[0];
            const callsign = state[1]?.trim() || '';
            const country = state[2] || 'Unknown';
            const longitude = state[5];
            const latitude = state[6];
            const baroAltitude = state[7];
            const onGround = state[8];
            const velocity = state[9];
            const heading = state[10] || 0;
            const verticalRate = state[11];
            const geoAltitude = state[13];
            const squawk = state[14];
            const typecode = state[16];
            
            if (longitude == null || latitude == null) return;
            
            // Create aircraft object
            const aircraft = {
                icao24, callsign, country, longitude, latitude,
                baroAltitude, onGround, velocity, heading,
                verticalRate, geoAltitude, squawk, typecode
            };
            
            const type = classifyAircraft(aircraft);
            aircraft.classification = type;
            
            // Check filters
            if (!this.filters[type]) return;
            if (this.filters.minAltitude > 0 && (baroAltitude || 0) < this.filters.minAltitude) return;
            if (this.filters.minSpeed > 0 && (velocity || 0) < this.filters.minSpeed) return;
            
            currentIcaos.add(icao24);
            
            // Store data
            this.aircraftData.set(icao24, aircraft);
            
            // Store trail history
            if (this.showTrails) {
                if (!this.trackedHistory.has(icao24)) {
                    this.trackedHistory.set(icao24, []);
                }
                const trail = this.trackedHistory.get(icao24);
                trail.push({ lat: latitude, lng: longitude, time: Date.now() });
                // Keep only recent points
                while (trail.length > 0 && (Date.now() - trail[0].time) > CONFIG.MAX_TRAIL_AGE) {
                    trail.shift();
                }
            }
            
            // Update or create marker
            this.updateMarker(aircraft, type);
        });
        
        // Remove markers for aircraft no longer in range
        Object.keys(this.aircraftMarkers).forEach(icao => {
            if (!currentIcaos.has(icao)) {
                this.removeMarker(icao);
                this.aircraftData.delete(icao);
            }
        });
    }
    
    updateMarker(aircraft, type) {
        const { icao24, latitude, longitude, heading, callsign } = aircraft;
        
        if (this.aircraftMarkers[icao24]) {
            // Update existing marker position and rotation
            const marker = this.aircraftMarkers[icao24];
            marker.setLatLng([latitude, longitude]);
            marker.setIcon(createAircraftIcon(heading, type, this.selectedAircraft === icao24));
            
            // Update label
            if (this.showLabels && marker.label) {
                marker.label.setLatLng([latitude, longitude]);
            }
        } else {
            // Create new marker
            const icon = createAircraftIcon(heading, type, this.selectedAircraft === icao24);
            
            const marker = L.marker([latitude, longitude], {
                icon: icon,
                rotationAngle: heading,
                zIndexOffset: type === 'military' ? 1000 : 500
            }).addTo(this.map);
            
            // Add popup
            marker.bindPopup(this.createPopupContent(aircraft), {
                className: 'aircraft-popup',
                closeButton: false
            });
            
            // Click handler
            marker.on('click', () => this.selectAircraft(icao24));
            
            // Hover handler
            const self = this;
            marker.on('mouseover', function() {
                this.openPopup();
            });
            marker.on('mouseout', function() {
                if (!self.selectedAircraft || self.selectedAircraft !== icao24) this.closePopup();
            });
            
            this.aircraftMarkers[icao24] = marker;
            
            // Add label if enabled
            if (this.showLabels) {
                this.addLabel(aircraft);
            }
        }
        
        // Update trail
        if (this.showTrails) {
            this.updateTrail(aircraft);
        }
    }
    
    addLabel(aircraft) {
        if (!this.aircraftMarkers[aircraft.icao24]?.label) {
            const label = L.marker([aircraft.latitude, aircraft.longitude], {
                icon: L.divIcon({
                    className: 'aircraft-label',
                    html: aircraft.callsign || aircraft.icao24.toUpperCase(),
                    iconSize: [60, 20],
                    iconAnchor: [30, -10]
                }),
                interactive: false
            }).addTo(this.map);
            
            if (this.aircraftMarkers[aircraft.icao24]) {
                this.aircraftMarkers[aircraft.icao24].label = label;
            }
        }
    }
    
    updateTrail(aircraft) {
        const trail = this.trackedHistory.get(aircraft.icao24);
        if (!trail || trail.length < 2) return;
        
        const latlngs = trail.map(t => [t.lat, t.lng]);
        
        if (this.aircraftTrails[aircraft.icao24]) {
            this.aircraftTrails[aircraft.icao24].setLatLngs(latlngs);
        } else {
            const colors = {
                commercial: '#00ff88',
                private: '#00ccff',
                military: '#ff3344',
                unknown: '#ffaa00'
            };
            
            this.aircraftTrails[aircraft.icao24] = L.polyline(latlngs, {
                color: colors[aircraft.classification] || '#ffaa00',
                weight: 2,
                opacity: 0.5,
                dashArray: '5, 5'
            }).addTo(this.map);
        }
    }
    
    removeMarker(icao) {
        if (this.aircraftMarkers[icao]) {
            if (this.aircraftMarkers[icao].label) {
                this.map.removeLayer(this.aircraftMarkers[icao].label);
            }
            this.map.removeLayer(this.aircraftMarkers[icao]);
            delete this.aircraftMarkers[icao];
        }
        
        if (this.aircraftTrails[icao]) {
            this.map.removeLayer(this.aircraftTrails[icao]);
            delete this.aircraftTrails[icao];
        }
        
        this.trackedHistory.delete(icao);
    }
    
    createPopupContent(aircraft) {
        const altFt = aircraft.baroAltitude ? Math.round(aircraft.baroAltitude * 3.281) : 'N/A';
        const speedKts = aircraft.velocity ? Math.round(aircraft.velocity * 1.944) : 'N/A';
        const vertRate = aircraft.verticalRate ? Math.round(aircraft.verticalRate * 196.85) + ' ft/min' : 'Level';
        
        return `
            <div style="font-family: 'Courier New', monospace; padding: 8px;">
                <div style="font-size: 16px; font-weight: bold; color: #00ff88; margin-bottom: 5px;">
                    ${aircraft.callsign || 'N/A'}
                </div>
                <div style="font-size: 11px; color: #00ccff; margin-bottom: 8px;">
                    ICAO: ${aircraft.icao24.toUpperCase()} | ${aircraft.country}
                </div>
                <div style="font-size: 11px; color: #ffaa00;">
                    ALT: ${altFt} ft | SPD: ${speedKts} kts
                </div>
                <div style="font-size: 11px; color: #00ff88; margin-top: 3px;">
                    HDG: ${Math.round(aircraft.heading)}° | VR: ${vertRate}
                </div>
                ${aircraft.squawk ? `<div style="font-size: 10px; color: #aaa; margin-top: 3px;">SQUAWK: ${aircraft.squawk}</div>` : ''}
            </div>
        `;
    }
    
    selectAircraft(icao) {
        this.selectedAircraft = icao;
        
        // Update marker highlight
        Object.keys(this.aircraftMarkers).forEach(key => {
            const ac = this.aircraftData.get(key);
            if (ac) {
                const marker = this.aircraftMarkers[key];
                marker.setIcon(createAircraftIcon(ac.heading, ac.classification, key === icao));
            }
        });
        
        this.updateDetailsPanel(this.aircraftData.get(icao));
    }
    
    updateDetailsPanel(aircraft = null) {
        const panel = document.getElementById('aircraftDetails');
        
        if (!aircraft) {
            panel.innerHTML = `
                <div class="no-selection">
                    <span class="crosshair">+</span>
                    <p>CLICK AIRCRAFT FOR<br>TARGET ACQUISITION</p>
                </div>
            `;
            return;
        }
        
        const altFt = aircraft.baroAltitude ? Math.round(aircraft.baroAltitude * 3.281) : 'N/A';
        const altGeo = aircraft.geoAltitude ? Math.round(aircraft.geoAltitude * 3.281) : 'N/A';
        const speedKts = aircraft.velocity ? Math.round(aircraft.velocity * 1.944) : 'N/A';
        const speedMph = aircraft.velocity ? Math.round(aircraft.velocity * 2.237) : 'N/A';
        const vertRate = aircraft.verticalRate ? Math.round(aircraft.verticalRate * 196.85) + ' ft/min' : '0 ft/min';
        
        const colors = {
            commercial: '#00ff88',
            private: '#00ccff',
            military: '#ff3344',
            unknown: '#ffaa00'
        };
        
        const typeColor = colors[aircraft.classification] || colors.unknown;
        
        panel.innerHTML = `
            <div class="aircraft-detail">
                <div class="detail-header">
                    <span class="detail-callsign">${aircraft.callsign || 'N/A'}</span>
                    <span class="detail-icao" style="color: ${typeColor}">${aircraft.classification?.toUpperCase()}</span>
                </div>
                
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-item-label">ICAO24 HEX</div>
                        <div class="detail-item-value">${aircraft.icao24?.toUpperCase() || 'N/A'}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">COUNTRY</div>
                        <div class="detail-item-value">${aircraft.country || 'N/A'}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">BARO ALTITUDE</div>
                        <div class="detail-item-value warning">${altFt} ft</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">GEO ALTITUDE</div>
                        <div class="detail-item-value">${altGeo} ft</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">GROUND SPEED</div>
                        <div class="detail-item-value">${speedKts} kts</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">SPEED (MPH)</div>
                        <div class="detail-item-value">${speedMph} mph</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">HEADING</div>
                        <div class="detail-item-value">${Math.round(aircraft.heading || 0)}°</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">VERTICAL RATE</div>
                        <div class="detail-item-value ${parseInt(vertRate) > 0 ? 'altitude' : ''}">${vertRate}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">SQUAWK</div>
                        <div class="detail-item-value">${aircraft.squawk || 'N/A'}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">STATUS</div>
                        <div class="detail-item-value">${aircraft.onGround ? 'ON GROUND' : 'AIRBORNE'}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">LATITUDE</div>
                        <div class="detail-item-value">${aircraft.latitude?.toFixed(4) || 'N/A'}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-item-label">LONGITUDE</div>
                        <div class="detail-item-value">${aircraft.longitude?.toFixed(4) || 'N/A'}</div>
                    </div>
                    ${aircraft.typecode ? `
                    <div class="detail-item full-width">
                        <div class="detail-item-label">AIRCRAFT TYPE</div>
                        <div class="detail-item-value">${aircraft.typecode}</div>
                    </div>
                    ` : ''}
                </div>
                
                <div class="compass-container">
                    <div class="compass">
                        <div class="compass-labels">
                            <span class="compass-label n">N</span>
                            <span class="compass-label s">S</span>
                            <span class="compass-label e">E</span>
                            <span class="compass-label w">W</span>
                        </div>
                        <div class="compass-needle" style="transform: translate(-50%, -100%) rotate(${aircraft.heading || 0}deg)"></div>
                        <div class="compass-center"></div>
                    </div>
                </div>
                
                <div style="text-align: center; margin-top: 8px;">
                    <button class="hud-btn" onclick="flightRadar.centerOnAircraft('${aircraft.icao24}')">
                        🎯 CENTER ON TARGET
                    </button>
                </div>
            </div>
        `;
    }
    
    centerOnAircraft(icao) {
        const aircraft = this.aircraftData.get(icao);
        if (aircraft) {
            this.map.flyTo([aircraft.latitude, aircraft.longitude], 10, {
                duration: 1.5
            });
        }
    }
    
    centerOnMyLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    this.map.flyTo([pos.coords.latitude, pos.coords.longitude], 10, {
                        duration: 1.5
                    });
                    this.fetchAircraft();
                },
                (err) => {
                    console.error('Geolocation error:', err);
                    // Default to a major airport
                    this.map.flyTo([33.9425, -118.4081], 10, { duration: 1.5 }); // LAX
                }
            );
        }
    }
    
    toggleSearch() {
        const modal = document.getElementById('searchModal');
        modal.classList.toggle('active');
        if (modal.classList.contains('active')) {
            document.getElementById('searchInput').focus();
        }
    }
    
    handleSearch(query) {
        const results = document.getElementById('searchResults');
        
        if (query.length < 2) {
            results.innerHTML = '';
            return;
        }
        
        const q = query.toUpperCase().trim();
        const matches = [];
        
        this.aircraftData.forEach((aircraft, icao) => {
            if (
                aircraft.callsign?.toUpperCase().includes(q) ||
                aircraft.icao24?.toUpperCase().includes(q) ||
                aircraft.country?.toUpperCase().includes(q)
            ) {
                matches.push(aircraft);
            }
        });
        
        if (matches.length === 0) {
            results.innerHTML = '<div class="search-result-item"><span class="icao">No matches found</span></div>';
            return;
        }
        
        results.innerHTML = matches.slice(0, 10).map(ac => `
            <div class="search-result-item" onclick="flightRadar.selectAndCenter('${ac.icao24}')">
                <span class="callsign">${ac.callsign || 'N/A'}</span>
                <span class="icao">ICAO: ${ac.icao24.toUpperCase()} | ${ac.country}</span>
            </div>
        `).join('');
    }
    
    selectAndCenter(icao) {
        this.selectAircraft(icao);
        this.centerOnAircraft(icao);
        this.toggleSearch();
        document.getElementById('searchInput').value = '';
        document.getElementById('searchResults').innerHTML = '';
    }
    
    toggleFilters() {
        document.getElementById('filterModal').classList.toggle('active');
    }
    
    applyFilters() {
        this.filters.commercial = document.getElementById('filterCommercial').checked;
        this.filters.private = document.getElementById('filterPrivate').checked;
        this.filters.military = document.getElementById('filterMilitary').checked;
        this.filters.unknown = document.getElementById('filterUnknown').checked;
        this.filters.minAltitude = parseInt(document.getElementById('minAltitude').value);
        this.filters.minSpeed = parseInt(document.getElementById('minSpeed').value);
        this.refreshInterval = parseInt(document.getElementById('refreshInterval').value) * 1000;
        
        // Clear all markers and re-fetch
        Object.keys(this.aircraftMarkers).forEach(icao => this.removeMarker(icao));
        this.fetchAircraft();
        
        this.toggleFilters();
        this.startAutoRefresh();
    }
    
    toggleTrails() {
        this.showTrails = !this.showTrails;
        document.getElementById('btnTrails').classList.toggle('active', this.showTrails);
        
        if (!this.showTrails) {
            // Remove all trails
            Object.keys(this.aircraftTrails).forEach(icao => {
                this.map.removeLayer(this.aircraftTrails[icao]);
                delete this.aircraftTrails[icao];
            });
            this.trackedHistory.clear();
        }
    }
    
    toggleLabels() {
        this.showLabels = !this.showLabels;
        document.getElementById('btnLabels').classList.toggle('active', this.showLabels);
        
        if (this.showLabels) {
            this.aircraftData.forEach((ac) => this.addLabel(ac));
        } else {
            Object.values(this.aircraftMarkers).forEach(marker => {
                if (marker.label) {
                    this.map.removeLayer(marker.label);
                    delete marker.label;
                }
            });
        }
    }
    
    startAutoRefresh() {
        if (this.refreshTimer) clearInterval(this.refreshTimer);
        if (this.countdownTimer) clearInterval(this.countdownTimer);
        
        this.refreshTimer = setInterval(() => {
            this.fetchAircraft();
            this.startCountdown();
        }, this.refreshInterval);
        
        this.startCountdown();
    }
    
    startCountdown() {
        let remaining = this.refreshInterval / 1000;
        const updateCountdown = () => {
            document.getElementById('refreshTimer').textContent = `${remaining}s`;
            remaining--;
            if (remaining < 0) {
                remaining = this.refreshInterval / 1000;
            }
        };
        
        updateCountdown();
        if (this.countdownTimer) clearInterval(this.countdownTimer);
        this.countdownTimer = setInterval(updateCountdown, 1000);
    }
    
    useDemoData() {
        // Demo aircraft data for when API is unavailable
        const demoAircraft = [
            {
                icao24: 'a8f3c1', callsign: 'UAL1234', country: 'United States',
                latitude: 34.0522, longitude: -118.2437, baroAltitude: 10668,
                onGround: false, velocity: 250, heading: 270,
                verticalRate: 0, squawk: '1200', typecode: 'B738'
            },
            {
                icao24: 'a12345', callsign: 'DAL456', country: 'United States',
                latitude: 40.7128, longitude: -74.0060, baroAltitude: 9144,
                onGround: false, velocity: 220, heading: 180,
                verticalRate: -500, squawk: '4521', typecode: 'A320'
            },
            {
                icao24: 'ae01ce', callsign: 'RCH345', country: 'United States',
                latitude: 38.8977, longitude: -77.0365, baroAltitude: 12192,
                onGround: false, velocity: 300, heading: 90,
                verticalRate: 0, squawk: '7700', typecode: 'C17'
            },
            {
                icao24: 'a9b8c7', callsign: '', country: 'United States',
                latitude: 25.7617, longitude: -80.1918, baroAltitude: 3048,
                onGround: false, velocity: 150, heading: 45,
                verticalRate: 300, squawk: '1200', typecode: 'C172'
            },
            {
                icao24: 'c0ffee', callsign: 'BAW117', country: 'United Kingdom',
                latitude: 51.5074, longitude: -0.1278, baroAltitude: 10000,
                onGround: false, velocity: 280, heading: 135,
                verticalRate: -200, squawk: '2000', typecode: 'B77W'
            },
            {
                icao24: 'd12345', callsign: 'DLH400', country: 'Germany',
                latitude: 48.1351, longitude: 11.5820, baroAltitude: 11000,
                onGround: false, velocity: 290, heading: 315,
                verticalRate: 0, squawk: '1000', typecode: 'A359'
            },
            {
                icao24: 'a45678', callsign: 'SWA2891', country: 'United States',
                latitude: 32.7767, longitude: -96.7970, baroAltitude: 8000,
                onGround: false, velocity: 200, heading: 225,
                verticalRate: -800, squawk: '3421', typecode: 'B737'
            },
            {
                icao24: 'ab1234', callsign: '', country: 'United States',
                latitude: 41.8781, longitude: -87.6298, baroAltitude: 0,
                onGround: true, velocity: 0, heading: 90,
                verticalRate: 0, squawk: '1200', typecode: 'GLF5'
            }
        ];
        
        // Convert demo data to OpenSky format
        const states = demoAircraft.map(ac => [
            ac.icao24, ac.callsign, ac.country, null, null,
            ac.longitude, ac.latitude, ac.baroAltitude, ac.onGround,
            ac.velocity, ac.heading, ac.verticalRate,
            null, ac.baroAltitude / 3.281, ac.squawk, false, ac.typecode
        ]);
        
        this.updateAircraftMarkers({ states });
        this.updateStats({ states });
    }
}

// Initialize the application
let flightRadar;

document.addEventListener('DOMContentLoaded', () => {
    flightRadar = new FlightRadarHUD();
    
    // Add custom CSS for popups
    const style = document.createElement('style');
    style.textContent = `
        .leaflet-popup-content-wrapper {
            background: rgba(0, 15, 30, 0.95) !important;
            border: 1px solid rgba(0, 255, 136, 0.4) !important;
            border-radius: 4px !important;
            box-shadow: 0 0 20px rgba(0, 255, 136, 0.3) !important;
            color: #00ff88 !important;
            font-family: 'Courier New', monospace !important;
        }
        .leaflet-popup-tip {
            background: rgba(0, 15, 30, 0.95) !important;
            border: 1px solid rgba(0, 255, 136, 0.4) !important;
        }
        .leaflet-popup-close-button {
            color: #ff3344 !important;
        }
        .leaflet-popup-close-button:hover {
            color: #ff6677 !important;
        }
    `;
    document.head.appendChild(style);
});
