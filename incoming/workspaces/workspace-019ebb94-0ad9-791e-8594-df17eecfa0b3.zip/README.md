# Ensō × BIP-39 Haiku Wallet × PIM IRC Client

A fully offline HTML5 web application converted from the [PIM Java source](https://github.com/sgreeran/pim).

## What was converted

The JAR contained raw Java source code (not compiled bytecode). Every file was read and converted:

### Java → JavaScript Mapping

| Original Java File | Converted To | Notes |
|---|---|---|
| `PimTest.java` | `js/app.js` + `js/irc.js` | **GUI (Swing) commented out, CLI restored** |
| `CmdProcessor.java` | `js/irc.js` handleCommand() | `/msg`, `/add`, `/remove`, `/block`, `/list`, `/help`, `/quit` |
| `Network.java` | `js/irc.js` IRCClient | Raw TCP → WebSocket IRC transport |
| `Connect.java` | `js/irc.js` onmessage | ObjectInputStream → WebSocket text frames |
| `listen.java` | WebSocket connection | ServerSocket → WebSocket URL |
| `listenBroadcast.java` | WebSocket reconnect | UDP multicast → WebSocket |
| `MsgGui.java` | **COMMENTED OUT** | GUI chat windows → CLI terminal buffers |
| `Display.java` | `termPrint()` | `System.out.println` → terminal output |
| `Peerlist.java` | IRC window management | Peer tracking → IRC channel/user tracking |
| `Peer.java` | IRC user state | Alias/IP/key → IRC nick/host |
| `UserInfo.java` | Client state | user info → IRC connection state |
| `Crypto.java` | **NOT CONVERTED** | RSA encryption → TLS via WSS |
| `Voice.java` | **NOT CONVERTED** | Java Sound API only |
| `SMSMsg.java` | **NOT CONVERTED** | Direct SMTP socket only |
| `FileMsg.java` | **NOT CONVERTED** | DCC file transfer only |

### Key Changes
- **CLI restored**: The command-line interface in `PimTest.main()` was commented out. It's now the primary interface.
- **GUI commented out**: `MsgGui` (Swing), `PimTest` (JFrame), `AddToChat`, `Voice` — all GUI components removed.
- **WebSocket transport**: `Network.java` used raw TCP sockets + UDP multicast. Converted to WebSocket IRC protocol.
- **IRC integration**: Full IRC client with `/connect`, `/join`, `/nick`, `/msg`, `/query`, `/whois`, `/mode`, `/kick`, `/topic`, etc.

## 🖌️ Ensō Generator (tab 1)
Seeded procedural ensō circle with 11 parameters, PNG download.

## 🔐 BIP-39 Haiku Wallet (tab 2)
Mine valid mnemonics forming 5-7-5 haikus. AES-256 encrypted storage.

## 💻 IRC Terminal (tab 3)
Full IRC client over WebSocket with multi-window sidebar.

```
Quick start: /connect wss://irc.libera.chat YourNick
```

## Files
```
index.html      — Main page (22 KB)
js/wordlist.js  — BIP-39 wordlist (2048 words)
js/enso.js      — Seeded ensō generator
js/wallet.js    — BIP-39 haiku miner + AES-256
js/irc.js       — Full IRC client over WebSocket (32 KB)
js/app.js       — App controller (25 KB)
```
