import React, { useEffect, useRef, useState } from 'react';
import { BookshelfDoor } from './components/BookshelfDoor';
import { DesktopWindowManager } from './components/DesktopWindowManager';

export const App: React.FC = () => {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [inControlRoom, setInControlRoom] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('patent-office-theme');
    return saved ? saved === 'dark' : true;
  });
  const unlockTimerRef = useRef<number | null>(null);

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev);

  const clearUnlockTimer = () => {
    if (unlockTimerRef.current !== null) {
      window.clearTimeout(unlockTimerRef.current);
      unlockTimerRef.current = null;
    }
  };

  const handleUnlockBookshelf = () => {
    if (isUnlocked || inControlRoom) return;
    setIsUnlocked(true);
    clearUnlockTimer();
    unlockTimerRef.current = window.setTimeout(() => {
      setInControlRoom(true);
      unlockTimerRef.current = null;
    }, 1500);
  };

  const handleLockBookshelf = () => {
    clearUnlockTimer();
    setInControlRoom(false);
    setIsUnlocked(false);
  };

  useEffect(() => {
    return () => clearUnlockTimer();
  }, []);

  useEffect(() => {
    localStorage.setItem('patent-office-theme', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  if (!inControlRoom) {
    return (
      <BookshelfDoor
        onUnlock={handleUnlockBookshelf}
        isUnlocked={isUnlocked}
        isDarkMode={isDarkMode}
        toggleDarkMode={toggleDarkMode}
      />
    );
  }

  return (
    <DesktopWindowManager
      onLockBookshelf={handleLockBookshelf}
      isDarkMode={isDarkMode}
      toggleDarkMode={toggleDarkMode}
    />
  );
};

export default App;
