import React, { useState } from 'react';
import { RefreshCw, CheckCircle, Award, Lightbulb } from 'lucide-react';

export const LogicPuzzle: React.FC = () => {
  // 3x3 Grid Lights Out game state
  const [grid, setGrid] = useState<boolean[]>([true, false, true, false, true, false, true, false, true]);
  const [moves, setMoves] = useState<number>(0);

  const toggleGrid = (index: number) => {
    const newGrid = [...grid];
    // Toggle clicked cell
    newGrid[index] = !newGrid[index];
    // Toggle top
    if (index >= 3) newGrid[index - 3] = !newGrid[index - 3];
    // Toggle bottom
    if (index < 6) newGrid[index + 3] = !newGrid[index + 3];
    // Toggle left
    if (index % 3 !== 0) newGrid[index - 1] = !newGrid[index - 1];
    // Toggle right
    if (index % 3 !== 2) newGrid[index + 1] = !newGrid[index + 1];

    setGrid(newGrid);
    setMoves((prev) => prev + 1);
  };

  const handleReset = () => {
    setGrid([true, false, true, false, true, false, true, false, true]);
    setMoves(0);
  };

  const isWon = grid.every((cell) => cell === true);

  return (
    <div className="w-full flex flex-col space-y-6 p-6">
      {/* Header Bar */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <Lightbulb className="w-8 h-8 text-amber-500 animate-pulse" />
          <div>
            <h2 className="text-xl font-mono font-extrabold text-amber-400">PATENT OFFICE LOGIC PUZZLE COPROCESSOR</h2>
            <p className="text-xs text-slate-400 font-mono">
              Align all cryptographic power matrix relays to unlock bonus patent schematics.
            </p>
          </div>
        </div>
        <button
          onClick={handleReset}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-mono text-xs flex items-center space-x-2 transition-all shadow"
        >
          <RefreshCw className="w-4 h-4 text-amber-500" />
          <span>Reset Grid</span>
        </button>
      </div>

      {/* Main Game Frame */}
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-8 shadow-xl max-w-3xl mx-auto w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        {/* Grid Game */}
        <div className="flex flex-col items-center space-y-6 bg-slate-950 p-6 rounded-2xl border border-slate-800 shadow-inner">
          <div className="flex justify-between w-full font-mono text-xs text-slate-400">
            <span>GRID SYSTEM: 3x3 RELAY</span>
            <span>MOVES: <strong className="text-amber-400">{moves}</strong></span>
          </div>

          <div className="grid grid-cols-3 gap-3 w-64 h-64">
            {grid.map((active, idx) => (
              <button
                key={idx}
                onClick={() => toggleGrid(idx)}
                className={`rounded-2xl border-2 font-mono font-bold text-xl transition-all duration-300 transform active:scale-95 shadow-lg ${
                  active
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-amber-500/30'
                    : 'bg-slate-900 text-slate-600 border-slate-800 shadow-none'
                }`}
              >
                {active ? 'ON' : 'OFF'}
              </button>
            ))}
          </div>

          <p className="text-[11px] font-mono text-slate-400 text-center">
            Clicking a relay toggles its state as well as all orthogonally adjacent relays. Turn all relays ON to win.
          </p>
        </div>

        {/* Victory Status */}
        <div className="flex flex-col space-y-6">
          <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 space-y-4 shadow">
            <h3 className="font-mono font-bold text-slate-200 text-lg flex items-center space-x-2 border-b border-slate-800 pb-3">
              <Award className="w-6 h-6 text-amber-500" />
              <span>Diagnostic Authorization Status</span>
            </h3>

            {isWon ? (
              <div className="space-y-4 animate-fadeIn">
                <div className="p-4 bg-emerald-950/40 border border-emerald-800 rounded-xl flex items-center space-x-3 text-emerald-300 font-mono text-sm">
                  <CheckCircle className="w-8 h-8 text-emerald-500 shrink-0" />
                  <div>
                    <span className="font-bold text-white block">POWER MATRIX ALIGNED!</span>
                    Secret patent authorization key unlocked.
                  </div>
                </div>

                <div className="p-4 bg-black rounded-lg border border-slate-800 font-mono text-xs space-y-2 text-amber-300">
                  <span className="text-slate-500 block text-[10px]">VERIFIED PATENT AUTHORIZATION KEY</span>
                  <div className="font-bold text-base select-all break-all">
                    IETF-PAT-99-LOGIC-AUTHORIZE-8812A
                  </div>
                  <p className="text-slate-400 text-[10px] pt-1 border-t border-slate-900">
                    Use this token in external IETF working group testnets.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 bg-amber-950/20 border border-amber-500/20 rounded-xl text-amber-300 font-mono text-xs space-y-2">
                  <span className="font-bold text-amber-400 block">SYSTEM LOCKED</span>
                  <p className="text-slate-300 leading-relaxed">
                    The secret patent authorization key remains encrypted until the 3x3 power matrix is fully illuminated.
                  </p>
                </div>

                <div className="p-4 bg-black rounded-lg border border-slate-900 font-mono text-xs text-slate-600 select-none">
                  [REDACTED AUTHORIZATION KEY]
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
