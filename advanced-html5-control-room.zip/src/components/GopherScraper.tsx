import React, { useState } from 'react';
import { Globe, Search, CloudRain, Newspaper, Terminal } from 'lucide-react';

export const GopherScraper: React.FC = () => {
  const [zipcode, setZipcode] = useState<string>("90210");
  const [secureLevel, setSecureLevel] = useState<number>(2); // 1 = Plain, 2 = Secure TLS, 3 = Maximum Geocoded ZK
  const [loading, setLoading] = useState<boolean>(false);
  const [weatherData, setWeatherData] = useState<{ temp: string; cond: string; geo: string }>({
    temp: "72°F (22.2°C)",
    cond: "Sunny with light coastal breeze. Humidity 45%.",
    geo: "Lat: 34.0901, Lon: -118.4065 (Beverly Hills / Los Angeles)"
  });
  const [newsFeed, setNewsFeed] = useState<Array<{ id: string; title: string; date: string }>>([
    { id: "gopher://floodgap.com/0/news/item1", title: "IETF Releases New Specifications for WebRTC TUN/TAP Bridging", date: "2026-03-15" },
    { id: "gopher://floodgap.com/0/news/item2", title: "Potassium Mining on Banano Lattice Surpasses 10 Terra-Hashes", date: "2026-03-14" },
    { id: "gopher://floodgap.com/0/news/item3", title: "CyberChef Deployed Across Secure Bookshelf Installations Globalwide", date: "2026-03-12" }
  ]);

  const handleScrapeGopher = () => {
    setLoading(true);
    setTimeout(() => {
      // Generate mock geocoded updates based on zipcode
      const hash = zipcode.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
      const temps = ["68°F (20.0°C)", "75°F (23.8°C)", "55°F (12.7°C)", "82°F (27.7°C)"];
      const conds = ["Partly cloudy with scattered rain.", "Clear skies. Excellent SSTV radio propagation conditions.", "Heavy fog. Recommended avian carrier pigeon grounding.", "Windy. High entropy observed in local atmospheric noise."];
      
      setWeatherData({
        temp: temps[hash % temps.length],
        cond: conds[hash % conds.length],
        geo: `Lat: ${(30 + (hash % 15)).toFixed(4)}, Lon: -${(80 + (hash % 40)).toFixed(4)} (Geocoded for Zip ${zipcode})`
      });

      setNewsFeed([
        { id: `gopher://floodgap.com/0/weather/zip/${zipcode}`, title: `Geocoded Weather Summary for Area Code ${zipcode}`, date: new Date().toISOString().slice(0, 10) },
        { id: `gopher://floodgap.com/0/news/local/${zipcode}`, title: `Regional IETF Working Group Discusses Exotic eth144 Storage Protocols`, date: new Date().toISOString().slice(0, 10) },
        { id: `gopher://floodgap.com/0/news/mesh`, title: `Wireframe Globe Mesh Nodes Report 99.9% Uptime across Swarm`, date: "2026-03-15" }
      ]);
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="w-full flex flex-col space-y-6 p-6 overflow-hidden max-w-full">
      {/* Header Bar */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg flex justify-between items-center max-w-full">
        <div className="flex items-center space-x-3 overflow-hidden">
          <Globe className="w-8 h-8 text-amber-500 shrink-0" />
          <div className="overflow-hidden">
            <h2 className="text-xl font-mono font-extrabold text-amber-400 truncate">FLOODGAPS GOPHER NEWS & WEATHER SCRAPER</h2>
            <p className="text-xs text-slate-400 font-mono truncate">
              Legacy gopher proxy protocol with geocoded zipcode resolution and adjustable security framing.
            </p>
          </div>
        </div>
        <div className="hidden md:flex items-center space-x-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800 shrink-0">
          <Terminal className="w-4 h-4 text-amber-500" />
          <span className="text-xs font-mono text-slate-300">gopher://floodgap.com:70</span>
        </div>
      </div>

      {/* Control Panel */}
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 shadow-xl space-y-6 max-w-full overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Zipcode Input */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <label className="block text-xs font-mono text-slate-400">TARGET ZIPCODE / POSTAL AREA</label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={zipcode}
                onChange={(e) => setZipcode(e.target.value)}
                placeholder="e.g. 90210"
                className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-500"
              />
              <button
                onClick={handleScrapeGopher}
                disabled={loading}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-mono font-bold rounded-lg shadow transition-all flex items-center space-x-1 shrink-0"
              >
                <Search className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                <span>{loading ? 'Scraping...' : 'Scrape'}</span>
              </button>
            </div>
            <span className="text-[10px] font-mono text-slate-500 block">Queries floodgap.com gopher root via secure local proxy bridge.</span>
          </div>

          {/* Secure Mode Slider */}
          <div className="lg:col-span-2 p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <div className="flex justify-between items-center">
              <label className="block text-xs font-mono text-slate-400">GOPHER SCRAPER SECURE OPTION LEVEL</label>
              <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold ${
                secureLevel === 1 ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                secureLevel === 2 ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {secureLevel === 1 ? 'Level 1: Standard Gopher (Plaintext)' :
                 secureLevel === 2 ? 'Level 2: TLS Encapsulated Proxy' :
                 'Level 3: Zero-Knowledge Encrypted Geocoding'}
              </span>
            </div>

            <input
              type="range"
              min="1"
              max="3"
              value={secureLevel}
              onChange={(e) => setSecureLevel(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />

            <div className="text-xs font-mono text-slate-400 pt-1">
              {secureLevel === 1 && "Displays raw cleartext gopher weather menus directly from server port 70."}
              {secureLevel === 2 && "Applies HTTPS-to-Gopher proxy encapsulation with strict frame isolation."}
              {secureLevel === 3 && "Encodes location queries over TOR datachannels with zero-knowledge coordinate masking."}
            </div>
          </div>
        </div>

        {/* Display Results Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-full overflow-hidden">
          {/* Weather Display */}
          <div className="p-5 bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 rounded-xl shadow-lg space-y-4 overflow-hidden">
            <h4 className="font-mono font-bold text-amber-400 text-sm flex items-center space-x-2">
              <CloudRain className="w-5 h-5 text-amber-500" />
              <span>Geocoded Weather Report</span>
            </h4>
            
            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-black/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">GEO-COORDINATES</span>
                <span className="text-emerald-400 font-bold block truncate">{weatherData.geo}</span>
              </div>
              <div className="p-3 bg-black/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">CURRENT TEMPERATURE</span>
                <span className="text-amber-300 font-extrabold text-base block">{weatherData.temp}</span>
              </div>
              <div className="p-3 bg-black/60 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">ATMOSPHERIC CONDITIONS</span>
                <span className="text-slate-200 block leading-normal">{weatherData.cond}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-[10px] font-mono text-slate-500">
              <span>Source: floodgaps gopher weather</span>
              <span>Frames verified bounded</span>
            </div>
          </div>

          {/* News Feed Display */}
          <div className="lg:col-span-2 p-5 bg-slate-950 border border-slate-800 rounded-xl shadow-lg space-y-4 max-w-full overflow-hidden">
            <h4 className="font-mono font-bold text-amber-400 text-sm flex items-center space-x-2">
              <Newspaper className="w-5 h-5 text-amber-500" />
              <span>Gopher Area News Menu (Item 0 & 1)</span>
            </h4>

            <div className="space-y-3 max-h-80 overflow-y-auto pr-1 max-w-full">
              {newsFeed.map((item, idx) => (
                <div key={idx} className="p-3 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-850 transition-all space-y-1 overflow-hidden">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-mono bg-slate-800 text-amber-400 px-2 py-0.5 rounded truncate max-w-[70%]">
                      {item.id}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 shrink-0">{item.date}</span>
                  </div>
                  <h5 className="font-mono font-bold text-slate-200 text-sm break-words leading-snug">
                    {secureLevel === 3 ? `🔒 [SECURE SHIELDED TITLE] ${item.title}` : item.title}
                  </h5>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
