import React, { useState } from 'react';
import { Moon, Sun, Key, Shield, BookOpen, Lock, Unlock } from 'lucide-react';

interface BookshelfDoorProps {
  onUnlock: () => void;
  isUnlocked: boolean;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export const BookshelfDoor: React.FC<BookshelfDoorProps> = ({
  onUnlock,
  isUnlocked,
  isDarkMode,
  toggleDarkMode,
}) => {
  const [activeTip, setActiveTip] = useState<string>("Click on book titles to examine them. Find the hidden mechanism to unlock the Patent Office.");
  const [wobblingBook, setWobblingBook] = useState<number | null>(null);

  const books = [
    { id: 1, title: "IETF RFC Archive Vol. 1", color: "bg-amber-900 border-amber-700 text-amber-200", hint: "Full of foundational network architecture proposals and early internet RFCs." },
    { id: 2, title: "BIP-39 Mnemonic Haiku Poetry", color: "bg-emerald-900 border-emerald-700 text-emerald-200", hint: "Explores the harmonic beauty of deterministic seed phrase wordlists." },
    { id: 3, title: "Banano Rare Artifact Exploration", color: "bg-yellow-700 border-yellow-500 text-amber-950 font-bold", hint: "A field guide to potassium-rich cryptographic mining artifacts." },
    { id: 4, title: "SSTV Ham Radio Transmission Specs", color: "bg-blue-900 border-blue-700 text-blue-200", hint: "MMSSTV sync protocols, slant calibration, and audio frequency mapping." },
    { id: 5, title: "CyberChef Secret Recipes", color: "bg-purple-900 border-purple-700 text-purple-200", hint: "A compendium of data conversion operations, bencode parsing, and hashing algorithms." },
    { id: 6, title: "Exotic Web3 Storage: ETH144", color: "bg-slate-800 border-slate-600 text-slate-300", hint: "Advanced specifications for multi-layered Ethereum testnet storage standards." },
    { id: 7, title: "Floodgaps Gopher Protocols", color: "bg-teal-900 border-teal-700 text-teal-200", hint: "Geocoded news scrapers and legacy text-only gopher navigation architectures." },
    { id: 8, title: "PATENT #4,042,981 (Pull Me)", color: "bg-red-800 border-red-600 text-white font-extrabold animate-pulse", hint: "This spine feels loose... pulling it might trigger a hidden mechanical gear behind the bookshelf!", isSecret: true },
    { id: 9, title: "Secure IRC & WebRTC TUN/TAP", color: "bg-indigo-950 border-indigo-800 text-indigo-200", hint: "Deep technical breakdown of DataChannel bridging over peer-to-peer tunnels." },
    { id: 10, title: "The HTML5 Quine & Selfie Guide", color: "bg-rose-950 border-rose-800 text-rose-200", hint: "Self-replicating source code and web browser PWA native installation manuals." }
  ];

  const handleBookClick = (book: typeof books[0]) => {
    setActiveTip(book.hint);
    setWobblingBook(book.id);
    setTimeout(() => setWobblingBook(null), 500);

    if (book.isSecret) {
      setTimeout(() => {
        onUnlock();
      }, 700);
    }
  };

  return (
    <div className={`min-h-screen w-full flex flex-col items-center justify-center p-4 transition-colors duration-500 ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-amber-50 text-slate-800'}`}>
      {/* Header Bar */}
      <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10 max-w-6xl mx-auto">
        <div className="flex items-center space-x-3 bg-opacity-80 backdrop-blur-md p-2 px-4 rounded-xl shadow-lg border border-amber-500/30">
          <Shield className="w-6 h-6 text-amber-500" />
          <span className="font-mono font-bold text-lg tracking-wider">RESTRICTED FACILITY: SECRET PATENT OFFICE</span>
        </div>
        <button
          onClick={toggleDarkMode}
          className="p-3 rounded-full bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-500 transition-all shadow-md flex items-center space-x-2"
          title="Toggle Day/Night Mode"
        >
          {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          <span className="hidden sm:inline font-mono text-xs">{isDarkMode ? 'Day Mode' : 'Night Mode'}</span>
        </button>
      </div>

      {/* Main Container */}
      <div className="w-full max-w-5xl mt-16 mb-8 flex flex-col items-center">
        {/* Bookshelf Frame */}
        <div className={`relative w-full border-8 border-amber-950 rounded-2xl p-6 shadow-2xl overflow-hidden transition-all duration-700 ${isDarkMode ? 'bg-amber-900/20 shadow-amber-500/5' : 'bg-amber-800 shadow-amber-900/20'}`}>
          {/* Wooden backboard texture simulation */}
          <div className="absolute inset-0 bg-gradient-to-b from-amber-950 via-amber-900 to-amber-950 opacity-90 pointer-events-none" />
          
          <div className="relative z-10">
            <div className="text-center mb-8">
              <h1 className="text-3xl sm:text-5xl font-extrabold text-amber-100 font-serif tracking-wide drop-shadow-md">
                The Historical Bookshelf
              </h1>
              <p className="text-amber-300 font-mono text-sm mt-2 max-w-2xl mx-auto bg-black/40 p-2 rounded-lg border border-amber-500/30">
                {activeTip}
              </p>
            </div>

            {/* Books Shelves Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 p-4 bg-amber-950/60 rounded-xl border-t-8 border-b-8 border-amber-800 shadow-inner">
              {books.map((book) => (
                <div
                  key={book.id}
                  onClick={() => handleBookClick(book)}
                  className={`group relative flex flex-col justify-between h-56 p-4 rounded-r-xl border-l-8 cursor-pointer select-none shadow-xl transition-all duration-300 hover:scale-105 hover:shadow-2xl ${book.color} ${wobblingBook === book.id ? 'animate-bounce' : ''}`}
                >
                  <div className="flex justify-between items-center opacity-70 group-hover:opacity-100 transition-opacity">
                    <BookOpen className="w-5 h-5" />
                    <span className="font-mono text-xs opacity-75">VOL {book.id}</span>
                  </div>
                  
                  <div className="my-auto">
                    <h3 className="font-serif font-bold text-lg leading-tight tracking-wide group-hover:translate-x-1 transition-transform">
                      {book.title}
                    </h3>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-white/10 text-xs font-mono opacity-80">
                    <span>{book.isSecret ? '★ LATCH' : 'IETF / BIP'}</span>
                    {book.isSecret ? <Unlock className="w-4 h-4 text-red-300 animate-pulse" /> : <Lock className="w-3 h-3 opacity-50" />}
                  </div>

                  {book.isSecret && (
                    <div className="absolute -bottom-2 -right-2 bg-red-600 text-white px-2 py-1 text-[10px] font-mono uppercase font-bold rounded shadow animate-ping">
                      SECRET
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Shelf bottom wood plank */}
            <div className="h-6 bg-amber-800 rounded-b shadow-lg border-t border-amber-700 mt-2" />
          </div>

          {/* Unlock Overlay Animation */}
          {isUnlocked && (
            <div className="absolute inset-0 bg-black/90 z-50 flex flex-col items-center justify-center space-y-4 animate-fadeIn">
              <Key className="w-16 h-16 text-amber-500 animate-spin" />
              <h2 className="text-3xl font-mono font-bold text-amber-400 animate-pulse">SECRET BOOKSHELF UNLOCKING...</h2>
              <p className="text-slate-300 font-mono text-sm max-w-md text-center">
                Mechanical hydraulic gears engaged. Opening secure airlock to the highly advanced IETF Patent Office & Standards Control Room.
              </p>
              <div className="w-48 h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 animate-[width_1s_ease-in-out]" style={{ width: '100%' }} />
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          <button
            onClick={() => onUnlock()}
            className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-white font-mono font-bold rounded-xl shadow-lg hover:shadow-amber-500/50 transition-all flex items-center space-x-2 border border-amber-400/30"
          >
            <Key className="w-5 h-5" />
            <span>Force Open Bookshelf (Enter Control Room)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
