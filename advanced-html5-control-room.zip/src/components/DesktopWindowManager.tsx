import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Menu, Moon, Sun, Lock, Minus, Square, X,
  BookOpen, Coins, Wand2, Shield, Radio, Globe,
  Lightbulb, MessageSquare, Code, LayoutGrid, Terminal,
  RotateCcw, PanelLeft, PanelRight, Maximize2,
} from 'lucide-react';

import { RFCArchive } from './RFCArchive';
import { CryptoSandbox } from './CryptoSandbox';
import { CyberChefApp } from './CyberChefApp';
import { SecuritySuite } from './SecuritySuite';
import { SSTVWebRTC } from './SSTVWebRTC';
import { GopherScraper } from './GopherScraper';
import { SpinningGlobe } from './SpinningGlobe';
import { LogicPuzzle } from './LogicPuzzle';
import { IRCApp } from './IRCApp';
import { QuineSelfieModal } from './QuineSelfieModal';
import { DrSbaitsoApp } from './DrSbaitsoApp';

interface AppDef {
  id: string;
  label: string;
  desc: string;
  icon: React.ElementType;
}

interface WinState {
  id: string;
  appId: string;
  title: string;
  Icon: React.ElementType;
  x: number;
  y: number;
  w: number;
  h: number;
  minimized: boolean;
  maximized: boolean;
  z: number;
}

interface DesktopWindowManagerProps {
  onLockBookshelf: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const APP_CATALOG: AppDef[] = [
  { id: 'rfcs', label: 'IETF RFC Archive', desc: 'Interactive working RFC demonstrations', icon: BookOpen },
  { id: 'crypto', label: 'BIP & Exotic Web3 Sandbox', desc: 'Haiku miner, Banano relics, Wave DEX', icon: Coins },
  { id: 'cyberchef', label: 'CyberChef Embedded App', desc: 'Data encoding, crypto & Magnet parser', icon: Wand2 },
  { id: 'security', label: 'Defensive Pentest Suite', desc: 'CIDR, strict CSP & entropy inspector', icon: Shield },
  { id: 'sstv', label: 'SSTV Modem & WebRTC', desc: 'AFSK synthesizer & TUN/TAP fallback', icon: Radio },
  { id: 'gopher', label: 'Floodgaps Gopher Scraper', desc: 'Geocoded weather & news gopher menu', icon: Globe },
  { id: 'globe', label: 'RSS Wireframe Globe', desc: '3D wireframe mesh active relays', icon: Globe },
  { id: 'puzzle', label: 'Logic Puzzle Coprocessor', desc: '3×3 power matrix alignment relay', icon: Lightbulb },
  { id: 'irc', label: 'IRC & Secure IRC Client', desc: 'Live chat with encryption toggle', icon: MessageSquare },
  { id: 'quine', label: 'HTML5 Quine Selfie & PWA', desc: 'Self-replicating bundle & install popup', icon: Code },
  { id: 'sbaitso', label: 'Dr. Sbaitso AI', desc: 'Sound Blaster retro AI psychologist', icon: MessageSquare },
];

const AppContent = React.memo(({ appId }: { appId: string }) => {
  switch (appId) {
    case 'rfcs':
      return <RFCArchive />;
    case 'crypto':
      return <CryptoSandbox />;
    case 'cyberchef':
      return <CyberChefApp />;
    case 'security':
      return <SecuritySuite />;
    case 'sstv':
      return <SSTVWebRTC />;
    case 'gopher':
      return <GopherScraper />;
    case 'globe':
      return <SpinningGlobe />;
    case 'puzzle':
      return <LogicPuzzle />;
    case 'irc':
      return <IRCApp />;
    case 'quine':
      return <QuineSelfieModal />;
    case 'sbaitso':
      return <DrSbaitsoApp />;
    default:
      return <div className="p-6 font-mono text-slate-400">Component not found.</div>;
  }
});

const TITLEBAR_H = 48;
const MIN_WIN_W = 360;
const MIN_WIN_H = 260;
const MIN_VISIBLE_X = 80;
const WM_STORAGE_KEY = 'patent-office-wm-layout-v2';

export const DesktopWindowManager: React.FC<DesktopWindowManagerProps> = ({
  onLockBookshelf,
  isDarkMode,
  toggleDarkMode,
}) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [topZ, setTopZ] = useState(100);
  const [wins, setWins] = useState<WinState[]>([]);
  const [clock, setClock] = useState('');
  const [startOpen, setStartOpen] = useState(false);
  const [toasts, setToasts] = useState<Array<{ id: number; title: string; body: string }>>([]);

  const canvasRef = useRef<HTMLDivElement>(null);
  const zRef = useRef(100);
  const bootstrappedRef = useRef(false);
  const winElMap = useRef<Map<string, HTMLDivElement>>(new Map());

  const dragRef = useRef<{
    winId: string;
    startPx: number;
    startPy: number;
    initX: number;
    initY: number;
  } | null>(null);

  const resizeRef = useRef<{
    winId: string;
    startPx: number;
    startPy: number;
    initW: number;
    initH: number;
  } | null>(null);

  useEffect(() => {
    const tick = () => {
      setClock(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  const allocateZ = useCallback(() => {
    zRef.current += 1;
    setTopZ(zRef.current);
    return zRef.current;
  }, []);

  const notify = useCallback((title: string, body: string) => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setToasts((prev) => [{ id, title, body }, ...prev].slice(0, 4));
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 3200);
  }, []);

  const canvasBounds = useCallback(() => {
    const el = canvasRef.current;
    if (!el) {
      return {
        cw: window.innerWidth,
        ch: window.innerHeight - 96,
      };
    }
    return {
      cw: el.clientWidth,
      ch: el.clientHeight,
    };
  }, []);

  const clampPosition = useCallback(
    (x: number, y: number, w: number) => {
      const { cw, ch } = canvasBounds();
      const clampedX = Math.max(-(w - MIN_VISIBLE_X), Math.min(x, cw - MIN_VISIBLE_X));
      const clampedY = Math.max(0, Math.min(y, ch - TITLEBAR_H));
      return { x: clampedX, y: clampedY };
    },
    [canvasBounds]
  );

  const clampWindow = useCallback(
    (win: WinState): WinState => {
      if (win.maximized) return win;
      const { cw, ch } = canvasBounds();
      const maxW = Math.max(MIN_WIN_W, cw);
      const maxH = Math.max(MIN_WIN_H, ch);
      const w = Math.min(win.w, maxW);
      const h = Math.min(win.h, maxH);
      const { x, y } = clampPosition(win.x, win.y, w);
      return { ...win, x, y, w, h };
    },
    [canvasBounds, clampPosition]
  );

  const syncWindowDom = useCallback((win: WinState) => {
    const el = winElMap.current.get(win.id);
    if (!el || win.maximized) return;
    el.style.left = `${win.x}px`;
    el.style.top = `${win.y}px`;
    el.style.width = `${win.w}px`;
    el.style.height = `${win.h}px`;
    el.style.zIndex = String(win.z);
  }, []);

  const bringToFront = useCallback(
    (winId: string) => {
      const z = allocateZ();
      setWins((prev) => prev.map((w) => (w.id === winId ? { ...w, z } : w)));
      const el = winElMap.current.get(winId);
      if (el) el.style.zIndex = String(z);
    },
    [allocateZ]
  );

  const createWindowForApp = useCallback(
    (app: AppDef, existingCount: number): WinState => {
      const { cw, ch } = canvasBounds();
      const w = Math.max(MIN_WIN_W, Math.min(820, cw - 60));
      const h = Math.max(MIN_WIN_H, Math.min(580, ch - 60));
      const offset = existingCount % 5;
      const rawX = Math.floor((cw - w) / 2 + offset * 28);
      const rawY = Math.floor((ch - h) / 4 + offset * 22);
      const pos = clampPosition(rawX, Math.max(0, rawY), w);

      return {
        id: `w-${app.id}-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
        appId: app.id,
        title: app.label,
        Icon: app.icon,
        x: pos.x,
        y: pos.y,
        w,
        h,
        minimized: false,
        maximized: false,
        z: allocateZ(),
      };
    },
    [allocateZ, canvasBounds, clampPosition]
  );

  const openApp = useCallback(
    (app: AppDef) => {
      setWins((prev) => {
        const existing = prev.find((w) => w.appId === app.id);
        if (existing) {
          const z = allocateZ();
          notify('Window focused', app.label);
          return prev.map((w) =>
            w.id === existing.id ? { ...w, minimized: false, z } : w
          );
        }

        const newWin = createWindowForApp(app, prev.length);
        notify('Application opened', app.label);
        return [...prev, newWin];
      });
    },
    [allocateZ, createWindowForApp, notify]
  );

  const closeWin = useCallback((id: string) => {
    setWins((prev) => prev.filter((w) => w.id !== id));
    winElMap.current.delete(id);
  }, []);

  const minimizeWin = useCallback((id: string) => {
    setWins((prev) => prev.map((w) => (w.id === id ? { ...w, minimized: !w.minimized } : w)));
  }, []);

  const maximizeWin = useCallback(
    (id: string) => {
      const z = allocateZ();
      setWins((prev) => prev.map((w) => (w.id === id ? { ...w, maximized: !w.maximized, z } : w)));
    },
    [allocateZ]
  );

  const makeGlobeWindow = useCallback((): WinState | null => {
    const app = APP_CATALOG.find((a) => a.id === 'globe');
    if (!app) return null;
    const { cw, ch } = canvasBounds();
    return {
      id: `w-globe-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      appId: app.id,
      title: app.label,
      Icon: app.icon,
      x: 0,
      y: 0,
      w: Math.max(MIN_WIN_W, cw),
      h: Math.max(MIN_WIN_H, ch),
      minimized: false,
      maximized: true,
      z: allocateZ(),
    };
  }, [allocateZ, canvasBounds]);

  const resetWindows = useCallback(() => {
    const globe = makeGlobeWindow();
    if (globe) setWins([globe]);
    localStorage.removeItem(WM_STORAGE_KEY);
    setSidebarOpen(true);
    notify('Window manager reset', 'Restored the globe-first cleanroom layout.');
  }, [makeGlobeWindow, notify]);

  const snapWindow = useCallback((id: string, snap: 'left' | 'right' | 'full') => {
    const { cw, ch } = canvasBounds();
    const z = allocateZ();
    setWins((prev) => prev.map((w) => {
      if (w.id !== id) return w;
      if (snap === 'full') {
        return { ...w, x: 0, y: 0, w: cw, h: ch, maximized: true, minimized: false, z };
      }
      const half = Math.max(MIN_WIN_W, Math.floor(cw / 2));
      return {
        ...w,
        x: snap === 'left' ? 0 : Math.max(0, cw - half),
        y: 0,
        w: half,
        h: ch,
        maximized: false,
        minimized: false,
        z,
      };
    }));
    notify('Snap layout applied', snap === 'full' ? 'Window filled the canvas.' : `Window snapped ${snap}.`);
  }, [allocateZ, canvasBounds, notify]);

  useEffect(() => {
    if (bootstrappedRef.current) return;
    const { cw, ch } = canvasBounds();
    if (cw < 240 || ch < 240) return;
    bootstrappedRef.current = true;

    try {
      const raw = localStorage.getItem(WM_STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Array<Omit<WinState, 'Icon'>>;
        const restored = saved
          .map((win) => {
            const app = APP_CATALOG.find((a) => a.id === win.appId);
            if (!app) return null;
            return clampWindow({ ...win, Icon: app.icon });
          })
          .filter(Boolean) as WinState[];
        if (restored.length > 0) {
          const maxZ = Math.max(...restored.map((w) => w.z), zRef.current);
          zRef.current = maxZ;
          setTopZ(maxZ);
          setWins(restored);
          return;
        }
      }
    } catch {
      localStorage.removeItem(WM_STORAGE_KEY);
    }

    const globe = makeGlobeWindow();
    if (globe) setWins([globe]);
  }, [canvasBounds, clampWindow, makeGlobeWindow]);

  useEffect(() => {
    if (!bootstrappedRef.current) return;
    const serialisable = wins.map(({ Icon, ...win }) => win);
    localStorage.setItem(WM_STORAGE_KEY, JSON.stringify(serialisable));
  }, [wins]);

  useEffect(() => {
    const applyBounds = () => {
      setWins((prev) => prev.map(clampWindow));
    };

    const handleResize = () => applyBounds();
    window.addEventListener('resize', handleResize);

    const id1 = window.requestAnimationFrame(applyBounds);
    const id2 = window.setTimeout(applyBounds, 240);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.cancelAnimationFrame(id1);
      window.clearTimeout(id2);
    };
  }, [sidebarOpen, clampWindow]);

  useEffect(() => {
    wins.forEach(syncWindowDom);
  }, [wins, syncWindowDom]);

  const onTitlePointerDown = useCallback(
    (e: React.PointerEvent, win: WinState) => {
      if (win.maximized) return;
      e.preventDefault();
      bringToFront(win.id);

      const el = winElMap.current.get(win.id);
      const initX = el ? parseInt(el.style.left, 10) || win.x : win.x;
      const initY = el ? parseInt(el.style.top, 10) || win.y : win.y;

      dragRef.current = {
        winId: win.id,
        startPx: e.clientX,
        startPy: e.clientY,
        initX,
        initY,
      };

      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    },
    [bringToFront]
  );

  const onTitlePointerMove = useCallback(
    (e: React.PointerEvent) => {
      const drag = dragRef.current;
      if (!drag) return;
      e.preventDefault();

      const win = wins.find((w) => w.id === drag.winId);
      const rawX = drag.initX + (e.clientX - drag.startPx);
      const rawY = drag.initY + (e.clientY - drag.startPy);
      const pos = clampPosition(rawX, rawY, win?.w ?? 600);

      const el = winElMap.current.get(drag.winId);
      if (el) {
        el.style.left = `${pos.x}px`;
        el.style.top = `${pos.y}px`;
      }
    },
    [wins, clampPosition]
  );

  const onTitlePointerUp = useCallback((e: React.PointerEvent) => {
    const drag = dragRef.current;
    if (!drag) return;
    (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);

    const el = winElMap.current.get(drag.winId);
    if (el) {
      const x = parseInt(el.style.left, 10) || 0;
      const y = parseInt(el.style.top, 10) || 0;
      setWins((prev) => prev.map((w) => (w.id === drag.winId ? { ...w, x, y } : w)));
    }

    dragRef.current = null;
  }, []);

  const onResizePointerDown = useCallback(
    (e: React.PointerEvent, win: WinState) => {
      if (win.maximized) return;
      e.preventDefault();
      e.stopPropagation();
      bringToFront(win.id);

      const el = winElMap.current.get(win.id);
      resizeRef.current = {
        winId: win.id,
        startPx: e.clientX,
        startPy: e.clientY,
        initW: el ? el.offsetWidth : win.w,
        initH: el ? el.offsetHeight : win.h,
      };

      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    },
    [bringToFront]
  );

  const onResizePointerMove = useCallback(
    (e: React.PointerEvent) => {
      const resize = resizeRef.current;
      if (!resize) return;
      e.preventDefault();

      const target = wins.find((w) => w.id === resize.winId);
      const { cw, ch } = canvasBounds();
      const maxW = target ? cw - target.x : cw;
      const maxH = target ? ch - target.y : ch;
      const nextW = Math.max(MIN_WIN_W, Math.min(resize.initW + (e.clientX - resize.startPx), maxW));
      const nextH = Math.max(MIN_WIN_H, Math.min(resize.initH + (e.clientY - resize.startPy), maxH));

      const el = winElMap.current.get(resize.winId);
      if (el) {
        el.style.width = `${nextW}px`;
        el.style.height = `${nextH}px`;
      }
    },
    [wins, canvasBounds]
  );

  const onResizePointerUp = useCallback((e: React.PointerEvent) => {
    const resize = resizeRef.current;
    if (!resize) return;
    (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);

    const el = winElMap.current.get(resize.winId);
    if (el) {
      setWins((prev) =>
        prev.map((w) =>
          w.id === resize.winId ? { ...w, w: el.offsetWidth, h: el.offsetHeight } : w
        )
      );
    }

    resizeRef.current = null;
  }, []);

  const dark = isDarkMode;

  return (
    <div className={`relative w-full h-screen flex flex-col overflow-hidden ${dark ? 'bg-slate-950 text-slate-100' : 'bg-slate-200 text-slate-800'}`}>
      <header className={`h-12 shrink-0 flex items-center justify-between px-3 gap-2 border-b z-50 ${dark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
        <div className="flex items-center gap-2 min-w-0">
          <button
            onClick={() => setSidebarOpen((open) => !open)}
            className={`p-2 rounded-lg border transition-colors shrink-0 ${dark ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-amber-400' : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-700'}`}
            title="Toggle sidebar"
          >
            <Menu className="w-4 h-4" />
          </button>

          <div className={`flex items-center gap-2 px-3 py-1 rounded-lg border text-amber-400 shrink-0 ${dark ? 'bg-slate-800/60 border-amber-500/20' : 'bg-amber-50 border-amber-300'}`}>
            <Shield className="w-4 h-4 text-amber-500 shrink-0" />
            <span className="font-mono font-bold text-xs tracking-widest hidden sm:block">PATENT OFFICE WM</span>
          </div>
        </div>

        <div className={`hidden lg:flex items-center gap-2 px-3 py-1 rounded-lg border font-mono text-xs shrink-0 ${dark ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-slate-100 border-slate-300 text-slate-600'}`}>
          <Terminal className="w-3.5 h-3.5 text-emerald-500" />
          <span>{clock}</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={resetWindows}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors font-mono font-bold text-xs ${dark ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200' : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-700'}`}
            title="WM-01 Reset windows to the globe-first prototype layout"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-500" />
            Reset WM
          </button>

          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-lg border transition-colors ${dark ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-amber-400' : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-700'}`}
            title="Toggle Day/Night Mode"
          >
            {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            onClick={onLockBookshelf}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-700 hover:bg-red-600 text-white font-mono font-bold text-xs rounded-lg border border-red-600 transition-colors"
            title="Return to bookshelf"
          >
            <Lock className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Lock</span>
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden min-h-0">
        <aside
          className={`h-full flex flex-col border-r z-30 transition-[width] duration-200 overflow-hidden shrink-0 ${sidebarOpen ? 'w-64' : 'w-0'} ${dark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}
        >
          <div className={`px-4 py-3 border-b shrink-0 flex items-center gap-2 ${dark ? 'border-slate-800' : 'border-slate-200'}`}>
            <LayoutGrid className="w-4 h-4 text-amber-500 shrink-0" />
            <span className="font-mono font-bold text-xs uppercase tracking-widest text-slate-400 whitespace-nowrap">Applications</span>
          </div>

          <nav className="flex-1 overflow-y-auto p-2 flex flex-col gap-1">
            {APP_CATALOG.map((app) => {
              const Icon = app.icon;
              const isOpen = wins.some((w) => w.appId === app.id && !w.minimized);
              const isMin = wins.some((w) => w.appId === app.id && w.minimized);

              return (
                <button
                  key={app.id}
                  onClick={() => openApp(app)}
                  className={`flex items-start gap-2.5 w-full px-3 py-2.5 rounded-xl border text-left transition-all ${isOpen ? dark ? 'bg-slate-800 border-amber-500/50 text-amber-300' : 'bg-amber-50 border-amber-400 text-amber-700' : dark ? 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800 hover:border-slate-700' : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'}`}
                >
                  <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${isOpen ? 'text-amber-500' : 'text-slate-400'}`} />
                  <div className="min-w-0">
                    <div className="font-mono font-bold text-xs truncate flex items-center gap-1.5">
                      {app.label}
                      {isOpen && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />}
                      {isMin && <span className="text-[9px] opacity-60">(min)</span>}
                    </div>
                    <div className="text-[10px] text-slate-500 truncate mt-0.5">{app.desc}</div>
                  </div>
                </button>
              );
            })}
          </nav>
        </aside>

        <main ref={canvasRef} className={`relative flex-1 overflow-hidden min-w-0 min-h-0 ${dark ? 'bg-slate-950' : 'bg-slate-200'}`}>
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage: `radial-gradient(${dark ? '#334155' : '#94a3b8'} 1px, transparent 1px)`,
              backgroundSize: '22px 22px',
              opacity: 0.3,
            }}
          />

          <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-[0.04]">
            <div className="text-center">
              <Shield className="w-64 h-64 mx-auto" />
              <p className="font-mono text-3xl font-black tracking-widest mt-2">PATENT OFFICE WM</p>
            </div>
          </div>

          <div className="absolute left-3 top-3 z-10 grid grid-cols-1 gap-2 pointer-events-auto">
            {APP_CATALOG.slice(0, 7).map((app) => {
              const Icon = app.icon;
              return (
                <button
                  key={`desktop-${app.id}`}
                  onDoubleClick={() => openApp(app)}
                  onClick={() => notify('Desktop icon', `Double-click to open ${app.label}.`)}
                  className={`w-20 p-2 rounded-xl border text-center shadow transition ${dark ? 'bg-slate-900/70 hover:bg-slate-800 border-slate-700 text-slate-200' : 'bg-white/70 hover:bg-white border-slate-300 text-slate-700'}`}
                  title={`Desktop icon: ${app.label}`}
                >
                  <Icon className="w-5 h-5 mx-auto text-amber-500" />
                  <span className="block mt-1 font-mono text-[9px] leading-tight line-clamp-2">{app.label}</span>
                </button>
              );
            })}
          </div>

          {wins.map((win) => {
            const { Icon } = win;
            if (win.minimized) return null;

            const boxStyle: React.CSSProperties = win.maximized
              ? { top: 0, left: 0, width: '100%', height: '100%', zIndex: win.z }
              : { top: win.y, left: win.x, width: win.w, height: win.h, zIndex: win.z };

            return (
              <div
                key={win.id}
                ref={(el) => {
                  if (el) winElMap.current.set(win.id, el);
                  else winElMap.current.delete(win.id);
                }}
                style={boxStyle}
                className={`absolute flex flex-col border shadow-2xl ${win.maximized ? '' : 'rounded-xl'} ${dark ? 'bg-slate-900 border-slate-700/70 shadow-black/70' : 'bg-white border-slate-300 shadow-slate-500/40'}`}
                onPointerDown={() => bringToFront(win.id)}
              >
                <div
                  onPointerDown={(e) => onTitlePointerDown(e, win)}
                  onPointerMove={onTitlePointerMove}
                  onPointerUp={onTitlePointerUp}
                  onDoubleClick={() => maximizeWin(win.id)}
                  style={{ touchAction: 'none', cursor: win.maximized ? 'default' : 'grab' }}
                  className={`h-11 shrink-0 flex items-center justify-between px-3 gap-2 border-b select-none ${win.maximized ? '' : 'rounded-t-xl'} ${dark ? 'bg-slate-950 border-slate-800 text-slate-200' : 'bg-slate-100 border-slate-200 text-slate-700'}`}
                >
                  <div className="flex items-center gap-2 min-w-0 pointer-events-none">
                    <Icon className="w-4 h-4 text-amber-500 shrink-0" />
                    <span className="font-mono font-semibold text-xs truncate">{win.title}</span>
                  </div>

                  <div className="flex items-center gap-1 shrink-0" onPointerDown={(e) => e.stopPropagation()}>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        snapWindow(win.id, 'left');
                      }}
                      className="w-6 h-6 rounded-md flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-700"
                      title="WM-02 Snap left"
                    >
                      <PanelLeft className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        snapWindow(win.id, 'right');
                      }}
                      className="w-6 h-6 rounded-md flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-700"
                      title="WM-03 Snap right"
                    >
                      <PanelRight className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        snapWindow(win.id, 'full');
                      }}
                      className="w-6 h-6 rounded-md flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-700"
                      title="WM-04 Fill desktop canvas"
                    >
                      <Maximize2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        minimizeWin(win.id);
                      }}
                      className="w-6 h-6 rounded-md flex items-center justify-center bg-yellow-500 hover:bg-yellow-400 text-yellow-950 transition-colors"
                      title="Minimise"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        maximizeWin(win.id);
                      }}
                      className="w-6 h-6 rounded-md flex items-center justify-center bg-green-600 hover:bg-green-500 text-green-50 transition-colors"
                      title={win.maximized ? 'Restore' : 'Maximise'}
                    >
                      <Square className="w-3 h-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        closeWin(win.id);
                      }}
                      className="w-6 h-6 rounded-md flex items-center justify-center bg-red-600 hover:bg-red-500 text-red-50 transition-colors"
                      title="Close"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-auto min-h-0">
                  <AppContent appId={win.appId} />
                </div>

                {!win.maximized && (
                  <div
                    onPointerDown={(e) => onResizePointerDown(e, win)}
                    onPointerMove={onResizePointerMove}
                    onPointerUp={onResizePointerUp}
                    style={{ touchAction: 'none' }}
                    className="absolute bottom-0 right-0 w-6 h-6 cursor-se-resize z-10 flex items-end justify-end pb-1 pr-1"
                  >
                    <svg width="10" height="10" viewBox="0 0 10 10" className="opacity-40">
                      <line x1="2" y1="10" x2="10" y2="2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                      <line x1="6" y1="10" x2="10" y2="6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                  </div>
                )}
              </div>
            );
          })}

          {wins.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
              <div className="text-center space-y-3 opacity-40">
                <LayoutGrid className="w-16 h-16 mx-auto text-slate-500" />
                <p className="font-mono text-sm text-slate-400">Open an application from the sidebar</p>
              </div>
            </div>
          )}
        </main>
      </div>

      {startOpen && (
        <div className={`absolute left-3 bottom-14 z-[80] w-80 rounded-2xl border shadow-2xl overflow-hidden ${dark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-300 text-slate-800'}`}>
          <div className="px-4 py-3 border-b border-slate-800 flex items-center gap-2">
            <Shield className="w-5 h-5 text-amber-500" />
            <div>
              <div className="font-mono font-black text-xs text-amber-400">START MENU</div>
              <div className="font-mono text-[10px] text-slate-500">Choice B desktop launcher</div>
            </div>
          </div>
          <div className="p-2 max-h-96 overflow-y-auto grid grid-cols-1 gap-1">
            {APP_CATALOG.map((app) => {
              const Icon = app.icon;
              return (
                <button
                  key={`start-${app.id}`}
                  onClick={() => { openApp(app); setStartOpen(false); }}
                  className={`flex items-center gap-3 p-3 rounded-xl text-left border transition ${dark ? 'bg-slate-950 hover:bg-slate-800 border-slate-800' : 'bg-slate-50 hover:bg-slate-100 border-slate-200'}`}
                >
                  <Icon className="w-5 h-5 text-amber-500 shrink-0" />
                  <div className="min-w-0">
                    <div className="font-mono font-bold text-xs truncate">{app.label}</div>
                    <div className="font-mono text-[10px] text-slate-500 truncate">{app.desc}</div>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="p-2 border-t border-slate-800 flex gap-2">
            <button onClick={resetWindows} className="flex-1 px-3 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold text-xs">Reset WM</button>
            <button onClick={() => setStartOpen(false)} className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono font-bold text-xs">Close</button>
          </div>
        </div>
      )}

      <div className="absolute right-3 top-14 z-[90] space-y-2 pointer-events-none">
        {toasts.map((toast) => (
          <div key={toast.id} className="w-72 rounded-xl border border-slate-700 bg-slate-900/95 p-3 shadow-2xl pointer-events-auto">
            <div className="font-mono font-bold text-xs text-amber-400">{toast.title}</div>
            <div className="font-mono text-[10px] text-slate-300 mt-1">{toast.body}</div>
          </div>
        ))}
      </div>

      <footer className={`h-12 shrink-0 flex items-center justify-between gap-2 px-3 border-t z-50 overflow-hidden ${dark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
        <button
          onClick={() => setStartOpen((open) => !open)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 border border-amber-500 font-mono font-black text-xs shrink-0"
        >
          <LayoutGrid className="w-4 h-4" /> Start
        </button>
        <div className="flex items-center gap-1.5 overflow-x-auto min-w-0 flex-1 py-0.5">
          {wins.length === 0 && (
            <span className="font-mono text-xs text-slate-500 italic whitespace-nowrap px-2">
              No open windows — launch apps from the sidebar
            </span>
          )}

          {wins.map((win) => {
            const { Icon } = win;
            const isActive = win.z === topZ && !win.minimized;

            return (
              <button
                key={win.id}
                onClick={() => {
                  if (win.minimized) {
                    const z = allocateZ();
                    setWins((prev) => prev.map((w) => (w.id === win.id ? { ...w, minimized: false, z } : w)));
                  } else if (isActive) {
                    minimizeWin(win.id);
                  } else {
                    bringToFront(win.id);
                  }
                }}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-mono text-xs font-semibold border shrink-0 max-w-[180px] transition-all whitespace-nowrap ${isActive ? 'bg-amber-500 text-slate-950 border-amber-400 shadow shadow-amber-500/30' : win.minimized ? dark ? 'bg-slate-800/50 text-slate-400 border-slate-700' : 'bg-slate-100 text-slate-500 border-slate-300' : dark ? 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'}`}
              >
                <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-slate-950' : 'text-amber-500'}`} />
                <span className="truncate">{win.title}</span>
                {win.minimized && <Minus className="w-3 h-3 opacity-50 shrink-0" />}
              </button>
            );
          })}
        </div>

        <div className={`flex items-center gap-3 font-mono text-xs shrink-0 pl-3 border-l ${dark ? 'text-slate-400 border-slate-800' : 'text-slate-500 border-slate-300'}`}>
          <span className="hidden md:inline">{clock}</span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Swarm Online" />
        </div>
      </footer>
    </div>
  );
};
