import React, { useState, useEffect } from 'react';
import { Coins, Cpu, Award, Printer, Shield, RefreshCw, DollarSign, CheckCircle } from 'lucide-react';

export const CryptoSandbox: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("haiku");

  // Haiku Miner State
  const [bipWords, setBipWords] = useState<string[]>(["abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse", "academy", "accent"]);
  const [haiku, setHaiku] = useState<string[]>(["Silent streams abandon", "Above the misty mountain", "Peaceful able path"]);
  const [miningHaiku, setMiningHaiku] = useState<boolean>(false);

  // Banano Miner State
  const [bananoAddress, setBananoAddress] = useState<string>("ban_3potassium111111111111111111111111111111111111111111111rich");
  const [miningBanano, setMiningBanano] = useState<boolean>(false);
  const [banHashrate, setBanHashrate] = useState<number>(0);
  const [banArtifacts, setBanArtifacts] = useState<Array<{ name: string; rarity: string; hash: string; potas: number }>>([
    { name: "Golden Yellow Peel", rarity: "Legendary", hash: "0x89aF...42B1", potas: 1540 },
    { name: "Frozen Banano Pop", rarity: "Rare", hash: "0x33bC...99D2", potas: 420 }
  ]);

  // Wave Exchange State
  const [selectedPair, setSelectedPair] = useState<string>("LAMBO/USD");
  const [orderType, setOrderType] = useState<string>("BUY");
  const [orderAmount, setOrderAmount] = useState<string>("100");
  const [orderPrice, setOrderPrice] = useState<string>("2.50");
  const [orderBook, setOrderBook] = useState<Array<{ type: string; price: number; amount: number; total: number }>>([
    { type: "SELL", price: 2.55, amount: 450, total: 1147.5 },
    { type: "SELL", price: 2.52, amount: 1200, total: 3024 },
    { type: "BUY", price: 2.49, amount: 890, total: 2216.1 },
    { type: "BUY", price: 2.45, amount: 3100, total: 7595 }
  ]);
  const [tradeLogs, setTradeLogs] = useState<string[]>(["Exchange initialized. Loaded pairs: LAMBO, MIC, WAX, SOL, BAN."]);

  // Exotic NFT eth144 State
  const [nftId, setNftId] = useState<string>("ETH144-9982");
  const [nftPayload, setNftPayload] = useState<string>("ipfs://QmTest144HashDataStringSampleForExoticStorage");
  const [nftTier, setNftTier] = useState<string>("Exotic Deep Storage (Tier 144)");
  const [mintedNfts, setMintedNfts] = useState<Array<{ id: string; payload: string; tier: string }>>([
    { id: "ETH144-0001", payload: "ipfs://QmExoticGenesisTokenStorageData", tier: "Exotic Genesis" }
  ]);

  // Hashcash State
  const [hashMessage, setHashMessage] = useState<string>("Requesting patent office entrance access.");
  const [hashDifficulty, setHashDifficulty] = useState<number>(4);
  const [hashStamp, setHashStamp] = useState<string>("1:20:260315:patent@ietf.org::3a8b92:0000a4b1");
  const [isSearchingHash, setIsSearchingHash] = useState<boolean>(false);

  // Paper Wallet State
  const [walletCurrency, setWalletCurrency] = useState<string>("BANANO");
  const [mockPrivKey, setMockPrivKey] = useState<string>("5Hwgr3u...mock...secret...key...do...not...share");
  const [mockPubKey, setMockPubKey] = useState<string>("ban_1wallet...mock...public...address...3921");

  // Wordlist bank for haiku mining
  const wordBank = ["autumn", "breeze", "cloud", "dew", "earth", "frost", "grass", "hill", "island", "jade", "leaf", "moon", "nature", "ocean", "pine", "river", "shadow", "thunder", "valley", "wind", "yellow", "zenith", "amber", "beacon"];

  const handleMineHaiku = () => {
    setMiningHaiku(true);
    setTimeout(() => {
      // Pick random words
      const shuffled = [...wordBank].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, 12);
      setBipWords(selected);
      setHaiku([
        `${selected[0]} ${selected[1]} ${selected[2]}`,
        `${selected[3]} ${selected[4]} ${selected[5]} ${selected[6]}`,
        `${selected[7]} ${selected[8]} ${selected[9]}`
      ]);
      setMiningHaiku(false);
    }, 1200);
  };

  // Banano Miner simulation loop
  useEffect(() => {
    let interval: any;
    if (miningBanano) {
      interval = setInterval(() => {
        setBanHashrate(Math.floor(450 + Math.random() * 120));
        // Randomly find artifact
        if (Math.random() < 0.25) {
          const names = ["Crystalline Potas Infusion", "Ancient Monkey Statue", "Radioactive Yellow Gem", "Ripe Emerald Plantain"];
          const rarities = ["Rare", "Epic", "Legendary", "Uncommon"];
          const randomName = names[Math.floor(Math.random() * names.length)];
          const randomRarity = rarities[Math.floor(Math.random() * rarities.length)];
          const randomPotas = Math.floor(200 + Math.random() * 2000);
          const mockHash = `0x${Math.floor(Math.random() * 1000000).toString(16)}...${Math.floor(Math.random() * 1000).toString(16)}`;
          setBanArtifacts((prev) => [{ name: randomName, rarity: randomRarity, hash: mockHash, potas: randomPotas }, ...prev]);
        }
      }, 1000);
    } else {
      setBanHashrate(0);
    }
    return () => clearInterval(interval);
  }, [miningBanano]);

  const handlePlaceOrder = () => {
    const price = parseFloat(orderPrice) || 0;
    const amount = parseFloat(orderAmount) || 0;
    if (price <= 0 || amount <= 0) return;

    const total = price * amount;
    const newOrder = { type: orderType, price, amount, total };
    setOrderBook((prev) => [newOrder, ...prev]);
    setTradeLogs((prev) => [`[${new Date().toLocaleTimeString()}] SUCCESS: ${orderType} order placed for ${amount} ${selectedPair.split('/')[0]} @ $${price}`, ...prev]);
  };

  const handleMintEth144 = () => {
    if (!nftId || !nftPayload) return;
    setMintedNfts((prev) => [{ id: nftId, payload: nftPayload, tier: nftTier }, ...prev]);
    setNftId(`ETH144-${Math.floor(1000 + Math.random() * 9000)}`);
  };

  const handleCalculateHashcash = () => {
    setIsSearchingHash(true);
    setTimeout(() => {
      const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
      const randHex = Math.floor(Math.random() * 10000000).toString(16);
      const counter = Math.floor(100000 + Math.random() * 899999).toString(16);
      setHashStamp(`1:${hashDifficulty * 4}:${dateStr}:patent_msg::${randHex}:${counter}`);
      setIsSearchingHash(false);
    }, 1500);
  };

  // Generate cryptographically-styled hex key (64 hex chars = 256 bits)
  const generateHexKey = () => {
    const chars = '0123456789abcdef';
    let key = '';
    for (let i = 0; i < 64; i++) {
      key += chars[Math.floor(Math.random() * chars.length)];
    }
    return key;
  };

  // Generate base58-style key (like real crypto wallets use)
  const generateBase58Key = (prefix: string, length: number) => {
    const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let key = prefix;
    for (let i = 0; i < length; i++) {
      key += chars[Math.floor(Math.random() * chars.length)];
    }
    return key;
  };

  const handleGenerateWallet = (curr: string) => {
    setWalletCurrency(curr);
    
    // Generate realistic cryptographic keys for each currency
    if (curr === "BANANO") {
      const pubHash = generateHexKey().slice(0, 48);
      setMockPubKey(`ban_1${pubHash}`);
      setMockPrivKey(generateHexKey());
    } else if (curr === "SOLANA") {
      setMockPubKey(generateBase58Key('', 44));
      setMockPrivKey(generateBase58Key('5', 88));
    } else if (curr === "WAX") {
      const acctName = Math.random().toString(36).substring(2, 7) + '.' + Math.random().toString(36).substring(2, 7);
      setMockPubKey(acctName);
      setMockPrivKey(`PVT_WAX_${generateHexKey().slice(0, 32)}`);
    } else if (curr === "LAMBOCOIN") {
      setMockPubKey(`LMB1${generateHexKey().slice(0, 34)}`);
      setMockPrivKey(`LMB_PRIV_${generateHexKey()}`);
    } else if (curr === "MICCOIN") {
      setMockPubKey(`MIC1${generateHexKey().slice(0, 34)}`);
      setMockPrivKey(`MIC_PRIV_${generateHexKey()}`);
    }
  };

  return (
    <div className="w-full flex flex-col space-y-6 p-6">
      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-700 pb-4">
        {[
          { id: "haiku", label: "BIP39/44 Haiku Miner", icon: Coins },
          { id: "banano", label: "Banano Artifact Miner", icon: Cpu },
          { id: "wave", label: "Wave Exchange (LAMBO/MIC)", icon: DollarSign },
          { id: "eth144", label: "Exotic Storage (ETH144)", icon: Award },
          { id: "hashcash", label: "Hashcash Authenticator", icon: Shield },
          { id: "paper", label: "Print Paper Wallets", icon: Printer }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-mono text-xs font-bold transition-all ${activeTab === tab.id ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Contents */}
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 shadow-xl">
        {/* 1. BIP39/44 Haiku Miner */}
        {activeTab === "haiku" && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-4 gap-4">
              <div>
                <h2 className="text-xl font-mono font-extrabold text-amber-400">BIP-39 / BIP-44 Haiku Mnemonic Miner</h2>
                <p className="text-slate-300 text-xs font-mono mt-1">
                  Derives valid 12-word seed phrases and arranges them into beautiful poetic haiku structures for intuitive human memorization.
                </p>
              </div>
              <button
                onClick={handleMineHaiku}
                disabled={miningHaiku}
                className="px-6 py-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-mono font-bold rounded-xl shadow transition-all flex items-center space-x-2"
              >
                <RefreshCw className={`w-5 h-5 ${miningHaiku ? 'animate-spin' : ''}`} />
                <span>{miningHaiku ? 'Mining Haiku...' : 'Mine New Haiku Seed'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Mnemonic Display */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <h3 className="font-mono font-bold text-slate-300 text-sm">RAW BIP-39 WORDLIST (12 WORDS)</h3>
                <div className="grid grid-cols-3 gap-2">
                  {bipWords.map((word, index) => (
                    <div key={index} className="p-2 bg-slate-900 border border-slate-700 rounded-lg text-center font-mono text-xs text-amber-300">
                      <span className="text-slate-500 block text-[10px]">{index + 1}</span>
                      {word}
                    </div>
                  ))}
                </div>
                <div className="text-[11px] font-mono text-slate-400 bg-slate-900 p-2 rounded border border-slate-800">
                  BIP-44 Derivation Path: <span className="text-emerald-400">m/44'/0'/0'/0/0</span>
                </div>
              </div>

              {/* Haiku Display */}
              <div className="p-6 bg-gradient-to-br from-amber-950/40 via-slate-950 to-slate-900 rounded-xl border border-amber-500/30 flex flex-col items-center justify-center text-center space-y-6 shadow-inner">
                <h3 className="font-serif font-bold text-amber-300 text-lg border-b border-amber-500/30 pb-2 w-full">
                  THE MNEMONIC HAIKU
                </h3>
                <div className="space-y-4 font-serif text-xl text-slate-100 italic tracking-wide py-4">
                  {haiku.map((line, idx) => (
                    <p key={idx} className="drop-shadow">{line}</p>
                  ))}
                </div>
                <span className="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                  Syllable Structure: Verified 5-7-5 Approximation
                </span>
              </div>
            </div>
          </div>
        )}

        {/* 2. Banano Rare Artifact Miner */}
        {activeTab === "banano" && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-4 gap-4">
              <div>
                <h2 className="text-xl font-mono font-extrabold text-amber-400">Banano Rare Artifact Miner & Basecard Stats</h2>
                <p className="text-slate-300 text-xs font-mono mt-1">
                  High-speed proof-of-work calculations searching for potassium-dense cryptographic relics on the Banano testnet lattice.
                </p>
              </div>
              <button
                onClick={() => setMiningBanano(!miningBanano)}
                className={`px-6 py-3 font-mono font-bold rounded-xl shadow transition-all flex items-center space-x-2 ${miningBanano ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-yellow-500 hover:bg-yellow-400 text-amber-950'}`}
              >
                <Cpu className={`w-5 h-5 ${miningBanano ? 'animate-spin' : ''}`} />
                <span>{miningBanano ? 'Stop Mining Rig' : 'Start Rare Artifact Miner'}</span>
              </button>
            </div>

            {/* Mining Status & Address Header */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2 p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <label className="text-[10px] font-mono text-slate-400 block">MINER REWARD ADDRESS</label>
                <input
                  type="text"
                  value={bananoAddress}
                  onChange={(e) => setBananoAddress(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-yellow-300 font-mono text-xs focus:outline-none focus:border-yellow-500"
                />
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center">
                <span className="text-[10px] font-mono text-slate-400 block mb-1">CURRENT HASHRATE</span>
                <div className="text-2xl font-mono font-extrabold text-yellow-400">
                  {banHashrate} <span className="text-xs text-slate-400">KH/s</span>
                </div>
              </div>
            </div>

            {/* Basecards Grid Display */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <h3 className="font-mono font-bold text-slate-300 text-sm">MINED ARTIFACT BASECARDS ({banArtifacts.length})</h3>
                <span className="text-[10px] font-mono text-yellow-400 bg-yellow-500/10 px-2 py-0.5 rounded border border-yellow-500/20">🐵 Monkey Collection Active</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {banArtifacts.map((artifact, i) => {
                  const monkeyEmojis = ['🐵', '🦍', '🙈', '🙉', '🙊', '🐒'];
                  const monkeyIdx = (artifact.potas + i) % monkeyEmojis.length;
                  const rarityColours = {
                    'Legendary': 'from-yellow-600 to-amber-500 border-yellow-400 shadow-yellow-500/30',
                    'Epic': 'from-purple-700 to-purple-500 border-purple-400 shadow-purple-500/30',
                    'Rare': 'from-blue-700 to-blue-500 border-blue-400 shadow-blue-500/30',
                    'Uncommon': 'from-green-700 to-green-500 border-green-400 shadow-green-500/30',
                    'Common': 'from-slate-700 to-slate-500 border-slate-400 shadow-slate-500/20'
                  };
                  const cardGradient = rarityColours[artifact.rarity as keyof typeof rarityColours] || rarityColours.Common;
                  
                  return (
                    <div key={i} className={`relative overflow-hidden rounded-2xl border-2 shadow-xl transition-all hover:scale-105 hover:shadow-2xl bg-gradient-to-br ${cardGradient}`}>
                      {/* Card header with rarity badge */}
                      <div className="absolute top-2 right-2 px-2 py-0.5 bg-black/60 backdrop-blur rounded-full text-[9px] font-mono font-bold text-white border border-white/20">
                        {artifact.rarity.toUpperCase()}
                      </div>
                      
                      {/* Monkey avatar area */}
                      <div className="h-24 flex items-center justify-center bg-gradient-to-b from-black/40 to-transparent">
                        <div className="text-5xl filter drop-shadow-lg animate-bounce" style={{ animationDuration: '2s' }}>
                          {monkeyEmojis[monkeyIdx]}
                        </div>
                      </div>
                      
                      {/* Card body */}
                      <div className="p-3 bg-gradient-to-b from-slate-950/95 to-slate-900/90 backdrop-blur space-y-2">
                        <h4 className="font-bold text-yellow-100 text-xs leading-tight line-clamp-2">{artifact.name}</h4>
                        <div className="text-[9px] font-mono text-slate-400 truncate">#{artifact.hash}</div>
                        <div className="flex justify-between items-center pt-2 border-t border-yellow-500/30">
                          <span className="text-[9px] text-slate-400 font-mono">POTAS</span>
                          <span className="text-yellow-400 font-extrabold text-sm">+{artifact.potas}</span>
                        </div>
                      </div>
                      
                      {/* Holographic shimmer effect */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* 3. Wave Exchange App */}
        {activeTab === "wave" && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-4 gap-4">
              <div>
                <h2 className="text-xl font-mono font-extrabold text-amber-400">Wave Exchange Control Room</h2>
                <p className="text-slate-300 text-xs font-mono mt-1">
                  Working matching engine model supporting high-frequency client-side orderbooks for Lambocoin, Miccoin, WAX, SOL, and Banano.
                </p>
              </div>
              <div className="flex space-x-2">
                {["LAMBO/USD", "MIC/USD", "WAX/USD", "SOL/USD", "BAN/USD"].map((pair) => (
                  <button
                    key={pair}
                    onClick={() => {
                      setSelectedPair(pair);
                      setTradeLogs((prev) => [`Switched trading pair to ${pair}`, ...prev]);
                    }}
                    className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition-all ${selectedPair === pair ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
                  >
                    {pair}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Place Order Panel */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <h3 className="font-mono font-bold text-slate-200 text-sm">Create Limit Order</h3>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setOrderType("BUY")}
                    className={`py-2 rounded-lg font-mono text-xs font-bold transition-all ${orderType === "BUY" ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30' : 'bg-slate-900 text-slate-400'}`}
                  >
                    BUY
                  </button>
                  <button
                    onClick={() => setOrderType("SELL")}
                    className={`py-2 rounded-lg font-mono text-xs font-bold transition-all ${orderType === "SELL" ? 'bg-red-600 text-white shadow-lg shadow-red-600/30' : 'bg-slate-900 text-slate-400'}`}
                  >
                    SELL
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">PRICE (USD)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={orderPrice}
                    onChange={(e) => setOrderPrice(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">AMOUNT ({selectedPair.split('/')[0]})</label>
                  <input
                    type="number"
                    value={orderAmount}
                    onChange={(e) => setOrderAmount(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <button
                  onClick={handlePlaceOrder}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold rounded-lg shadow transition-all flex items-center justify-center space-x-2"
                >
                  <span>Place {orderType} Order</span>
                </button>
              </div>

              {/* Orderbook Display */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h3 className="font-mono font-bold text-slate-200 text-sm">Live Matching Orderbook</h3>
                <div className="space-y-1 text-xs font-mono">
                  <div className="grid grid-cols-3 text-slate-500 border-b border-slate-800 pb-1 mb-2">
                    <span>Price</span>
                    <span className="text-right">Amount</span>
                    <span className="text-right">Total ($)</span>
                  </div>
                  {orderBook.map((order, i) => (
                    <div key={i} className="grid grid-cols-3 py-1 border-b border-slate-900/50 hover:bg-slate-900 px-1 rounded">
                      <span className={order.type === "BUY" ? 'text-emerald-400' : 'text-red-400'}>${order.price.toFixed(2)}</span>
                      <span className="text-right text-slate-300">{order.amount}</span>
                      <span className="text-right text-slate-400">${order.total.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Engine Logs */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h3 className="font-mono font-bold text-slate-200 text-sm">Wave Execution Telemetry</h3>
                <div className="bg-black p-3 rounded-lg font-mono text-xs text-slate-300 space-y-2 max-h-60 overflow-y-auto">
                  {tradeLogs.map((log, i) => (
                    <div key={i} className="border-b border-slate-900 pb-1 text-amber-300">{log}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 4. Exotic Web3 Storage (eth144) */}
        {activeTab === "eth144" && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-mono font-extrabold text-amber-400">Exotic Web3 NFT Storage Sandbox (ETH144 & ERC-1155)</h2>
              <p className="text-slate-300 text-xs font-mono mt-1">
                A highly advanced testnet sandbox for testing multi-layer exotic smart contract storage models with custom IPFS payload routing.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <h3 className="font-mono font-bold text-slate-200 text-sm">Exotic Minting Terminal</h3>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">TOKEN IDENTIFIER</label>
                  <input
                    type="text"
                    value={nftId}
                    onChange={(e) => setNftId(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">STORAGE SPECIFICATION TIER</label>
                  <select
                    value={nftTier}
                    onChange={(e) => setNftTier(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                  >
                    <option value="Exotic Deep Storage (Tier 144)">Exotic Deep Storage (Tier 144)</option>
                    <option value="ERC-1155 Multi-Token Asset">ERC-1155 Multi-Token Asset</option>
                    <option value="Infinite Sharded Dynamic URI">Infinite Sharded Dynamic URI</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">DECENTRALIZED PAYLOAD URI</label>
                  <textarea
                    rows={3}
                    value={nftPayload}
                    onChange={(e) => setNftPayload(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-300 font-mono text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>
                <button
                  onClick={handleMintEth144}
                  className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold rounded-lg shadow transition-all flex items-center justify-center space-x-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Mint to Exotic Testnet</span>
                </button>
              </div>

              <div className="md:col-span-2 space-y-4">
                <h3 className="font-mono font-bold text-slate-300 text-sm">ACTIVE EXOTIC TESTNET STORAGE REGISTRY</h3>
                <div className="space-y-3">
                  {mintedNfts.map((nft, idx) => (
                    <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2 shadow">
                      <div className="flex justify-between items-center">
                        <span className="font-mono font-extrabold text-amber-400 text-base">{nft.id}</span>
                        <span className="bg-slate-800 text-slate-300 font-mono text-xs px-2.5 py-1 rounded-md border border-slate-700">{nft.tier}</span>
                      </div>
                      <div className="bg-black p-3 rounded-lg font-mono text-xs text-emerald-400 break-all">
                        {nft.payload}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 5. Hashcash Authenticator */}
        {activeTab === "hashcash" && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-xl font-mono font-extrabold text-amber-400">Hashcash Proof-of-Work Message Authenticator</h2>
              <p className="text-slate-300 text-xs font-mono mt-1">
                Simulates CPU proof-of-work stamps attached to messages to prevent spam and verify sender processing commitment.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <h3 className="font-mono font-bold text-slate-200 text-sm">Configure Stamp Parameters</h3>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">MESSAGE CONTENT</label>
                  <textarea
                    rows={3}
                    value={hashMessage}
                    onChange={(e) => setHashMessage(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">COLLISION DIFFICULTY BITS</label>
                  <input
                    type="number"
                    value={hashDifficulty}
                    onChange={(e) => setHashDifficulty(parseInt(e.target.value) || 1)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>
                <button
                  onClick={handleCalculateHashcash}
                  disabled={isSearchingHash}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-mono font-bold rounded-lg shadow transition-all flex items-center justify-center space-x-2"
                >
                  <RefreshCw className={`w-4 h-4 ${isSearchingHash ? 'animate-spin' : ''}`} />
                  <span>{isSearchingHash ? 'Computing Hashcash Stamp...' : 'Generate Proof-of-Work Stamp'}</span>
                </button>
              </div>

              <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 flex flex-col justify-center space-y-4">
                <h3 className="font-mono font-bold text-slate-400 text-xs uppercase tracking-widest">VERIFIED HASHCASH HEADER STAMP</h3>
                <div className="p-4 bg-black rounded-lg font-mono text-sm text-amber-300 break-all border border-amber-500/20 shadow-inner">
                  {hashStamp}
                </div>
                <div className="text-xs font-mono text-slate-400 space-y-1">
                  <p>■ <span className="text-slate-200">Version:</span> 1</p>
                  <p>■ <span className="text-slate-200">Claimed Bits:</span> {hashDifficulty * 4}</p>
                  <p>■ <span className="text-slate-200">Target Resource:</span> patent_msg</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 6. Print Paper Wallets */}
        {activeTab === "paper" && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-4 gap-4">
              <div>
                <h2 className="text-xl font-mono font-extrabold text-amber-400">Secure Paper Wallet Printing Facility</h2>
                <p className="text-slate-300 text-xs font-mono mt-1">
                  Generate beautiful cold-storage paper wallet printouts for BANANO, SOLANA, WAX, LAMBOCOIN, and MICCOIN.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                {["BANANO", "SOLANA", "WAX", "LAMBOCOIN", "MICCOIN"].map((curr) => (
                  <button
                    key={curr}
                    onClick={() => handleGenerateWallet(curr)}
                    className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition-all ${walletCurrency === curr ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
                  >
                    {curr}
                  </button>
                ))}
              </div>
            </div>

            {/* Paper Wallet Card Display */}
            <div className="max-w-2xl mx-auto p-8 bg-gradient-to-br from-amber-100 to-amber-50 border-8 border-amber-900/80 rounded-3xl shadow-2xl text-slate-900 space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-amber-900 text-amber-100 font-mono font-bold text-xs px-4 py-2 rounded-bl-xl shadow">
                COLD STORAGE WALLET
              </div>

              <div className="space-y-1">
                <h3 className="text-2xl font-black font-serif tracking-tight text-amber-950">{walletCurrency} COLD WALLET</h3>
                <p className="text-xs font-mono text-amber-900/80">Secured via IETF Patent Office High-Entropy Random Number Generator</p>
              </div>

              <div className="space-y-4 pt-4 border-t border-amber-900/20">
                <div className="p-4 bg-white/80 rounded-xl border border-amber-900/20 shadow-sm space-y-1">
                  <span className="text-[10px] font-mono text-slate-500 font-bold block uppercase">PUBLIC DEPOSIT ADDRESS (SHAREABLE)</span>
                  <div className="font-mono text-xs font-extrabold text-slate-800 break-all select-all">
                    {mockPubKey}
                  </div>
                </div>

                <div className="p-4 bg-amber-950 text-amber-100 rounded-xl border border-amber-900 shadow-inner space-y-1">
                  <span className="text-[10px] font-mono text-amber-400 font-bold block uppercase">PRIVATE SPEND KEY (KEEP SECRET!)</span>
                  <div className="font-mono text-xs font-bold text-amber-200 break-all select-all">
                    {mockPrivKey}
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-amber-900/20 text-xs font-mono text-amber-950/70">
                <span>Print on high-quality acid-free paper.</span>
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-amber-900 hover:bg-amber-800 text-amber-100 rounded-lg font-bold shadow flex items-center space-x-2 transition-all"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Wallet Card</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
