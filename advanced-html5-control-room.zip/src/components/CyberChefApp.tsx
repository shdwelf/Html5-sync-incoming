import React, { useState, useMemo } from 'react';
import { Menu, Wand2, Lightbulb, Lock } from 'lucide-react';

interface RecipeOperation {
  id: string;
  name: string;
  category: string;
  desc: string;
  tip: string;
}

export const CyberChefApp: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(true);
  const [selectedOp, setSelectedOp] = useState<string>("base64_enc");
  const [inputText, setInputText] = useState<string>("Patent Office Secret Information & Test Payload #4042981");
  const [encryptionKey, setEncryptionKey] = useState<string>("secretkey123");

  const operations: RecipeOperation[] = [
    { id: "base64_enc", name: "To Base64", category: "Data Format", desc: "Encodes raw text into Base64 ASCII representation.", tip: "Base64 expands data size by ~33%. Excellent for embedding binary objects in JSON or text formats." },
    { id: "base64_dec", name: "From Base64", category: "Data Format", desc: "Decodes Base64 encoded strings back to normal raw text.", tip: "Ensure input is properly padded with '=' characters if required by strict parsers." },
    { id: "hex_enc", name: "To Hexadecimal", category: "Data Format", desc: "Converts text characters to their corresponding hexadecimal byte representation.", tip: "Useful for low-level packet inspection and buffer analysis." },
    { id: "hex_dec", name: "From Hexadecimal", category: "Data Format", desc: "Transforms hexadecimal pairs back into plain ASCII strings.", tip: "Input can contain spaces or be continuous (e.g. 41 42 43 or 414243)." },
    { id: "url_enc", name: "URL Encode", category: "Web", desc: "Replaces unsafe ASCII characters with a '%' followed by two hexadecimal digits.", tip: "Essential for encoding query parameters in HTTP GET requests." },
    { id: "rot13", name: "ROT13 Cipher", category: "Cryptography", desc: "A simple letter substitution cipher that replaces a letter with the 13th letter after it.", tip: "ROT13 is self-inverting: applying it twice restores the original text. Do not use for secure data." },
    { id: "sha256", name: "SHA-256 Hash", category: "Cryptography", desc: "Computes a fixed-length 256-bit cryptographic hash of the input text.", tip: "Cryptographic hash functions are one-way. Keep your original plaintext secure if verifying passwords." },
    { id: "aes_sim", name: "AES-256 Mock Encrypt", category: "Cryptography", desc: "Symmetric encryption simulation using a secret passkey.", tip: "In production, always use authenticated encryption modes like AES-GCM to prevent ciphertext tampering." },
    { id: "magnet_torrent", name: "Magnet to Torrent Parser", category: "P2P / Networks", desc: "Extracts BTIH (BitTorrent Info Hash), display name, and trackers from a magnet link.", tip: "Magnet URIs allow peers to download torrent metadata directly from the swarm via DHT without a .torrent file." }
  ];

  // Live computation of output
  const outputData = useMemo(() => {
    try {
      if (!inputText) return "No input provided.";

      switch (selectedOp) {
        case "base64_enc":
          return btoa(inputText);
        case "base64_dec":
          try {
            return atob(inputText);
          } catch (e) {
            return "Error: Invalid Base64 input string.";
          }
        case "hex_enc":
          return inputText.split('').map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join(' ');
        case "hex_dec":
          try {
            const clean = inputText.replace(/\s+/g, '');
            let res = "";
            for (let i = 0; i < clean.length; i += 2) {
              res += String.fromCharCode(parseInt(clean.substr(i, 2), 16));
            }
            return res;
          } catch (e) {
            return "Error: Invalid Hexadecimal input.";
          }
        case "url_enc":
          return encodeURIComponent(inputText);
        case "rot13":
          return inputText.replace(/[a-zA-Z]/g, c => {
            const base = c <= 'Z' ? 65 : 97;
            return String.fromCharCode((c.charCodeAt(0) - base + 13) % 26 + base);
          });
        case "sha256":
          // Simulated stable client-side hash representation
          let hash = 0;
          for (let i = 0; i < inputText.length; i++) {
            hash = ((hash << 5) - hash) + inputText.charCodeAt(i);
            hash |= 0;
          }
          const baseHex = Math.abs(hash).toString(16);
          return `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.substring(0, 64 - baseHex.length) + baseHex;
        case "aes_sim":
          return `U2FsdGVkX1+MockAesEncryptedCiphertext+${btoa(inputText.substring(0, 15))}... (Passkey: ${encryptionKey})`;
        case "magnet_torrent":
          if (!inputText.startsWith("magnet:?")) {
            return `Error: Valid magnet links must begin with 'magnet:?'.\n\nExample:\nmagnet:?xt=urn:btih:c12fe1c06bba254a9dc9f519b335aa7c1367a88a&dn=ArchLinux&tr=udp://tracker.archlinux.org:6969`;
          }
          const params = new URLSearchParams(inputText.substring(8));
          const xt = params.get("xt") || "Unknown BTIH";
          const dn = params.get("dn") || "Unknown Display Name";
          const tr = params.getAll("tr") || [];
          return `=== TORRENT METADATA EXTRACTED FROM MAGNET URI ===\n\nInfoHash (BTIH): ${xt.replace('urn:btih:', '')}\nDisplay Name (dn): ${dn}\nTrackers Count: ${tr.length}\nTrackers List:\n${tr.join('\n') || 'None specified (DHT fallback)'}\n\nGenerated Bencode Root Dictionary Representation:\n{ "info": { "name": "${dn}", "length": 4294967296 }, "announce": "${tr[0] || 'udp://tracker.openbittorrent.com:80'}" }`;
        default:
          return inputText;
      }
    } catch (e: any) {
      return `Execution Error: ${e.message}`;
    }
  }, [inputText, selectedOp, encryptionKey]);

  const activeOperation = operations.find(o => o.id === selectedOp) || operations[0];

  return (
    <div className="w-full flex flex-col space-y-6 p-6">
      {/* Header Bar with Hamburger */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-amber-500 transition-all shadow"
            title="Toggle Recipe Sidebar"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div>
            <h2 className="text-xl font-mono font-extrabold text-amber-400 flex items-center space-x-2">
              <Wand2 className="w-6 h-6 text-amber-500" />
              <span>CYBERCHEF EMBEDDED WEB APP</span>
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Advanced multi-tool for data baking, encoding, cryptography, and magnet-to-torrent conversion.
            </p>
          </div>
        </div>

        <div className="hidden sm:flex items-center space-x-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
          <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
          <span className="text-xs font-mono text-slate-300">Live Feedback Loop Active</span>
        </div>
      </div>

      {/* App Body */}
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        {sidebarOpen && (
          <div className="w-full lg:w-1/4 flex flex-col space-y-2 bg-slate-900 p-4 rounded-xl border border-slate-700 shadow-xl max-h-[650px] overflow-y-auto">
            <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">Recipe Operations</h3>
            {operations.map((op) => (
              <button
                key={op.id}
                onClick={() => setSelectedOp(op.id)}
                className={`flex flex-col items-start p-3 rounded-xl border transition-all text-left font-mono ${selectedOp === op.id ? 'bg-slate-800 border-amber-500 text-amber-400 shadow-md' : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-850'}`}
              >
                <div className="flex justify-between items-center w-full mb-1">
                  <span className="font-bold text-sm">{op.name}</span>
                  <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded">{op.category}</span>
                </div>
                <span className="text-xs text-slate-400 line-clamp-1">{op.desc}</span>
              </button>
            ))}
          </div>
        )}

        {/* Input/Output Editor & Feedback area */}
        <div className="flex-1 flex flex-col space-y-6">
          <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 shadow-xl space-y-6">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-lg font-mono font-extrabold text-amber-400 flex items-center space-x-2">
                <span>Active Recipe: {activeOperation.name}</span>
              </h3>
              <span className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1 rounded-full border border-slate-800">
                Category: {activeOperation.category}
              </span>
            </div>

            {/* If Magnet is selected, give a button to load a sample magnet link */}
            {selectedOp === "magnet_torrent" && (
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                <span className="text-xs font-mono text-slate-300">Click to load a sample magnet link for testing:</span>
                <button
                  onClick={() => setInputText("magnet:?xt=urn:btih:c12fe1c06bba254a9dc9f519b335aa7c1367a88a&dn=ArchLinux_ISO_Sample&tr=udp://tracker.archlinux.org:6969&tr=udp://tracker.openbittorrent.com:80")}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold text-xs rounded-lg shadow transition-all"
                >
                  Insert Sample Magnet URI
                </button>
              </div>
            )}

            {/* If AES is selected, give a passkey input */}
            {selectedOp === "aes_sim" && (
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center space-x-4">
                <Lock className="w-5 h-5 text-amber-500" />
                <div className="flex-1">
                  <label className="block text-[10px] font-mono text-slate-400 mb-1">AES MOCK PASSKEY</label>
                  <input
                    type="text"
                    value={encryptionKey}
                    onChange={(e) => setEncryptionKey(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-amber-300 font-mono text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            )}

            {/* Input & Output Panels */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="flex justify-between items-center text-xs font-mono text-slate-300 font-bold uppercase tracking-wider">
                  <span>Input Data</span>
                  <span className="text-slate-500 text-[10px]">{inputText.length} chars</span>
                </label>
                <textarea
                  rows={10}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500 shadow-inner"
                  placeholder="Enter text or raw strings here..."
                />
              </div>

              <div className="space-y-2">
                <label className="flex justify-between items-center text-xs font-mono text-slate-300 font-bold uppercase tracking-wider">
                  <span>Cooked Output</span>
                  <span className="text-emerald-400 text-[10px]">Real-time evaluation</span>
                </label>
                <textarea
                  rows={10}
                  readOnly
                  value={outputData}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-amber-300 font-mono text-sm focus:outline-none shadow-inner cursor-text"
                />
              </div>
            </div>
          </div>

          {/* Feedback & Ways to improve */}
          <div className="p-6 bg-slate-900 rounded-xl border border-slate-700 shadow-xl space-y-4">
            <h3 className="text-base font-mono font-extrabold text-emerald-400 flex items-center space-x-2">
              <Lightbulb className="w-5 h-5 text-emerald-500 animate-bounce" />
              <span>Feedback & Ways to Improve This Recipe</span>
            </h3>
            <p className="text-slate-300 text-sm font-mono leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
              {activeOperation.tip}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono space-y-1">
                <span className="text-amber-400 font-bold block">EFFICIENCY SCORE</span>
                <p className="text-slate-300">O(N) linear time complexity for streaming execution.</p>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono space-y-1">
                <span className="text-amber-400 font-bold block">SAFETY EVALUATION</span>
                <p className="text-slate-300">Pure client-side offline execution. Zero server logging.</p>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono space-y-1">
                <span className="text-amber-400 font-bold block">RECOMMENDED TWEAK</span>
                <p className="text-slate-300">Chain with gzip compression for reduced transmission weight.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
