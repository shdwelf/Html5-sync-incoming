import React, { useState } from 'react';
import { Hash, MessageSquare, Shield, Send, Lock, Users, Terminal } from 'lucide-react';

interface ChatMessage {
  sender: string;
  text: string;
  time: string;
  isEncrypted: boolean;
}

export const IRCApp: React.FC = () => {
  const [currentChannel, setCurrentChannel] = useState<string>("#patent-office");
  const [isSecureMode, setIsSecureMode] = useState<boolean>(true);
  const [inputValue, setInputValue] = useState<string>("");

  const [messages, setMessages] = useState<{ [key: string]: ChatMessage[] }>({
    "#patent-office": [
      { sender: "SysOp", text: "Welcome to the Secret Patent Office IRC server. Keep discussions confidential.", time: "12:00", isEncrypted: false },
      { sender: "RFC_Guru", text: "Has anyone successfully deployed the eth144 smart contract testnet?", time: "12:05", isEncrypted: true },
      { sender: "PigeonMaster", text: "Yes, fully confirmed via RFC 1149 avian carrier protocol.", time: "12:08", isEncrypted: true }
    ],
    "#sstv-feed": [
      { sender: "HamRadio99", text: "Transmitting Martin M1 subcarrier on 14.230 MHz.", time: "11:45", isEncrypted: false },
      { sender: "VisDecoder", text: "Automatic slant calibration active. Perfect synchronization.", time: "11:50", isEncrypted: true }
    ],
    "#lambocoin": [
      { sender: "WaveTrader", text: "Placed limit BUY order on Wave Exchange at $2.45.", time: "10:30", isEncrypted: false },
      { sender: "MicMaster", text: "High volume incoming. Swarm orderbooks fully synchronized.", time: "10:32", isEncrypted: false }
    ],
    "#ietf-rfcs": [
      { sender: "IETF_Admin", text: "Drafting new wireframe mesh geocoding globe specifications.", time: "09:15", isEncrypted: false }
    ]
  });

  const channels = ["#patent-office", "#sstv-feed", "#lambocoin", "#ietf-rfcs"];
  const currentMessages = messages[currentChannel] || [];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newMsg: ChatMessage = {
      sender: "You",
      text: inputValue,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isEncrypted: isSecureMode
    };

    setMessages((prev) => ({
      ...prev,
      [currentChannel]: [...(prev[currentChannel] || []), newMsg]
    }));
    setInputValue("");

    // Simulate automatic bot response
    setTimeout(() => {
      const botMsg: ChatMessage = {
        sender: "ServerDaemon",
        text: `ACK received for message frame. Secure status: ${isSecureMode ? 'Verified End-to-End Encrypted' : 'Standard Text Mode'}.`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isEncrypted: isSecureMode
      };
      setMessages((prev) => ({
        ...prev,
        [currentChannel]: [...(prev[currentChannel] || []), botMsg]
      }));
    }, 1000);
  };

  return (
    <div className="w-full flex flex-col space-y-6 p-6">
      {/* Header Bar */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <MessageSquare className="w-8 h-8 text-amber-500" />
          <div>
            <h2 className="text-xl font-mono font-extrabold text-amber-400">IRC & SECURE IRC APPARATUS</h2>
            <p className="text-xs text-slate-400 font-mono">
              Real-time communication channels with optional end-to-end cryptographic encapsulation.
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsSecureMode(!isSecureMode)}
          className={`px-4 py-2 rounded-xl font-mono text-xs font-bold transition-all flex items-center space-x-2 border ${
            isSecureMode ? 'bg-emerald-600 text-slate-950 border-emerald-500 shadow-lg shadow-emerald-600/30' : 'bg-slate-800 text-slate-400 border-slate-700'
          }`}
        >
          {isSecureMode ? <Shield className="w-4 h-4 text-slate-950" /> : <Lock className="w-4 h-4 text-slate-500" />}
          <span>{isSecureMode ? 'SECURE IRC: ON' : 'SECURE IRC: OFF'}</span>
        </button>
      </div>

      {/* Main IRC Interface */}
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 shadow-xl grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[500px]">
        {/* Channel List & Status */}
        <div className="flex flex-col space-y-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center space-x-2 text-xs font-mono text-slate-400 border-b border-slate-800 pb-2">
            <Terminal className="w-4 h-4 text-amber-500" />
            <span>IRC CHANNELS</span>
          </div>

          <div className="flex flex-col space-y-2 flex-1">
            {channels.map((chan) => (
              <button
                key={chan}
                onClick={() => setCurrentChannel(chan)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg font-mono text-xs font-bold transition-all text-left ${
                  currentChannel === chan ? 'bg-slate-800 text-amber-400 border border-slate-700 shadow' : 'text-slate-400 hover:bg-slate-900'
                }`}
              >
                <Hash className="w-4 h-4 text-amber-500 shrink-0" />
                <span>{chan}</span>
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center space-x-2 text-xs font-mono text-slate-500">
            <Users className="w-4 h-4 text-amber-500" />
            <span>Active Swarm Peers: 14</span>
          </div>
        </div>

        {/* Chat Log & Message Input */}
        <div className="lg:col-span-3 flex flex-col space-y-4 bg-slate-950 p-4 rounded-xl border border-slate-800 flex-1">
          {/* Channel Info Header */}
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <h3 className="font-mono font-bold text-amber-400 text-base flex items-center space-x-1">
              <Hash className="w-5 h-5 text-amber-500" />
              <span>{currentChannel.replace('#', '')}</span>
            </h3>
            <span className="text-xs font-mono text-slate-400 bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
              irc.patentoffice.ietf.org:6697
            </span>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 flex flex-col space-y-3 overflow-y-auto max-h-96 pr-1 font-mono text-xs">
            {currentMessages.map((msg, idx) => (
              <div key={idx} className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1 hover:bg-slate-850 transition-all">
                <div className="flex justify-between items-center">
                  <span className={`font-bold ${msg.sender === 'You' ? 'text-amber-400' : msg.sender === 'ServerDaemon' ? 'text-blue-400' : 'text-emerald-400'}`}>
                    &lt;{msg.sender}&gt;
                  </span>
                  <div className="flex items-center space-x-2">
                    {msg.isEncrypted && (
                      <span className="px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[9px] font-bold flex items-center space-x-1">
                        <span>🛡️ SECURE</span>
                      </span>
                    )}
                    <span className="text-slate-500 text-[10px]">{msg.time}</span>
                  </div>
                </div>
                <p className="text-slate-200 break-words text-sm leading-relaxed">{msg.text}</p>
              </div>
            ))}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSendMessage} className="flex space-x-2 pt-2 border-t border-slate-800">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={`Message ${currentChannel}...`}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl p-3 text-slate-100 font-mono text-sm focus:outline-none focus:border-amber-500 shadow-inner"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold rounded-xl shadow-lg hover:shadow-amber-500/50 transition-all flex items-center space-x-2 shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Send</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
