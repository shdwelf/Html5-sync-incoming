import React, { useState } from 'react';
import { Radio, Send, Play, Settings, Activity, Upload, CheckCircle } from 'lucide-react';

export const SSTVWebRTC: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>("sstv");

  // SSTV State
  const [sstvMode, setSstvMode] = useState<string>("Martin M1");
  const [visCode, setVisCode] = useState<string>("0x2C (Martin M1)");
  const [slantCorrection, setSlantCorrection] = useState<number>(0.000015);
  const [syncTolerance, setSyncTolerance] = useState<number>(1200); // 1200Hz sync pulse
  const [isTransmittingSstv, setIsTransmittingSstv] = useState<boolean>(false);
  const [sstvLogs, setSstvLogs] = useState<string[]>([
    "SSTV Demodulator & AFSK Synthesizer ready.",
    "VIS Decoder armed for 1200Hz sync / 1900Hz leader tone."
  ]);
  const [, setAudioSynthesizerSupported] = useState<boolean>(true);

  // WebRTC TUN/TAP State
  const [webrtcConnected, setWebrtcConnected] = useState<boolean>(true);
  const [packetPayload, setPacketPayload] = useState<string>("192.168.9.9 -> 192.168.9.10 [TCP Flag: PSH, ACK] len=64");
  const [bridgeLogs, setBridgeLogs] = useState<string[]>([
    "Virtual TUN/TAP Interface 'tun0' allocated.",
    "WebRTC DataChannel peer-to-peer connection established.",
    "SSTV Audio-fallback monitoring daemon active."
  ]);

  const handleSimulateSSTVTransmission = () => {
    setIsTransmittingSstv(true);
    setSstvLogs((prev) => [`[${new Date().toLocaleTimeString()}] Generating AFSK subcarrier for ${sstvMode}...`, ...prev]);

    // Attempt Web Audio API tone generation if supported
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContext) {
        const ctx = new AudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1900, ctx.currentTime); // VIS leader
        osc.frequency.setValueAtTime(1200, ctx.currentTime + 0.3); // Sync pulse
        osc.frequency.setValueAtTime(1500, ctx.currentTime + 0.6); // Black level
        osc.frequency.setValueAtTime(2300, ctx.currentTime + 0.9); // White level
        gain.gain.setValueAtTime(0.1, ctx.currentTime); // keep volume low
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 1.2);
      }
    } catch (e) {
      setAudioSynthesizerSupported(false);
    }

    setTimeout(() => {
      setSstvLogs((prev) => [`[${new Date().toLocaleTimeString()}] VIS Header 0x2C acknowledged. Slant alignment complete.`, ...prev]);
    }, 1500);

    setTimeout(() => {
      setIsTransmittingSstv(false);
      setSstvLogs((prev) => [`[${new Date().toLocaleTimeString()}] SUCCESS: SSTV image raster transmitted. Automatic slant calibration verified at ${slantCorrection}.`, ...prev]);
    }, 3000);
  };

  const handleSendTunTapPacket = () => {
    if (!webrtcConnected) {
      // Trigger SSTV Fallback
      setBridgeLogs((prev) => [
        `[${new Date().toLocaleTimeString()}] WARNING: WebRTC DataChannel offline! Triggering SSTV Audio Fallback Bridge...`,
        `[${new Date().toLocaleTimeString()}] Modulating TUN packet into AFSK SSTV burst...`,
        `[${new Date().toLocaleTimeString()}] SSTV Fallback broadcast complete. Packet delivered over audio spectrum.`,
        ...prev
      ]);
    } else {
      setBridgeLogs((prev) => [
        `[${new Date().toLocaleTimeString()}] TUN/TAP DataChannel frame sent: ${packetPayload}`,
        `[${new Date().toLocaleTimeString()}] ACK received from peer via WebRTC SCTP protocol.`,
        ...prev
      ]);
    }
  };

  return (
    <div className="w-full flex flex-col space-y-6 p-6">
      {/* Header Bar */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <Radio className="w-8 h-8 text-amber-500" />
          <div>
            <h2 className="text-xl font-mono font-extrabold text-amber-400">SSTV HTML5 MODEM & WEBRTC TUN/TAP BRIDGE</h2>
            <p className="text-xs text-slate-400 font-mono">
              Working models for Slow Scan TV audio import/export and peer-to-peer DataChannel virtual network bridges.
            </p>
          </div>
        </div>
        <div className="hidden sm:flex items-center space-x-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
          <Activity className="w-4 h-4 text-amber-500 animate-pulse" />
          <span className="text-xs font-mono text-slate-300">AFSK Web Audio API Ready</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 border-b border-slate-700 pb-4">
        <button
          onClick={() => setActiveTab("sstv")}
          className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all ${activeTab === "sstv" ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
        >
          <Radio className="w-4 h-4" />
          <span>MMSSTV Web Synthesizer & Calibration</span>
        </button>
        <button
          onClick={() => setActiveTab("webrtc")}
          className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all ${activeTab === "webrtc" ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
        >
          <Activity className="w-4 h-4" />
          <span>WebRTC TUN/TAP Bridge + SSTV Fallback</span>
        </button>
      </div>

      {/* Workspace */}
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 shadow-xl">
        {/* 1. SSTV Module */}
        {activeTab === "sstv" && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-4 gap-4">
              <div>
                <h3 className="text-lg font-mono font-extrabold text-amber-400">MMSSTV-Compatible AFSK Modulator / Demodulator</h3>
                <p className="text-slate-300 text-xs font-mono mt-1">
                  Adjust automatic slant correction, VIS sync pulses, and import mock WAV audio for visual spectrogram analysis.
                </p>
              </div>
              <button
                onClick={handleSimulateSSTVTransmission}
                disabled={isTransmittingSstv}
                className="px-6 py-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-slate-950 font-mono font-bold rounded-xl shadow transition-all flex items-center space-x-2"
              >
                <Play className={`w-4 h-4 ${isTransmittingSstv ? 'animate-ping' : ''}`} />
                <span>{isTransmittingSstv ? 'Transmitting AFSK Tone...' : 'Broadcast SSTV Audio Subcarrier'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Controls */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <h4 className="font-mono font-bold text-slate-200 text-sm flex items-center space-x-2">
                  <Settings className="w-4 h-4 text-amber-500" />
                  <span>SSTV Modem Settings</span>
                </h4>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">ENCODING PROTOCOL MODE</label>
                  <select
                    value={sstvMode}
                    onChange={(e) => {
                      setSstvMode(e.target.value);
                      if (e.target.value.includes("Martin M1")) setVisCode("0x2C (Martin M1)");
                      if (e.target.value.includes("Scottie S1")) setVisCode("0x3C (Scottie S1)");
                      if (e.target.value.includes("PD 120")) setVisCode("0x5F (PD 120)");
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                  >
                    <option value="Martin M1">Martin M1 (114s)</option>
                    <option value="Scottie S1">Scottie S1 (110s)</option>
                    <option value="PD 120">PD 120 (126s)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">SLANT CORRECTION CALIBRATION</label>
                  <input
                    type="number"
                    step="0.000001"
                    value={slantCorrection}
                    onChange={(e) => setSlantCorrection(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-500"
                  />
                  <span className="text-[10px] font-mono text-slate-500 block mt-1">Automatic skew alignment factor for clock drift.</span>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">SYNC TOLERANCE FREQUENCY (Hz)</label>
                  <input
                    type="number"
                    value={syncTolerance}
                    onChange={(e) => setSyncTolerance(parseInt(e.target.value) || 1200)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                  />
                  <span className="text-[10px] font-mono text-slate-500 block mt-1">Expected horizontal sync pulse at 1200 Hz.</span>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <label className="block text-xs font-mono text-slate-400 mb-2">IMPORT MMSSTV WAV FILE</label>
                  <button
                    onClick={() => setSstvLogs((prev) => [`[${new Date().toLocaleTimeString()}] Mock MMSSTV WAV file imported successfully. Auto-calibrating slant...`, ...prev])}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs rounded-lg border border-slate-700 shadow flex items-center justify-center space-x-2"
                  >
                    <Upload className="w-4 h-4 text-amber-500" />
                    <span>Upload Mock .WAV Audio</span>
                  </button>
                </div>
              </div>

              {/* Display Canvas & Raster */}
              <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center space-y-4 shadow-inner overflow-hidden relative">
                <div className="absolute top-2 left-2 bg-slate-900 px-3 py-1 rounded text-slate-400 font-mono text-xs border border-slate-800">
                  VIS Code: <span className="text-amber-400 font-bold">{visCode}</span>
                </div>

                <div className="w-full max-w-sm h-48 bg-gradient-to-r from-blue-900 via-slate-800 to-indigo-900 rounded-lg border border-slate-700 shadow-2xl relative overflow-hidden flex items-center justify-center">
                  {/* Simulated Scan Line Animation */}
                  <div className={`absolute left-0 top-0 right-0 h-1 bg-amber-400 opacity-80 shadow-lg shadow-amber-400 ${isTransmittingSstv ? 'animate-[bounce_2s_infinite]' : 'hidden'}`} />
                  
                  {isTransmittingSstv ? (
                    <div className="text-amber-300 font-mono text-sm bg-black/80 p-4 rounded-xl border border-amber-500/30 animate-pulse">
                      RECEIVING SSTV IMAGE RASTER...
                    </div>
                  ) : (
                    <div className="text-slate-300 font-mono text-xs p-4 bg-black/60 rounded-xl border border-slate-800">
                      SSTV IDLE / NO CARRIER TONE DETECTED.<br />Click 'Broadcast SSTV Audio Subcarrier' above.
                    </div>
                  )}
                </div>
                
                <span className="text-xs font-mono text-slate-400">
                  Color Calibration: YUV Luminance Sub-carrier @ 2300Hz Max
                </span>
              </div>

              {/* Logs */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-mono font-bold text-slate-200 text-sm">SSTV Audio Telemetry Logs</h4>
                <div className="bg-black p-3 rounded-lg font-mono text-xs text-slate-300 space-y-2 max-h-64 overflow-y-auto">
                  {sstvLogs.map((log, i) => (
                    <div key={i} className="border-b border-slate-900 pb-1 text-amber-300">{log}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. WebRTC TUN/TAP Bridge */}
        {activeTab === "webrtc" && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h3 className="text-lg font-mono font-extrabold text-amber-400">WebRTC DataChannel Virtual TUN/TAP Interface</h3>
                <p className="text-slate-300 text-xs font-mono mt-1">
                  Establishes a peer-to-peer raw packet bridge. If the WebRTC socket disconnects, it automatically switches to SSTV acoustic fallback transmission.
                </p>
              </div>
              <button
                onClick={() => {
                  setWebrtcConnected(!webrtcConnected);
                  setBridgeLogs((prev) => [`[${new Date().toLocaleTimeString()}] WebRTC DataChannel connection state changed to: ${!webrtcConnected ? 'ONLINE' : 'OFFLINE (SSTV Fallback Active)'}`, ...prev]);
                }}
                className={`px-5 py-2.5 font-mono font-bold text-xs rounded-xl shadow transition-all flex items-center space-x-2 ${webrtcConnected ? 'bg-emerald-600 hover:bg-emerald-500 text-slate-950' : 'bg-red-600 hover:bg-red-500 text-white'}`}
              >
                <CheckCircle className="w-4 h-4" />
                <span>{webrtcConnected ? 'DataChannel: ONLINE (Click to Cut)' : 'DataChannel: OFFLINE (SSTV Fallback)'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <h4 className="font-mono font-bold text-slate-200 text-sm">Send Virtual TUN Packet</h4>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">TUN/TAP PACKET PAYLOAD</label>
                  <textarea
                    rows={4}
                    value={packetPayload}
                    onChange={(e) => setPacketPayload(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-slate-200 font-mono text-xs focus:outline-none focus:border-amber-500 shadow-inner"
                  />
                </div>
                <button
                  onClick={handleSendTunTapPacket}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold rounded-lg shadow transition-all flex items-center justify-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Packet Across Bridge</span>
                </button>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h4 className="font-mono font-bold text-slate-200 text-sm">Bridge Virtual Switch Logs</h4>
                <div className="bg-black p-4 rounded-lg font-mono text-xs text-slate-300 space-y-2 max-h-64 overflow-y-auto">
                  {bridgeLogs.map((log, i) => (
                    <div key={i} className={`border-b border-slate-900 pb-1 ${log.includes('WARNING') || log.includes('SSTV Fallback') ? 'text-yellow-400 font-bold' : 'text-emerald-400'}`}>
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
