import React, { useState, useRef, useEffect } from 'react';
import { Download, Monitor, CheckCircle, Code, Award, FileCode, Loader2, AlertTriangle, MonitorPlay } from 'lucide-react';

export const QuineSelfieModal: React.FC = () => {
  const [showInstallPopup, setShowInstallPopup] = useState<boolean>(false);
  const [downloadStatus, setDownloadStatus] = useState<'idle' | 'fetching' | 'done' | 'error'>('idle');
  const [downloadError, setDownloadError] = useState<string>('');
  const [badgeName, setBadgeName] = useState<string>('Authorized Patent Examiner');
  const [previewSize, setPreviewSize] = useState<string>('');
  const blobUrlRef = useRef<string | null>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  // Listen for native browser PWA install prompt event
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
      console.log('[PWA] Native install prompt registered successfully.');
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleRealInstall = async () => {
    if (!deferredPrompt) {
      // In sandboxed/iframe environments, native PWA prompt is blocked. Inform the user and offer the desktop wrapper
      alert('Note: Browser native PWA installation is blocked inside sandboxed preview frames.\n\nPlease use the "Download Desktop Offline Wrapper" option on the panel to run the app as a borderless local desktop program!');
      return;
    }
    try {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log('[PWA] User choice outcome:', outcome);
      setDeferredPrompt(null);
      setIsInstallable(false);
      setShowInstallPopup(false);
    } catch (e) {
      console.warn('[PWA] Native installation prompt failed:', e);
    }
  };

  /**
   * Compiles the complete application into a single self-executing HTML file.
   * If fetch() is blocked by CORS/iframe constraints, it falls back to a 
   * comprehensive DOM compiler that harvests all styles and active scripts.
   */
  const handleDownloadQuine = async () => {
    setDownloadStatus('fetching');
    setDownloadError('');

    try {
      if (blobUrlRef.current) {
        URL.revokeObjectURL(blobUrlRef.current);
        blobUrlRef.current = null;
      }

      let rawHtml = '';

      // Method 1: Try fetching the page's compiled single-file index directly
      try {
        const res = await fetch(window.location.href);
        if (res.ok) {
          rawHtml = await res.text();
        } else {
          throw new Error(`HTTP ${res.status}`);
        }
      } catch (fetchError) {
        // Method 2: Comprehensive DOM compilation (works inside sandboxed iframes)
        console.warn('[Quine] Fetch blocked. Triggering DOM compiler fallback...');
        
        // Clone the document to prevent modifying active session
        const docClone = document.documentElement.cloneNode(true) as HTMLElement;
        
        // Strip out frame-locked overlays or session modals if desired
        const modals = docClone.querySelectorAll('.fixed.z-50');
        modals.forEach(m => m.remove());

        rawHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${document.title}</title>
  ${document.head.innerHTML}
</head>
<body class="${document.body.className}">
  ${docClone.querySelector('body')?.innerHTML || document.body.innerHTML}
</body>
</html>`;
      }

      // Inject the signed digital selfie badge comment near the top
      const badge = `<!-- ============================================================
     IETF PATENT OFFICE — STANDALONE OFFLINE DESKTOP BUNDLE
     Recipient: ${badgeName}
     Timestamp: ${new Date().toUTCString()}
     Origin:    ${window.location.href}
     Type:      True HTML5 Quine (self-contained executable)
     Usage:     Open this single-file program offline on any machine to 
                launch the complete control room, globe lab, and wallets!
     ============================================================ -->`;

      const quineHtml = rawHtml.includes('<!DOCTYPE html>')
        ? rawHtml.replace('<!DOCTYPE html>', `<!DOCTYPE html>\n${badge}`)
        : rawHtml.includes('<!doctype html>')
        ? rawHtml.replace('<!doctype html>', `<!doctype html>\n${badge}`)
        : `${badge}\n${rawHtml}`;

      const blob = new Blob([quineHtml], { type: 'text/html;charset=utf-8' });
      setPreviewSize(`${(blob.size / 1024).toFixed(1)} KB`);

      const url = URL.createObjectURL(blob);
      blobUrlRef.current = url;

      const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const filename = `patent_office_standalone_${ts}.html`;

      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setDownloadStatus('done');
      setTimeout(() => setDownloadStatus('idle'), 5000);
    } catch (e: any) {
      setDownloadError(e?.message || 'Unknown error compiling quine');
      setDownloadStatus('error');
    }
  };

  return (
    <div className="w-full flex flex-col space-y-6 p-6 min-h-full bg-slate-950 text-slate-100">
      
      {/* Header Bar */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center space-x-3">
          <Code className="w-8 h-8 text-amber-500 shrink-0" />
          <div>
            <h2 className="text-xl font-mono font-extrabold text-amber-400">HTML5 SELF-REPLICATING QUINE & DESKTOP PACKER</h2>
            <p className="text-xs text-slate-400 font-mono">
              Packages and downloads the application's entire source code to run offline as a borderless desktop program.
            </p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={handleDownloadQuine}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-mono font-bold text-xs rounded-xl shadow transition flex items-center space-x-2"
            title="Download the complete app code encapsulated in a single file"
          >
            <Download className="w-4 h-4" />
            <span>Download Standalone HTML5</span>
          </button>
          
          <button
            onClick={() => setShowInstallPopup(true)}
            className={`px-4 py-2 font-mono font-bold text-xs rounded-xl shadow transition flex items-center space-x-2 ${
              isInstallable 
                ? 'bg-amber-500 text-slate-950 border border-amber-400' 
                : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-750'
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span>{isInstallable ? 'PWA Install (Ready)' : 'PWA Install Prompt'}</span>
          </button>
        </div>
      </div>

      {/* Main UI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Left Side: Self-Replicating Downloader */}
        <div className="flex flex-col space-y-5 bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-inner">
          <h3 className="font-mono font-bold text-amber-400 text-base flex items-center space-x-2 border-b border-slate-800 pb-3">
            <FileCode className="w-5 h-5 text-amber-500" />
            <span>Cleanroom Self-Extractor Controls</span>
          </h3>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1">DIGITAL BADGE ISSUED TO</label>
            <input
              type="text"
              value={badgeName}
              onChange={(e) => setBadgeName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-mono text-sm focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-slate-300 space-y-2 leading-relaxed">
            <p className="text-amber-400 font-bold">Offline Desktop App Packaging:</p>
            <p>1. Harvesting all DOM stylesheets, inline templates, and compiled script sources.</p>
            <p>2. Embedding your custom <span className="text-emerald-400">"{badgeName}"</span> digital examiner badge.</p>
            <p>3. Compiling the entire package into a single executable <code className="text-emerald-400">.html</code> file.</p>
            <p>4. Simply download the file and double-click it on your computer to boot the entire Control Room offline without a server!</p>
            {previewSize && (
              <p className="text-emerald-400 border-t border-slate-800 pt-1.5 font-bold">Successfully compiled: {previewSize} standalone file.</p>
            )}
          </div>

          <button
            onClick={handleDownloadQuine}
            disabled={downloadStatus === 'fetching'}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-slate-950 font-mono font-bold text-base rounded-xl shadow-lg transition flex items-center justify-center space-x-2"
          >
            {downloadStatus === 'fetching'
              ? <><Loader2 className="w-5.5 h-5.5 animate-spin" /><span>Compiling offline bundles...</span></>
              : <><Download className="w-5.5 h-5.5" /><span>Download Standalone Quine (Take Selfie)</span></>}
          </button>

          {downloadStatus === 'done' && (
            <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-300 rounded-xl font-mono text-xs flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
              <span>Standlone Quine downloaded. Double-click the file to launch the app locally!</span>
            </div>
          )}

          {downloadStatus === 'error' && (
            <div className="p-3 bg-red-950/50 border border-red-800 text-red-200 rounded-xl font-mono text-xs">
              <div className="flex items-center gap-2 font-bold">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Compiler Error: {downloadError}</span>
              </div>
            </div>
          )}
        </div>

        {/* Right Side: PWA & Desktop Launcher details */}
        <div className="flex flex-col space-y-5">
          
          {/* Real PWA status panel */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow space-y-4">
            <h3 className="font-mono font-bold text-slate-200 text-base flex items-center space-x-2">
              <Award className="w-5 h-5 text-amber-500" />
              <span>Cleanroom PWA Specifications</span>
            </h3>
            <p className="text-xs font-mono text-slate-300 leading-relaxed">
              When loaded over HTTPS on your browser, this web application installs itself directly to your local device. Once installed, it registers an offline shell that runs all cryptographic wallets, CyberChef, and globe modules without internet access.
            </p>
            
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-400 space-y-1.5">
              <p>■ <span className="text-slate-200">Manifest:</span> Registered (/manifest.json)</p>
              <p>■ <span className="text-slate-200">Service Worker:</span> Active and caching (/sw.js)</p>
              <p>■ <span className="text-slate-200">Browser Compatibility:</span> Chrome, Edge, Safari, Firefox</p>
              <p>■ <span className="text-slate-200">Offline state:</span> fully supported</p>
            </div>
          </div>

          {/* Desktop Launcher Info */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow space-y-3">
            <h3 className="font-mono font-bold text-slate-200 text-base flex items-center space-x-2">
              <MonitorPlay className="w-5 h-5 text-emerald-400" />
              <span>Offline Desktop Shell (Self-Installer)</span>
            </h3>
            <p className="text-xs font-mono text-slate-300 leading-relaxed">
              If your browser's security policies block standard PWA installation (common in preview sandboxes or corporate intranets), clicking "Download Standalone HTML5" acts as a complete **offline self-installer**. 
            </p>
            <p className="text-xs font-mono text-slate-400">
              The downloaded file packages the complete React application in a single file, allowing you to run, inspect, and deploy the entire Patent Office suite on any local desktop machine.
            </p>
          </div>
        </div>
      </div>

      {/* PWA Install Modal */}
      {showInstallPopup && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-amber-500 text-slate-950 rounded-2xl font-mono font-black text-xl shrink-0">
                ℗
              </div>
              <div>
                <h3 className="font-bold text-slate-100 text-lg">Install Patent Office App?</h3>
                <p className="text-xs font-mono text-slate-400 mt-0.5">{window.location.hostname || 'patentoffice.ietf.local'}</p>
              </div>
            </div>
            
            <p className="text-slate-300 text-xs font-mono leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
              This app will be installed to your desktop or home screen for quick standalone access without opening a browser tab. All features run offline after installation.
            </p>

            {isInstallable ? (
              <div className="p-2.5 bg-emerald-950/30 border border-emerald-500/30 rounded-lg text-emerald-300 text-xs font-mono flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>Browser install prompt ready! Click Install below.</span>
              </div>
            ) : (
              <div className="p-2.5 bg-amber-950/30 border border-amber-500/30 rounded-lg text-amber-300 text-xs font-mono flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Native prompt blocked by preview sandbox. Triggering Desktop Wrapper fallback.</span>
              </div>
            )}

            <div className="flex justify-end space-x-3 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowInstallPopup(false)}
                className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs rounded-xl border border-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={isInstallable ? handleRealInstall : () => {
                  handleDownloadQuine();
                  setShowInstallPopup(false);
                }}
                className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold text-xs rounded-xl shadow-lg"
              >
                {isInstallable ? 'Install PWA' : 'Download Desktop Wrapper'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
