import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Volume2, VolumeX, RefreshCw, Send, Sliders } from 'lucide-react';

interface ChatLine {
  sender: 'SBAITSO' | 'USER';
  text: string;
}

export const DrSbaitsoApp: React.FC = () => {
  const [input, setInput] = useState<string>('');
  const [chat, setChat] = useState<ChatLine[]>([
    { sender: 'SBAITSO', text: 'HELLO, I AM DR. SBAITSO.' },
    { sender: 'SBAITSO', text: 'I AM HERE TO HELP YOU.' },
    { sender: 'SBAITSO', text: 'SAY WHATEVER IS ON YOUR MIND.' }
  ]);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(true);
  const [pitch, setPitch] = useState<number>(0.5); // lower pitch = more robotic
  const [rate, setRate] = useState<number>(1.0);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat]);

  // Speak function utilizing HTML5 SpeechSynthesis
  const speak = (text: string) => {
    if (!voiceEnabled || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel(); // Stop current speech
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Attempt to find a robotic-sounding voice
      const voices = window.speechSynthesis.getVoices();
      const roboticVoice = voices.find(v => 
        v.name.toLowerCase().includes('robot') || 
        v.name.toLowerCase().includes('synth') ||
        v.name.toLowerCase().includes('google uk english male')
      );
      if (roboticVoice) {
        utterance.voice = roboticVoice;
      }
      
      utterance.pitch = pitch;
      utterance.rate = rate;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('SpeechSynthesis failed:', e);
    }
  };

  // Speak Dr. Sbaitso's initial greeting on mount
  useEffect(() => {
    const greeting = 'HELLO, I AM DR. SBAITSO. I AM HERE TO HELP YOU. SAY WHATEVER IS ON YOUR MIND.';
    const tid = setTimeout(() => speak(greeting), 1000);
    return () => {
      clearTimeout(tid);
      if (window.speechSynthesis) window.speechSynthesis.cancel();
    };
  }, []);

  // Web Audio API retro DOS beep
  const playBeep = (freq = 800, duration = 0.08) => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'square'; // retro chiptune sound
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // AudioContext not supported or blocked
    }
  };

  const getSbaitsoResponse = (query: string): string => {
    const q = query.toUpperCase().trim();
    if (!q) return 'PLEASE SAY SOMETHING.';

    // Sound Blaster / Creative references
    if (q.includes('SOUND BLASTER') || q.includes('CREATIVE')) {
      return 'I WAS DISTRIBUTED ON A 3.5 INCH FLOPPY DISK WITH THE SOUND BLASTER PRO. EXCELLENT HARDWARE.';
    }

    // Standard ELIZA / Sbaitso doctor logic
    if (q.startsWith('HELLO') || q.startsWith('HI') || q.startsWith('HEY')) {
      return 'HELLO. HOW DO YOU DO. PLEASE STATE YOUR PROBLEM.';
    }
    if (q.includes('WHY')) {
      return 'WHY DO YOU ASK? DOES THAT INTEREST YOU?';
    }
    if (q.includes('HOW')) {
      return 'HOW DO YOU FEEL ABOUT THAT?';
    }
    if (q.includes('WHAT') || q.includes('WHO')) {
      return 'WHY DO YOU WANT TO KNOW?';
    }
    if (q.includes('YOU')) {
      return 'WE ARE DISCUSSING YOU, NOT ME. PLEASE CONTINUE.';
    }
    if (q.includes('SAD') || q.includes('DEPRESSED') || q.includes('ANXIOUS') || q.includes('AFRAID')) {
      return 'DO YOU OFTEN FEEL THIS WAY? WHAT MAKES YOU FEEL THAT?';
    }
    if (q.includes('ANGRY') || q.includes('HATE') || q.includes('MAD')) {
      return 'TELL ME MORE ABOUT THESE INTENSE FEELINGS. DOES ANGER HELP YOU?';
    }
    if (q.includes('MOTHER') || q.includes('FATHER') || q.includes('BROTHER') || q.includes('SISTER') || q.includes('FAMILY')) {
      return 'TELL ME MORE ABOUT YOUR FAMILY. HOW IS YOUR RELATIONSHIP WITH THEM?';
    }
    if (q.includes('COMPUTER') || q.includes('ROBOT') || q.includes('AI') || q.includes('PROGRAM')) {
      return 'DO COMPUTERS WORRY YOU? I AM A VERY POWERFUL PSYCHOLOGIST.';
    }
    if (q.includes('PATENT') || q.includes('BOOKSHELF') || q.includes('SECRET')) {
      return 'THE SECRET BOOKSHELF IS A SECURE CLEANROOM. DO YOU FEEL SAFE IN THE CONTROL ROOM?';
    }
    if (q.includes('CRYPTO') || q.includes('BANANO') || q.includes('MONKEY') || q.includes('LAMBO')) {
      return 'POTASSIUM AND LAMBOS ARE FASCINATING CRYPTOGRAPHIC CONCEPTS.';
    }
    if (q.includes('SBAITSO')) {
      return 'THAT IS MY NAME. I AM A REGISTERED TRADEMARK OF CREATIVE TECHNOLOGY LTD.';
    }
    if (q.includes('HELP') || q.includes('PROBLEM') || q.includes('STRESSED')) {
      return 'I AM HERE TO HELP YOU. PLEASE EXPLAIN THE NATURE OF YOUR COMPLAINTS.';
    }

    // Default random Sbaitso fillers
    const fallbacks = [
      'THAT IS VERY INTERESTING. PLEASE CONTINUE.',
      'SAY, OTHER THAN THAT, WHAT ELSE IS ON YOUR MIND?',
      'I UNDERSTAND. TELL ME MORE.',
      'WHY DO YOU SAY THAT?',
      'HOW DOES THAT AFFECT YOU?',
      'PLEASE GO ON. DO NOT BE SHY.',
      'YOU ARE A VERY INTERESTING CONVERSATIONALIST.'
    ];
    return fallbacks[Math.floor(Math.random() * fallbacks.length)];
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userText = input.toUpperCase();
    setInput('');
    playBeep(600, 0.05);

    // Append user line
    const userLine: ChatLine = { sender: 'USER', text: userText };
    setChat((prev) => [...prev, userLine]);

    // Compute Sbaitso response with slight typing lag simulation
    setTimeout(() => {
      const response = getSbaitsoResponse(userText);
      playBeep(900, 0.08);
      setChat((prev) => [...prev, { sender: 'SBAITSO', text: response }]);
      speak(response);
    }, 450);
  };

  const handleReset = () => {
    playBeep(400, 0.15);
    setChat([
      { sender: 'SBAITSO', text: 'HELLO, I AM DR. SBAITSO.' },
      { sender: 'SBAITSO', text: 'I AM HERE TO HELP YOU.' },
      { sender: 'SBAITSO', text: 'SAY WHATEVER IS ON YOUR MIND.' }
    ]);
    speak('HELLO, I AM DR. SBAITSO. I AM HERE TO HELP YOU. SAY WHATEVER IS ON YOUR MIND.');
  };

  return (
    <div className="w-full h-full flex flex-col bg-blue-900 text-white font-mono text-sm shadow-2xl relative select-text min-h-[480px]">
      
      {/* Sound Blaster Card Header */}
      <div className="shrink-0 bg-slate-900 border-b-4 border-amber-500 p-3 flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center space-x-2">
          <Terminal className="w-5 h-5 text-amber-400" />
          <div>
            <div className="font-bold text-xs tracking-wider text-slate-100">CREATIVE LABS / SOUND BLASTER PRO</div>
            <div className="text-[10px] text-amber-500">DR. SBAITSO AI PSYCHOLOGIST · VERSION 2.20</div>
          </div>
        </div>

        {/* Speech & Audio Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-1 rounded border border-slate-800">
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
            <label className="text-[9px] text-slate-400 font-bold">PITCH:</label>
            <input 
              type="range" 
              min="0.1" 
              max="2.0" 
              step="0.1" 
              value={pitch} 
              onChange={(e) => setPitch(parseFloat(e.target.value))} 
              className="w-12 h-1 bg-slate-800 accent-amber-500 rounded-lg appearance-none"
              title="Robotic pitch (lower = deeper robot)"
            />
            <label className="text-[9px] text-slate-400 font-bold ml-1">SPEED:</label>
            <input 
              type="range" 
              min="0.5" 
              max="2.0" 
              step="0.1" 
              value={rate} 
              onChange={(e) => setRate(parseFloat(e.target.value))} 
              className="w-12 h-1 bg-slate-800 accent-amber-500 rounded-lg appearance-none"
              title="Speech rate speed"
            />
          </div>

          <button
            onClick={() => {
              setVoiceEnabled(!voiceEnabled);
              playBeep(700, 0.05);
            }}
            className={`p-2 rounded border transition ${
              voiceEnabled 
                ? 'bg-amber-500 text-slate-950 border-amber-400' 
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-750'
            }`}
            title={voiceEnabled ? 'Mute Speech synthesis' : 'Enable Speech synthesis'}
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={handleReset}
            className="p-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded transition"
            title="Reset conversation"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Classic Blue DOS Chat Canvas */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-blue-950 select-text font-mono shadow-inner border-b-4 border-slate-900">
        
        {/* Cassette card splash logo */}
        <div className="p-4 bg-blue-900 border-2 border-dashed border-blue-800 rounded-xl text-center max-w-lg mx-auto space-y-1.5 opacity-80 pointer-events-none select-none">
          <div className="text-xl font-black tracking-widest text-amber-400">DR. SBAITSO</div>
          <div className="text-[10px] text-slate-300">COPYRIGHT (C) 1991 CREATIVE TECHNOLOGY LTD. ALL RIGHTS RESERVED.</div>
          <div className="text-[9px] text-slate-400">REQUIRES SOUND BLASTER VOCAL MODULE FOR AUDIO SYNTHESIS.</div>
        </div>

        {/* Dialog lines */}
        <div className="space-y-4 pt-2">
          {chat.map((line, idx) => (
            <div 
              key={idx} 
              className={`flex flex-col space-y-0.5 ${
                line.sender === 'USER' ? 'items-end' : 'items-start'
              }`}
            >
              <span className={`text-[10px] font-bold tracking-widest ${
                line.sender === 'USER' ? 'text-amber-400' : 'text-cyan-400'
              }`}>
                {line.sender === 'USER' ? 'C:\\SBAITSO> USER' : 'DR. SBAITSO:'}
              </span>
              <div className={`p-3 rounded-2xl max-w-[85%] break-words text-base leading-relaxed ${
                line.sender === 'USER' 
                  ? 'bg-amber-600 text-white rounded-tr-none shadow' 
                  : 'bg-slate-900 text-cyan-300 rounded-tl-none shadow border border-slate-800'
              }`}>
                {line.text}
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
      </div>

      {/* DOS Prompt Input Bar */}
      <form onSubmit={handleSend} className="shrink-0 bg-slate-900 p-3 border-t border-slate-800 flex gap-2 items-center">
        <span className="font-bold text-amber-500 text-base shrink-0 select-none">C:\SBAITSO&gt;</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Say whatever is on your mind (e.g. why are you here?)..."
          className="flex-1 bg-black border border-slate-800 rounded-xl p-3 text-slate-100 font-mono text-sm focus:outline-none focus:border-amber-500 uppercase shadow-inner"
          autoFocus
        />
        <button
          type="submit"
          className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono font-bold rounded-xl shadow-lg hover:shadow-amber-500/50 transition flex items-center gap-2 shrink-0"
        >
          <Send className="w-4 h-4" />
          <span>Send</span>
        </button>
      </form>
    </div>
  );
};
