import React, { useState, useEffect } from 'react';
import { BookOpen, RefreshCw, Send, ShieldCheck, Server } from 'lucide-react';

interface RFCItem {
  id: string;
  title: string;
  year: string;
  category: string;
  summary: string;
}

export const RFCArchive: React.FC = () => {
  const [selectedRFC, setSelectedRFC] = useState<string>("RFC6238");

  const rfcs: RFCItem[] = [
    { id: "RFC6238", title: "TOTP: Time-Based One-Time Password Algorithm", year: "2011", category: "Security", summary: "Defines an extension of HMAC-based One-Time Passwords (HOTP) to support time-based moving factors." },
    { id: "RFC791", title: "Internet Protocol (IPv4 Specification)", year: "1981", category: "Routing", summary: "The foundational specification for transmitting blocks of data called datagrams from sources to destinations over an interconnected system of networks." },
    { id: "RFC2616", title: "Hypertext Transfer Protocol -- HTTP/1.1", year: "1999", category: "Application", summary: "Defines the request-response protocol for distributed, collaborative, hypermedia information systems." },
    { id: "RFC1149", title: "Transmission of IP Datagrams on Avian Carriers", year: "1990", category: "Experimental / Humor", summary: "A highly robust experimental standard for encapsulating IP datagrams in avian carriers (carrier pigeons)." },
    { id: "RFC6455", title: "The WebSocket Protocol", year: "2011", category: "Transport", summary: "Enables two-way communication between a client running untrusted code in a controlled environment to a remote host." },
    { id: "RFC7519", title: "JSON Web Token (JWT)", year: "2015", category: "Security", summary: "A compact, URL-safe means of representing claims to be transferred between two parties." }
  ];

  // TOTP State
  const [totpSecret, setTotpSecret] = useState<string>("JBSWY3DPEHPK3PXP");
  const [totpCode, setTotpCode] = useState<string>("529381");
  const [timer, setTimer] = useState<number>(30);

  // IPv4 State
  const [ipSrc, setIpSrc] = useState<string>("192.168.1.50");
  const [ipDst, setIpDst] = useState<string>("10.0.0.1");
  const [ipTtl, setIpTtl] = useState<number>(64);
  const [ipPayload, setIpPayload] = useState<string>("GET /index.html HTTP/1.1");

  // HTTP State
  const [httpMethod, setHttpMethod] = useState<string>("POST");
  const [httpPath, setHttpPath] = useState<string>("/api/v1/resource");
  const [httpHeaders, setHttpHeaders] = useState<string>("Host: patentoffice.ietf.org\nAuthorization: Bearer test_token\nUser-Agent: PatentOfficeApp/1.0");
  const [httpResponse, setHttpResponse] = useState<string>("Click 'Execute Simulated Request' to view response.");

  // Avian Carrier State
  const [pigeonStatus, setPigeonStatus] = useState<string>("Ready for take-off. Leg band unattached.");
  const [carrierLogs, setCarrierLogs] = useState<string[]>([]);

  // WebSocket State
  const [wsMessage, setWsMessage] = useState<string>("Hello, Patent Office WebSocket Echo Server!");
  const [wsLogs, setWsLogs] = useState<string[]>(["[Server] Connection established on ws://localhost:8080/echo"]);

  // JWT State
  const [jwtSub, setJwtSub] = useState<string>("user_12345");
  const [jwtRole, setJwtRole] = useState<string>("admin");
  const [jwtSecret, setJwtSecret] = useState<string>("secret_patent_key");

  // Simulate TOTP Timer
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          // Regenerate mock 6-digit code
          setTotpCode(Math.floor(100000 + Math.random() * 900000).toString());
          return 30;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleLaunchPigeon = () => {
    setPigeonStatus("Pigeon released! En route to target station...");
    setCarrierLogs((prev) => [`[${new Date().toLocaleTimeString()}] Datagram printed on lightweight paper, attached to Pigeon #42 leg. Released into headwinds.`, ...prev]);
    setTimeout(() => {
      setPigeonStatus("Pigeon spotted over waypoint Alpha. Maintaining 45 knots.");
      setCarrierLogs((prev) => [`[${new Date().toLocaleTimeString()}] Pigeon successfully dodged wandering hawk. Packet loss avoided.`, ...prev]);
    }, 2000);
    setTimeout(() => {
      setPigeonStatus("Pigeon arrived successfully! Datagram scanned into receiving router.");
      setCarrierLogs((prev) => [`[${new Date().toLocaleTimeString()}] SUCCESS: Packet delivered with 0% loss. Round-trip time: 3,450,000 ms.`, ...prev]);
    }, 4000);
  };

  const handleSendWS = () => {
    if (!wsMessage) return;
    const msg = wsMessage;
    setWsLogs((prev) => [`[Client -> Server]: ${msg}`, ...prev]);
    setTimeout(() => {
      setWsLogs((prev) => [`[Server -> Client Echo]: ${msg} (ACK)`, ...prev]);
    }, 500);
  };

  const handleExecHttp = () => {
    setHttpResponse(`HTTP/1.1 200 OK
Date: ${new Date().toUTCString()}
Server: IETF-PatentOffice-Server/1.0
Content-Type: application/json
Content-Length: 78

{
  "status": "success",
  "message": "RFC 2616 simulated transaction completed successfully."
}`);
  };

  // Helper for mock JWT generation
  const mockBase64Url = (obj: object) => btoa(JSON.stringify(obj)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const jwtHeader = mockBase64Url({ alg: "HS256", typ: "JWT" });
  const jwtPayload = mockBase64Url({ sub: jwtSub, role: jwtRole, iat: Math.floor(Date.now() / 1000) });
  const mockSignature = btoa(`${jwtHeader}.${jwtPayload}.${jwtSecret}`).substring(0, 43);

  return (
    <div className="w-full flex flex-col lg:flex-row gap-6 p-6">
      {/* Sidebar listing RFCs */}
      <div className="w-full lg:w-1/3 flex flex-col space-y-4">
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg">
          <h2 className="text-xl font-bold font-mono text-amber-400 flex items-center space-x-2">
            <BookOpen className="w-6 h-6 text-amber-500" />
            <span>IETF RFC ARCHIVE</span>
          </h2>
          <p className="text-xs text-slate-400 mt-2 font-mono">
            Explore functional working models of key internet specifications and experimental proposals.
          </p>
        </div>

        <div className="flex flex-col space-y-3 overflow-y-auto max-h-[700px] pr-1">
          {rfcs.map((rfc) => (
            <div
              key={rfc.id}
              onClick={() => setSelectedRFC(rfc.id)}
              className={`p-4 rounded-xl cursor-pointer border transition-all duration-200 ${selectedRFC === rfc.id ? 'bg-slate-800 border-amber-500 shadow-md shadow-amber-500/10' : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/60'}`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="font-mono font-bold text-amber-400 text-sm">{rfc.id}</span>
                <span className="text-xs font-mono px-2 py-0.5 bg-slate-700 rounded text-slate-300">{rfc.year}</span>
              </div>
              <h3 className="font-bold text-slate-100 text-base mb-1">{rfc.title}</h3>
              <span className="text-xs text-slate-400 font-mono italic block mb-2">{rfc.category}</span>
              <p className="text-xs text-slate-300 line-clamp-2">{rfc.summary}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main Interactive Sandbox */}
      <div className="flex-1 bg-slate-900 rounded-xl border border-slate-700 p-6 shadow-xl flex flex-col">
        {(() => {
          const current = rfcs.find((r) => r.id === selectedRFC);
          if (!current) return null;

          return (
            <>
              {/* Header Info */}
              <div className="border-b border-slate-700 pb-4 mb-6">
                <div className="flex justify-between items-center">
                  <h1 className="text-2xl font-mono font-extrabold text-amber-400 flex items-center space-x-3">
                    <span>{current.id}: {current.title}</span>
                  </h1>
                  <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 font-mono px-3 py-1 rounded-full text-sm">
                    {current.category} ({current.year})
                  </span>
                </div>
                <p className="text-slate-300 text-sm mt-3 leading-relaxed">
                  {current.summary}
                </p>
              </div>

              {/* Functional Interactive Examples */}
              <div className="flex-1 flex flex-col">
                {/* 1. RFC 6238 TOTP */}
                {selectedRFC === "RFC6238" && (
                  <div className="space-y-6 flex-1 flex flex-col">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                        <h3 className="font-mono font-bold text-emerald-400 text-lg flex items-center space-x-2">
                          <ShieldCheck className="w-5 h-5" />
                          <span>TOTP Parameter Control</span>
                        </h3>
                        <div>
                          <label className="block text-xs font-mono text-slate-400 mb-1">BASE32 SECRET KEY</label>
                          <input
                            type="text"
                            value={totpSecret}
                            onChange={(e) => setTotpSecret(e.target.value.toUpperCase())}
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-mono text-slate-400 mb-1">TIME STEP INTERVAL</label>
                          <input
                            type="text"
                            disabled
                            value="30 seconds (Tx = 30)"
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-400 font-mono text-sm cursor-not-allowed"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-mono text-slate-400 mb-1">CRYPTOGRAPHIC ALGORITHM</label>
                          <input
                            type="text"
                            disabled
                            value="HMAC-SHA-1 (Default RFC 6238)"
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-400 font-mono text-sm cursor-not-allowed"
                          />
                        </div>
                      </div>

                      <div className="p-6 bg-gradient-to-br from-slate-950 to-slate-900 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center space-y-6 shadow-inner">
                        <div>
                          <span className="text-xs font-mono text-slate-400 uppercase tracking-widest block mb-2">LIVE GENERATED TOKEN</span>
                          <div className="text-5xl font-mono font-extrabold text-amber-400 tracking-widest py-3 px-6 bg-black/60 rounded-xl border border-amber-500/30 shadow-lg animate-pulse">
                            {totpCode}
                          </div>
                        </div>

                        <div className="w-full max-w-xs space-y-2">
                          <div className="flex justify-between text-xs font-mono text-slate-400">
                            <span>Time Remaining:</span>
                            <span className="text-amber-400 font-bold">{timer}s</span>
                          </div>
                          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-amber-500 transition-all duration-1000"
                              style={{ width: `${(timer / 30) * 100}%` }}
                            />
                          </div>
                        </div>

                        <button
                          onClick={() => setTotpCode(Math.floor(100000 + Math.random() * 900000).toString())}
                          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 rounded-lg font-mono text-xs flex items-center space-x-2 transition-all"
                        >
                          <RefreshCw className="w-4 h-4 text-amber-500" />
                          <span>Generate Manual Refresher</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. RFC 791 IPv4 */}
                {selectedRFC === "RFC791" && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">SOURCE IP ADDRESS</label>
                        <input
                          type="text"
                          value={ipSrc}
                          onChange={(e) => setIpSrc(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">DESTINATION IP ADDRESS</label>
                        <input
                          type="text"
                          value={ipDst}
                          onChange={(e) => setIpDst(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">TTL (TIME TO LIVE)</label>
                        <input
                          type="number"
                          value={ipTtl}
                          onChange={(e) => setIpTtl(parseInt(e.target.value) || 0)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-slate-400 mb-1">PACKET PAYLOAD DATA</label>
                      <input
                        type="text"
                        value={ipPayload}
                        onChange={(e) => setIpPayload(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                      <h3 className="font-mono font-bold text-amber-400 text-sm">SYNTHESIZED IPV4 DATAGRAM HEADER MAP</h3>
                      <div className="bg-black p-4 rounded-lg font-mono text-xs text-slate-300 overflow-x-auto whitespace-pre">
                        {`+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|Version: 4|  IHL: 5 |Type of Service|    Total Length: ${20 + ipPayload.length}      |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|    Identification: 0x1A2B    |Flags|     Fragment Offset: 0   |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   TTL: ${ipTtl.toString().padEnd(6)} | Protocol: 6 (TCP) |    Header Checksum: 0x4F2C   |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|             Source IP Address: ${ipSrc.padEnd(25)} |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|          Destination IP Address: ${ipDst.padEnd(25)} |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   Options: None                                               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|   Payload Data: ${ipPayload}
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+`}
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. RFC 2616 HTTP */}
                {selectedRFC === "RFC2616" && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">HTTP METHOD</label>
                        <select
                          value={httpMethod}
                          onChange={(e) => setHttpMethod(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        >
                          <option value="GET">GET</option>
                          <option value="POST">POST</option>
                          <option value="PUT">PUT</option>
                          <option value="DELETE">DELETE</option>
                        </select>
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-xs font-mono text-slate-400 mb-1">REQUEST PATH</label>
                        <input
                          type="text"
                          value={httpPath}
                          onChange={(e) => setHttpPath(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">REQUEST HEADERS</label>
                        <textarea
                          rows={4}
                          value={httpHeaders}
                          onChange={(e) => setHttpHeaders(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-emerald-400 font-mono text-xs focus:outline-none focus:border-amber-500"
                        />
                        <button
                          onClick={handleExecHttp}
                          className="mt-3 w-full py-2 bg-amber-600 hover:bg-amber-500 text-slate-900 font-mono font-bold rounded-lg shadow transition-all flex items-center justify-center space-x-2"
                        >
                          <Server className="w-4 h-4" />
                          <span>Execute Simulated Request</span>
                        </button>
                      </div>

                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">MOCK SERVER RESPONSE</label>
                        <textarea
                          rows={6}
                          readOnly
                          value={httpResponse}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-amber-300 font-mono text-xs focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* 4. RFC 1149 Avian Carriers */}
                {selectedRFC === "RFC1149" && (
                  <div className="space-y-6">
                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                      <div className="space-y-1">
                        <h3 className="font-mono font-bold text-amber-400 text-lg">RFC 1149 Avian Pigeon Launchpad</h3>
                        <p className="text-slate-300 text-xs font-mono">Current Pigeon Status: <span className="text-emerald-400 font-bold">{pigeonStatus}</span></p>
                      </div>
                      <button
                        onClick={handleLaunchPigeon}
                        className="px-6 py-3 bg-red-600 hover:bg-red-500 text-white font-mono font-bold rounded-xl shadow-lg hover:shadow-red-500/50 transition-all flex items-center space-x-2"
                      >
                        <Send className="w-5 h-5 animate-bounce" />
                        <span>Launch Carrier Pigeon</span>
                      </button>
                    </div>

                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                      <h3 className="font-mono font-bold text-slate-400 text-xs uppercase tracking-widest">Avian Flight Telemetry Logs</h3>
                      <div className="bg-black p-4 rounded-lg font-mono text-xs text-slate-300 space-y-2 max-h-60 overflow-y-auto">
                        {carrierLogs.length === 0 ? (
                          <p className="text-slate-500 italic">No flights recorded yet. Click 'Launch Carrier Pigeon' to test RFC 1149 packet delivery.</p>
                        ) : (
                          carrierLogs.map((log, i) => (
                            <div key={i} className="border-b border-slate-900 pb-1 text-amber-300">{log}</div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* 5. RFC 6455 WebSockets */}
                {selectedRFC === "RFC6455" && (
                  <div className="space-y-6">
                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                      <h3 className="font-mono font-bold text-amber-400 text-sm">Bi-directional Frame Transmission Echo Sandbox</h3>
                      <div className="flex space-x-3">
                        <input
                          type="text"
                          value={wsMessage}
                          onChange={(e) => setWsMessage(e.target.value)}
                          placeholder="Enter message frame..."
                          className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                        <button
                          onClick={handleSendWS}
                          className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-mono font-bold rounded-lg shadow transition-all flex items-center space-x-2"
                        >
                          <Send className="w-4 h-4" />
                          <span>Send Frame</span>
                        </button>
                      </div>
                    </div>

                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                      <h3 className="font-mono font-bold text-slate-400 text-xs uppercase tracking-widest">WebSocket Frame Stream</h3>
                      <div className="bg-black p-4 rounded-lg font-mono text-xs text-slate-300 space-y-2 max-h-60 overflow-y-auto">
                        {wsLogs.map((log, i) => (
                          <div key={i} className={`border-b border-slate-900 pb-1 ${log.includes('Server') ? 'text-blue-400' : 'text-emerald-400'}`}>{log}</div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* 6. RFC 7519 JWT */}
                {selectedRFC === "RFC7519" && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">SUBJECT CLAIM (sub)</label>
                        <input
                          type="text"
                          value={jwtSub}
                          onChange={(e) => setJwtSub(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">ROLE CLAIM (role)</label>
                        <input
                          type="text"
                          value={jwtRole}
                          onChange={(e) => setJwtRole(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-mono text-slate-400 mb-1">SIGNING SECRET KEY</label>
                        <input
                          type="text"
                          value={jwtSecret}
                          onChange={(e) => setJwtSecret(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 font-mono text-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>

                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                      <h3 className="font-mono font-bold text-amber-400 text-sm">ENCODED JWT TOKEN OUTPUT</h3>
                      <div className="p-4 bg-black rounded-lg font-mono text-sm break-all select-all">
                        <span className="text-red-400">{jwtHeader}</span>
                        <span className="text-slate-300">.</span>
                        <span className="text-purple-400">{jwtPayload}</span>
                        <span className="text-slate-300">.</span>
                        <span className="text-emerald-400">{mockSignature}</span>
                      </div>
                      <div className="flex space-x-4 text-xs font-mono">
                        <span className="text-red-400">■ Header (Algorithm & Token Type)</span>
                        <span className="text-purple-400">■ Payload (Claims)</span>
                        <span className="text-emerald-400">■ Signature (HMAC-SHA256)</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </>
          );
        })()}
      </div>
    </div>
  );
};
