import React, {
  useState, useEffect, useRef, useMemo, useCallback,
} from 'react';
import {
  Globe as GlobeIcon, Rss, Upload, ZoomIn, ZoomOut, Layers,
  RefreshCw, Loader2, ExternalLink, MapPin, X, Wifi, AlertTriangle,
  RotateCcw, Crosshair, Mountain, Image as ImageIcon, Code,
  Download, CheckCircle2, PanelRightClose, PanelRightOpen, Target,
  Activity,
} from 'lucide-react';

import { DEFAULT_OPML } from './globe/defaultOpml';
import {
  Feed, FeedFetchState, FeedMode, QuakeEvent,
  parseOpml, fetchFeedDetailed, fetchEarthquakes, stripHtml,
} from './globe/opmlAndRss';

type GlobeMode = 'wireframe' | 'topo' | 'imagery' | 'hybrid' | 'relief';
type PanelTab = 'feeds' | 'opml' | 'lab' | 'quakes';

// ─── Tile math (WebMercator) ──────────────────────────────────────────────────
const lonToTileX = (lon: number, z: number) => ((lon + 180) / 360) * 2 ** z;
const latToTileY = (lat: number, z: number) => {
  const r = (lat * Math.PI) / 180;
  return ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * 2 ** z;
};
const tileYToLat = (y: number, z: number) => {
  const n = Math.PI - (2 * Math.PI * y) / 2 ** z;
  return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
};

const USGS_TILE_URL: Record<Exclude<GlobeMode, 'wireframe'>, string> = {
  topo: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}',
  imagery: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}',
  hybrid: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/{z}/{y}/{x}',
  relief: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSShadedReliefOnly/MapServer/tile/{z}/{y}/{x}',
};

// ─── Orthographic projection helpers (for wireframe globe) ────────────────────
interface OrthoView { rotLon: number; rotLat: number; radius: number; }
interface Projected { x: number; y: number; visible: boolean; }

function projectOrtho(lat: number, lon: number, view: OrthoView): Projected {
  const phi = (lat * Math.PI) / 180;
  const lambda = ((lon - view.rotLon) * Math.PI) / 180;
  const phi0 = (view.rotLat * Math.PI) / 180;
  const cosC = Math.sin(phi0) * Math.sin(phi)
             + Math.cos(phi0) * Math.cos(phi) * Math.cos(lambda);
  const x = view.radius * Math.cos(phi) * Math.sin(lambda);
  const y = view.radius * (Math.cos(phi0) * Math.sin(phi)
                         - Math.sin(phi0) * Math.cos(phi) * Math.cos(lambda));
  return { x, y: -y, visible: cosC >= 0 };
}

export const SpinningGlobe: React.FC = () => {
  // OPML / feed state
  const [opmlText, setOpmlText] = useState<string>(DEFAULT_OPML);
  const [opmlName, setOpmlName] = useState<string>('patent-mesh-feeds.opml');
  const [opmlError, setOpmlError] = useState<string | null>(null);

  const feeds = useMemo<Feed[]>(() => {
    try {
      const result = parseOpml(opmlText);
      setOpmlError(null);
      return result;
    } catch (e: any) {
      setOpmlError(e?.message || 'OPML parse failed');
      return [];
    }
  }, [opmlText]);

  // Feed-fetch state map: id -> {status, items, ...}
  const [fetchMap, setFetchMap] = useState<Record<string, FeedFetchState>>({});
  const fetchControllers = useRef<Record<string, AbortController>>({});
  const [feedMode, setFeedMode] = useState<FeedMode>('hybrid');
  const [fetchLogs, setFetchLogs] = useState<string[]>([]);

  const pushLog = useCallback((message: string) => {
    setFetchLogs((prev) => [`${new Date().toLocaleTimeString()} ${message}`, ...prev].slice(0, 80));
  }, []);

  const refreshFeed = useCallback(async (feed: Feed) => {
    // Abort any in-flight request for this feed id
    fetchControllers.current[feed.id]?.abort();
    const ctrl = new AbortController();
    fetchControllers.current[feed.id] = ctrl;

    setFetchMap((m) => ({ ...m, [feed.id]: { status: 'loading' } }));
    pushLog(`RF-01 ${feed.title}: fetching (${feedMode})`);
    try {
      const result = await fetchFeedDetailed(feed.xmlUrl, feed.title, ctrl.signal, feedMode);
      setFetchMap((m) => ({
        ...m,
        [feed.id]: {
          status: 'ok',
          items: result.items,
          source: result.source,
          warning: result.warning,
          ts: Date.now(),
        },
      }));
      pushLog(`RF-02 ${feed.title}: ${result.source.toUpperCase()} ${result.items.length} items`);
    } catch (e: any) {
      if (e?.name === 'AbortError') return;
      setFetchMap((m) => ({
        ...m,
        [feed.id]: { status: 'error', error: e?.message || 'Fetch failed' },
      }));
      pushLog(`RF-ERR ${feed.title}: ${e?.message || 'Fetch failed'}`);
    }
  }, [feedMode, pushLog]);

  const refreshAll = useCallback(() => {
    feeds.forEach((f) => refreshFeed(f));
  }, [feeds, refreshFeed]);

  // Auto-load first batch on mount / OPML change
  useEffect(() => {
    if (feeds.length === 0) return;
    const tid = window.setTimeout(() => {
      feeds.slice(0, 8).forEach((f) => refreshFeed(f));
    }, 300);
    return () => window.clearTimeout(tid);
  }, [feeds, refreshFeed]);

  // Selected feed for detail panel
  const [selectedFeedId, setSelectedFeedId] = useState<string | null>(null);
  const [selectedClusterIds, setSelectedClusterIds] = useState<string[] | null>(null);
  const selectedFeed = useMemo(
    () => feeds.find((f) => f.id === selectedFeedId) || null,
    [feeds, selectedFeedId]
  );
  const selectedClusterFeeds = useMemo(
    () => selectedClusterIds ? feeds.filter((f) => selectedClusterIds.includes(f.id)) : [],
    [feeds, selectedClusterIds]
  );

  const [feedDraft, setFeedDraft] = useState({
    title: '',
    xmlUrl: '',
    htmlUrl: '',
    category: 'Imported',
    loc: '',
    lat: '',
    lon: '',
  });

  // Globe display mode & UI panel controls
  const [mode, setMode] = useState<GlobeMode>('wireframe');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<PanelTab>('feeds');

  // Wireframe view state
  const [view, setView] = useState<OrthoView>({ rotLon: 0, rotLat: 20, radius: 200 });

  // Tile map view state (lat/lon center + zoom level)
  const [tileCenter, setTileCenter] = useState({ lat: 39.5, lon: -98.35, z: 4 });

  // Viewport size (resizable globe area)
  const [viewport, setViewport] = useState({ w: 640, h: 480 });
  const viewportRef = useRef<HTMLDivElement>(null);
  const [tileStats, setTileStats] = useState({ key: 'wireframe', total: 0, loaded: 0, error: 0 });

  useEffect(() => {
    if (!viewportRef.current) return;
    const ro = new ResizeObserver(() => {
      if (!viewportRef.current) return;
      const r = viewportRef.current.getBoundingClientRect();
      setViewport({ w: Math.max(200, Math.floor(r.width)), h: Math.max(200, Math.floor(r.height)) });
      // Also tighten globe radius to fit
      setView((v) => ({ ...v, radius: Math.min(Math.floor(Math.min(r.width, r.height) / 2 - 24), Math.max(80, v.radius)) }));
    });
    ro.observe(viewportRef.current);
    return () => ro.disconnect();
  }, []);

  // Drag state (rotation or pan)
  const dragRef = useRef<{
    sx: number; sy: number;
    initLon: number; initLat: number;
    initCx: number; initCy: number;  // tile center on pan
    initZoom: number;
  } | null>(null);

  const onCanvasPointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('[data-pin]')) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragRef.current = {
      sx: e.clientX, sy: e.clientY,
      initLon: view.rotLon, initLat: view.rotLat,
      initCx: tileCenter.lon, initCy: tileCenter.lat,
      initZoom: tileCenter.z,
    };
  };

  const onCanvasPointerMove = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d) return;
    const dx = e.clientX - d.sx;
    const dy = e.clientY - d.sy;

    if (mode === 'wireframe') {
      setView((v) => ({
        ...v,
        rotLon: d.initLon - dx * 0.4,
        rotLat: Math.max(-85, Math.min(85, d.initLat + dy * 0.4)),
      }));
    } else {
      const tilePxAtZoom = 256 * 2 ** d.initZoom;
      const dLon = -(dx / tilePxAtZoom) * 360;
      const cyTile = latToTileY(d.initCy, d.initZoom);
      const newCyTile = cyTile - dy / 256;
      const newLat = tileYToLat(newCyTile, d.initZoom);
      setTileCenter((c) => ({
        ...c,
        lon: ((d.initCx + dLon + 540) % 360) - 180,
        lat: Math.max(-85, Math.min(85, newLat)),
      }));
    }
  };

  const onCanvasPointerUp = (e: React.PointerEvent) => {
    try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch {}
    dragRef.current = null;
  };

  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (mode === 'wireframe') {
      setView((v) => {
        const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
        const maxR = Math.min(viewport.w, viewport.h) / 2 - 24;
        const minR = 60;
        return { ...v, radius: Math.max(minR, Math.min(maxR * 2.5, v.radius * factor)) };
      });
    } else {
      setTileCenter((c) => {
        const dz = e.deltaY < 0 ? 1 : -1;
        return { ...c, z: Math.max(2, Math.min(16, c.z + dz)) };
      });
    }
  };

  // ── Wireframe globe: compute graticule paths ────────────────────────────────
  const cx = viewport.w / 2;
  const cy = viewport.h / 2;

  const wireframePaths = useMemo(() => {
    if (mode !== 'wireframe') return { meridians: [], parallels: [] };
    const meridians: string[] = [];
    const parallels: string[] = [];
    const samples = 90;

    for (let lon = -180; lon < 180; lon += 30) {
      const pts: string[] = [];
      let started = false;
      for (let i = 0; i <= samples; i++) {
        const lat = -90 + (i * 180) / samples;
        const p = projectOrtho(lat, lon, view);
        if (p.visible) {
          pts.push(`${started ? 'L' : 'M'} ${cx + p.x} ${cy + p.y}`);
          started = true;
        } else {
          started = false;
        }
      }
      if (pts.length) meridians.push(pts.join(' '));
    }

    for (let lat = -60; lat <= 60; lat += 30) {
      const pts: string[] = [];
      let started = false;
      for (let i = 0; i <= samples; i++) {
        const lon = -180 + (i * 360) / samples;
        const p = projectOrtho(lat, lon, view);
        if (p.visible) {
          pts.push(`${started ? 'L' : 'M'} ${cx + p.x} ${cy + p.y}`);
          started = true;
        } else {
          started = false;
        }
      }
      if (pts.length) parallels.push(pts.join(' '));
    }

    return { meridians, parallels };
  }, [mode, view, cx, cy]);

  // ── Tile map: compute tiles to render and pin positions ─────────────────────
  const tileLayer = useMemo(() => {
    if (mode === 'wireframe') return null;
    const z = tileCenter.z;
    const centerX = lonToTileX(tileCenter.lon, z);
    const centerY = latToTileY(tileCenter.lat, z);
    const tilesAcross = Math.ceil(viewport.w / 256) + 2;
    const tilesDown = Math.ceil(viewport.h / 256) + 2;
    const startTx = Math.floor(centerX - tilesAcross / 2);
    const startTy = Math.floor(centerY - tilesDown / 2);

    const list: { url: string; left: number; top: number; key: string }[] = [];
    const N = 2 ** z;
    const tmpl = USGS_TILE_URL[mode];
    for (let ix = 0; ix < tilesAcross; ix++) {
      for (let iy = 0; iy < tilesDown; iy++) {
        const tx = startTx + ix;
        const ty = startTy + iy;
        if (ty < 0 || ty >= N) continue;
        const wrappedX = ((tx % N) + N) % N;
        const left = (tx - centerX) * 256 + viewport.w / 2;
        const top = (ty - centerY) * 256 + viewport.h / 2;
        const url = tmpl
          .replace('{z}', String(z))
          .replace('{x}', String(wrappedX))
          .replace('{y}', String(ty));
        list.push({ url, left, top, key: `${z}-${tx}-${ty}` });
      }
    }
    return { tiles: list, centerX, centerY, z };
  }, [mode, tileCenter, viewport]);

  const tileLayerKey = useMemo(
    () => mode === 'wireframe'
      ? 'wireframe'
      : `${mode}-${tileCenter.z}-${tileCenter.lat.toFixed(3)}-${tileCenter.lon.toFixed(3)}-${viewport.w}x${viewport.h}`,
    [mode, tileCenter, viewport]
  );

  useEffect(() => {
    setTileStats({
      key: tileLayerKey,
      total: tileLayer?.tiles.length || 0,
      loaded: 0,
      error: 0,
    });
  }, [tileLayerKey, tileLayer]);

  // Project feed onto current view → screen coords
  const projectFeed = (f: Feed) => {
    if (mode === 'wireframe') {
      const p = projectOrtho(f.lat, f.lon, view);
      return { x: cx + p.x, y: cy + p.y, visible: p.visible };
    }
    if (!tileLayer) return { x: 0, y: 0, visible: false };
    const z = tileCenter.z;
    const tx = lonToTileX(f.lon, z);
    const ty = latToTileY(f.lat, z);
    const x = (tx - tileLayer.centerX) * 256 + viewport.w / 2;
    const y = (ty - tileLayer.centerY) * 256 + viewport.h / 2;
    const visible = x >= -8 && x <= viewport.w + 8 && y >= -8 && y <= viewport.h + 8;
    return { x, y, visible };
  };

  const markerClusters = useMemo(() => {
    const projected = feeds
      .map((feed) => ({ feed, ...projectFeed(feed) }))
      .filter((p) => p.visible);

    const clusters: Array<{ x: number; y: number; feeds: Feed[] }> = [];
    const threshold = mode === 'wireframe' ? 34 : 42;

    projected.forEach((pin) => {
      const cluster = clusters.find((c) => Math.hypot(c.x - pin.x, c.y - pin.y) < threshold);
      if (cluster) {
        const count = cluster.feeds.length;
        cluster.x = (cluster.x * count + pin.x) / (count + 1);
        cluster.y = (cluster.y * count + pin.y) / (count + 1);
        cluster.feeds.push(pin.feed);
      } else {
        clusters.push({ x: pin.x, y: pin.y, feeds: [pin.feed] });
      }
    });

    return clusters;
  }, [feeds, mode, view, tileLayer, tileCenter, viewport]);

  // ── Earthquake layer ──────────────────────────────────────────────────────
  const [quakes, setQuakes] = useState<QuakeEvent[]>([]);
  const [quakeSource, setQuakeSource] = useState<'live' | 'demo' | 'off'>('off');
  const [quakeLoading, setQuakeLoading] = useState(false);
  const [selectedQuake, setSelectedQuake] = useState<QuakeEvent | null>(null);

  const loadQuakes = useCallback(async () => {
    setQuakeLoading(true);
    setSelectedQuake(null);
    const result = await fetchEarthquakes();
    setQuakes(result.events);
    setQuakeSource(result.source);
    setQuakeLoading(false);
    pushLog(`QUAKE layer: ${result.events.length} events (${result.source})`);
    setSidebarOpen(true);
    setActiveTab('quakes');
  }, [pushLog]);

  const projectQuake = useCallback((lat: number, lon: number) => {
    if (mode === 'wireframe') {
      const p = projectOrtho(lat, lon, view);
      return { visible: p.visible, px: cx + p.x, py: cy + p.y };
    }
    if (!tileLayer) return { visible: false, px: 0, py: 0 };
    const z = tileCenter.z;
    const tx = lonToTileX(lon, z);
    const ty = latToTileY(lat, z);
    const px = (tx - tileLayer.centerX) * 256 + viewport.w / 2;
    const py = (ty - tileLayer.centerY) * 256 + viewport.h / 2;
    const visible = px >= -24 && px <= viewport.w + 24 && py >= -24 && py <= viewport.h + 24;
    return { visible, px, py };
  }, [mode, view, tileLayer, tileCenter, viewport, cx, cy]);

  const quakeMagColour = (mag: number) => {
    if (mag >= 7.0) return 'bg-red-600 border-red-300 shadow-red-500/60';
    if (mag >= 6.0) return 'bg-orange-500 border-orange-200 shadow-orange-400/50';
    if (mag >= 5.0) return 'bg-yellow-400 border-yellow-100 shadow-yellow-300/50';
    return 'bg-lime-400 border-lime-100 shadow-lime-300/40';
  };
  const quakeSizePx = (mag: number) => Math.max(10, Math.min(30, Math.round((mag - 3) * 5 + 8)));

  const onOpmlUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setOpmlName(file.name);
    const reader = new FileReader();
    reader.onload = () => setOpmlText(String(reader.result || ''));
    reader.readAsText(file);
  };

  const resetView = () => {
    if (mode === 'wireframe') setView({ rotLon: 0, rotLat: 20, radius: Math.min(viewport.w, viewport.h) / 2 - 32 });
    else setTileCenter({ lat: 39.5, lon: -98.35, z: 4 });
  };

  const centerOnFeed = (f: Feed) => {
    if (mode === 'wireframe') {
      setView((v) => ({ ...v, rotLon: f.lon, rotLat: f.lat }));
    } else {
      setTileCenter({ lat: f.lat, lon: f.lon, z: Math.max(tileCenter.z, 8) });
    }
  };

  const loadTopoForFeed = (f: Feed) => {
    setMode('topo');
    setTileCenter({ lat: f.lat, lon: f.lon, z: 12 });
  };

  const fitAllFeeds = () => {
    if (feeds.length === 0) return;
    if (mode === 'wireframe') {
      setView({
        rotLon: 0,
        rotLat: 15,
        radius: Math.max(90, Math.min(viewport.w, viewport.h) / 2 - 28),
      });
      return;
    }

    const minLat = Math.min(...feeds.map((f) => f.lat));
    const maxLat = Math.max(...feeds.map((f) => f.lat));
    const minLon = Math.min(...feeds.map((f) => f.lon));
    const maxLon = Math.max(...feeds.map((f) => f.lon));
    const latSpan = Math.max(1, maxLat - minLat);
    const lonSpan = Math.max(1, maxLon - minLon);
    const span = Math.max(latSpan, lonSpan);
    const z = span > 120 ? 2 : span > 70 ? 3 : span > 35 ? 4 : span > 15 ? 5 : span > 7 ? 6 : 8;
    setTileCenter({
      lat: (minLat + maxLat) / 2,
      lon: (minLon + maxLon) / 2,
      z,
    });
  };

  const downloadOpml = () => {
    const blob = new Blob([opmlText], { type: 'text/xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = opmlName || 'patent-office-feeds.opml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportBlob = (filename: string, content: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportFeeds = (format: 'json' | 'csv') => {
    const rows = feeds.map((feed) => ({
      title: feed.title,
      category: feed.category,
      loc: feed.loc,
      lat: feed.lat,
      lon: feed.lon,
      xmlUrl: feed.xmlUrl,
      htmlUrl: feed.htmlUrl,
      status: fetchMap[feed.id]?.status || 'idle',
      source: fetchMap[feed.id]?.source || 'none',
      items: fetchMap[feed.id]?.items?.length || 0,
    }));

    if (format === 'json') {
      exportBlob('globe-feed-results.json', JSON.stringify(rows, null, 2), 'application/json');
      return;
    }

    const header = Object.keys(rows[0] || { title: '', category: '', loc: '', lat: '', lon: '', xmlUrl: '', htmlUrl: '', status: '', source: '', items: '' });
    const csv = [
      header.join(','),
      ...rows.map((row) => header.map((key) => `"${String((row as any)[key] ?? '').replace(/"/g, '""')}"`).join(',')),
    ].join('\n');
    exportBlob('globe-feed-results.csv', csv, 'text/csv;charset=utf-8');
  };

  const escapeXml = (value: string) => value
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  const addFeedToOpml = () => {
    const lat = parseFloat(feedDraft.lat);
    const lon = parseFloat(feedDraft.lon);
    if (!feedDraft.title || !feedDraft.xmlUrl || !Number.isFinite(lat) || !Number.isFinite(lon)) {
      alert('Enter title, RSS/Atom URL, latitude, and longitude.');
      return;
    }

    const outline = `    <outline text="${escapeXml(feedDraft.category || 'Imported')}" title="${escapeXml(feedDraft.category || 'Imported')}">\n      <outline type="rss" text="${escapeXml(feedDraft.title)}" title="${escapeXml(feedDraft.title)}" xmlUrl="${escapeXml(feedDraft.xmlUrl)}" htmlUrl="${escapeXml(feedDraft.htmlUrl)}" lat="${lat}" lon="${lon}" loc="${escapeXml(feedDraft.loc || `${lat.toFixed(3)}, ${lon.toFixed(3)}`)}"/>\n    </outline>`;

    setOpmlText((text) => text.includes('</body>')
      ? text.replace('</body>', `${outline}\n  </body>`)
      : `${text}\n${outline}`);
    setFeedDraft({ title: '', xmlUrl: '', htmlUrl: '', category: 'Imported', loc: '', lat: '', lon: '' });
    setActiveTab('feeds');
    pushLog(`RF-ADD Imported feed ${feedDraft.title}`);
  };

  const validateOpml = () => {
    try {
      const parsed = parseOpml(opmlText);
      alert(`OPML valid. ${parsed.length} geocoded RSS/Atom feeds found.`);
    } catch (e: any) {
      alert(`OPML validation failed: ${e?.message || 'Unknown XML error'}`);
    }
  };

  const fetchedCount = Object.values(fetchMap).filter((s) => s.status === 'ok').length;
  const errorCount = Object.values(fetchMap).filter((s) => s.status === 'error').length;
  const loadingCount = Object.values(fetchMap).filter((s) => s.status === 'loading').length;
  const liveCount = Object.values(fetchMap).filter((s) => s.source === 'live').length;
  const fallbackCount = Object.values(fetchMap).filter((s) => s.source === 'fallback').length;
  const offlineCount = Object.values(fetchMap).filter((s) => s.source === 'offline').length;

  return (
    <div className="w-full h-full flex flex-col bg-slate-950 text-slate-100 min-h-[480px]">
      
      {/* Top Toolbar */}
      <div className="shrink-0 flex flex-wrap items-center gap-2 px-3 py-2 bg-slate-900 border-b border-slate-850">
        <div className="flex items-center gap-1.5 mr-2">
          <GlobeIcon className="w-4.5 h-4.5 text-amber-500" />
          <span className="font-mono font-bold text-xs tracking-wider text-amber-400">GLOBE RESEARCH LAB</span>
        </div>

        {/* Mode switch */}
        <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-lg overflow-hidden">
          <button
            onClick={() => setMode('wireframe')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-mono font-bold transition ${mode === 'wireframe' ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:bg-slate-800'}`}
            title="Wireframe orthographic 3D globe"
          >
            <Layers className="w-3.5 h-3.5" /> 3D Wireframe
          </button>
          <button
            onClick={() => setMode('topo')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-mono font-bold transition border-l border-slate-700 ${mode === 'topo' ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:bg-slate-800'}`}
            title="USGS National Map Topo tiles"
          >
            <Mountain className="w-3.5 h-3.5" /> USGS Topo
          </button>
          <button
            onClick={() => setMode('imagery')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-mono font-bold transition border-l border-slate-700 ${mode === 'imagery' ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:bg-slate-800'}`}
            title="USGS Imagery (orthorectified DOQQ-style) tiles"
          >
            <ImageIcon className="w-3.5 h-3.5" /> USGS Imagery
          </button>
          <button
            onClick={() => setMode('hybrid')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-mono font-bold transition border-l border-slate-700 ${mode === 'hybrid' ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:bg-slate-800'}`}
            title="USGS imagery with topographic overlays"
          >
            <Layers className="w-3.5 h-3.5" /> Hybrid
          </button>
          <button
            onClick={() => setMode('relief')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-mono font-bold transition border-l border-slate-700 ${mode === 'relief' ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:bg-slate-800'}`}
            title="USGS shaded relief tiles"
          >
            <Mountain className="w-3.5 h-3.5" /> Relief
          </button>
        </div>

        <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-lg overflow-hidden">
          {(['hybrid', 'live', 'offline'] as FeedMode[]).map((m) => (
            <button
              key={m}
              onClick={() => setFeedMode(m)}
              className={`px-2.5 py-1 text-[10px] font-mono font-bold capitalize border-l first:border-l-0 border-slate-700 ${feedMode === m ? 'bg-sky-500 text-slate-950' : 'text-slate-300 hover:bg-slate-800'}`}
              title={m === 'hybrid' ? 'Try live RSS first, fallback if proxy blocks it' : m === 'live' ? 'Live RSS only, show real errors' : 'Cleanroom offline demo data only'}
            >
              {m}
            </button>
          ))}
        </div>

        {/* Zoom controls */}
        <div className="flex items-center bg-slate-950 border border-slate-700/80 rounded-lg overflow-hidden">
          <button
            onClick={() => mode === 'wireframe'
              ? setView((v) => ({ ...v, radius: Math.min(v.radius * 1.15, Math.min(viewport.w, viewport.h)) }))
              : setTileCenter((c) => ({ ...c, z: Math.min(16, c.z + 1) }))}
            className="px-2.5 py-1 text-slate-300 hover:bg-slate-800"
            title="Zoom in"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => mode === 'wireframe'
              ? setView((v) => ({ ...v, radius: Math.max(60, v.radius / 1.15) }))
              : setTileCenter((c) => ({ ...c, z: Math.max(2, c.z - 1) }))}
            className="px-2.5 py-1 text-slate-300 hover:bg-slate-800 border-l border-slate-700"
            title="Zoom out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={resetView}
            className="px-2.5 py-1 text-slate-300 hover:bg-slate-800 border-l border-slate-700"
            title="Reset view"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={fitAllFeeds}
            className="px-2.5 py-1 text-slate-300 hover:bg-slate-800 border-l border-slate-700"
            title="Fit all RSS feed pins"
          >
            <Target className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          onClick={refreshAll}
          className="flex items-center gap-1.5 px-3 py-1 bg-emerald-700 hover:bg-emerald-600 text-white font-mono text-[11px] font-bold rounded-lg border border-emerald-600"
          title="Refresh all feeds live"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Sync Feeds
        </button>

        <button
          onClick={loadQuakes}
          disabled={quakeLoading}
          className={`flex items-center gap-1.5 px-3 py-1 font-mono text-[11px] font-bold rounded-lg border transition ${
            quakeSource !== 'off'
              ? 'bg-red-600 border-red-500 text-white'
              : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
          }`}
          title="Load USGS live earthquake event layer — each quake plotted at its real coordinates"
        >
          {quakeLoading
            ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
            : <Activity className="w-3.5 h-3.5" />}
          {quakeSource === 'off'
            ? 'Earthquakes'
            : quakeSource === 'live'
            ? `⚡ ${quakes.length} Live Quakes`
            : `${quakes.length} Demo Quakes`}
        </button>

        <label className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-[11px] font-bold rounded-lg border border-slate-750 cursor-pointer">
          <Upload className="w-3.5 h-3.5" /> Load OPML
          <input type="file" accept=".opml,.xml,application/xml,text/xml" onChange={onOpmlUpload} className="hidden" />
        </label>

        <button
          onClick={downloadOpml}
          className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-[11px] font-bold rounded-lg border border-slate-750"
          title="Download current OPML file"
        >
          <Download className="w-3.5 h-3.5" /> OPML
        </button>

        <button
          onClick={validateOpml}
          className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-[11px] font-bold rounded-lg border border-slate-750"
          title="Validate OPML feed coordinates"
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Validate
        </button>

        {/* Toggle feeds sidebar */}
        <button
          onClick={() => setSidebarOpen(o => !o)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-mono text-[11px] font-bold transition border ${
            sidebarOpen
              ? 'bg-amber-500 text-slate-950 border-amber-400'
              : 'bg-slate-800 text-slate-300 border-slate-750 hover:bg-slate-750'
          }`}
          title="Toggle Details Panel"
        >
          {sidebarOpen ? <PanelRightClose className="w-3.5 h-3.5" /> : <PanelRightOpen className="w-3.5 h-3.5" />}
          <span>Panel: {sidebarOpen ? 'OPEN' : 'CLOSED'}</span>
        </button>

        <div className="ml-auto flex items-center gap-3 text-[10px] font-mono text-slate-400">
          <span className="flex items-center gap-1"><Wifi className="w-3 h-3 text-emerald-500" /> {opmlName}</span>
          <span className="text-emerald-400">{fetchedCount} active</span>
          <span className="text-sky-400">{liveCount} live</span>
          <span className="text-amber-400">{fallbackCount} fallback</span>
          <span className="text-purple-400">{offlineCount} offline</span>
          {loadingCount > 0 && <span className="text-amber-400 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" />{loadingCount}</span>}
          {errorCount > 0 && <span className="text-red-400 flex items-center gap-1"><AlertTriangle className="w-3 h-3" />{errorCount}</span>}
        </div>
      </div>

      {opmlError && (
        <div className="shrink-0 px-3 py-1.5 bg-red-950 border-b border-red-800 text-red-200 font-mono text-xs">
          OPML error: {opmlError}
        </div>
      )}

      {/* Main split */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">
        
        {/* Globe Viewport */}
        <div
          ref={viewportRef}
          className="relative flex-1 bg-slate-950 overflow-hidden cursor-grab active:cursor-grabbing select-none"
          onPointerDown={onCanvasPointerDown}
          onPointerMove={onCanvasPointerMove}
          onPointerUp={onCanvasPointerUp}
          onPointerCancel={onCanvasPointerUp}
          onWheel={onWheel}
          style={{ touchAction: 'none' }}
        >
          {/* Topography Grid Layer (USGS Server Fallback/Underlay) */}
          <div
            className="absolute inset-0 pointer-events-none opacity-20"
            style={{
              backgroundImage: `radial-gradient(circle, rgba(245,158,11,0.15) 1px, transparent 1px), linear-gradient(rgba(51,65,85,0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(51,65,85,0.2) 1px, transparent 1px)`,
              backgroundSize: '24px 24px, 48px 48px, 48px 48px',
            }}
          />

          {/* Wireframe layer */}
          {mode === 'wireframe' && (
            <svg
              width={viewport.w}
              height={viewport.h}
              className="absolute inset-0 pointer-events-none"
            >
              <defs>
                <radialGradient id="oceanGrad" cx="40%" cy="40%" r="65%">
                  <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.65" />
                  <stop offset="80%" stopColor="#0c1e3f" stopOpacity="0.95" />
                  <stop offset="100%" stopColor="#020617" stopOpacity="1" />
                </radialGradient>
              </defs>
              <circle cx={cx} cy={cy} r={view.radius} fill="url(#oceanGrad)" stroke="rgba(96,165,250,0.4)" strokeWidth="1.5" />
              {wireframePaths.parallels.map((d, i) => (
                <path key={`p${i}`} d={d} stroke="rgba(56,189,248,0.35)" strokeWidth="0.6" fill="none" />
              ))}
              {wireframePaths.meridians.map((d, i) => (
                <path key={`m${i}`} d={d} stroke="rgba(56,189,248,0.35)" strokeWidth="0.6" fill="none" />
              ))}
              <path
                d={(() => {
                  const pts: string[] = [];
                  let started = false;
                  for (let i = 0; i <= 180; i++) {
                    const lon = -180 + (i * 360) / 180;
                    const p = projectOrtho(0, lon, view);
                    if (p.visible) {
                      pts.push(`${started ? 'L' : 'M'} ${cx + p.x} ${cy + p.y}`);
                      started = true;
                    } else started = false;
                  }
                  return pts.join(' ');
                })()}
                stroke="rgba(251,191,36,0.6)" strokeWidth="1.2" fill="none"
              />
            </svg>
          )}

          {/* Tile layer */}
          {mode !== 'wireframe' && tileLayer && (
            <div className="absolute inset-0 overflow-hidden">
              {/* Fallback baseline mesh grid underneath tiles */}
              <div className="absolute inset-0 border border-amber-500/20 bg-slate-900/40 pointer-events-none" />
              
              {tileLayer.tiles.map((t) => (
                <img
                  key={t.key}
                  src={t.url}
                  alt=""
                  draggable={false}
                  style={{
                    position: 'absolute',
                    left: t.left, top: t.top,
                    width: 256, height: 256,
                    imageRendering: 'auto',
                    userSelect: 'none',
                    pointerEvents: 'none',
                  }}
                  onLoad={() => setTileStats((s) => s.key === tileLayerKey ? { ...s, loaded: Math.min(s.total, s.loaded + 1) } : s)}
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.visibility = 'hidden';
                    setTileStats((s) => s.key === tileLayerKey ? { ...s, error: Math.min(s.total, s.error + 1) } : s);
                  }}
                />
              ))}
              
              {/* Crosshair */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <Crosshair className="w-6 h-6 text-amber-400 opacity-80 drop-shadow" />
              </div>
              
              {/* Attribution */}
              <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/75 text-[9px] font-mono text-slate-300 rounded border border-slate-800">
                Basemap: USGS National Map ({mode === 'topo' ? 'Topo' : mode === 'imagery' ? 'Imagery Only' : mode === 'hybrid' ? 'Imagery + Topo' : 'Shaded Relief'})
              </div>
            </div>
          )}

          {/* Pins (over both layers) */}
          <div className="absolute inset-0">
            {markerClusters.map((cluster, index) => {
              const primary = cluster.feeds[0];
              const state = fetchMap[primary.id];
              const colour =
                cluster.feeds.some((f) => fetchMap[f.id]?.status === 'ok') ? 'bg-emerald-400 border-emerald-200' :
                state?.status === 'loading' ? 'bg-amber-400 border-amber-200 animate-pulse' :
                state?.status === 'error' ? 'bg-red-500 border-red-200' :
                'bg-sky-400 border-sky-200';

              return (
                <button
                  key={`${primary.id}-${index}`}
                  data-pin
                  onClick={(e) => {
                    e.stopPropagation();
                    setSidebarOpen(true);
                    if (cluster.feeds.length > 1) {
                      setSelectedClusterIds(cluster.feeds.map((f) => f.id));
                      setSelectedFeedId(null);
                      setActiveTab('feeds');
                      cluster.feeds.slice(0, 4).forEach((f) => { if (!fetchMap[f.id]) refreshFeed(f); });
                    } else {
                      setSelectedClusterIds(null);
                      setSelectedFeedId(primary.id);
                      setActiveTab('feeds');
                      if (!state) refreshFeed(primary);
                    }
                  }}
                  style={{ left: cluster.x, top: cluster.y }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group"
                  title={cluster.feeds.length > 1 ? `${cluster.feeds.length} feeds clustered` : `${primary.title} - ${primary.loc}`}
                >
                  <span className={`flex items-center justify-center min-w-3.5 h-3.5 px-1 rounded-full border-2 shadow-lg transition-transform group-hover:scale-125 ${colour} text-[9px] font-mono font-black text-slate-950`}>
                    {cluster.feeds.length > 1 ? cluster.feeds.length : ''}
                  </span>
                  <span className="hidden group-hover:block absolute left-1/2 top-5 -translate-x-1/2 z-15 whitespace-nowrap px-2 py-1 rounded bg-slate-900/95 border border-slate-700 text-[10px] font-mono text-slate-100 shadow-lg">
                    {cluster.feeds.length > 1 ? `${cluster.feeds.length} clustered feeds` : primary.title}
                    <span className="block text-slate-400">{cluster.feeds.length > 1 ? 'Click to inspect cluster' : primary.loc}</span>
                  </span>
                </button>
              );
            })}
          </div>

          {/* Earthquake pins */}
          {quakeSource !== 'off' && (
            <div className="absolute inset-0 pointer-events-none">
              {quakes.map((q) => {
                const p = projectQuake(q.lat, q.lon);
                if (!p.visible) return null;
                const sz = quakeSizePx(q.magnitude);
                const col = quakeMagColour(q.magnitude);
                return (
                  <button
                    key={q.id}
                    data-pin
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedQuake(q);
                      setSidebarOpen(true);
                      setActiveTab('quakes');
                    }}
                    style={{ left: p.px, top: p.py, width: sz, height: sz, pointerEvents: 'auto' }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 shadow-lg opacity-85 hover:opacity-100 hover:scale-125 transition-all ${col}`}
                    title={`${q.title} | Depth ${q.depth}km`}
                  />
                );
              })}
            </div>
          )}

          {/* HUD coordinate inspector overlay */}
          <div className="absolute top-2 left-2 px-2.5 py-1.5 bg-slate-900/90 border border-slate-700/80 rounded font-mono text-[10px] text-slate-200 shadow-lg">
            {mode === 'wireframe'
              ? `PROJ: ORTHOGRAPHIC 3D | RADIUS: ${view.radius.toFixed(0)}px | LAT: ${view.rotLat.toFixed(2)}° | LON: ${(-view.rotLon).toFixed(2)}°`
              : `PROJ: WEBMERCATOR | ZOOM: ${tileCenter.z} | LAT: ${tileCenter.lat.toFixed(4)}° | LON: ${tileCenter.lon.toFixed(4)}°`}
            {mode !== 'wireframe' && (
              <span className="block text-amber-300">
                TILES: {tileStats.loaded}/{tileStats.total} loaded, {tileStats.error} hidden fallback
              </span>
            )}
          </div>
        </div>

        {/* Collapsible details sidebar */}
        <aside
          className={`
            absolute right-0 top-0 bottom-0 z-30 bg-slate-900 border-l border-slate-800 flex flex-col min-h-0 shadow-2xl transition-transform duration-200
            ${sidebarOpen ? 'w-80 translate-x-0' : 'w-80 translate-x-full pointer-events-none'}
          `}
        >
          {/* Sidebar Tab Header */}
          <div className="shrink-0 flex border-b border-slate-800 bg-slate-950">
            <button
              onClick={() => setActiveTab('feeds')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 font-mono font-bold text-xs transition border-b-2 ${
                activeTab === 'feeds'
                  ? 'border-amber-500 text-amber-400 bg-slate-900/60'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Rss className="w-3.5 h-3.5" />
              <span>Feed Mesh</span>
            </button>
            <button
              onClick={() => setActiveTab('opml')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 font-mono font-bold text-xs transition border-b-2 ${
                activeTab === 'opml'
                  ? 'border-amber-500 text-amber-400 bg-slate-900/60'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>OPML 2.0</span>
            </button>
            <button
              onClick={() => setActiveTab('lab')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 font-mono font-bold text-xs transition border-b-2 ${
                activeTab === 'lab'
                  ? 'border-amber-500 text-amber-400 bg-slate-900/60'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Lab</span>
            </button>
            <button
              onClick={() => setActiveTab('quakes')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 font-mono font-bold text-xs transition border-b-2 ${
                activeTab === 'quakes'
                  ? 'border-red-500 text-red-400 bg-slate-900/60'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Quakes</span>
            </button>
          </div>

          {activeTab === 'feeds' ? (
            selectedClusterFeeds.length > 0 ? (
              <div className="flex-1 flex flex-col min-h-0 bg-slate-950">
                <div className="px-3 py-2 border-b border-slate-800 flex items-center gap-2">
                  <button onClick={() => setSelectedClusterIds(null)} className="p-1 rounded hover:bg-slate-800 text-slate-400">
                    <X className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-mono font-bold text-xs text-amber-400">Cluster: {selectedClusterFeeds.length} feeds</span>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
                  {selectedClusterFeeds.map((f) => {
                    const s = fetchMap[f.id];
                    return (
                      <button
                        key={f.id}
                        onClick={() => { setSelectedClusterIds(null); setSelectedFeedId(f.id); if (!s) refreshFeed(f); }}
                        className="w-full text-left p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/60 transition"
                      >
                        <div className="font-mono font-bold text-xs text-slate-100 truncate">{f.title}</div>
                        <div className="text-[10px] font-mono text-slate-400 truncate mt-0.5">{f.category} - {f.loc}</div>
                        <div className="text-[9px] font-mono text-slate-500 mt-1">{f.lat.toFixed(3)}, {f.lon.toFixed(3)}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : !selectedFeed ? (
              <>
                <div className="px-3 py-2 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
                  <span className="font-mono text-[10px] text-slate-400 uppercase tracking-wider">Active Relay Nodes</span>
                  <span className="font-mono text-[10px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                    {feeds.length} SUBS
                  </span>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
                  {feeds.map((f) => {
                    const s = fetchMap[f.id];
                    const item = s?.items?.[0];
                    const colour =
                      s?.status === 'ok' ? 'border-emerald-500/40' :
                      s?.status === 'loading' ? 'border-amber-500/40' :
                      s?.status === 'error' ? 'border-red-500/40' :
                      'border-slate-800';
                    return (
                      <button
                        key={f.id}
                        onClick={() => { setSelectedFeedId(f.id); if (!s) refreshFeed(f); }}
                        className={`w-full text-left p-2.5 rounded-xl bg-slate-950 border ${colour} hover:border-amber-500/60 transition shadow-inner`}
                      >
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3 h-3 text-amber-500 shrink-0" />
                          <span className="font-mono font-bold text-xs text-slate-100 truncate">{f.title}</span>
                          {s?.status === 'loading' && <Loader2 className="w-3 h-3 text-amber-400 animate-spin shrink-0 ml-auto" />}
                          {s?.status === 'ok' && <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 ml-auto" />}
                        </div>
                        <div className="text-[10px] font-mono text-slate-400 mt-0.5 truncate">{f.category} · {f.loc}</div>
                        {s?.source && (
                          <div className="mt-1 flex gap-1 text-[9px] font-mono">
                            <span className={`px-1.5 py-0.5 rounded border ${
                              s.source === 'live'
                                ? 'text-sky-300 border-sky-500/30 bg-sky-500/10'
                                : s.source === 'fallback'
                                  ? 'text-amber-300 border-amber-500/30 bg-amber-500/10'
                                  : 'text-purple-300 border-purple-500/30 bg-purple-500/10'
                            }`}>
                              {s.source.toUpperCase()}
                            </span>
                            {s.warning && <span className="text-slate-500 truncate">{s.warning}</span>}
                          </div>
                        )}
                        {item && (
                          <div className="text-[10px] text-slate-300 mt-1.5 line-clamp-2 leading-snug font-mono border-t border-slate-900 pt-1">
                            {item.title}
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </>
            ) : (
              <FeedDetail
                feed={selectedFeed}
                state={fetchMap[selectedFeed.id]}
                onClose={() => setSelectedFeedId(null)}
                onRefresh={() => refreshFeed(selectedFeed)}
                onCenter={() => centerOnFeed(selectedFeed)}
                onLoadTopo={() => loadTopoForFeed(selectedFeed)}
              />
            )
          ) : activeTab === 'opml' ? (
            // OPML XML Code Viewer
            <div className="flex-1 flex flex-col min-h-0 p-3 bg-slate-950">
              <div className="pb-2 border-b border-slate-800 flex flex-wrap gap-2 justify-between items-center">
                <span className="font-mono text-[10px] text-slate-400 uppercase tracking-wider">XML OPML 2.0 Feed Spec</span>
                <div className="flex flex-wrap gap-1">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(opmlText);
                      alert('OPML source code copied to clipboard.');
                    }}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded font-mono text-[9px] font-bold"
                  >Copy</button>
                  <button onClick={() => exportFeeds('json')} className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded font-mono text-[9px] font-bold">JSON</button>
                  <button onClick={() => exportFeeds('csv')} className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded font-mono text-[9px] font-bold">CSV</button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 py-3 border-b border-slate-900">
                <input value={feedDraft.title} onChange={(e) => setFeedDraft((d) => ({ ...d, title: e.target.value }))} placeholder="Feed title" className="bg-black border border-slate-800 rounded px-2 py-1 text-[10px] font-mono text-slate-200" />
                <input value={feedDraft.category} onChange={(e) => setFeedDraft((d) => ({ ...d, category: e.target.value }))} placeholder="Category" className="bg-black border border-slate-800 rounded px-2 py-1 text-[10px] font-mono text-slate-200" />
                <input value={feedDraft.xmlUrl} onChange={(e) => setFeedDraft((d) => ({ ...d, xmlUrl: e.target.value }))} placeholder="RSS/Atom URL" className="col-span-2 bg-black border border-slate-800 rounded px-2 py-1 text-[10px] font-mono text-slate-200" />
                <input value={feedDraft.htmlUrl} onChange={(e) => setFeedDraft((d) => ({ ...d, htmlUrl: e.target.value }))} placeholder="Website URL" className="col-span-2 bg-black border border-slate-800 rounded px-2 py-1 text-[10px] font-mono text-slate-200" />
                <input value={feedDraft.lat} onChange={(e) => setFeedDraft((d) => ({ ...d, lat: e.target.value }))} placeholder="Latitude" className="bg-black border border-slate-800 rounded px-2 py-1 text-[10px] font-mono text-slate-200" />
                <input value={feedDraft.lon} onChange={(e) => setFeedDraft((d) => ({ ...d, lon: e.target.value }))} placeholder="Longitude" className="bg-black border border-slate-800 rounded px-2 py-1 text-[10px] font-mono text-slate-200" />
                <input value={feedDraft.loc} onChange={(e) => setFeedDraft((d) => ({ ...d, loc: e.target.value }))} placeholder="Location label" className="col-span-2 bg-black border border-slate-800 rounded px-2 py-1 text-[10px] font-mono text-slate-200" />
                <button onClick={addFeedToOpml} className="col-span-2 px-2 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 border border-amber-500 rounded font-mono text-[10px] font-bold">Add Feed To OPML</button>
              </div>
              <textarea
                value={opmlText}
                onChange={(e) => setOpmlText(e.target.value)}
                className="flex-1 w-full bg-black text-emerald-400 font-mono text-[10px] p-2 rounded-lg border border-slate-800 mt-3 resize-none focus:outline-none overflow-y-auto"
              />
              <div className="pt-2 text-[9px] font-mono text-slate-500 leading-relaxed">
                Editable OPML specification outlining structural feed paths, geolocational coordinates, and standard parameters.
              </div>
            </div>
          ) : (
            <LabChecklist
              mode={mode}
              feedMode={feedMode}
              feedsCount={feeds.length}
              fetchedCount={fetchedCount}
              liveCount={liveCount}
              fallbackCount={fallbackCount}
              offlineCount={offlineCount}
              loadingCount={loadingCount}
              errorCount={errorCount}
              tileStats={tileStats}
              fetchLogs={fetchLogs}
              opmlError={opmlError}
              selectedFeed={selectedFeed}
              onExportJson={() => exportFeeds('json')}
              onExportCsv={() => exportFeeds('csv')}
            />
          )}
          {activeTab === 'quakes' && (
            /* Quakes tab */
            <div className="flex-1 flex flex-col min-h-0 bg-slate-950">
              <div className="px-3 py-2 border-b border-slate-800 flex items-center justify-between">
                <span className="font-mono font-bold text-xs text-red-400 flex items-center gap-1.5">
                  <Activity className="w-4 h-4" />
                  USGS Seismic Events
                </span>
                <div className="flex items-center gap-2">
                  {quakeSource !== 'off' && (
                    <span className={`text-[9px] font-mono px-2 py-0.5 rounded border ${quakeSource === 'live' ? 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10' : 'text-amber-300 border-amber-500/30 bg-amber-500/10'}`}>
                      {quakeSource === 'live' ? 'LIVE USGS' : 'DEMO DATA'}
                    </span>
                  )}
                  <button onClick={loadQuakes} className="p-1 rounded hover:bg-slate-800 text-emerald-400" title="Reload quakes">
                    {quakeLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Colour legend */}
              <div className="px-3 py-2 border-b border-slate-800 bg-slate-900 flex flex-wrap gap-2 text-[10px] font-mono">
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-lime-400 inline-block" /> M &lt; 5</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-yellow-400 inline-block" /> M 5–5.9</span>
                <span className="flex items-center gap-1"><span className="w-4 h-4 rounded-full bg-orange-500 inline-block" /> M 6–6.9</span>
                <span className="flex items-center gap-1"><span className="w-5 h-5 rounded-full bg-red-600 inline-block" /> M ≥ 7</span>
              </div>

              {quakeSource === 'off' ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-3">
                  <Activity className="w-10 h-10 text-slate-600" />
                  <p className="font-mono text-xs text-slate-400">Click the <span className="text-red-400 font-bold">Earthquakes</span> toolbar button to load the USGS significant events layer.</p>
                  <p className="font-mono text-[10px] text-slate-500">Each event appears as a magnitude-scaled coloured circle at its real geocoded coordinates. Pins are independent of the RSS feed cluster layer.</p>
                  <button onClick={loadQuakes} className="px-4 py-2 bg-red-700 hover:bg-red-600 text-white font-mono font-bold text-xs rounded-xl border border-red-600 flex items-center gap-2">
                    <Activity className="w-4 h-4" /> Load Earthquake Layer
                  </button>
                </div>
              ) : (
                <div className="flex-1 overflow-y-auto">
                  {/* Selected quake detail */}
                  {selectedQuake && (
                    <div className="m-2 p-3 rounded-xl bg-slate-900 border border-red-500/40 space-y-2">
                      <div className="flex justify-between items-start gap-2">
                        <span className="font-mono font-bold text-xs text-red-300 leading-snug">{selectedQuake.place}</span>
                        <button onClick={() => setSelectedQuake(null)} className="p-0.5 rounded hover:bg-slate-800 text-slate-400 shrink-0">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono">
                        <div className="bg-slate-950 p-2 rounded border border-slate-800 text-center">
                          <span className="text-slate-500 block">Magnitude</span>
                          <span className="text-red-300 font-black text-sm">M {selectedQuake.magnitude.toFixed(1)}</span>
                        </div>
                        <div className="bg-slate-950 p-2 rounded border border-slate-800 text-center">
                          <span className="text-slate-500 block">Depth</span>
                          <span className="text-amber-300 font-bold">{selectedQuake.depth} km</span>
                        </div>
                        <div className="bg-slate-950 p-2 rounded border border-slate-800 text-center">
                          <span className="text-slate-500 block">Coords</span>
                          <span className="text-slate-200 text-[9px]">{selectedQuake.lat.toFixed(2)}, {selectedQuake.lon.toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="text-[10px] font-mono text-slate-400 truncate">{new Date(selectedQuake.time).toLocaleString()}</div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            if (mode === 'wireframe') setView((v) => ({ ...v, rotLon: selectedQuake.lon, rotLat: selectedQuake.lat }));
                            else setTileCenter({ lat: selectedQuake.lat, lon: selectedQuake.lon, z: 8 });
                          }}
                          className="flex-1 px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-[10px] rounded border border-slate-700 flex items-center justify-center gap-1"
                        >
                          <Crosshair className="w-3 h-3 text-amber-400" /> Center
                        </button>
                        <a href={selectedQuake.link} target="_blank" rel="noopener noreferrer"
                          className="flex-1 px-2 py-1.5 bg-red-700 hover:bg-red-600 text-white font-mono text-[10px] font-bold rounded border border-red-600 flex items-center justify-center gap-1">
                          <ExternalLink className="w-3 h-3" /> USGS Detail
                        </a>
                      </div>
                    </div>
                  )}

                  {/* All quakes list */}
                  <div className="divide-y divide-slate-900">
                    {quakes.map((q) => (
                      <button
                        key={q.id}
                        onClick={() => {
                          setSelectedQuake(q);
                          if (mode === 'wireframe') setView((v) => ({ ...v, rotLon: q.lon, rotLat: q.lat }));
                          else setTileCenter({ lat: q.lat, lon: q.lon, z: 6 });
                        }}
                        className={`w-full text-left px-3 py-2.5 hover:bg-slate-900 transition flex items-start gap-2.5 ${selectedQuake?.id === q.id ? 'bg-slate-900' : ''}`}
                      >
                        <span className={`mt-0.5 shrink-0 w-5 h-5 rounded-full border-2 ${quakeMagColour(q.magnitude)}`} />
                        <div className="min-w-0">
                          <div className="font-mono font-bold text-xs text-slate-100 leading-snug truncate">{q.place}</div>
                          <div className="flex gap-2 mt-0.5 text-[10px] font-mono text-slate-400">
                            <span className="text-red-300 font-bold">M {q.magnitude.toFixed(1)}</span>
                            <span>{q.depth} km deep</span>
                            <span className="truncate">{q.lat.toFixed(2)}, {q.lon.toFixed(2)}</span>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </aside>
      </div>
    </div>
  );
};

// ─── Cleanroom lab checklist ──────────────────────────────────────────────────
const LabChecklist: React.FC<{
  mode: GlobeMode;
  feedMode: FeedMode;
  feedsCount: number;
  fetchedCount: number;
  liveCount: number;
  fallbackCount: number;
  offlineCount: number;
  loadingCount: number;
  errorCount: number;
  tileStats: { key: string; total: number; loaded: number; error: number };
  fetchLogs: string[];
  opmlError: string | null;
  selectedFeed: Feed | null;
  onExportJson: () => void;
  onExportCsv: () => void;
}> = ({
  mode,
  feedMode,
  feedsCount,
  fetchedCount,
  liveCount,
  fallbackCount,
  offlineCount,
  loadingCount,
  errorCount,
  tileStats,
  fetchLogs,
  opmlError,
  selectedFeed,
  onExportJson,
  onExportCsv,
}) => {
  const rows = [
    { code: 'UI-01', label: 'Collapsible feed/OPML side panel', pass: true, detail: 'Panel defaults closed so the globe gets priority.' },
    { code: 'GL-01', label: 'Interactive globe projection', pass: true, detail: `Current basemap: ${mode}` },
    { code: 'GL-02', label: 'USGS tile attempt path', pass: mode !== 'wireframe', detail: mode === 'wireframe' ? 'Switch to a USGS mode to request tiles.' : 'USGS tile URL template active.' },
    { code: 'GL-03', label: 'Tile diagnostics', pass: mode === 'wireframe' || tileStats.total > 0, detail: `${tileStats.loaded}/${tileStats.total} loaded, ${tileStats.error} failed.` },
    { code: 'RF-01', label: 'OPML geocoded feeds parsed', pass: feedsCount > 0 && !opmlError, detail: `${feedsCount} feed nodes loaded.` },
    { code: 'RF-02', label: 'RSS/Atom fetch layer', pass: fetchedCount > 0 || loadingCount > 0, detail: `${liveCount} live, ${fallbackCount} fallback, ${offlineCount} offline.` },
    { code: 'SR-01', label: 'Visible source reporting', pass: true, detail: `Data mode: ${feedMode}. Badges show live/fallback/offline.` },
    { code: 'SC-01', label: 'System console checklist', pass: true, detail: 'This panel records cleanroom diagnostics.' },
    { code: 'CR-01', label: 'Cleanroom no-fail fallback', pass: feedMode !== 'live' || errorCount === 0, detail: feedMode === 'live' ? `${errorCount} live-only errors.` : 'Fallback prevents proxy failure UI dead-ends.' },
    { code: 'SY-01', label: 'Selected target detail', pass: !!selectedFeed, detail: selectedFeed ? selectedFeed.title : 'Click a pin or feed row for detail.' },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950 p-3 space-y-3">
      <div className="rounded-xl border border-slate-800 bg-slate-900 p-3">
        <div className="font-mono text-xs font-bold text-amber-400 mb-1">CLEANROOM LAB STATUS</div>
        <div className="text-[10px] font-mono text-slate-400 leading-relaxed">
          UI/GL/WM/SR/SC/CR/SY/RF implementation checks. This is the user-facing proof panel for the prototype.
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-2">
          <span className="text-slate-500 block">Feeds</span>
          <span className="text-amber-300 font-bold">{feedsCount}</span>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-2">
          <span className="text-slate-500 block">Fetched</span>
          <span className="text-emerald-300 font-bold">{fetchedCount}</span>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-2">
          <span className="text-slate-500 block">Live</span>
          <span className="text-sky-300 font-bold">{liveCount}</span>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-2">
          <span className="text-slate-500 block">Fallback</span>
          <span className="text-amber-300 font-bold">{fallbackCount + offlineCount}</span>
        </div>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900 p-3 space-y-2">
        <div className="font-mono text-[10px] font-bold text-slate-300">C-EXPORT</div>
        <div className="flex gap-2">
          <button onClick={onExportJson} className="flex-1 px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 font-mono text-[10px] text-slate-200">Export JSON</button>
          <button onClick={onExportCsv} className="flex-1 px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 font-mono text-[10px] text-slate-200">Export CSV</button>
        </div>
      </div>

      <div className="space-y-2">
        {rows.map((row) => (
          <div key={row.code} className="rounded-xl border border-slate-800 bg-slate-900 p-2.5">
            <div className="flex items-start gap-2">
              {row.pass ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />}
              <div className="min-w-0">
                <div className="font-mono text-[10px] font-bold text-slate-100">
                  <span className="text-amber-400">{row.code}</span> {row.label}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">{row.detail}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-slate-800 bg-black p-2">
        <div className="font-mono text-[10px] font-bold text-amber-400 mb-2">RSS FETCH LOG</div>
        <div className="max-h-48 overflow-y-auto space-y-1">
          {fetchLogs.length === 0 ? (
            <div className="text-[10px] font-mono text-slate-500">No fetches yet. Use Sync Feeds.</div>
          ) : fetchLogs.map((line, i) => (
            <div key={i} className="text-[10px] font-mono text-emerald-300 border-b border-slate-900 pb-1">{line}</div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── Detail panel ─────────────────────────────────────────────────────────────
const FeedDetail: React.FC<{
  feed: Feed;
  state?: FeedFetchState;
  onClose: () => void;
  onRefresh: () => void;
  onCenter: () => void;
  onLoadTopo: () => void;
}> = ({ feed, state, onClose, onRefresh, onCenter, onLoadTopo }) => {
  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="px-3 py-2.5 border-b border-slate-800 flex items-center gap-2 bg-slate-950">
        <button onClick={onClose} className="p-1 rounded hover:bg-slate-800 text-slate-400">
          <X className="w-3.5 h-3.5" />
        </button>
        <span className="font-mono font-bold text-xs text-amber-400 truncate">{feed.title}</span>
        <button onClick={onRefresh} className="ml-auto p-1.5 rounded hover:bg-slate-800 text-emerald-400" title="Refresh">
          {state?.status === 'loading' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
        </button>
      </div>

      <div className="px-3 py-3 border-b border-slate-800 space-y-2 bg-slate-950">
        <div className="text-[10px] font-mono text-slate-400">{feed.category} · {feed.loc}</div>
        <div className="flex flex-wrap gap-1 text-[10px] font-mono">
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">lat {feed.lat.toFixed(3)}</span>
          <span className="px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">lon {feed.lon.toFixed(3)}</span>
          {state?.source && (
            <span className={`px-1.5 py-0.5 rounded border ${
              state.source === 'live'
                ? 'text-sky-300 border-sky-500/30 bg-sky-500/10'
                : state.source === 'fallback'
                  ? 'text-amber-300 border-amber-500/30 bg-amber-500/10'
                  : 'text-purple-300 border-purple-500/30 bg-purple-500/10'
            }`}>{state.source.toUpperCase()}</span>
          )}
        </div>
        {state?.warning && (
          <div className="text-[10px] font-mono text-amber-300 bg-amber-500/10 border border-amber-500/20 rounded p-1.5">
            {state.warning}
          </div>
        )}
        <div className="flex gap-1.5 pt-1">
          <button onClick={onCenter} className="flex-1 px-2 py-1.5 bg-slate-850 hover:bg-slate-850 text-slate-200 font-mono text-[10px] rounded border border-slate-750 flex items-center justify-center gap-1">
            <Crosshair className="w-3.5 h-3.5 text-amber-400" /> Center
          </button>
          <button onClick={onLoadTopo} className="flex-1 px-2 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-mono text-[10px] font-bold rounded border border-amber-500 flex items-center justify-center gap-1" title="Load USGS DOQQ-area orthorectified tile for this target">
            <Mountain className="w-3.5 h-3.5" /> Load Tile
          </button>
        </div>
        {feed.htmlUrl && (
          <a href={feed.htmlUrl} target="_blank" rel="noopener noreferrer" className="block text-[10px] font-mono text-sky-400 hover:underline truncate flex items-center gap-1 pt-1">
            <ExternalLink className="w-3 h-3" /> {feed.htmlUrl}
          </a>
        )}
      </div>

      <div className="flex-1 overflow-y-auto bg-slate-950">
        {state?.status === 'loading' && (
          <div className="p-4 flex items-center gap-2 text-slate-400 font-mono text-xs">
            <Loader2 className="w-4 h-4 animate-spin" /> Fetching live feed via CORS bridge…
          </div>
        )}
        {state?.status === 'ok' && state.items && state.items.length > 0 && (
          <ul className="divide-y divide-slate-900">
            {state.items.map((it, i) => (
              <li key={i} className="p-3 hover:bg-slate-900/50">
                <a
                  href={it.link || '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono font-bold text-xs text-slate-100 hover:text-amber-400 leading-snug block"
                >
                  {it.title}
                </a>
                {it.pubDate && (
                  <div className="text-[10px] font-mono text-slate-500 mt-0.5">{it.pubDate}</div>
                )}
                {it.description && (
                  <div className="text-[11px] text-slate-300 mt-1 leading-snug font-mono">{stripHtml(it.description, 180)}</div>
                )}
              </li>
            ))}
          </ul>
        )}
        {!state && (
          <div className="p-4 text-slate-500 font-mono text-xs">Click Refresh to fetch this feed.</div>
        )}
      </div>
    </div>
  );
};
