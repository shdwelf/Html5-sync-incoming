import React, { useState } from 'react';
import { Shield, Server, Lock, AlertTriangle, CheckCircle, Terminal } from 'lucide-react';

export const SecuritySuite: React.FC = () => {
  const [activeTool, setActiveTool] = useState<string>("cidr");

  // CIDR Calculator State
  const [cidrInput, setCidrInput] = useState<string>("192.168.10.0/24");
  
  // CSP / XSS Evaluator State
  const [cspInput, setCspInput] = useState<string>("<script>alert(document.cookie)</script>\n<img src=x onerror=alert(1)>");
  
  // Header Validator State
  const [headerInput, setHeaderInput] = useState<string>("HTTP/1.1 200 OK\nServer: nginx/1.14.0\nContent-Type: text/html\nConnection: keep-alive");

  // Entropy State
  const [entropyKey, setEntropyKey] = useState<string>("CorrectHorseBatteryStaple2026!");

  // CIDR Calculation Logic
  const calculateCidr = (cidr: string) => {
    try {
      const parts = cidr.split('/');
      if (parts.length !== 2) return { error: "Invalid format. Use IP/prefix (e.g. 192.168.1.0/24)" };
      const ip = parts[0];
      const prefix = parseInt(parts[1], 10);
      if (isNaN(prefix) || prefix < 0 || prefix > 32) return { error: "Prefix must be between 0 and 32." };

      const ipParts = ip.split('.').map(Number);
      if (ipParts.length !== 4 || ipParts.some(p => isNaN(p) || p < 0 || p > 255)) {
        return { error: "Invalid IPv4 address." };
      }

      const ipLong = ((ipParts[0] << 24) | (ipParts[1] << 16) | (ipParts[2] << 8) | ipParts[3]) >>> 0;
      const mask = prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0;
      const netLong = (ipLong & mask) >>> 0;
      const broadcastLong = (netLong | ~mask) >>> 0;

      const toIP = (num: number) => [
        (num >>> 24) & 255,
        (num >>> 16) & 255,
        (num >>> 8) & 255,
        num & 255
      ].join('.');

      const numHosts = prefix >= 31 ? 0 : Math.pow(2, 32 - prefix) - 2;

      return {
        ip,
        netmask: toIP(mask),
        network: toIP(netLong),
        broadcast: toIP(broadcastLong),
        hosts: numHosts,
        firstHost: prefix >= 31 ? "N/A" : toIP(netLong + 1),
        lastHost: prefix >= 31 ? "N/A" : toIP(broadcastLong - 1),
        error: null
      };
    } catch (e: any) {
      return { error: `Calculation failed: ${e.message}` };
    }
  };

  const cidrResult = calculateCidr(cidrInput);

  // CSP Analysis logic
  const analyzeCsp = (html: string) => {
    const issues = [];
    if (html.includes("<script>")) issues.push({ type: "Critical", desc: "Inline script tag detected. Vulnerable to simple XSS injection." });
    if (/on\w+\s*=/i.test(html)) issues.push({ type: "High", desc: "Inline event handler (e.g. onerror, onload) detected. Violates strict CSP." });
    if (html.includes("eval(")) issues.push({ type: "Critical", desc: "Use of eval() detected. Allows arbitrary string execution." });
    if (html.includes("document.cookie")) issues.push({ type: "Medium", desc: "Access to document.cookie detected. Consider setting HttpOnly flag on cookies." });
    if (issues.length === 0) issues.push({ type: "Good", desc: "No obvious inline XSS vectors detected in snippet." });
    return issues;
  };

  // Header verification logic
  const verifyHeaders = (headers: string) => {
    const lower = headers.toLowerCase();
    const checks = [
      { name: "Strict-Transport-Security (HSTS)", found: lower.includes("strict-transport-security"), desc: "Enforces secure HTTPS connections." },
      { name: "Content-Security-Policy (CSP)", found: lower.includes("content-security-policy"), desc: "Mitigates XSS and data injection attacks." },
      { name: "X-Frame-Options", found: lower.includes("x-frame-options"), desc: "Protects against Clickjacking attacks." },
      { name: "X-Content-Type-Options", found: lower.includes("x-content-type-options"), desc: "Prevents MIME-sniffing vulnerabilities." }
    ];
    return checks;
  };

  // Shannon Entropy calculation
  const calculateEntropy = (str: string) => {
    const len = str.length;
    if (len === 0) return 0;
    const freq: { [key: string]: number } = {};
    for (let i = 0; i < len; i++) {
      const char = str[i];
      freq[char] = (freq[char] || 0) + 1;
    }
    let entropy = 0;
    for (const char in freq) {
      const p = freq[char] / len;
      entropy -= p * Math.log2(p);
    }
    return entropy;
  };

  const currentEntropy = calculateEntropy(entropyKey);

  return (
    <div className="w-full flex flex-col space-y-6 p-6">
      {/* Header Bar */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-700 shadow-lg flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <Shield className="w-8 h-8 text-amber-500" />
          <div>
            <h2 className="text-xl font-mono font-extrabold text-amber-400">DEFENSIVE SECURITY & PENTEST VERIFICATION SUITE</h2>
            <p className="text-xs text-slate-400 font-mono">
              Working models for network subnets, strict Content Security Policy evaluation, and cryptographic entropy analysis.
            </p>
          </div>
        </div>
        <div className="hidden md:flex items-center space-x-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
          <Terminal className="w-4 h-4 text-emerald-500" />
          <span className="text-xs font-mono text-slate-300">Local Sandbox Mode: Live Active</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-700 pb-4">
        {[
          { id: "cidr", label: "IP Subnet / CIDR Calculator", icon: Server },
          { id: "csp", label: "XSS & CSP Vulnerability Evaluator", icon: AlertTriangle },
          { id: "headers", label: "Secure HTTP Headers Verifier", icon: CheckCircle },
          { id: "entropy", label: "Shannon Entropy Key Inspector", icon: Lock }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTool(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-mono text-xs font-bold transition-all ${activeTool === tab.id ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tool Workspaces */}
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 shadow-xl">
        {/* 1. CIDR Calculator */}
        {activeTool === "cidr" && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-lg font-mono font-extrabold text-amber-400">Live CIDR Network & Host Range Calculator</h3>
              <p className="text-slate-300 text-xs font-mono mt-1">
                Computes exact routing masks, broadcast addresses, and usable IP limits for defensive firewall rules.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <label className="block text-xs font-mono text-slate-400 mb-1">CIDR INPUT STRING</label>
                <input
                  type="text"
                  value={cidrInput}
                  onChange={(e) => setCidrInput(e.target.value)}
                  placeholder="192.168.1.0/24"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-500"
                />
                <p className="text-[11px] font-mono text-slate-400 leading-relaxed">
                  Enter any valid IPv4 address followed by a slash and a prefix number between 0 and 32.
                </p>
              </div>

              <div className="md:col-span-2 p-6 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <h4 className="font-mono font-bold text-slate-300 text-xs uppercase tracking-widest">CALCULATED SUBNET TELEMETRY</h4>
                {cidrResult.error ? (
                  <div className="p-4 bg-red-950/50 border border-red-800 rounded-lg text-red-200 font-mono text-sm">
                    {cidrResult.error}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <span className="text-slate-400 block">IP ADDRESS</span>
                      <span className="text-amber-300 font-bold text-sm">{cidrResult.ip}</span>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <span className="text-slate-400 block">SUBNET NETMASK</span>
                      <span className="text-amber-300 font-bold text-sm">{cidrResult.netmask}</span>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <span className="text-slate-400 block">NETWORK ADDRESS</span>
                      <span className="text-emerald-400 font-bold text-sm">{cidrResult.network}</span>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <span className="text-slate-400 block">BROADCAST ADDRESS</span>
                      <span className="text-blue-400 font-bold text-sm">{cidrResult.broadcast}</span>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <span className="text-slate-400 block">USABLE HOST RANGE</span>
                      <span className="text-slate-200 font-bold text-xs">{cidrResult.firstHost} - {cidrResult.lastHost}</span>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <span className="text-slate-400 block">TOTAL USABLE HOSTS</span>
                      <span className="text-purple-400 font-bold text-sm">{cidrResult.hosts?.toLocaleString()}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 2. CSP / XSS Evaluator */}
        {activeTool === "csp" && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-lg font-mono font-extrabold text-amber-400">Content Security Policy & XSS Evaluator</h3>
              <p className="text-slate-300 text-xs font-mono mt-1">
                Scans client-side DOM injection vectors and provides strict CSP header definitions for total defensive mitigation.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-2">TARGET HTML / JAVASCRIPT SNIPPET</label>
                <textarea
                  rows={8}
                  value={cspInput}
                  onChange={(e) => setCspInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-red-400 font-mono text-sm focus:outline-none focus:border-amber-500 shadow-inner"
                />
              </div>

              <div className="space-y-4">
                <label className="block text-xs font-mono text-slate-400 mb-2">VULNERABILITY REPORT & CSP REMEDIATION</label>
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 max-h-[260px] overflow-y-auto">
                  {analyzeCsp(cspInput).map((item, idx) => (
                    <div key={idx} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-start space-x-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold mt-0.5 ${
                        item.type === "Critical" ? "bg-red-600 text-white" :
                        item.type === "High" ? "bg-orange-500 text-slate-950" :
                        item.type === "Medium" ? "bg-yellow-500 text-slate-950" : "bg-emerald-600 text-white"
                      }`}>
                        {item.type}
                      </span>
                      <p className="text-xs font-mono text-slate-200 flex-1">{item.desc}</p>
                    </div>
                  ))}
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <span className="text-[11px] font-mono text-emerald-400 font-bold block">RECOMMENDED STRICT CSP HEADER:</span>
                  <div className="p-3 bg-black rounded-lg font-mono text-xs text-amber-300 select-all break-all">
                    Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'; frame-ancestors 'none';
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 3. HTTP Secure Headers Verifier */}
        {activeTool === "headers" && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-lg font-mono font-extrabold text-amber-400">Secure HTTP Response Headers Validator</h3>
              <p className="text-slate-300 text-xs font-mono mt-1">
                Audits HTTP headers for missing web security constraints and security compliance.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-2">PASTE RAW HTTP RESPONSE HEADERS</label>
                <textarea
                  rows={8}
                  value={headerInput}
                  onChange={(e) => setHeaderInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-emerald-400 font-mono text-sm focus:outline-none focus:border-amber-500 shadow-inner"
                />
              </div>

              <div className="space-y-3">
                <label className="block text-xs font-mono text-slate-400 mb-2">HEADER COMPLIANCE RESULTS</label>
                {verifyHeaders(headerInput).map((check, idx) => (
                  <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="font-mono font-bold text-slate-200 text-sm">{check.name}</h4>
                      <p className="text-xs text-slate-400 font-mono">{check.desc}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {check.found ? (
                        <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-mono text-xs rounded-full flex items-center space-x-1">
                          <span>Verified</span>
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-red-500/20 border border-red-500/30 text-red-400 font-mono text-xs rounded-full flex items-center space-x-1">
                          <span>Missing</span>
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 4. Shannon Entropy Key Inspector */}
        {activeTool === "entropy" && (
          <div className="space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-lg font-mono font-extrabold text-amber-400">Shannon Entropy Cryptographic Key Inspector</h3>
              <p className="text-slate-300 text-xs font-mono mt-1">
                Measures the unpredictability and information density of keys or passwords to evaluate resistance to brute-force decryption.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <label className="block text-xs font-mono text-slate-400 mb-1">TARGET KEY / PASSPHRASE</label>
                <input
                  type="text"
                  value={entropyKey}
                  onChange={(e) => setEntropyKey(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-amber-300 font-mono text-sm focus:outline-none focus:border-amber-500"
                />
                <div className="text-xs font-mono text-slate-400 space-y-2 pt-2 border-t border-slate-800">
                  <p>■ <span className="text-slate-200">Length:</span> {entropyKey.length} characters</p>
                  <p>■ <span className="text-slate-200">Formula:</span> H(X) = -Σ P(x_i) log₂ P(x_i)</p>
                  <p>■ <span className="text-slate-200">Target Benchmark:</span> &gt; 3.5 bits/char for high entropy</p>
                </div>
              </div>

              <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center space-y-6">
                <div>
                  <span className="text-xs font-mono text-slate-400 block mb-2 uppercase tracking-widest">CALCULATED SHANNON ENTROPY</span>
                  <div className="text-5xl font-mono font-extrabold text-amber-400 py-4 px-8 bg-black rounded-xl border border-amber-500/20 shadow-inner">
                    {currentEntropy.toFixed(3)} <span className="text-xl text-slate-400">bits/char</span>
                  </div>
                </div>

                <div className="w-full max-w-xs space-y-2">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Cryptographic Strength:</span>
                    <span className={currentEntropy > 3.5 ? 'text-emerald-400 font-bold' : 'text-yellow-400 font-bold'}>
                      {currentEntropy > 3.5 ? 'STRONG (High Entropy)' : 'WEAK / REPETITIVE'}
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${currentEntropy > 3.5 ? 'bg-emerald-500' : 'bg-yellow-500'}`}
                      style={{ width: `${Math.min(100, (currentEntropy / 5) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
