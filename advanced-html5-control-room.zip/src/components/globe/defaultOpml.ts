// Default OPML 2.0 — geocoded RSS subscriptions for the live globe.
// Each <outline> carries non-standard lat/lon/loc attributes used to plot pins.

export const DEFAULT_OPML = `<?xml version="1.0" encoding="UTF-8"?>
<opml version="2.0">
  <head>
    <title>Patent Office Global Feed Mesh</title>
    <dateCreated>${new Date().toUTCString()}</dateCreated>
    <ownerName>IETF Patent Office Cleanroom</ownerName>
  </head>
  <body>
    <outline text="World News" title="World News">
      <outline type="rss" text="BBC World" title="BBC World" xmlUrl="http://feeds.bbci.co.uk/news/world/rss.xml" htmlUrl="https://www.bbc.com/news/world" lat="51.5074" lon="-0.1278" loc="London, UK"/>
      <outline type="rss" text="NHK World" title="NHK World" xmlUrl="https://www3.nhk.or.jp/nhkworld/en/news/feeds/" htmlUrl="https://www3.nhk.or.jp" lat="35.6895" lon="139.6917" loc="Tokyo, JP"/>
      <outline type="rss" text="Al Jazeera English" title="Al Jazeera" xmlUrl="https://www.aljazeera.com/xml/rss/all.xml" htmlUrl="https://aljazeera.com" lat="25.2854" lon="51.5310" loc="Doha, QA"/>
      <outline type="rss" text="Deutsche Welle" title="DW English" xmlUrl="https://rss.dw.com/rdf/rss-en-world" htmlUrl="https://dw.com" lat="50.7374" lon="7.0982" loc="Bonn, DE"/>
      <outline type="rss" text="France 24" title="France 24" xmlUrl="https://www.france24.com/en/rss" htmlUrl="https://france24.com" lat="48.8566" lon="2.3522" loc="Paris, FR"/>
      <outline type="rss" text="ABC News AU" title="ABC News Australia" xmlUrl="https://www.abc.net.au/news/feed/51120/rss.xml" htmlUrl="https://abc.net.au/news" lat="-33.8688" lon="151.2093" loc="Sydney, AU"/>
      <outline type="rss" text="CBC News" title="CBC Top Stories" xmlUrl="https://www.cbc.ca/cmlink/rss-topstories" htmlUrl="https://cbc.ca" lat="43.6532" lon="-79.3832" loc="Toronto, CA"/>
      <outline type="rss" text="The Guardian World" title="Guardian World" xmlUrl="https://www.theguardian.com/world/rss" htmlUrl="https://theguardian.com" lat="51.5350" lon="-0.1200" loc="London, UK"/>
      <outline type="rss" text="Times of India" title="Times of India" xmlUrl="https://timesofindia.indiatimes.com/rssfeedstopstories.cms" htmlUrl="https://timesofindia.com" lat="19.0760" lon="72.8777" loc="Mumbai, IN"/>
      <outline type="rss" text="Xinhua World" title="Xinhua" xmlUrl="https://english.news.cn/rss/world.xml" htmlUrl="https://english.news.cn" lat="39.9042" lon="116.4074" loc="Beijing, CN"/>
    </outline>
    <outline text="Science &amp; Space" title="Science &amp; Space">
      <outline type="rss" text="NASA Breaking" title="NASA News" xmlUrl="https://www.nasa.gov/news-release/feed/" htmlUrl="https://nasa.gov" lat="38.8830" lon="-77.0163" loc="Washington DC, US"/>
      <outline type="rss" text="USGS Significant Quakes (week)" title="USGS Earthquakes" xmlUrl="https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_week.atom" htmlUrl="https://earthquake.usgs.gov" lat="37.4419" lon="-122.1430" loc="Menlo Park, CA"/>
      <outline type="rss" text="ESA Space News" title="ESA" xmlUrl="https://www.esa.int/rssfeed/Our_Activities/Space_News" htmlUrl="https://esa.int" lat="48.8326" lon="2.2870" loc="Paris, FR (ESA HQ)"/>
      <outline type="rss" text="Phys.org" title="Phys.org" xmlUrl="https://phys.org/rss-feed/" htmlUrl="https://phys.org" lat="40.4406" lon="-79.9959" loc="Pittsburgh, US"/>
    </outline>
    <outline text="Tech" title="Tech">
      <outline type="rss" text="Hacker News" title="Hacker News" xmlUrl="https://news.ycombinator.com/rss" htmlUrl="https://news.ycombinator.com" lat="37.7749" lon="-122.4194" loc="San Francisco, US"/>
      <outline type="rss" text="The Register" title="The Register" xmlUrl="https://www.theregister.com/headlines.atom" htmlUrl="https://theregister.com" lat="51.5074" lon="-0.1278" loc="London, UK"/>
      <outline type="rss" text="Slashdot" title="Slashdot" xmlUrl="http://rss.slashdot.org/Slashdot/slashdotMain" htmlUrl="https://slashdot.org" lat="40.7128" lon="-74.0060" loc="New York, US"/>
      <outline type="rss" text="Ars Technica" title="Ars Technica" xmlUrl="https://feeds.arstechnica.com/arstechnica/index" htmlUrl="https://arstechnica.com" lat="41.8781" lon="-87.6298" loc="Chicago, US"/>
    </outline>
    <outline text="Standards" title="Standards">
      <outline type="rss" text="RFC Editor" title="IETF RFC Index" xmlUrl="https://www.rfc-editor.org/rfcrss.xml" htmlUrl="https://www.rfc-editor.org" lat="46.2044" lon="6.1432" loc="Geneva, CH"/>
      <outline type="rss" text="W3C News" title="W3C News" xmlUrl="https://www.w3.org/blog/news/feed" htmlUrl="https://www.w3.org" lat="42.3601" lon="-71.0942" loc="Cambridge, MA (MIT)"/>
    </outline>
  </body>
</opml>`;
