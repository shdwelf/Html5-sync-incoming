// Real OPML parser + live RSS/Atom fetcher via AllOrigins CORS bridge,
// with robust high-fidelity offline fallbacks to guarantee a working prototype.

export interface Feed {
  id: string;
  title: string;
  xmlUrl: string;
  htmlUrl: string;
  lat: number;
  lon: number;
  loc: string;
  category: string;
}

export interface FeedItem {
  title: string;
  link: string;
  pubDate: string;
  description: string;
}

export interface FeedFetchState {
  status: 'idle' | 'loading' | 'ok' | 'error';
  items?: FeedItem[];
  error?: string;
  ts?: number;
  source?: 'live' | 'fallback' | 'offline';
  warning?: string;
}

export type FeedMode = 'hybrid' | 'live' | 'offline';

export interface FeedFetchResult {
  items: FeedItem[];
  source: 'live' | 'fallback' | 'offline';
  warning?: string;
}

/** Parse an OPML 2.0 string. Recognises non-standard lat/lon/loc attributes. */
export function parseOpml(opmlText: string): Feed[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(opmlText, 'application/xml');
  if (doc.querySelector('parsererror')) {
    throw new Error('Invalid OPML XML');
  }

  const feeds: Feed[] = [];
  const body = doc.querySelector('body');
  if (!body) return feeds;

  const walk = (node: Element, category: string) => {
    const children = Array.from(node.children).filter(
      (c) => c.tagName.toLowerCase() === 'outline'
    );
    for (const outline of children) {
      const xmlUrl = outline.getAttribute('xmlUrl');
      if (xmlUrl) {
        const lat = parseFloat(outline.getAttribute('lat') || 'NaN');
        const lon = parseFloat(outline.getAttribute('lon') || 'NaN');
        if (Number.isFinite(lat) && Number.isFinite(lon)) {
          feeds.push({
            id: `feed-${feeds.length}-${xmlUrl.replace(/\W+/g, '').slice(0, 24)}`,
            title:
              outline.getAttribute('title') ||
              outline.getAttribute('text') ||
              xmlUrl,
            xmlUrl,
            htmlUrl: outline.getAttribute('htmlUrl') || '',
            lat,
            lon,
            loc: outline.getAttribute('loc') || `${lat.toFixed(2)}, ${lon.toFixed(2)}`,
            category,
          });
        }
      } else {
        // group node — recurse with its text as category
        const groupCat =
          outline.getAttribute('text') ||
          outline.getAttribute('title') ||
          category;
        walk(outline, groupCat);
      }
    }
  };

  walk(body, 'Uncategorised');
  return feeds;
}

/** Rich offline database of high-fidelity news/weather/standards updates as fallback. */
const OFFLINE_FALLBACK_BANK: Record<string, FeedItem[]> = {
  bbc: [
    { title: "IETF Releases New Protocol Standards for WebRTC TUN/TAP Bridges", link: "https://www.bbc.com/news/technology", pubDate: new Date().toUTCString(), description: "A cleanroom lab test of the new WebRTC encapsulation layers reports successfully routing TCP packages over Slow Scan TV (SSTV) fallbacks with automatic slant calibration." },
    { title: "Global Mesh Network Upgrades Completed in Geneva", link: "https://www.bbc.com/news/technology", pubDate: new Date().toUTCString(), description: "Strategic routers across Switzerland deploy sharded eth144 token contracts to archive structural documents on the Ethereum testnet." }
  ],
  nhk: [
    { title: "Tokyo Laboratory successfully decodes high-frequency AFSK subcarriers", link: "https://www3.nhk.or.jp", pubDate: new Date().toUTCString(), description: "Engineers demonstrate zero-packet loss over simulated peer-to-peer data channels utilizing active orthorectified USGS topographic overlays." }
  ],
  aljazeera: [
    { title: "Doha tech cluster publishes draft specifications for Banano rare artifacts", link: "https://aljazeera.com", pubDate: new Date().toUTCString(), description: "An interactive browser-based mnemonic haiku generator enables offline cryptographic key derivation for potassium-dense network nodes." }
  ],
  dw: [
    { title: "Bonn digital summits report 99.9% uptime across active RSS mesh relays", link: "https://dw.com", pubDate: new Date().toUTCString(), description: "Federated standards working groups adopt OPML 2.0 subscription schemas to coordinate geocoded sensor grids globally." }
  ],
  france24: [
    { title: "Paris space telemetry center syncs orbiters using MMSSTV WAV calibration", link: "https://france24.com", pubDate: new Date().toUTCString(), description: "Automatic skew and slant alignment parameters successfully isolate satellite clock drift under severe electromagnetic weather conditions." }
  ],
  abc: [
    { title: "Sydney developers release Wave Exchange limit orderbooks", link: "https://abc.net.au", pubDate: new Date().toUTCString(), description: "A high-frequency client-side matching engine supports instantaneous swaps between Lambocoin, Miccoin, WAX, and Solana tokens." }
  ],
  cbc: [
    { title: "Toronto cleanroom labs successfully boot custom eth144 multi-token assets", link: "https://cbc.ca", pubDate: new Date().toUTCString(), description: "An exotic ERC-1155 decentralized registry implements sharded dynamic URIs for secure offline metadata storage." }
  ],
  guardian: [
    { title: "Guardian Tech: The history of IETF RFC 1149 avian carrier datagrams", link: "https://theguardian.com", pubDate: new Date().toUTCString(), description: "A nostalgic look at the highly robust carrier pigeon internet protocol and its modern Web3 smart contract adaptations." }
  ],
  timesofindia: [
    { title: "Mumbai engineering colleges deploy local Shannon entropy validators", link: "https://timesofindia.com", pubDate: new Date().toUTCString(), description: "Students build interactive password complexity estimators to measure brute-force decryption times using information theory formulas." }
  ],
  xinhua: [
    { title: "Beijing working group submits draft for zero-knowledge location masking", link: "https://english.news.cn", pubDate: new Date().toUTCString(), description: "A new gopher proxy protocol enables secure weather zip queries over TOR networks with maximum coordinates protection." }
  ],
  nasa: [
    { title: "NASA space communications network tests WebRTC tunnel over lunar relay", link: "https://nasa.gov", pubDate: new Date().toUTCString(), description: "Deep space simulation reports successful transmission of high-entropy cryptographic keys utilizing SSTV fallback acoustic modems." }
  ],
  usgs: [
    { title: "USGS Significant Earthquake Alert: Magnitude 5.4 detected in California", link: "https://earthquake.usgs.gov", pubDate: new Date().toUTCString(), description: "Seismic stations utilize geocoded RSS feeds to transmit real-time telemetry updates. Orthorectified DOQQ topo maps updated." }
  ],
  esa: [
    { title: "ESA satellites map global atmospheric noise entropy", link: "https://esa.int", pubDate: new Date().toUTCString(), description: "Spectrogram analysis reveals high-density cosmic radiation fluctuations. MMSSTV calibration settings recommended for ham radio receivers." }
  ],
  phys: [
    { title: "Physics Lab: Measuring Shannon entropy of quantum keys", link: "https://phys.org", pubDate: new Date().toUTCString(), description: "Researchers construct multi-dimensional cryptographic lattices to evaluate structural resistance against quantum-computing decryptors." }
  ],
  hacker: [
    { title: "Show HN: Interactive Patent Office Bookshelf with working IETF RFC modems", link: "https://news.ycombinator.com", pubDate: new Date().toUTCString(), description: "A highly advanced desktop replacement shell featuring draggable windows, custom eth144 Web3 storage, and real-time mesh geocoding." }
  ],
  register: [
    { title: "The Register: IT admin pulled a loose book and fell into a secret patent control room", link: "https://theregister.com", pubDate: new Date().toUTCString(), description: "Underneath the library floorboards, a custom WebRTC TUN/TAP bridge was found routing simulated Lambocoin orders over Slow Scan TV." }
  ],
  slashdot: [
    { title: "Slashdot: W3C and IETF coordinate on strict Content Security Policies", link: "https://slashdot.org", pubDate: new Date().toUTCString(), description: "A new draft aims to eliminate inline script event handlers by enforcing zero-knowledge SHA-256 header validation." }
  ],
  arstechnica: [
    { title: "Ars Technica: How to print high-entropy cold-storage paper wallets safely", link: "https://arstechnica.com", pubDate: new Date().toUTCString(), description: "A step-by-step guide to generating private spend keys offline using random seed words and verification stamps." }
  ],
  rfc: [
    { title: "RFC Editor: New RFC index additions for decentralized mesh networks", link: "https://www.rfc-editor.org", pubDate: new Date().toUTCString(), description: "Standardized specifications for peer-to-peer data channels and automatic slant calibration formats published." }
  ],
  w3c: [
    { title: "W3C News: HTML5 self-replicating quine standards draft released", link: "https://www.w3.org", pubDate: new Date().toUTCString(), description: "Web browsers gain native support for taking DOM snapshots and compiling standalone PWA installation files automatically." }
  ]
};

/** Get offline fallback items for a specific feed based on keywords in URL/Title. */
export function getOfflineFallback(url: string, title: string): FeedItem[] {
  const cleanUrl = url.toLowerCase();
  const cleanTitle = title.toLowerCase();

  for (const [key, items] of Object.entries(OFFLINE_FALLBACK_BANK)) {
    if (cleanUrl.includes(key) || cleanTitle.includes(key)) {
      return items;
    }
  }

  // Generic fallback if no keyword match
  return [
    {
      title: `Live Swarm Update: ${title} relay synced`,
      link: "https://www.ietf.org",
      pubDate: new Date().toUTCString(),
      description: `Active geocoded mesh node at ${url} reports nominal telemetry. Standard cleanroom parameters verified.`
    }
  ];
}

/** Pick the first available CORS proxy and return raw RSS text. */
async function fetchViaProxy(url: string, signal?: AbortSignal): Promise<string> {
  const proxies = [
    (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
    (u: string) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
  ];

  let lastError: any = null;
  for (const build of proxies) {
    try {
      const res = await fetch(build(url), { signal });
      if (res.ok) {
        const text = await res.text();
        if (text && text.length > 32) return text;
      }
      lastError = new Error(`HTTP ${res.status}`);
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError ?? new Error('All CORS proxies failed');
}

/** Parse RSS 2.0 or Atom 1.0 into a normalised list of items. */
export function parseFeedXml(xmlText: string): FeedItem[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'application/xml');
  if (doc.querySelector('parsererror')) return [];

  const items: FeedItem[] = [];

  // RSS 2.0
  const rssItems = doc.querySelectorAll('rss > channel > item, channel > item, item');
  rssItems.forEach((item) => {
    const title = item.querySelector('title')?.textContent?.trim() || '(untitled)';
    const link =
      item.querySelector('link')?.textContent?.trim() ||
      item.querySelector('guid')?.textContent?.trim() ||
      '';
    const pubDate =
      item.querySelector('pubDate')?.textContent?.trim() ||
      item.querySelector('date')?.textContent?.trim() ||
      '';
    const description =
      item.querySelector('description')?.textContent?.trim() ||
      item.querySelector('summary')?.textContent?.trim() ||
      '';
    items.push({ title, link, pubDate, description });
  });

  if (items.length > 0) return items.slice(0, 25);

  // Atom 1.0
  const atomEntries = doc.querySelectorAll('feed > entry, entry');
  atomEntries.forEach((entry) => {
    const title = entry.querySelector('title')?.textContent?.trim() || '(untitled)';
    const linkEl = entry.querySelector('link');
    const link =
      linkEl?.getAttribute('href') || linkEl?.textContent?.trim() || '';
    const pubDate =
      entry.querySelector('updated')?.textContent?.trim() ||
      entry.querySelector('published')?.textContent?.trim() ||
      '';
    const description =
      entry.querySelector('summary')?.textContent?.trim() ||
      entry.querySelector('content')?.textContent?.trim() ||
      '';
    items.push({ title, link, pubDate, description });
  });

  return items.slice(0, 25);
}

export async function fetchFeedDetailed(
  url: string,
  title: string,
  signal?: AbortSignal,
  mode: FeedMode = 'hybrid'
): Promise<FeedFetchResult> {
  if (mode === 'offline') {
    return { items: getOfflineFallback(url, title), source: 'offline' };
  }

  try {
    const xml = await fetchViaProxy(url, signal);
    const items = parseFeedXml(xml);
    if (items.length > 0) return { items, source: 'live' };
  } catch (e) {
    console.warn(`CORS Proxy failed for ${url}. Engaging offline fallback engine...`);
    if (mode === 'live') {
      throw e;
    }
    return {
      items: getOfflineFallback(url, title),
      source: 'fallback',
      warning: 'Public RSS proxy unavailable; using cleanroom fallback feed.',
    };
  }

  if (mode === 'live') {
    throw new Error('No RSS/Atom items parsed from live feed.');
  }

  return {
    items: getOfflineFallback(url, title),
    source: 'fallback',
    warning: 'Live feed returned no parseable items; using cleanroom fallback feed.',
  };
}

export async function fetchFeed(
  url: string,
  title: string,
  signal?: AbortSignal,
  mode: FeedMode = 'hybrid'
): Promise<FeedItem[]> {
  const result = await fetchFeedDetailed(url, title, signal, mode);
  return result.items;
}

/** Strip HTML tags so description previews stay safe & short. */
export function stripHtml(s: string, max = 240): string {
  const cleaned = s.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  return cleaned.length > max ? cleaned.slice(0, max).trimEnd() + '…' : cleaned;
}

// ─── Earthquake layer ─────────────────────────────────────────────────────────

export interface QuakeEvent {
  id: string;
  title: string;
  link: string;
  time: string;
  lat: number;
  lon: number;
  depth: number;
  magnitude: number;
  place: string;
}

/**
 * Parse a USGS Earthquake Atom feed.
 * Each <entry> carries a <georss:point> and a <title> like
 * "M 4.5 - 40km SSW of Somewhere, Country"
 */
export function parseEarthquakeAtom(xmlText: string): QuakeEvent[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'application/xml');
  if (doc.querySelector('parsererror')) return [];

  const quakes: QuakeEvent[] = [];
  const ns = 'http://www.georss.org/georss';

  doc.querySelectorAll('entry').forEach((entry, idx) => {
    const title = entry.querySelector('title')?.textContent?.trim() || '';
    const link = entry.querySelector('link')?.getAttribute('href') || '';
    const time =
      entry.querySelector('updated')?.textContent?.trim() ||
      entry.querySelector('published')?.textContent?.trim() || '';

    // <georss:point>lat lon</georss:point>
    let geoText: string | undefined = entry.getElementsByTagNameNS(ns, 'point')[0]?.textContent?.trim();
    if (!geoText) geoText = entry.querySelector('point')?.textContent?.trim() || undefined;
    if (!geoText) return;

    const [rawLat, rawLon] = geoText.split(/\s+/).map(Number);
    if (!Number.isFinite(rawLat) || !Number.isFinite(rawLon)) return;

    const summary = entry.querySelector('summary')?.textContent || '';
    const depthMatch = summary.match(/Depth:\s*([\d.]+)\s*km/i) ||
      title.match(/depth:\s*([\d.]+)/i);
    const depth = depthMatch ? parseFloat(depthMatch[1]) : 0;

    const magMatch = title.match(/M\s*([\d.]+)/i);
    const magnitude = magMatch ? parseFloat(magMatch[1]) : 0;

    const place = title.includes(' - ')
      ? title.split(' - ').slice(1).join(' - ')
      : title;

    quakes.push({
      id: `quake-${idx}-${rawLat.toFixed(3)}-${rawLon.toFixed(3)}`,
      title, link, time,
      lat: rawLat,
      lon: rawLon,
      depth,
      magnitude,
      place,
    });
  });

  return quakes;
}

const DEMO_QUAKES: QuakeEvent[] = [
  { id: 'dq1', title: 'M 6.2 - 45km NNE of Kathmandu, Nepal',        link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat: 28.21, lon:  85.37, depth: 18, magnitude: 6.2, place: '45km NNE of Kathmandu, Nepal' },
  { id: 'dq2', title: 'M 5.8 - 22km ESE of Honshu, Japan',            link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat: 37.42, lon: 142.91, depth: 35, magnitude: 5.8, place: '22km ESE of Honshu, Japan' },
  { id: 'dq3', title: 'M 5.4 - 12km SE of San José, Costa Rica',       link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat:  9.88, lon: -84.01, depth: 22, magnitude: 5.4, place: '12km SE of San José, Costa Rica' },
  { id: 'dq4', title: 'M 7.1 - 180km W of Anchorage, Alaska',          link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat: 61.08, lon:-152.74, depth: 42, magnitude: 7.1, place: '180km W of Anchorage, Alaska' },
  { id: 'dq5', title: 'M 5.1 - 60km NW of Thessaloniki, Greece',       link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat: 40.93, lon:  22.46, depth: 10, magnitude: 5.1, place: '60km NW of Thessaloniki, Greece' },
  { id: 'dq6', title: 'M 5.9 - 33km SW of Palu, Indonesia',            link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat: -0.98, lon: 119.51, depth: 28, magnitude: 5.9, place: '33km SW of Palu, Indonesia' },
  { id: 'dq7', title: 'M 4.8 - 8km NNW of Calexico, CA',               link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat: 32.70, lon:-115.52, depth: 12, magnitude: 4.8, place: '8km NNW of Calexico, CA' },
  { id: 'dq8', title: 'M 6.0 - 95km S of Kermadec Islands, NZ',        link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat:-30.88, lon:-178.11, depth: 60, magnitude: 6.0, place: '95km S of Kermadec Islands' },
  { id: 'dq9', title: 'M 5.3 - 48km NW of Valparaíso, Chile',          link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat:-32.62, lon: -71.59, depth: 30, magnitude: 5.3, place: '48km NW of Valparaíso, Chile' },
  { id: 'dq10', title: 'M 6.4 - 110km NE of Petropavlovsk, Russia',    link: 'https://earthquake.usgs.gov', time: new Date().toISOString(), lat: 53.72, lon: 159.41, depth: 55, magnitude: 6.4, place: '110km NE of Petropavlovsk, Russia' },
];

export async function fetchEarthquakes(signal?: AbortSignal): Promise<{ events: QuakeEvent[]; source: 'live' | 'demo' }> {
  const url = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_week.atom';
  try {
    const xml = await fetchViaProxy(url, signal);
    const events = parseEarthquakeAtom(xml);
    if (events.length > 0) return { events, source: 'live' };
  } catch {
    // fall through to demo
  }
  return { events: DEMO_QUAKES, source: 'demo' };
}
